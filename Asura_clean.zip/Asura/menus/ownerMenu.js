const config = require("../config");
const { developerButtonBlock, photoBlock, footerBlock } = require("./broken");

function ownerMenuBlocks() {
  return [
    developerButtonBlock(),
    { type: "heading", text: "A S U R A 𖤝︎ THE FIFTH INVITATION", size: 4 },
    photoBlock(),

    {
      type: "details",
      summary: "[🍃]-  𝐎𝐖𝐍𝐄𝐑 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 ",
      is_open: true,
      blocks: [
        {
          type: "table",
          cells: [
            [{ text: "Command", is_header: true }, { text: "Job", is_header: true }],
            [{ text: "/addprem" }, { text: "grant premium access" }],
            [{ text: "/delprem" }, { text: "remove premium access" }],
            [{ text: "/admin" }, { text: "add a new admin" }],
            [{ text: "/deladmin" }, { text: "remove an admin" }],
          ],
        },
      ],
    },

    {
      type: "buttons",
      buttons: [
        { text: "📢 Broadcast ", callback_data: "broadcast", style: "danger" },
        { text: "🔖 ListPrem", callback_data: "list_premium", style: "danger" },
      ],
    },
    {
      type: "buttons",
      buttons: [{ text: "🪶 Back", callback_data: "menu_main", style: "success" }],
    },
    footerBlock(),
  ];
}

module.exports = { ownerMenuBlocks };