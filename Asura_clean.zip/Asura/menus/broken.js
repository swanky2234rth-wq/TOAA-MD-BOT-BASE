


const config = require("../config");
function developerButtonBlock() {
  return {
    type: "buttons",
    buttons: [{ text: " 𝕮𝖔𝖓𝖙𝖆𝖈𝖙 𝕯𝖊𝖛𝖊𝖑𝖔𝖕𝖊𝖗", url: config.DEVELOPER_URL, style: "primary" }],
  };
}

function photoBlock() {
  return {
    type: "photo",
    photo: { type: "photo", media: config.MAIN_PHOTO_URL },
    caption: { text: config.MENU_CAPTION },
  };
}

// Footer shown at the bottom of every menu.
function footerBlock() {
  return { type: "footer", text: config.FOOTER_TEXT };
}

module.exports = { developerButtonBlock, photoBlock, footerBlock };
