const config = require("../config");
const { developerButtonBlock, photoBlock, footerBlock } = require("./broken");

function userMenuBlocks() {
  return [
    developerButtonBlock(),
    { type: "heading", text: "A S U R A 𖤝︎ THE FIFTH INVITATION", size: 4 },
    photoBlock(),

    {
      type: "details",
      summary: "[🍃]-  𝐔𝐒𝐄𝐑 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 ",
      is_open: true,
      blocks: [
        {
          type: "table",
          cells: [
            [{ text: "Command", is_header: true }, { text: "Job", is_header: true }],
            [{ text: "/pair" }, { text: "create Whatsapp session" }],
            [{ text: "/delpair" }, { text: "remove WhatsApp sessions" }],
            [{ text: "/mysat" }, { text: "check your account status" }],
            [{ text: "/bancheck" }, { text: "check if a number is banned" }],
          ],
        },
      ],
    },

    {
      type: "buttons",
      buttons: [
        { text: "👾 Mysessions", callback_data: "my_sessions", style: "danger" },
        { text: "🎠 TqTo", callback_data: "accolades", style: "danger" },
      ],
    },
    {
      type: "buttons",
      buttons: [{ text: "🪶 Back", callback_data: "menu_main", style: "success" }],
    },
    footerBlock(),
  ];
}

module.exports = { userMenuBlocks };