const { developerButtonBlock, photoBlock, footerBlock } = require("./broken");

function accoladesMenuBlocks() {
  return [
    developerButtonBlock(),
    { type: "heading", text: "🍃 A S U R A  ACKNOWLEDGEMENT", size: 4 },
    photoBlock(),

    {
      type: "details",
      summary: "[🍃]-  𝐒𝐏𝐄𝐂𝐈𝐀𝐋 𝐓𝐇𝐀𝐍𝐊𝐒 ",
      is_open: true,
      blocks: [
        {
          type: "table",
          cells: [
            [{ text: "Name", is_header: true }, { text: "Role", is_header: true }],
            [{ text: "ғᴀᴛᴇᴅ 〆 デミー 𓆸" }, { text: "support" }],
            [{ text: "ғᴀᴛᴇᴅ 〆 ウェア 𓆸" }, { text: "support" }],
            [{ text: "ғᴀᴛᴇᴅ 〆 ケンツキ 𓆸" }, { text: "support" }],
            [{ text: "イエス𓆸" }, { text: "creator" }],
          ],
        },
      ],
    },
    {
      type: "buttons",
      buttons: [
        { text: "Demmy ", url: "https://t.me/FE5UY", style: "success" },
        { text: "Weaver", url: "https://t.me/weaverisfated", style: "success" },
      ],
    },
    {
      type: "buttons",
      buttons: [
        { text: "Kentuski", url: "https://t.me/kenzki_01", style: "danger" },
        { text: "イエス𓆸", url: "https://t.me/Broken_symptoms", style: "danger" },
      ],
    },
    {
      type: "buttons",
      buttons: [{ text: "🪶 Back", callback_data: "user_menu", style: "success" }],
    },
    footerBlock(),
  ];
}

module.exports = { accoladesMenuBlocks };