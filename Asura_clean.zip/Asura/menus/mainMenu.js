const config = require("../config");
const { developerButtonBlock, photoBlock, footerBlock } = require("./broken");

function mainMenuBlocks() {
  return [
    developerButtonBlock(),
    { type: "heading", text: "A S U R A 𖤝︎ THE FIFTH INVITATION", size: 4 },
    photoBlock(),

    // foldable "Info Bot" section
    {
      type: "details",
      summary: "[🍃]-  𝐁𝐎𝐓 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ",
      is_open: true,
      blocks: [
        {
          type: "table",
          cells: [
            [{ text: " Creator", is_header: true }, { text: config.OWNER_NAME }],
            [{ text: " Status", is_header: true }, { text: "Active" }],
            [{ text: " Version", is_header: true }, { text: "Five" }],
            [{ text: " Bot type", is_header: true }, { text: "Java sc" }],
          ],
        },
      ],
    },

    {
      type: "buttons",
      buttons: [
        { text: "‼️ Owner Menu", callback_data: "owner_menu", style: "danger" },
        { text: "🫯 User Menu", callback_data: "user_menu", style: "danger" },
      ],
    },
    {
      type: "buttons",
      buttons: [{ text: " 𝕵𝖔𝖎𝖓 𝕭𝖗𝖔𝖐𝖊𝖓'𝖘 𝖘𝖍𝖗𝖎𝖓𝖊 𝖈𝖍𝖆𝖓𝖓𝖊𝖑 ", url: config.CHANNEL_URL, style: "primary" }],
    },
    footerBlock(),
  ];
}

module.exports = { mainMenuBlocks };
