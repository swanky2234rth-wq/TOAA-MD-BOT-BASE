// Asura — WhatsApp command selector, triggered by menu / .menu / /menu / ?menu / !menu.

// Top-level categories.
const commands = [
    { id: "android", label: "•⋅⤿ Android", value: "android" },
    { id: "iphone", label: "•⋅⤿ IPhone", value: "iphone" },
    { id: "group_chat", label: "•⋅⤿ GroupChat", value: "group_chat" },
    { id: "utilities", label: "•⋅⤿ Utilities", value: "utilities" },
    { id: "legends", label: "•⋅⤿ Legends", value: "legends" },
    { id: "owner", label: "•⋅⤿ Owner", value: "owner" },
];

// Sub-menu commands
const subMenus = {
    android: [
        { id: "fc", label: "•⋅⤿Forclose", value: "fc" },
        { id: "dly", label: "•⋅⤿ Delay_Invis", value: "dly" },
        { id: "frzz", label: "•⋅⤿ Freeze_Invis", value: "frzz" },
        { id: "blnk", label: "•⋅⤿ Blank_Andro", value: "blnk" },
    ],
    iphone: [
        { id: "fcios", label: "•⋅⤿ Crash_ip", value: "fcios" },
        { id: "dlyios", label: "•⋅⤿ Delay_ip", value: "dlyios" },
        { id: "frzzios", label: "•⋅⤿ Freeze_ip", value: "frzzios" },
        { id: "blnkios", label: "•⋅⤿ Blank_ip", value: "blnkios" },
    ],
    group_chat: [
        { id: "axgc", label: "•⋅⤿ Crash_gc", value: "axgc" },
        { id: "dxgc", label: "•⋅⤿ Delay_gc", value: "dxgc" },
        { id: "tag", label: "•⋅⤿ Tagall", value: "tag" },
        { id: "kall", label: "•⋅⤿ Kick_All", value: "kall" },
    ],
    utilities: [
        { id: "p", label: "•⋅⤿ Ping", value: "p" },
        { id: "s", label: "•⋅⤿ Sticker", value: "s" },
        { id: "vv", label: "•⋅⤿ Reveal", value: "vv" },
        { id: "gcid", label: "•⋅⤿ Group_id", value: "gcid" },
        { id: "dvic", label: "•⋅⤿ Device", value: "dvic" },
    ],
    legends: [
        { id: "brk", label: "•⋅⤿ Broken - owner", value: "brk" },
        { id: "dmy", label: "•⋅⤿ Demmy - support", value: "dmy" },
        { id: "wvr", label: "•⋅⤿ Weaver - support", value: "wvr" },
        { id: "knn", label: "•⋅⤿ Kentuski - support", value: "knn" },
        { id: "Nul", label: "•⋅⤿ Nuell - support", value: "Nul" },
        { id: "Z", label: "•⋅⤿ Zed - support", value: "Z" },
    ],
};

const fs = require("fs");
const path = require("path");
const { prepareWAMessageMedia } = require("@whiskeysockets/baileys");
// Every sub-command flattened into one list, for easy lookup by value.
const allSubCommands = Object.values(subMenus).flat();

const BANNER_PATH = path.join(__dirname, "media", "Abanner.jpg");

/** Uploads the banner image for use as an interactiveMessage header. Never throws — a
 *  missing/broken banner just means the card sends without one, instead of not sending. */
async function buildHeader(sock) {
    try {
        const buffer = fs.readFileSync(BANNER_PATH);
        const media = await prepareWAMessageMedia({ image: buffer }, { upload: sock.waUploadToServer });
        return { ...media, hasMediaAttachment: true };
    } catch (err) {
        return undefined;
    }
}

const ownerDetails =
    "OWNER DETAILS\n\n" +
    "Name: Broken\n" +
    "Tg: @Broken_symptoms\n" +
    "Wa: 2347049017873\n" +
    "Ch: @Brokensshrine";

/** Builds a single nativeFlowMessage "single_select" button (opens a list bottom-sheet). */
function buildListButton(sectionTitle, options, backValue) {
    const rows = options.map((o) => ({ title: o.label, id: o.value }));
    if (backValue) rows.push({ title: "🪶 Back", id: backValue });

    return [
        {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
                title: "⑄ View Options ⑄",
                sections: [{ title: sectionTitle, rows }],
            }),
        },
    ];
}

/** Sends a title + description + option list. Reused for the main card and every sub-menu. */
async function sendSelector(sock, target, title, description, options, backValue, name = "User") {
    const header = await buildHeader(sock);
    const msg = {
        interactiveMessage: {
            ...(header ? { header } : {}),
            body: { text: `*${title}*\n${description}` },
            footer: { text: "𝐀𝐒𝐔𝐑𝐀" },
            nativeFlowMessage: {
                buttons: buildListButton(title, options, backValue),
                messageParamsJson: "",
            },
        },
    };
    return sock.relayMessage(target, msg, {});
}

/** Sends the top-level command selector. */
async function sendMainCard(sock, target, name = "User") {
    return sendSelector(sock, target, "THE FIFTH INVITE", `\`𝐒𝐀𝐍𝐓𝐀 𝐀𝐒𝐔𝐑𝐀 𝐂𝐇𝐑𝐈𝐒𝐓𝐌𝐀𝐒 𝐂𝐇𝐀𝐎𝐒\`
┏⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌
┃✴︎𝐃𝐄𝐕 : Broken_symptoms
┃✴︎𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 𝐅𝐈𝐕𝐄
┃✴︎𝐔𝐒𝐄𝐑 : ${name}
┃✴︎𝐓𝐘𝐏𝐄 : 𝐉𝐀𝐕𝐀 𝐒𝐂
┗⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌
    `, commands, undefined, name);
     
    
}

/** Sends a category's sub-menu. */
async function sendSubMenu(sock, target, categoryId, name = "User") {
    const category = commands.find((c) => c.id === categoryId);
    const options = subMenus[categoryId];
    if (!category || !options) return;
    return sendSelector(sock, target, category.label.toUpperCase(), 
`\`𝐒𝐀𝐍𝐓𝐀 𝐀𝐒𝐔𝐑𝐀 𝐂𝐇𝐑𝐈𝐒𝐓𝐌𝐀𝐒 𝐂𝐇𝐀𝐎𝐒\`
┏⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌
┃✴︎𝐃𝐄𝐕 : Broken_symptoms
┃✴︎𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 𝐅𝐈𝐕𝐄
┃✴︎𝐔𝐒𝐄𝐑 : ${name}
┃✴︎𝐓𝐘𝐏𝐄 : 𝐉𝐀𝐕𝐀 𝐒𝐂
┗⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌⚌`, options, "back_to_main", name);
}

/** Sends the owner details, with a Back option in the same list button. */
async function sendOwnerCard(sock, target) {
    const header = await buildHeader(sock);
    const msg = {
        interactiveMessage: {
            ...(header ? { header } : {}),
            body: { text: ownerDetails },
            footer: { text: "𝐀𝐒𝐔𝐑𝐀 𝐕-𝟓" },
            nativeFlowMessage: {
                buttons: buildListButton("Owner", [], "back_to_main"),
                messageParamsJson: "",
            },
        },
    };
    return sock.relayMessage(target, msg, {});
}

module.exports = { sendMainCard, sendSubMenu, sendOwnerCard, commands, subMenus, allSubCommands, ownerDetails };
