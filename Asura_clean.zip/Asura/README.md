# Asura

Telegram bot with rich menus, force-join, premium gate, and WhatsApp pairing bridge (using Baileys).

## Setup

1. Copy `.env.example` to `.env` and fill in your values:
   ```bash
   cp .env.example .env
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the bot:
   ```bash
   npm start
   ```

## Notes

- `node_modules` was removed from this archive (regenerate with `npm install`).
- Original nested archive structure (zip > gzip > tar) has been cleaned up.
- Secrets from the original `.env` have been removed; use the example template.
