require("dotenv").config();

module.exports = {
  BOT_TOKEN: process.env.BOT_TOKEN,
  FORCE_JOIN_CHANNEL: process.env.FORCE_JOIN_CHANNEL, // e.g. "@your_channel_username"
  WHATSAPP_WORKER_URL: process.env.WHATSAPP_WORKER_URL || "http://localhost:4000",
  BAN_CHECK_API_URL: process.env.BAN_CHECK_API_URL || "https://kyuux-r.indevs.in",

  ADMIN_IDS: (process.env.ADMIN_TELEGRAM_ID || "")
    .split(",")
    .map((id) => id.trim())
    .filter(Boolean),

  // menu content
  MAIN_PHOTO_URL: process.env.MAIN_PHOTO_URL || "https://i.postimg.cc/fbKvqWNW/Lord-Broken-Asuraa.jpg",
  CHANNEL_URL: process.env.CHANNEL_URL || "https://t.me/Brokensshrine",
  DEVELOPER_URL: process.env.DEVELOPER_URL || "https://t.me/Broken_symptoms",
  OWNER_NAME: process.env.OWNER_NAME || "Broken",

  MENU_CAPTION: process.env.MENU_CAPTION || "Your all-in-one WhatsApp automation hub.",
  FOOTER_TEXT: process.env.FOOTER_TEXT || "Asura v5",
};
