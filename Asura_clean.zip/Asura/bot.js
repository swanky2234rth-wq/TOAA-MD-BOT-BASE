const { Telegraf } = require("telegraf");
const fetch = require("node-fetch");
const config = require("./config");
const { reportError, reportEvent } = require("./lib/diagnostics");

const { forceJoinMiddleware, hasJoined } = require("./middlewares/forceJoin");
const { requireAdmin, isAdmin } = require("./middlewares/isAdmin");
const { showMenu } = require("./lib/menuManager");
const { mainMenuBlocks } = require("./menus/mainMenu");
const { ownerMenuBlocks } = require("./menus/ownerMenu");
const { userMenuBlocks } = require("./menus/userMenu");
const { accoladesMenuBlocks } = require("./menus/accoladesMenu");
const { startPairing, restoreAllSessions, logoutSession } = require("./lib/whatsapp");
const { startCommand } = require("./commands/start");
const {
  isPremium,
  setPremium,
  removePremium,
  addExtraAdmin,
  removeExtraAdmin,
  getWhatsappSession,
  getAllUserIds,
  getPremiumUsers,
} = require("./lib/db");

const bot = new Telegraf(config.BOT_TOKEN);

bot.catch((err, ctx) => {
  reportError("telegram-update-handler", err, `update=${ctx?.updateType || "unknown"}`);
});

// telegram ids of admins currently mid-broadcast — their next text message gets sent to everyone
const awaitingBroadcast = new Set();


async function commandCard(ctx, { heading, headingSize = 2, cells, backTo }) {
  return showMenu(ctx, [
    { type: "heading", text: heading, size: headingSize },
    { type: "table", cells },
    { type: "buttons", buttons: [{ text: "🪶 Back", callback_data: backTo, style: "success" }] },
  ]);
}

async function resolveTargetUserId(ctx, arg) {
  if (ctx.message.reply_to_message) {
    return String(ctx.message.reply_to_message.from.id);
  }
  if (!arg) return null;
  if (/^\d+$/.test(arg)) return arg;
  if (arg.startsWith("@")) {
    try {
      const chat = await ctx.telegram.getChat(arg);
      return String(chat.id);
    } catch (err) {
      return null;
    }
  }
  return null;
}
bot.command("start", forceJoinMiddleware, startCommand);

// ---- callback buttons ----

// "I've Joined" recheck button
bot.action("check_joined", async (ctx) => {
  await ctx.answerCbQuery();
  const joined = await hasJoined(ctx);
  if (!joined) {
    return ctx.answerCbQuery("Still not joined. Join then tap again.", { show_alert: true });
  }
  await showMenu(ctx, mainMenuBlocks());
});

// Back to main menu
bot.action("menu_main", async (ctx) => {
  await ctx.answerCbQuery();
  await showMenu(ctx, mainMenuBlocks());
});

// Owner Menu (admin-only)
bot.action("owner_menu", async (ctx) => {
  const allowed = await requireAdmin(ctx);
  if (!allowed) return;

  await ctx.answerCbQuery();
  await showMenu(ctx, ownerMenuBlocks());
});

// User Menu (open to everyone)
bot.action("user_menu", async (ctx) => {
  await ctx.answerCbQuery();
  await showMenu(ctx, userMenuBlocks());
});

// Accolades / thank-you submenu (from the "TqTo" button in User Menu)
bot.action("accolades", async (ctx) => {
  await ctx.answerCbQuery();
  await showMenu(ctx, accoladesMenuBlocks());
});

// Broadcast (Owner Menu) — asks for the message, then the next text message
// from this admin gets sent to every stored user.
bot.action("broadcast", async (ctx) => {
  const allowed = await requireAdmin(ctx);
  if (!allowed) return;

  await ctx.answerCbQuery();
  awaitingBroadcast.add(String(ctx.from.id));
  await showMenu(ctx, [
    { type: "heading", text: "📢 Broadcast", size: 2 },
    { type: "paragraph", text: "Send the message you want broadcast to every user now — just type and send it." },
    { type: "buttons", buttons: [{ text: "🪶 Back", callback_data: "owner_menu", style: "success" }] },
  ]);
});

// List Premium (Owner Menu)
bot.action("list_premium", async (ctx) => {
  const allowed = await requireAdmin(ctx);
  if (!allowed) return;

  await ctx.answerCbQuery();
  const premiumUsers = getPremiumUsers();

  const cells = [[{ text: "User ID", is_header: true }, { text: "Expires", is_header: true }]];
  if (premiumUsers.length > 0) {
    for (const u of premiumUsers) {
      cells.push([{ text: u.telegram_id }, { text: u.premium_until || "Lifetime" }]);
    }
  } else {
    cells.push([{ text: "—" }, { text: "No premium users yet" }]);
  }

  await commandCard(ctx, { heading: "🔖 Premium Users", headingSize: 3, cells, backTo: "owner_menu" });
});

// My Sessions (User Menu)
bot.action("my_sessions", async (ctx) => {
  await ctx.answerCbQuery();
  const session = getWhatsappSession(String(ctx.from.id));

  const cells = session
    ? [
        [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
        [{ text: "Status" }, { text: session.status }],
        [{ text: "Number" }, { text: session.linked_number || "—" }],
      ]
    : [
        [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
        [{ text: "Status" }, { text: "No active session. Use /pair." }],
      ];

  await commandCard(ctx, { heading: "👾 My Sessions", cells, backTo: "user_menu" });
});

// ---- owner commands (stubs — logic TODO) ----

// Usage: reply to a user with "/addprem [days]", or "/addprem <id|@username> [days]".
// Omit days for lifetime premium.
bot.command("addprem", async (ctx) => {
  const allowed = await requireAdmin(ctx);
  if (!allowed) return;

  const args = ctx.message.text.trim().split(/\s+/).slice(1);
  const isReply = !!ctx.message.reply_to_message;
  const targetArg = isReply ? null : args[0];
  const daysArg = isReply ? args[0] : args[1];

  const targetId = await resolveTargetUserId(ctx, targetArg);
  if (!targetId) {
    return commandCard(ctx, {
      heading: "🍃 Add Premium",
      cells: [
        [{ text: "Usage", is_header: true }],
        [{ text: "Reply to a user with /addprem [days]" }],
        [{ text: "or /addprem <id|@username> [days]" }],
      ],
      backTo: "owner_menu",
    });
  }

  const days = daysArg ? parseInt(daysArg, 10) : null;
  const until = days && !isNaN(days) ? new Date(Date.now() + days * 86400000).toISOString() : null;
  setPremium(targetId, until);

  try {
    await ctx.telegram.sendMessage(targetId, `🌟 You've Premium access has been activated${until ? ` until ${until}` : " (lifetime)"}!`);
  } catch (err) {
    // target may have blocked the bot — premium is still granted, just couldn't notify them
  }

  await commandCard(ctx, {
    heading: "➕ Add Premium",
    cells: [
      [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
      [{ text: "User" }, { text: targetId }],
      [{ text: "Expires" }, { text: until || "Lifetime" }],
    ],
    backTo: "owner_menu",
  });
});

// Usage: reply to a user with "/delprem", or "/delprem <id|@username>".
bot.command("delprem", async (ctx) => {
  const allowed = await requireAdmin(ctx);
  if (!allowed) return;

  const args = ctx.message.text.trim().split(/\s+/).slice(1);
  const targetId = await resolveTargetUserId(ctx, args[0]);

  if (!targetId) {
    return commandCard(ctx, {
      heading: "➖ Remove Premium",
      cells: [
        [{ text: "Usage", is_header: true }],
        [{ text: "Reply to a user with /delprem" }],
        [{ text: "or /delprem <id|@username>" }],
      ],
      backTo: "owner_menu",
    });
  }

  removePremium(targetId);

  await commandCard(ctx, {
    heading: "➖ Remove Premium",
    cells: [
      [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
      [{ text: "User" }, { text: targetId }],
      [{ text: "Status" }, { text: "Premium removed" }],
    ],
    backTo: "owner_menu",
  });
});

// Usage: reply to a user with "/admin", or "/admin <id|@username>".
bot.command("admin", async (ctx) => {
  const allowed = await requireAdmin(ctx);
  if (!allowed) return;

  const args = ctx.message.text.trim().split(/\s+/).slice(1);
  const targetId = await resolveTargetUserId(ctx, args[0]);

  if (!targetId) {
    return commandCard(ctx, {
      heading: "🛡️ Add Admin",
      cells: [
        [{ text: "Usage", is_header: true }],
        [{ text: "Reply to a user with /admin" }],
        [{ text: "or /admin <id|@username>" }],
      ],
      backTo: "owner_menu",
    });
  }

  addExtraAdmin(targetId);

  try {
    await ctx.telegram.sendMessage(targetId, "🌟 Admin access purchased and activated!");
  } catch (err) {
    // target may have blocked the bot — they're still admin, just couldn't notify them
  }

  await commandCard(ctx, {
    heading: "🛡️ Add Admin",
    cells: [
      [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
      [{ text: "User" }, { text: targetId }],
      [{ text: "Status" }, { text: "Now an admin" }],
    ],
    backTo: "owner_menu",
  });
});

// Usage: reply to a user with "/deladmin", or "/deladmin <id|@username>".
// Admins set via ADMIN_TELEGRAM_ID in .env can't be removed this way — only
// admins added at runtime with /admin can be undone.
bot.command("deladmin", async (ctx) => {
  const allowed = await requireAdmin(ctx);
  if (!allowed) return;

  const args = ctx.message.text.trim().split(/\s+/).slice(1);
  const targetId = await resolveTargetUserId(ctx, args[0]);

  if (!targetId) {
    return commandCard(ctx, {
      heading: "🛡️ Remove Admin",
      cells: [
        [{ text: "Usage", is_header: true }],
        [{ text: "Reply to a user with /deladmin" }],
        [{ text: "or /deladmin <id|@username>" }],
      ],
      backTo: "owner_menu",
    });
  }

  if (config.ADMIN_IDS.includes(targetId)) {
    return commandCard(ctx, {
      heading: "🛡️ Remove Admin",
      cells: [
        [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
        [{ text: "User" }, { text: targetId }],
        [{ text: "Status" }, { text: "⚠️ Set in .env — can't be removed here" }],
      ],
      backTo: "owner_menu",
    });
  }

  removeExtraAdmin(targetId);

  await commandCard(ctx, {
    heading: "🛡️ Remove Admin",
    cells: [
      [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
      [{ text: "User" }, { text: targetId }],
      [{ text: "Status" }, { text: "Admin removed" }],
    ],
    backTo: "owner_menu",
  });
});

// ---- user commands ----

// Usage: /pair <phone_number>  — country code + number, digits only, no + or spaces.
bot.command("pair", async (ctx) => {
  const telegramId = String(ctx.from.id);
  const existing = getWhatsappSession(telegramId);
  if (existing && existing.status === "paired") {
    return commandCard(ctx, {
      heading: "🔗 Pair WhatsApp",
      cells: [
        [{ text: "Status", is_header: true }],
        [{ text: "Already paired. Use /delpair first if you want to relink." }],
      ],
      backTo: "user_menu",
    });
  }

  const phone = (ctx.message.text.trim().split(/\s+/)[1] || "").replace(/[^0-9]/g, "");
  if (!phone || phone.length < 8) {
    return commandCard(ctx, {
      heading: "🔗 Pair WhatsApp",
      cells: [
        [{ text: "Usage", is_header: true }],
        [{ text: "/pair <phone_number> — country code + number, digits only" }],
      ],
      backTo: "user_menu",
    });
  }

  const sentMsg = await commandCard(ctx, {
    heading: "🔗 Pairing WhatsApp",
    cells: [
      [{ text: "Status", is_header: true }],
      [{ text: "Generating your pairing code..." }],
    ],
    backTo: "user_menu",
  });

  try {
    const code = await startPairing(telegramId, phone, {
      // fires later, once the phone actually confirms the pairing
      onPaired: async () => {
        try {
          await ctx.telegram.callApi("editMessageText", {
            chat_id: ctx.chat.id,
            message_id: sentMsg.message_id,
            rich_message: {
              blocks: [
                { type: "heading", text: "✅ Successfully Paired!", size: 2 },
                {
                  type: "table",
                  cells: [
                    [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
                    [{ text: "Number" }, { text: phone }],
                    [{ text: "Status" }, { text: "Connected" }],
                  ],
                },
                { type: "buttons", buttons: [{ text: "🪶 Back", callback_data: "user_menu", style: "success" }] },
              ],
            },
          });
        } catch (err) {
          // message may be too old to edit — session is still paired regardless
        }
      },
    });

    await ctx.telegram.callApi("editMessageText", {
      chat_id: ctx.chat.id,
      message_id: sentMsg.message_id,
      rich_message: {
        blocks: [
          { type: "heading", text: "🔗 Pair WhatsApp", size: 2 },
          {
            type: "table",
            cells: [
              [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
              [{ text: "Code" }, { text: code }],
              [{ text: "Steps" }, { text: "WhatsApp > Linked Devices > Link with phone number > enter this code" }],
            ],
          },
          {
            type: "buttons",
            buttons: [
              // Telegram Bot API 8.0+ copy-to-clipboard button (CopyTextButton).
              // If your rich_message server predates that, this button may not render —
              // let me know and I'll swap it for a fallback.
              { text: " 🌀 Copy Code", copy_text: { text: code }, style: "primary" },
              { text: "🪶 Back", callback_data: "user_menu", style: "success" },
            ],
          },
        ],
      },
    });
  } catch (err) {
    await ctx.telegram.callApi("editMessageText", {
      chat_id: ctx.chat.id,
      message_id: sentMsg.message_id,
      rich_message: {
        blocks: [
          { type: "heading", text: "❌ Pairing Failed", size: 2 },
          { type: "table", cells: [[{ text: "Error", is_header: true }], [{ text: err.message }]] },
          { type: "buttons", buttons: [{ text: "🪶 Back", callback_data: "user_menu", style: "success" }] },
        ],
      },
    });
  }
});

bot.command("delpair", async (ctx) => {
  const telegramId = String(ctx.from.id);
  await logoutSession(telegramId);

  await commandCard(ctx, {
    heading: "🔗 Unpair WhatsApp",
    cells: [
      [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
      [{ text: "Status" }, { text: "Session cleared" }],
    ],
    backTo: "user_menu",
  });
});

bot.command("mysat", async (ctx) => {
  const telegramId = String(ctx.from.id);
  const admin = isAdmin(telegramId);
  const premium = admin || isPremium(telegramId); // admins are automatically premium
  const session = getWhatsappSession(telegramId);
  const pairedCount = session && session.status === "paired" ? 1 : 0;

  await commandCard(ctx, {
    heading: "📊 Your Status",
    cells: [
      [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
      [{ text: "Owner/Admin" }, { text: admin ? "✅ Yes" : "❌ No" }],
      [{ text: "Premium" }, { text: premium ? "✅ Active" : "❌ Not active" }],
      [{ text: "Paired Sessions" }, { text: String(pairedCount) }],
    ],
    backTo: "user_menu",
  });
});

bot.command("bancheck", async (ctx) => {
  const args = ctx.message.text.trim().split(/\s+/).slice(1);
  const phone = String(args[0] || "").replace(/[^0-9]/g, "");

  if (!phone || phone.length < 8) {
    return commandCard(ctx, {
      heading: "🚫 Ban Check",
      cells: [
        [{ text: "Usage", is_header: true }],
        [{ text: "/bancheck <phone_number>" }],
        [{ text: "Use country code + number, digits only." }],
      ],
      backTo: "user_menu",
    });
  }

  await commandCard(ctx, {
    heading: "🚫 Ban Check",
    cells: [
      [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
      [{ text: "Number" }, { text: phone }],
      [{ text: "Status" }, { text: "Checking..." }],
    ],
    backTo: "user_menu",
  });

  try {
    const base = String(config.BAN_CHECK_API_URL || "").replace(/\/$/, "");
    if (!base) throw new Error("BAN_CHECK_API_URL is not configured.");

    const url = `${base}/api/check-whatsapp?phone=${encodeURIComponent(phone)}`;
    const response = await fetch(url, {
      method: "GET",
      headers: { accept: "application/json" },
      timeout: 15000,
    });

    const raw = await response.text();
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      throw new Error(`API returned non-JSON (${response.status}).`);
    }

    if (!response.ok) {
      const apiError = data?.error || data?.message || `HTTP ${response.status}`;
      throw new Error(String(apiError));
    }

    const sources = [
      data,
      data?.data,
      data?.result,
      data?.info,
      data?.data?.result,
      data?.data?.info,
    ].filter(Boolean);

    let banned;
    for (const source of sources) {
      for (const key of ["banned", "isBanned", "ban", "is_banned"]) {
        if (typeof source?.[key] === "boolean") {
          banned = source[key];
          break;
        }
      }
      if (typeof banned === "boolean") break;
    }

    if (typeof banned !== "boolean") {
      const status = sources
        .map((source) => source?.status)
        .find((value) => typeof value === "string");

      if (typeof status === "string") {
        const normalized = status.toLowerCase();
        if (["banned", "ban", "blocked"].includes(normalized)) banned = true;
        if (["unbanned", "not_banned", "not banned", "active", "ok"].includes(normalized)) banned = false;
      }
    }

    if (typeof banned !== "boolean") {
      throw new Error("API response did not contain a recognizable ban-status field.");
    }

    await commandCard(ctx, {
      heading: banned ? "🚫 Ban Check" : "✅ Ban Check",
      cells: [
        [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
        [{ text: "Number" }, { text: phone }],
        [{ text: "Result" }, { text: banned ? "BANNED" : "NOT BANNED" }],
      ],
      backTo: "user_menu",
    });
  } catch (err) {
    await commandCard(ctx, {
      heading: "🚫 Ban Check",
      cells: [
        [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
        [{ text: "Number" }, { text: phone }],
        [{ text: "Result" }, { text: "FAILED" }],
        [{ text: "Error" }, { text: String(err.message || err).slice(0, 180) }],
      ],
      backTo: "user_menu",
    });
  }
});

// ---- catch the broadcast text (must stay after the bot.command() calls above) ----
bot.on("text", async (ctx, next) => {
  const telegramId = String(ctx.from.id);
  if (!awaitingBroadcast.has(telegramId)) return next();

  awaitingBroadcast.delete(telegramId);
  const text = ctx.message.text;
  const userIds = getAllUserIds();

  let sent = 0;
  let failed = 0;
  for (const id of userIds) {
    try {
      await ctx.telegram.sendMessage(id, text);
      sent++;
    } catch (err) {
      failed++;
    }
    await new Promise((r) => setTimeout(r, 40)); // stay well under Telegram's rate limit
  }

  await commandCard(ctx, {
    heading: "📢 Broadcast Sent",
    cells: [
      [{ text: "Field", is_header: true }, { text: "Value", is_header: true }],
      [{ text: "Delivered" }, { text: String(sent) }],
      [{ text: "Failed" }, { text: String(failed) }],
    ],
    backTo: "owner_menu",
  });
});

// Persistent diagnostics + Telegram alerts for errors that would otherwise disappear from the panel console.
process.on("unhandledRejection", (reason) => {
  reportError("process-unhandled-rejection", reason instanceof Error ? reason : new Error(String(reason)));
});

process.on("uncaughtException", (err) => {
  // Try to deliver the alert before exiting; the fallback prevents a stuck process.
  const fallback = setTimeout(() => process.exit(1), 5000);
  reportError("process-uncaught-exception", err).finally(() => {
    clearTimeout(fallback);
    process.exit(1);
  });
});

process.on("warning", (warning) => {
  reportEvent("process-warning", `${warning.name}: ${warning.message}${warning.stack ? `\n${warning.stack}` : ""}`, "warn", true);
});

process.on("exit", (code) => {
  // Exit hooks must remain synchronous; the persistent log records this even if Telegram is unreachable.
  reportEvent("process-exit", `Node.js process exiting with code ${code}`, code === 0 ? "info" : "error", false);
});

bot.launch().catch((err) => reportError("telegram-bot-launch", err));
console.log("Telegram bot is running...");

// reconnect anyone who was already paired before a restart/redeploy
restoreAllSessions().catch((err) => reportError("session-restore-startup", err));

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
