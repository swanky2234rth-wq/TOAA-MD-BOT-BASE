const config = require("../config");

/**
 * Returns true if the user is currently a member of the required channel.
 */
async function hasJoined(ctx) {
  if (!config.FORCE_JOIN_CHANNEL) return true; // gate disabled if not set

  try {
    const member = await ctx.telegram.getChatMember(
      config.FORCE_JOIN_CHANNEL,
      ctx.from.id
    );
    return ["member", "administrator", "creator"].includes(member.status);
  } catch (err) {
    console.error("forceJoin check failed:", err.message);
    // fail-open or fail-closed is a judgement call; failing closed is safer
    return false;
  }
}

/**
 * Middleware for commands (e.g. /start) - blocks straight away if not joined.
 */
async function forceJoinMiddleware(ctx, next) {
  const joined = await hasJoined(ctx);
  if (joined) return next();

  return ctx.telegram.callApi("sendRichMessage", {
    chat_id: ctx.chat.id,
    rich_message: {
      blocks: [
        { type: "heading", text: "Join to continue", size: 2 },
        { type: "paragraph", text: "🫵You need to join our channel before you can use this bot." },
        {
          type: "buttons",
          buttons: [
            { text: "‼️ Join Channel", url: `https://t.me/${config.FORCE_JOIN_CHANNEL.replace("@", "")}`, style: "danger" },
            { text: "🌀 I've Joined", callback_data: "check_joined", style: "success" },
          ],
        },
      ],
    },
  });
}

module.exports = { hasJoined, forceJoinMiddleware };
