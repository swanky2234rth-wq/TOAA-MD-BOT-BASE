'use strict';
const fs = require('fs');
const path = require('path');
const settings = require('./settings');
const sessions = require('./sessions');
const main = require('./main');

const BANNER = `
 ████████╗ ██████╗ █████╗ █████╗
 ╚══██╔══╝██╔═══██╗██╔══██╗██╔══██╗
    ██║   ██║   ██║███████║███████║
    ██║   ██║   ██║██╔══██║██╔══██║
    ██║   ╚██████╔╝██║  ██║██║  ██║
    ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
      ℘ 𝙨𝙬𝙖𝙣𝙠𝙮 ℘ multi session engine ℘
`;

function ensureDirs() {
  for (const d of ['database', 'sessions', 'plugins', 'helper', 'temp']) {
    const p = path.join(__dirname, d);
    if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
  }
}

function seedFiles() {
  const seeds = {
    'database/paired.json': {},
    'database/sudo.json': [],
    'database/premium.json': [],
    'database/usersettings.json': {}
  };
  for (const [rel, data] of Object.entries(seeds)) {
    const p = path.join(__dirname, rel);
    if (!fs.existsSync(p)) {
      try { fs.writeFileSync(p, JSON.stringify(data, null, 2)); } catch {}
    }
  }
}

async function boot() {
  console.log(BANNER);
  ensureDirs();
  seedFiles();

  const plugins = main.loadPlugins();
  console.log(`℘ plugins loaded: ${plugins} ℘`);

  try {
    require('./telegram');
  } catch (e) {
    console.error('[TG BOOT]', e.stack || e.message);
  }

  await sessions.reloadExistingSessions();

  console.log(`℘ ${settings.BOT_NAME} online ℘`);
  console.log(`℘ prefix ${settings.DEFAULT_PREFIX} ℘`);
}

process.on('uncaughtException', (e) => console.error('[UNCAUGHT]', e.stack || e.message));
process.on('unhandledRejection', (e) => console.error('[UNHANDLED]', e?.stack || e?.message || e));

boot().catch((e) => {
  console.error('[BOOT FAIL]', e.stack || e.message);
  process.exit(1);
});