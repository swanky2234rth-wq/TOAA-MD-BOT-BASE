'use strict';
// Sans-Serif Bold Italic (U+1D63C–U+1D66F, digits U+1D7EC–U+1D7F5)
const UPPER = 0x1D63C, LOWER = 0x1D656, DIGIT = 0x1D7EC;

function swanky(input) {
  return [...String(input ?? '')].map(ch => {
    const cp = ch.codePointAt(0);
    if (cp >= 65 && cp <= 90) return String.fromCodePoint(UPPER + cp - 65);
    if (cp >= 97 && cp <= 122) return String.fromCodePoint(LOWER + cp - 97);
    if (cp >= 48 && cp <= 57) return String.fromCodePoint(DIGIT + cp - 48);
    return ch;
  }).join('');
}

// ℘-rule header/footer — zero emoji
const PH = (label) => `℘ ${swanky(label)} ℘`;
const RULE = '━'.repeat(18);

module.exports = { swanky, PH, RULE };