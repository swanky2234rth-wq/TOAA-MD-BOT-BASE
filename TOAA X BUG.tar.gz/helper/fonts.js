'use strict';
// 14 fonts. Index 1 is plain. Used by applyFont() in main.js via the
// per-session "font" setting.
const R = {
  2: [0x1D400, 0x1D41A, 0x1D7CE], // bold
  3: [0x1D434, 0x1D44E, 0x1D7CE], // italic
  4: [0x1D468, 0x1D482, 0x1D7CE], // bold italic
  5: [0x1D5A0, 0x1D5BA, 0x1D7E2], // sans
  6: [0x1D5D4, 0x1D5EE, 0x1D7EC], // sans bold
  7: [0x1D670, 0x1D68A, 0x1D7F6], // mono
  8: [0x1D49C, 0x1D4B6, 0x1D7CE], // script
  9: [0x1D504, 0x1D51E, 0x1D7CE], // fraktur
  10: [0x24B6, 0x24D0, 0x2460], // circled
  11: [0x1F130, 0x1F150, 0x1D7CE], // squared
  12: [0x1D538, 0x1D552, 0x1D7D8], // double struck
  13: [0xFF21, 0xFF41, 0xFF10], // fullwidth
  14: [0x1D63C, 0x1D656, 0x1D7EC] // swanky (sans bold italic)
};

const FONT_COUNT = 14;

function mapText(text, [up, low, dig]) {
  return [...String(text ?? '')].map(ch => {
    const cp = ch.codePointAt(0);
    if (cp >= 65 && cp <= 90) return String.fromCodePoint(up + cp - 65);
    if (cp >= 97 && cp <= 122) return String.fromCodePoint(low + cp - 97);
    if (cp >= 48 && cp <= 57) return String.fromCodePoint(dig + cp - 48);
    return ch;
  }).join('');
}

function applyFont(text, n) {
  const r = R[n];
  if (!r) return String(text ?? '');
  try { return mapText(text, r); } catch { return String(text ?? ''); }
}

module.exports = { applyFont, FONT_COUNT };