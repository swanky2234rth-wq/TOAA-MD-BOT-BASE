module.exports = {
 /*~~~~ Management ~~~~*/
 TELEGRAM_TOKEN: '9170384892:AAGNP2fPXqk62H14fIdbB-m2v0zozCjzVuU',
 TELEGRAM_BOT_TOKEN: '9170384892:AAGNP2fPXqk62H14fIdbB-m2v0zozCjzVuU',
 OWNER_ID: '7046020356',
 BOT_NAME: 'TOAA',
 OWNER_NUMBER: '2349010262734',
 OWNER_NAME: 'swanky',
 DEFAULT_PREFIX: '.',
 RICH_ENABLED: true,

 /*~~~~ Database ~~~~*/
 SESSIONS_DIR: './sessions',
 SUDO_DB: './database/sudo.json',
 PREMIUM_DB: './database/premium.json',
 USERSETTINGS_DB: './database/usersettings.json',

 /*~~~~ Session limits ~~~~*/
 MAX_TOTAL_SESSIONS: 30,
 MAX_SESSIONS_PER_USER: 2,

 /*~~~~ Auto Follow ~~~~*/
 AUTO_JOIN_CHANNEL: true,
 WA_AUTO_FOLLOW_JIDS: ['120363427785085460@newsletter', '120363406660285927@newsletter'],

 /*~~~~ Photo Urls ~~~~*/
 MENU_IMAGE: 'https://i.ibb.co/qvf1WhD/IMG-9635.jpg',
 TG_MENU_IMAGE: 'https://i.ibb.co/b5wVHGP8/IMG-8486.jpg',
 BOT_IMAGE_URL: 'https://i.ibb.co/MDw6pcmF/IMG-7984.jpg',

 /*~~~~ Bug Engine ~~~~*/
 BUG_IMAGE: 'https://i.ibb.co/SXtghycC/IMG-9633.jpg',
 BAN_KEY: 'toaa-ban-2234',
 BAN_COOLDOWN: 30000,
 FREEZE_ROUNDS: 3,
 BUG_COOLDOWN: 180000,
 BUG_ROUNDS: 100,
 BUG_DELAY: 1200,
 AI_BOT_JID: '2349010262734@bot',

 /*~~~~ Manual Premiums ~~~~*/
 PREMIUM_USERS: ['7046020356'],

 /*~~~~ Ban Appeal Aliases ~~~~*/
 SENDER_EMAIL: 'swankygo2234@gmail.com',
 SENDER_PASS: 'drewldbgntzqumrn',
 SUPPORT_EMAIL: 'smb_web@support.whatsapp.com',

 /*~~~ Owner|GC|Channel links ~~~*/
 OWNER_HANDLE: 't.me/swanky_is_TOAA',
 WA_CHANNEL_LINK: 'https://whatsapp.com/channel/0029Vb9am1UGOj9pG1eSUO1s',
 WA_CHANNEL_INVITE: '0029Vb9am1UGOj9pG1eSUO1s',
 WA_CHANNEL_JID: '',
 TG_LINK: 'https://t.me/swankysaltar',
 TG_CHANNEL: 'swankysaltar',
 TG_GROUP: '',
 TG_GROUP_LINK: '',

 /*~~~~ API Keys ~~~~*/
 IMGBB_API_KEY: '5d4ac3da1ce99f856c293bc20ad0f818',
 SCREENSHOTMACHINE_KEY: '3a3f15',
 MISTRAL_API_KEY: 'M4mkIopC8AX0agHIfM2YuKqb0MvfK0yt',
};