'use strict';
const fs = require('fs');
const TelegramBot = require('node-telegram-bot-api');
const settings = require('./settings');
const sessions = require('./sessions');
const pad = require('./helper/tgpad');
const { swanky, RULE } = require('./helper/swanky');

const bot = new TelegramBot(settings.TELEGRAM_TOKEN, { polling: true });
const OWNER = String(settings.OWNER_ID);
const pending = new Map();
const verified = new Set();

// ─── mark ──────────────────────────────────────────────────────────────────
const M = '❨𖣓❩';
const TOP = (M + ' ').repeat(5).trim();
const BOT = TOP;

const isOwner = (id) => String(id) === OWNER;
const say = (chat, text, kb) =>
 bot.sendMessage(chat, text, { parse_mode: 'Markdown', reply_markup: kb }).catch(() => {});
const H = (t) => `${M} ℘ ${swanky(t)} ℘ ${M}`;

function card(title, body) {
 return [TOP, '', H(title), '', body, '', BOT].join('\n');
}

// ─── force join ────────────────────────────────────────────────────────────
async function joined(userId) {
 if (verified.has(userId) || isOwner(userId)) return true;

 const targets = [];
 if (settings.TG_CHANNEL) targets.push('@' + settings.TG_CHANNEL);
 if (settings.TG_GROUP) targets.push('@' + settings.TG_GROUP);
 if (!targets.length) { verified.add(userId); return true; }

 for (const t of targets) {
 let status = null;
 try {
 const m = await bot.getChatMember(t, userId);
 status = m.status;
 } catch (e) {
 // bot not admin in that chat — retry once, then skip rather than lock out
 try {
 const m2 = await bot.getChatMember(t, userId);
 status = m2.status;
 } catch {
 console.log('[GATE] cannot check', t, '—', e.message);
 continue;
 }
 }
 if (!['member', 'administrator', 'creator'].includes(status)) return false;
 }

 verified.add(userId);
 return true;
}

function gate(chat, userId) {
 const rows = [];
 const row = [];
 if (settings.TG_LINK) row.push({ text: `${M} channel`, url: settings.TG_LINK });
 if (settings.TG_GROUP_LINK) row.push({ text: `${M} group`, url: settings.TG_GROUP_LINK });
 if (row.length) rows.push(row);
 rows.push([{ text: `${M} ` + swanky('authorize'), callback_data: 'verify' }]);

 return say(chat, card('join first',
 [`${M} ` + swanky('both links, then authorize'),
 `${M} ` + swanky('one is not enough')].join('\n')), { inline_keyboard: rows });
}

// ─── screens ───────────────────────────────────────────────────────────────
const screen = {
 async start(chat, id) {
 await say(chat, card('toaa reigns',
 [`${M} ` + swanky('pair a number to begin'),
 `${M} ` + swanky('the pad below drives everything'),
 `${M} ` + swanky('nothing is typed')].join('\n')));
 },

 async status(chat, id) {
 const all = sessions.pairedList();
 const mine = all.filter(s => String(s.ownerTg) === String(id));
 await say(chat, card('status',
 [`${M} ` + swanky('sessions') + ': ' + mine.length,
 `${M} ` + swanky('running') + ': ' + mine.filter(s => sessions.isRunning(s.name)).length,
 `${M} ` + swanky('engine online')].join('\n')));
 },

 async list(chat, id) {
 const mine = sessions.pairedList().filter(s => String(s.ownerTg) === String(id) || isOwner(id));
 if (!mine.length) return say(chat, card('no sessions', `${M} ` + swanky('tap pair to begin')));

 const body = mine.map((s, i) =>
 `${M} ${i + 1}. ${swanky(s.phone || s.name)}\n    ${sessions.isRunning(s.name) ? 'online' : 'offline'}`
 ).join('\n');

 await say(chat, card('your sessions', body));
 },

 async panel(chat) {
 const all = sessions.pairedList();
 await say(chat, card('owner console',
 [`${M} ` + swanky('users') + ': ' + new Set(all.map(s => s.ownerTg)).size,
 `${M} ` + swanky('sessions') + ': ' + all.length,
 `${M} ` + swanky('running') + ': ' + all.filter(s => sessions.isRunning(s.name)).length].join('\n')));
 },

 async guide(chat) {
 await say(chat, card('guide',
 [`${M} *${swanky('1')}* ` + swanky('tap pair number'),
 `${M} *${swanky('2')}* ` + swanky('send number with country code, no + or 0'),
 `${M} *${swanky('3')}* ` + swanky('copy the 8-char code'),
 `${M} *${swanky('4')}* ` + swanky('whatsapp > linked devices > link with number'),
 `${M} *${swanky('5')}* ` + swanky('session appears under sessions')].join('\n')));
 },

 async menu(chat, id) {
 await say(chat, card('menu',
 [`${M} ` + swanky('pair number') + ' — ' + swanky('link a new session'),
 `${M} ` + swanky('status') + ' — ' + swanky('your session counts'),
 `${M} ` + swanky('sessions') + ' — ' + swanky('list and state'),
 `${M} ` + swanky('delete') + ' — ' + swanky('drop a session'),
 `${M} ` + swanky('guide') + ' — ' + swanky('pairing walkthrough'),
 `${M} ` + swanky('owner panel') + ' — ' + swanky('owner only')].join('\n')));
 },

 async config(chat) {
 await say(chat, card('config',
 [`${M} ` + swanky('prefix') + ': ' + settings.DEFAULT_PREFIX,
 `${M} ` + swanky('max total') + ': ' + settings.MAX_TOTAL_SESSIONS,
 `${M} ` + swanky('per user') + ': ' + settings.MAX_SESSIONS_PER_USER,
 `${M} ` + swanky('rich') + ': ' + settings.RICH_ENABLED].join('\n')), pad.ownerPad());
 }
};

// ─── pairing ───────────────────────────────────────────────────────────────
async function doPair(chat, id, input) {
 const phone = String(input || '').replace(/\D/g, '');
 if (phone.length < 8) return say(chat, card('bad number', `${M} ` + swanky('send full number with country code')));

 const all = sessions.pairedList();
 if (all.length >= (settings.MAX_TOTAL_SESSIONS || 30)) return say(chat, H('server full'));
 const mine = all.filter(s => String(s.ownerTg) === String(id));
 if (mine.length >= (settings.MAX_SESSIONS_PER_USER || 2)) return say(chat, H('limit reached'));

 const name = `session_${id}_${phone}`;
 if (sessions.isRunning(name)) return say(chat, H('already paired'));

 if (sessions.hasCreds(name)) {
 if (sessions.credsRegistered(name)) return say(chat, H('already paired'));
 sessions.wipe(name);
 }

 await say(chat, card('requesting code', `${M} ` + swanky(phone)));

 try {
 await sessions.startWASession(name, phone, String(id), async (code, err) => {
 if (!code) return say(chat, card('pairing failed', `${M} ` + swanky(err || 'retry')));
 await say(chat, [TOP, '', H('pairing code'), '', `\`${code}\``, '', BOT, '', `${M} ` + swanky('whatsapp > linked devices > link with number')].join('\n'));
 });
 } catch (e) {
 await say(chat, card('error', `${M} ` + swanky(e.message)));
 }
}

async function doDelete(chat, id, input) {
 const phone = String(input || '').replace(/\D/g, '');
 const name = `session_${id}_${phone}`;
 const rec = sessions.live.get(name);
 if (!rec && !sessions.hasCreds(name)) return say(chat, H('not found'));
 await sessions.stopSession(name);
 sessions.unregisterPaired(name);
 try { fs.rmSync(sessions.dirOf(name), { recursive: true, force: true }); } catch {}
 await say(chat, card('deleted', `${M} ` + swanky(phone)));
}

async function doBroadcast(chat, text) {
 const owners = [...new Set(sessions.pairedList().map(s => s.ownerTg).filter(Boolean))];
 let ok = 0;
 for (const o of owners) {
 try { await bot.sendMessage(o, card('broadcast', text)); ok++; } catch {}
 }
 await say(chat, H(`sent ${ok}/${owners.length}`));
}

// ─── commands ──────────────────────────────────────────────────────────────
bot.onText(/^\/start/, async (msg) => {
 const chat = msg.chat.id;
 if (!(await joined(msg.from.id))) return gate(chat, msg.from.id);
 await pad.install(bot, chat, isOwner(msg.from.id));
 await screen.start(chat, msg.from.id);
});

bot.onText(/^\/menu$/, async (msg) => {
 const chat = msg.chat.id;
 if (!(await joined(msg.from.id))) return gate(chat, msg.from.id);
 await screen.menu(chat, msg.from.id);
});

bot.onText(/^\/guide$/, async (msg) => {
 const chat = msg.chat.id;
 if (!(await joined(msg.from.id))) return gate(chat, msg.from.id);
 await screen.guide(chat);
});

bot.onText(/^\/pair(?:\s+(.+))?$/, async (msg, match) => {
 const chat = msg.chat.id;
 if (!(await joined(msg.from.id))) return gate(chat, msg.from.id);
 if (!match[1]) { pending.set(msg.from.id, 'pair'); return say(chat, H('send the number')); }
 return doPair(chat, msg.from.id, match[1]);
});

bot.onText(/^\/delpair(?:\s+(.+))?$/, async (msg, match) => {
 const chat = msg.chat.id;
 if (!(await joined(msg.from.id))) return gate(chat, msg.from.id);
 if (!match[1]) { pending.set(msg.from.id, 'delete'); return say(chat, H('send the number')); }
 return doDelete(chat, msg.from.id, match[1]);
});

bot.onText(/^\/sessions$/, async (msg) => {
 if (!(await joined(msg.from.id))) return gate(msg.chat.id, msg.from.id);
 return screen.list(msg.chat.id, msg.from.id);
});

bot.onText(/^\/panel$/, async (msg) => {
 if (!isOwner(msg.from.id)) return say(msg.chat.id, H('owner only'));
 await screen.panel(msg.chat.id);
});

bot.onText(/^\/addprem(?:\s+(.+))?$/, async (msg, match) => {
 if (!isOwner(msg.from.id)) return;
 const n = String(match[1] || '').replace(/\D/g, '');
 if (!n) return say(msg.chat.id, H('send a number'));
 require('./main').addPremium(n);
 await say(msg.chat.id, H(`premium added ${swanky(n)}`));
});

bot.onText(/^\/delprem(?:\s+(.+))?$/, async (msg, match) => {
 if (!isOwner(msg.from.id)) return;
 const n = String(match[1] || '').replace(/\D/g, '');
 if (!n) return say(msg.chat.id, H('send a number'));
 require('./main').delPremium(n);
 await say(msg.chat.id, H(`premium removed ${swanky(n)}`));
});

bot.onText(/^\/restart$/, async (msg) => {
 if (!isOwner(msg.from.id)) return;
 await say(msg.chat.id, H('restarting'));
 setTimeout(() => process.exit(0), 800);
});

bot.on('callback_query', async (q) => {
 if (q.data !== 'verify') return;
 const chat = q.message.chat.id;
 bot.answerCallbackQuery(q.id).catch(() => {});
 if (!(await joined(q.from.id))) return say(chat, H('still not joined'));
 await pad.install(bot, chat, isOwner(q.from.id));
 await screen.start(chat, q.from.id);
});

// ─── pad taps ──────────────────────────────────────────────────────────────
bot.on('message', async (msg) => {
 const chat = msg.chat.id;
 const id = msg.from?.id;
 if (!id || !msg.text || msg.text.startsWith('/')) return;
 if (!(await joined(id))) return gate(chat, id);

 if (await pad.handlePad(bot, msg, {
 onPair: async () => { pending.set(id, 'pair'); await say(chat, H('send the number')); return true; },
 onStatus: async () => { await screen.status(chat, id); return true; },
 onSessions: async () => { await screen.list(chat, id); return true; },
 onDelete: async () => { pending.set(id, 'delete'); await say(chat, H('send the number')); return true; },
 onGuide: async () => { await screen.guide(chat); return true; },
 onMenu: async () => { await screen.menu(chat, id); return true; },
 onUsers: async () => {
 const owners = [...new Set(sessions.pairedList().map(s => s.ownerTg))];
 await say(chat, card('users', owners.length ? owners.map(o => `${M} ${o}`).join('\n') : `${M} ` + swanky('none yet')));
 return true;
 },
 onStats: async () => { await screen.panel(chat); return true; },
 onBroadcast: async () => { pending.set(id, 'broadcast'); await say(chat, H('send the text')); return true; },
 onConfig: async () => { await screen.config(chat); return true; },
 onRestart: async () => { await say(chat, H('restarting')); setTimeout(() => process.exit(0), 800); return true; }
 })) return;

 const p = pending.get(id);
 if (!p) return;
 pending.delete(id);

 if (p === 'pair') return doPair(chat, id, msg.text);
 if (p === 'delete') return doDelete(chat, id, msg.text);
 if (p === 'broadcast') {
 if (!isOwner(id)) return say(chat, H('owner only'));
 return doBroadcast(chat, msg.text);
 }
});

bot.on('polling_error', (e) => console.log('[TG]', e.message));

console.log(`${M} ℘ telegram online ℘ ${M}`);

module.exports = bot;