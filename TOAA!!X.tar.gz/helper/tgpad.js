'use strict';
const settings = require('../settings');
const { swanky } = require('./swanky');

const L = swanky;
const M = '❨𖣓❩';

const LABELS = {
 pair: L('pair number'),
 status: L('status'),
 sessions: L('sessions'),
 delete: L('delete'),
 guide: L('guide'),
 menu: L('menu'),
 panel: L('owner panel'),
 users: L('users'),
 stats: L('stats'),
 broadcast: L('broadcast'),
 config: L('config'),
 restart: L('restart'),
 back: L('back')
};

const REVERSE = Object.fromEntries(Object.entries(LABELS).map(([k, v]) => [v, k]));
const OWNER = String(settings.OWNER_ID);

const userPad = () => ({
 keyboard: [
 [{ text: LABELS.pair }],
 [{ text: LABELS.status }, { text: LABELS.sessions }],
 [{ text: LABELS.delete }, { text: LABELS.guide }],
 [{ text: LABELS.menu }, { text: LABELS.panel }]
 ],
 resize_keyboard: true,
 is_persistent: true,
 one_time_keyboard: false
});

const ownerPad = () => ({
 keyboard: [
 [{ text: LABELS.pair }],
 [{ text: LABELS.users }, { text: LABELS.stats }],
 [{ text: LABELS.broadcast }, { text: LABELS.config }],
 [{ text: LABELS.restart }, { text: LABELS.back }]
 ],
 resize_keyboard: true,
 is_persistent: true,
 one_time_keyboard: false
});

function install(bot, chatId, isOwner) {
 return bot.sendMessage(chatId, isOwner ? `${M} ℘ owner console armed ℘ ${M}` : `${M} ℘ console armed ℘ ${M}`, {
 reply_markup: isOwner ? ownerPad() : userPad()
 });
}

async function handlePad(bot, msg, deps = {}) {
 const text = msg.text;
 if (!text) return false;
 const key = REVERSE[text];
 if (!key) return false;

 const chatId = msg.chat.id;
 const isOwner = String(msg.from.id) === OWNER;

 const say = (t, kb) => bot.sendMessage(chatId, t, {
 parse_mode: 'Markdown',
 reply_markup: kb || (isOwner ? ownerPad() : userPad())
 });

 switch (key) {
 case 'pair':
 return (await deps.onPair?.(msg)) ?? (say(`${M} ℘ sᴇɴᴅ ᴀ ɴᴜᴍʙᴇʀ ᴛᴏ ᴘᴀɪʀ ℘ ${M}`), true);

 case 'status':
 return (await deps.onStatus?.(msg)) ?? (say('℘ ʀᴜɴɴɪɴɢ ℘'), true);

 case 'sessions':
 return (await deps.onSessions?.(msg)) ?? (say('℘ ɴᴏ sᴇssɪᴏɴs ℘'), true);

 case 'delete':
 return (await deps.onDelete?.(msg)) ?? (say('℘ sᴇɴᴅ ɴᴜᴍʙᴇʀ ᴛᴏ ᴅᴇʟᴇᴛᴇ ℘'), true);

 case 'guide':
 return (await deps.onGuide?.(msg)) ?? (say('℘ ɢᴜɪᴅᴇ ᴜɴᴀᴠᴀɪʟᴀʙʟᴇ ℘'), true);

 case 'menu':
 return (await deps.onMenu?.(msg)) ?? (say('℘ ᴍᴇɴᴜ ᴜɴᴀᴠᴀɪʟᴀʙʟᴇ ℘'), true);

 case 'panel':
 if (!isOwner) { await say('℘ ᴏᴡɴᴇʀ ᴏɴʟʏ ℘'); return true; }
 await say(`${M} ℘ ᴏᴡɴᴇʀ ᴄᴏɴsᴏʟᴇ ℘ ${M}`, ownerPad());
 return true;

 case 'users':
 if (!isOwner) { await say('℘ ᴏᴡɴᴇʀ ᴏɴʟʏ ℘'); return true; }
 return (await deps.onUsers?.(msg)) ?? (say('℘ ɴᴏ ᴜsᴇʀs ʏᴇᴛ ℘', ownerPad()), true);

 case 'stats':
 if (!isOwner) { await say('℘ ᴏᴡɴᴇʀ ᴏɴʟʏ ℘'); return true; }
 return (await deps.onStats?.(msg)) ?? (say('℘ sᴛᴀᴛs ᴜɴᴀᴠᴀɪʟᴀʙʟᴇ ℘', ownerPad()), true);

 case 'broadcast':
 if (!isOwner) { await say('℘ ᴏᴡɴᴇʀ ᴏɴʟʏ ℘'); return true; }
 return (await deps.onBroadcast?.(msg)) ?? (say('℘ sᴇɴᴅ ᴛʜᴇ ᴛᴇxᴛ ᴛᴏ ʙʀᴏᴀᴅᴄᴀsᴛ ℘', ownerPad()), true);

 case 'config':
 if (!isOwner) { await say('℘ ᴏᴡɴᴇʀ ᴏɴʟʏ ℘'); return true; }
 return (await deps.onConfig?.(msg)) ?? (say('℘ ᴄᴏɴғɪɢ ℘', ownerPad()), true);

 case 'restart':
 if (!isOwner) { await say('℘ ᴏᴡɴᴇʀ ᴏɴʟʏ ℘'); return true; }
 return (await deps.onRestart?.(msg)) ?? (say('℘ ʀᴇsᴛᴀʀᴛɪɴɢ ℘', ownerPad()), true);

 case 'back':
 await say(`${M} ℘ ᴍᴀɪɴ ᴍᴇɴᴜ ℘ ${M}`);
 return true;
 }
 return true;
}

module.exports = { install, handlePad, userPad, ownerPad, LABELS, REVERSE };