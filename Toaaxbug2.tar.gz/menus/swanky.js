const config = require("../config");

function developerButtonBlock() {
  return {
    type: "buttons",
    buttons: [{ text: " cοиtαct οwиєʀ", url: config.DEVELOPER_URL, style: "primary" }],
  };
}

function photoBlock() {
  return {
    type: "photo",
    photo: { type: "photo", media: config.MAIN_PHOTO_URL },
    caption: { text: config.MENU_CAPTION },
  };
}

// Footer shown at the bottom of every menu.
function footerBlock() {
  return { type: "footer", text: config.FOOTER_TEXT };
}

module.exports = { developerButtonBlock, photoBlock, footerBlock };