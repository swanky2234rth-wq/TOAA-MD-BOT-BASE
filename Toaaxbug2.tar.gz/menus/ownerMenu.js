const config = require("../config");
const { developerButtonBlock, photoBlock, footerBlock } = require("./swanky");

function ownerMenuBlocks() {
  return [
    developerButtonBlock(),
    { type: "heading", text: "𝖳𝖮𝖠𝖠 𓃨 𝖠𝖲𝖢𝖤𝖭𝖣𝖲", size: 4 },
    photoBlock(),

    {
      type: "details",
      summary: "[𐌏]- 𝖮𝖶𝖭𝖤𝖱 𝖢𝖮𝖬𝖬𝖠𝖭𝖣𝖲 𐌏",
      is_open: true,
      blocks: [
        {
          type: "table",
          cells: [
            [{ text: "Command", is_header: true }, { text: "Job", is_header: true }],
            [{ text: "/addprem" }, { text: "grant premium access" }],
            [{ text: "/delprem" }, { text: "remove premium access" }],
            [{ text: "/admin" }, { text: "add a new admin" }],
            [{ text: "/deladmin" }, { text: "remove an admin" }],
          ],
        },
      ],
    },

    {
      type: "buttons",
      buttons: [
        { text: "𐌏 Broadcast ", callback_data: "broadcast", style: "danger" },
        { text: "𐌏 ListPrem", callback_data: "list_premium", style: "danger" },
      ],
    },
    {
      type: "buttons",
      buttons: [{ text: "𐌏 Back", callback_data: "menu_main", style: "success" }],
    },
    footerBlock(),
  ];
}

module.exports = { ownerMenuBlocks };