const config = require("../config");
const { developerButtonBlock, photoBlock, footerBlock } = require("./swanky");

function userMenuBlocks() {
  return [
    developerButtonBlock(),
    { type: "heading", text: "𝖳𝖮𝖠𝖠 𓃨 𝖠𝖲𝖢𝖤𝖭𝖣𝖲", size: 4 },
    photoBlock(),

    {
      type: "details",
      summary: "[𐌏]- 𝖴𝖲𝖤𝖱 𝖢𝖮𝖬𝖬𝖠𝖭𝖣𝖲 𐌏",
      is_open: true,
      blocks: [
        {
          type: "table",
          cells: [
            [{ text: "Command", is_header: true }, { text: "Job", is_header: true }],
            [{ text: "/pair" }, { text: "create Whatsapp session" }],
            [{ text: "/delpair" }, { text: "remove WhatsApp sessions" }],
            [{ text: "/mysat" }, { text: "check your account status" }],
            [{ text: "/bancheck" }, { text: "check if a number is banned" }],
          ],
        },
      ],
    },

    {
      type: "buttons",
      buttons: [
        { text: "𐌏 Mysessions", callback_data: "my_sessions", style: "danger" },
        { text: "𐌏 TqTo", callback_data: "accolades", style: "danger" },
      ],
    },
    {
      type: "buttons",
      buttons: [{ text: "𐌏 Back", callback_data: "menu_main", style: "success" }],
    },
    footerBlock(),
  ];
}

module.exports = { userMenuBlocks };