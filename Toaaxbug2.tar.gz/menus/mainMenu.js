const config = require("../config");
const { developerButtonBlock, photoBlock, footerBlock } = require("./swanky");

function mainMenuBlocks() {
  return [
    developerButtonBlock(),
    { type: "heading", text: "𝖳𝖮𝖠𝖠 𓃨 𝖠𝖲𝖢𝖤𝖭𝖣𝖲", size: 4 },
    photoBlock(),

    // foldable "Info Bot" section
    {
      type: "details",
      summary: "[𐌏]- 𝖡𝖮𝖳 𝖨𝖭𝖥𝖮𝖱𝖬𝖠𝖳𝖨𝖮𝖭 ",
      is_open: true,
      blocks: [
        {
          type: "table",
          cells: [
            [{ text: " Creator", is_header: true }, { text: config.OWNER_NAME }],
            [{ text: " Status", is_header: true }, { text: "Active" }],
            [{ text: " Version", is_header: true }, { text: "V1" }],
            [{ text: " Bot type", is_header: true }, { text: "Java sc" }],
          ],
        },
      ],
    },

    {
      type: "buttons",
      buttons: [
        { text: "𐌏 Owner Menu", callback_data: "owner_menu", style: "danger" },
        { text: "𐌏 User Menu", callback_data: "user_menu", style: "danger" },
      ],
    },
    {
      type: "buttons",
      buttons: [{ text: " jοiи swαиky’s αℓtαʀ ", url: config.CHANNEL_URL, style: "primary" }],
    },
    footerBlock(),
  ];
}

module.exports = { mainMenuBlocks };