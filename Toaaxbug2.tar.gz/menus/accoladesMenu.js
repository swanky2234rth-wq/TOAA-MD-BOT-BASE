const { developerButtonBlock, photoBlock, footerBlock } = require("./swanky");

function accoladesMenuBlocks() {
  return [
    developerButtonBlock(),
    { type: "heading", text: "𝖳𝖮𝖠𝖠 𝖠𝖲𝖢𝖤𝖭𝖣𝖲 𓃨", size: 4 },
    photoBlock(),
    {
      type: "details",
      summary: "𐌏 𝖮𝗐𝗇𝖾𝗋",
      is_open: true,
      blocks: [
        {
          type: "table",
          cells: [
            [{ text: "Name", is_header: true }, { text: "Role", is_header: true }],
            [{ text: "swanky" }, { text: "Owner / Developer" }],
          ],
        },
      ],
    },
    {
      type: "buttons",
      buttons: [{ text: "𐌏 𝖮𝗐𝗇𝖾𝗋", url: "https://t.me/swanky_is_TOAA", style: "primary" }],
    },
    {
      type: "buttons",
      buttons: [{ text: "𐌏 𝖡𝖺𝖼𝗄", callback_data: "user_menu", style: "success" }],
    },
    footerBlock(),
  ];
}

module.exports = { accoladesMenuBlocks };
