// WhatsApp-side card builder. Exports the shape lib/whatsapp.js expects:
// sendMainCard / sendOwnerCard / sendSubMenu, plus the `commands` and
// `allSubCommands` arrays the interactive-selector loop resolves against.
const config = require("./config");
const { sendNativeButtons } = require("./lib/richmenu");

const HEADING = "𝖳𝖮𝖠𝖠 𓃨 𝖠𝖲𝖢𝖤𝖭𝖣𝖲";

// Top-level categories. Owner only — support removed.
const commands = [
  { id: "owner", label: "Owner", value: "owner_menu" },
];

// Leaf commands reachable from the owner card.
const allSubCommands = [
  { id: "tagall", label: "tagall", value: "cmd_tagall" },
  { id: "group_id", label: "group_id", value: "cmd_group_id" },
  { id: "ping", label: "ping", value: "cmd_ping" },
  { id: "device", label: "device", value: "cmd_device" },
  { id: "sticker", label: "sticker", value: "cmd_sticker" },
  { id: "reveal", label: "reveal", value: "cmd_reveal" },
  { id: "kickall", label: "kickall", value: "cmd_kickall" },
  { id: "forclose", label: "forclose", value: "cmd_forclose" },
  { id: "delay-invis", label: "delay-invis", value: "cmd_delay-invis" },
  { id: "freeze_invis", label: "freeze_invis", value: "cmd_freeze_invis" },
  { id: "blank_andro", label: "blank_andro", value: "cmd_blank_andro" },
  { id: "crash_ip", label: "crash_ip", value: "cmd_crash_ip" },
  { id: "delay_ip", label: "delay_ip", value: "cmd_delay_ip" },
  { id: "freeze_ip", label: "freeze_ip", value: "cmd_freeze_ip" },
  { id: "blank_ip", label: "blank_ip", value: "cmd_blank_ip" },
  { id: "crash_gc", label: "crash_gc", value: "cmd_crash_gc" },
  { id: "delay_gc", label: "delay_gc", value: "cmd_delay_gc" },
];

async function sendPhotoCard(sock, jid, caption) {
  try {
    await sock.sendMessage(jid, {
      image: { url: config.MAIN_PHOTO_URL },
      caption,
    });
  } catch (err) {
    // image host down — the card still has to arrive
    await sock.sendMessage(jid, { text: caption });
  }
}

function chunkButtons(items) {
  const rows = [];
  for (let i = 0; i < items.length; i += 2) {
    rows.push(items.slice(i, i + 2));
  }
  return rows;
}

async function sendMainCard(sock, jid, pushname = "User") {
  const caption =
    `${HEADING}\n\n` +
    `𐌏 Hey ${pushname}\n` +
    `𐌏 ${config.MENU_CAPTION}\n` +
    `𐌏 ${config.FOOTER_TEXT}`;

  await sendPhotoCard(sock, jid, caption);

  await sendNativeButtons(sock, jid, "𐌏 Pick a menu", config.FOOTER_TEXT, [
    { type: "quick_reply", text: "𐌏 Owner Menu", id: "owner_menu" },
  ]);
}

async function sendOwnerCard(sock, jid) {
  const caption =
    `${HEADING}\n\n` +
    `𐌏 Owner commands\n` +
    `𐌏 Pick one, then send it with the target\n` +
    `𐌏 ${config.FOOTER_TEXT}`;

  await sendPhotoCard(sock, jid, caption);

  const rows = chunkButtons(
    allSubCommands.map((c) => ({ type: "quick_reply", text: `𐌏 ${c.label}`, id: c.value }))
  );

  for (const row of rows) {
    await sendNativeButtons(sock, jid, "", config.FOOTER_TEXT, row);
  }

  await sendNativeButtons(sock, jid, "", config.FOOTER_TEXT, [
    { type: "quick_reply", text: "𐌏 Back", id: "back_to_main" },
  ]);
}

async function sendSubMenu(sock, jid, categoryId, pushname = "User") {
  if (categoryId === "owner") return sendOwnerCard(sock, jid);
  // Only Owner survives — anything else falls back to the main card.
  return sendMainCard(sock, jid, pushname);
}

module.exports = { commands, allSubCommands, sendMainCard, sendOwnerCard, sendSubMenu };