require("dotenv").config();

const { Telegraf } = require("telegraf");
const fetch = require("node-fetch");

const config = require("./config");
const { showMenu } = require("./lib/menuManager");
const { mainMenuBlocks } = require("./menus/mainMenu");
const { ownerMenuBlocks } = require("./menus/ownerMenu");
const { userMenuBlocks } = require("./menus/userMenu");
const { accoladesMenuBlocks } = require("./menus/accoladesMenu");
const { startCommand } = require("./commands/start");
const { forceJoinMiddleware, hasJoined } = require("./middlewares/forceJoin");
const { requireAdmin, isAdmin } = require("./middlewares/isAdmin");
const { requirePremium } = require("./middlewares/isPremium");
const {
  getUser,
  setPremium,
  removePremium,
  getPremiumUsers,
  getAllUserIds,
  getWhatsappSession,
  setWhatsappSession,
} = require("./lib/db");
const { startPairing, restoreAllSessions, logoutSession } = require("./lib/whatsapp");
const { reportError, reportEvent } = require("./lib/diagnostics");

if (!config.BOT_TOKEN) {
  console.error("BOT_TOKEN is missing — set it in .env");
  process.exit(1);
}

const bot = new Telegraf(config.BOT_TOKEN);

// telegramId -> pending action ("pair")
const pending = new Map();

async function gate(ctx) {
  const joined = await hasJoined(ctx);
  if (joined) return true;
  await ctx.telegram.callApi("sendRichMessage", {
    chat_id: ctx.chat.id,
    rich_message: {
      blocks: [
        { type: "heading", text: "Join to continue", size: 2 },
        { type: "paragraph", text: "𐌏 You need to join our channel before you can use this bot." },
        {
          type: "buttons",
          buttons: [
            {
              text: "𐌏 Join Channel",
              url: `https://t.me/${config.FORCE_JOIN_CHANNEL.replace("@", "")}`,
              style: "danger",
            },
            { text: "𐌏 I've Joined", callback_data: "check_joined", style: "success" },
          ],
        },
      ],
    },
  });
  return false;
}

/* ─────────────── commands ─────────────── */

bot.start(forceJoinMiddleware, startCommand);

bot.command("menu", forceJoinMiddleware, async (ctx) => {
  getUser(String(ctx.from.id));
  await showMenu(ctx, mainMenuBlocks());
});

bot.command("ping", async (ctx) => {
  const t0 = Date.now();
  const sent = await ctx.reply("𐌏");
  const ms = Date.now() - t0;
  try {
    await ctx.telegram.deleteMessage(ctx.chat.id, sent.message_id);
  } catch (err) {
    /* ignore */
  }
  await ctx.reply(`𐌏 PONG — ${ms}ms`);
});

bot.command("id", async (ctx) => {
  await ctx.reply(`𐌏 Your ID: \`${ctx.from.id}\``, { parse_mode: "Markdown" });
});

/* ─────────────── pairing ─────────────── */

bot.command("pair", async (ctx) => {
  if (!(await gate(ctx))) return;
  pending.set(String(ctx.from.id), "pair");
  await showMenu(ctx, [
    { type: "heading", text: "𐌏 Pair WhatsApp", size: 3 },
    {
      type: "paragraph",
      text: "Send the number you want to link, with the country code and no + or spaces.\nExample: 2348012345678",
    },
  ]);
});

bot.command("delpair", async (ctx) => {
  if (!(await requirePremium(ctx))) return;
  const id = String(ctx.from.id);
  const session = getWhatsappSession(id);
  if (!session || session.status === "none") {
    await ctx.reply("𐌏 No WhatsApp session to remove.");
    return;
  }
  await logoutSession(id);
  await ctx.reply("𐌏 Session removed. Pair again with /pair.");
});

bot.command("mysat", async (ctx) => {
  const id = String(ctx.from.id);
  const session = getWhatsappSession(id);
  if (!session || session.status === "none") {
    await ctx.reply("𐌏 No session. Pair with /pair.");
    return;
  }
  await ctx.reply(
    `𐌏 Status: ${session.status}\n𐌏 Number: ${session.linked_number || "unknown"}`
  );
});

bot.command("bancheck", async (ctx) => {
  const arg = ctx.message.text.split(/\s+/)[1];
  if (!arg) {
    await ctx.reply("𐌏 Usage: /bancheck 2348012345678");
    return;
  }
  const number = arg.replace(/[^0-9]/g, "");
  if (number.length < 10) {
    await ctx.reply("𐌏 That doesn't look like a number.");
    return;
  }
  try {
    const res = await fetch(`${config.BAN_CHECK_API_URL}/?number=${number}`, { timeout: 20000 });
    const body = await res.json();
    const verdict =
      body?.banned === true || body?.status === "banned"
        ? "BANNED"
        : body?.banned === false || body?.status === "active"
        ? "ACTIVE"
        : JSON.stringify(body).slice(0, 300);
    await ctx.reply(`𐌏 ${number}\n𐌏 ${verdict}`);
  } catch (err) {
    await ctx.reply(`𐌏 Check failed: ${err.message}`);
  }
});

/* ─────────────── owner commands ─────────────── */

bot.command("addprem", async (ctx) => {
  if (!(await requireAdmin(ctx))) return;
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) {
    await ctx.reply("𐌏 Usage: /addprem <telegram_id> [days]");
    return;
  }
  const days = parseInt(ctx.message.text.split(/\s+/)[2], 10);
  const until = Number.isFinite(days) ? new Date(Date.now() + days * 86400000).toISOString() : null;
  setPremium(target, until);
  await ctx.reply(`𐌏 Premium granted to ${target}${until ? ` until ${until.slice(0, 10)}` : " (lifetime)"}.`);
});

bot.command("delprem", async (ctx) => {
  if (!(await requireAdmin(ctx))) return;
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) {
    await ctx.reply("𐌏 Usage: /delprem <telegram_id>");
    return;
  }
  removePremium(target);
  await ctx.reply(`𐌏 Premium removed from ${target}.`);
});

bot.command("admin", async (ctx) => {
  if (!(await requireAdmin(ctx))) return;
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) {
    await ctx.reply("𐌏 Usage: /admin <telegram_id>");
    return;
  }
  require("./lib/db").addExtraAdmin(target);
  await ctx.reply(`𐌏 ${target} is now an admin.`);
});

bot.command("deladmin", async (ctx) => {
  if (!(await requireAdmin(ctx))) return;
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) {
    await ctx.reply("𐌏 Usage: /deladmin <telegram_id>");
    return;
  }
  require("./lib/db").removeExtraAdmin(target);
  await ctx.reply(`𐌏 ${target} is no longer an admin.`);
});

/* ─────────────── callbacks ─────────────── */

bot.action("menu_main", async (ctx) => {
  await ctx.answerCbQuery();
  await showMenu(ctx, mainMenuBlocks());
});

bot.action("owner_menu", async (ctx) => {
  if (!(await requireAdmin(ctx))) return;
  await ctx.answerCbQuery();
  await showMenu(ctx, ownerMenuBlocks());
});

bot.action("user_menu", async (ctx) => {
  await ctx.answerCbQuery();
  await showMenu(ctx, userMenuBlocks());
});

bot.action("accolades", async (ctx) => {
  await ctx.answerCbQuery();
  await showMenu(ctx, accoladesMenuBlocks());
});

bot.action("my_sessions", async (ctx) => {
  await ctx.answerCbQuery();
  const session = getWhatsappSession(String(ctx.from.id));
  await showMenu(ctx, [
    { type: "heading", text: "𐌏 My Sessions", size: 3 },
    {
      type: "paragraph",
      text: session
        ? `𐌏 Status: ${session.status}\n𐌏 Number: ${session.linked_number || "unknown"}`
        : "𐌏 No session yet. Use /pair to link one.",
    },
    {
      type: "buttons",
      buttons: [{ text: "𐌏 Back", callback_data: "user_menu", style: "success" }],
    },
  ]);
});

bot.action("check_joined", async (ctx) => {
  const joined = await hasJoined(ctx);
  if (!joined) {
    await ctx.answerCbQuery("𐌏 Not joined yet.", { show_alert: true });
    return;
  }
  await ctx.answerCbQuery("𐌏 Verified.");
  getUser(String(ctx.from.id));
  await showMenu(ctx, mainMenuBlocks());
});

bot.action("list_premium", async (ctx) => {
  if (!(await requireAdmin(ctx))) return;
  await ctx.answerCbQuery();
  const users = getPremiumUsers();
  const body = users.length
    ? users.map((u) => `𐌏 ${u.telegram_id}${u.premium_until ? ` — ${u.premium_until.slice(0, 10)}` : ""}`).join("\n")
    : "𐌏 Nobody has premium right now.";
  await showMenu(ctx, [
    { type: "heading", text: "𐌏 Premium List", size: 3 },
    { type: "paragraph", text: body },
    {
      type: "buttons",
      buttons: [{ text: "𐌏 Back", callback_data: "owner_menu", style: "success" }],
    },
  ]);
});

bot.action("broadcast", async (ctx) => {
  if (!(await requireAdmin(ctx))) return;
  await ctx.answerCbQuery();
  pending.set(String(ctx.from.id), "broadcast");
  await ctx.reply("𐌏 Send the message to broadcast now.");
});

/* ─────────────── free text ─────────────── */

bot.on("text", async (ctx) => {
  const id = String(ctx.from.id);
  const action = pending.get(id);
  if (!action) return;

  if (action === "broadcast") {
    if (!isAdmin(id)) {
      pending.delete(id);
      return;
    }
    pending.delete(id);
    const ids = getAllUserIds();
    let sent = 0;
    for (const target of ids) {
      try {
        await ctx.telegram.sendMessage(target, ctx.message.text);
        sent++;
      } catch (err) {
        /* user blocked the bot */
      }
    }
    await ctx.reply(`𐌏 Broadcast sent to ${sent}/${ids.length}.`);
    return;
  }

  if (action === "pair") {
    pending.delete(id);
    const number = ctx.message.text.replace(/[^0-9]/g, "");
    if (number.length < 10) {
      await ctx.reply("𐌏 Invalid number. Try /pair again.");
      return;
    }

    await ctx.reply("𐌏 Requesting a pairing code...");
    try {
      const code = await startPairing(id, number, {
        onPaired: async (telegramId) => {
          try {
            await bot.telegram.sendMessage(telegramId, "𐌏 WhatsApp linked successfully.");
          } catch (err) {
            /* ignore */
          }
        },
        onLoggedOut: async (telegramId) => {
          try {
            await bot.telegram.sendMessage(telegramId, "𐌏 Session logged out. Pair again with /pair.");
          } catch (err) {
            /* ignore */
          }
        },
      });

      setWhatsappSession(id, { status: "pairing", linked_number: number });
      await ctx.reply(
        `𐌏 Pairing code: ${code}\n\nOpen WhatsApp → Linked devices → Link with phone number, then enter it. It expires fast.`
      );
    } catch (err) {
      await ctx.reply(`𐌏 Pairing failed: ${err.message}`);
    }
  }
});

/* ─────────────── errors ─────────────── */

bot.catch((err, ctx) => {
  reportError("telegram", err, `update=${ctx.updateType}`);
  ctx.reply("𐌏 Something broke. The owner has been notified.").catch(() => {});
});

process.on("unhandledRejection", (err) => reportError("unhandledRejection", err));
process.on("uncaughtException", (err) => reportError("uncaughtException", err));

/* ─────────────── boot ─────────────── */

(async () => {
  await bot.launch();
  console.log("[BOT] TOAA is up.");
  reportEvent("bot", "TOAA started", "info", false);

  try {
    await restoreAllSessions({
      onLoggedOut: async (telegramId) => {
        try {
          await bot.telegram.sendMessage(telegramId, "𐌏 Session logged out. Pair again with /pair.");
        } catch (err) {
          /* ignore */
        }
      },
    });
  } catch (err) {
    reportError("startup-restore", err);
  }
})();

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));