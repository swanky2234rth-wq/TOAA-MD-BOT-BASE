const { isPremium } = require("../lib/db");
const { isAdmin } = require("./isAdmin");

/**
 * Guard for a specific button/action. Call this at the top of any
 * callback_query handler (or command) that should be premium-only.
 * Returns true if allowed to proceed, false if it blocked.
 * Admins/owners always pass — they're treated as automatically premium.
 *
 * Denial is alert-only, no card message — keeps the chat clean.
 */
async function requirePremium(ctx) {
  const telegramId = String(ctx.from.id);

  if (isAdmin(telegramId) || isPremium(telegramId)) return true;

  const msg = "𐌏 Premium feature — contact the owner to get access.";
  if (ctx.callbackQuery) {
    await ctx.answerCbQuery(msg, { show_alert: true });
  } else {
    await ctx.reply(msg);
  }

  return false;
}

module.exports = { requirePremium };