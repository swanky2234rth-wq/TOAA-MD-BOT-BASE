const config = require("../config");
const { getExtraAdmins } = require("../lib/db");

function isAdmin(telegramId) {
  const id = String(telegramId);
  return config.ADMIN_IDS.includes(id) || getExtraAdmins().includes(id);
}

/**
 * Guard for admin-only actions (Owner Menu, /addprem, etc).
 * Returns true if allowed to proceed, false if it blocked.
 *
 * Denial is alert-only, no card message — keeps the chat clean.
 */
async function requireAdmin(ctx) {
  const telegramId = String(ctx.from.id);

  if (isAdmin(telegramId)) return true;

  const msg = "𐌏 Admins only.";
  if (ctx.callbackQuery) {
    await ctx.answerCbQuery(msg, { show_alert: true });
  } else {
    await ctx.reply(msg);
  }

  return false;
}

module.exports = { isAdmin, requireAdmin };