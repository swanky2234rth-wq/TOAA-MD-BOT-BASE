const { showMenu } = require("../lib/menuManager");
const { mainMenuBlocks } = require("../menus/mainMenu");
const { getUser } = require("../lib/db");

async function startCommand(ctx) {
  getUser(String(ctx.from.id)); // create user row if new
  await showMenu(ctx, mainMenuBlocks());
}

module.exports = { startCommand };
