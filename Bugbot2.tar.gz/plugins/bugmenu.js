'use strict';
const settings = require('../settings');

const MARK = '℘';
const RULE = '──────────────────────';
const MENU_IMG = 'https://i.ibb.co/qvf1WhD/IMG-9635.jpg';

const FU = 0x1D63C, FL = 0x1D656, FD = 0x1D7EC;
function typed(s) {
  return String(s).replace(/[A-Za-z0-9]/g, (c) => {
    const p = c.charCodeAt(0);
    if (p >= 65 && p <= 90) return String.fromCodePoint(FU + p - 65);
    if (p >= 97 && p <= 122) return String.fromCodePoint(FL + p - 97);
    return String.fromCodePoint(FD + p - 48);
  });
}

const SECTIONS = [
  ['freeze', [
    ['freeze droid', 'freeze-droid'],
    ['freeze ios', 'freeze-ios'],
    ['lag', 'lag'],
    ['delay', 'delay'],
    ['spam', 'spam']
  ]],
  ['payloads', [
    ['order bug', 'order-bug'],
    ['newsletter', 'newsletter'],
    ['location', 'location'],
    ['sticker', 'sticker'],
    ['status mention', 'status-mention'],
    ['doc crash', 'doc-crash'],
    ['flow response', 'flow'],
    ['pairing loop', 'pairing']
  ]],
  ['groups', [
    ['lock group', 'lockgroup'],
    ['ban group', 'bangroup'],
    ['tag all', 'tagall']
  ]]
];

module.exports = {
  name: 'bugmenu',
  version: '2.1',
  author: 'swanky',

  commands: {
    bugmenu: {
      category: 'bug',
      handler: async (conn, m, args, ctx) => {
        const p = (ctx && ctx.prefix) || settings.DEFAULT_PREFIX || '.';

        const lines = [
          `${MARK} ${RULE} ${MARK}`,
          `       ${typed('TOAA')}`,
          `    ${typed('BUG CONSOLE')}`,
          `${MARK} ${RULE} ${MARK}`,
          ''
        ];

        for (const [title, items] of SECTIONS) {
          lines.push(`${MARK}  ${typed(title)}`, '');
          for (const [label, cmd] of items) {
            lines.push(`      ${typed(label)}`, `      ${p}${cmd}`, '');
          }
        }

        lines.push(
          `${MARK} ${RULE} ${MARK}`,
          `   ${typed('usage')}  ${p}<cmd> <number | group link>`,
          '',
          `   ${typed('rounds')}  ${p}lag <number> 40`,
          '',
          `   ${typed('wait 5 minutes between payloads')}`,
          `${MARK} ${RULE} ${MARK}`
        );

        await conn.sendMessage(
          m.key.remoteJid,
          { image: { url: MENU_IMG }, caption: lines.join('\n') },
          { quoted: m }
        );
      }
    }
  }
};