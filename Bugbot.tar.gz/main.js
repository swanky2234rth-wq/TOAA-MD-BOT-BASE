'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const settings = require('./settings');
const { applyFont, FONT_COUNT } = require('./helper/fonts');
const {
  proto,
  generateWAMessageFromContent,
  generateWAMessage,
  prepareWAMessageMedia,
  jidNormalizedUser,
  downloadContentFromMessage
} = require('@whiskeysockets/baileys');

// ─── Number helpers ─────────────────────────────────────────────────────────
function rawNumber(v) {
  if (!v) return '';
  return String(v).split('@')[0].split(':')[0].replace(/\D/g, '');
}
const normalizeNumber = rawNumber;
const cleanJidNumber = rawNumber;
const fromJid = (n) => `${rawNumber(n)}@s.whatsapp.net`;
const getRawId = rawNumber;

// ─── Persistent stores ──────────────────────────────────────────────────────
const bannedUsers = new Set();
const sudoUsers = new Set();

function readJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch { return fallback; }
}
function writeJson(file, data) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (e) { console.error('[STORE]', e.message); }
}

function loadSudo() {
  for (const n of readJson(settings.SUDO_DB, [])) {
    const num = rawNumber(n);
    if (num) sudoUsers.add(num);
  }
}
function addSudo(num) { const n = rawNumber(num); if (n) { sudoUsers.add(n); writeJson(settings.SUDO_DB, [...sudoUsers]); } }
function delSudo(num) { const n = rawNumber(num); if (n) { sudoUsers.delete(n); writeJson(settings.SUDO_DB, [...sudoUsers]); } }
loadSudo();

const premiumUsers = new Set((readJson(settings.PREMIUM_DB, []) || []).map(rawNumber).filter(Boolean));
for (const n of settings.PREMIUM_USERS || []) premiumUsers.add(rawNumber(n));
const isPremium = (n) => premiumUsers.has(rawNumber(n));
function addPremium(n) { const x = rawNumber(n); if (x) { premiumUsers.add(x); writeJson(settings.PREMIUM_DB, [...premiumUsers]); } }
function delPremium(n) { const x = rawNumber(n); if (x) { premiumUsers.delete(x); writeJson(settings.PREMIUM_DB, [...premiumUsers]); } }

// ─── Per-session user settings ──────────────────────────────────────────────
function loadUserSettings(sessionName) {
  const all = readJson(settings.USERSETTINGS_DB, {});
  return all[sessionName] || { prefix: settings.DEFAULT_PREFIX, mode: 'public' };
}
function saveUserSettings(sessionName, data) {
  const all = readJson(settings.USERSETTINGS_DB, {});
  all[sessionName] = { ...(all[sessionName] || {}), ...data };
  writeJson(settings.USERSETTINGS_DB, all);
}
function getSessionSetting(sessionName, key, fallback) {
  const v = loadUserSettings(sessionName)[key];
  return v === undefined ? fallback : v;
}
function setSessionSetting(sessionName, key, value) {
  saveUserSettings(sessionName, { [key]: value });
}

// ─── Command registry ───────────────────────────────────────────────────────
const COMMANDS = {};
function registerCmd(name, category, handler) {
  if (typeof category === 'function') { handler = category; category = 'utilities'; }
  COMMANDS[name] = { handler, category };
}

// ─── Reply helpers ──────────────────────────────────────────────────────────
async function fReply(conn, m, text, sessionName) {
  const f = getSessionSetting(sessionName, 'font', 1);
  const out = f > 1 ? applyFont(text, f) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function newsletterReply(conn, m, text, sessionName) {
  await fReply(conn, m, text, sessionName);
}
const fReplyWithFooter = newsletterReply;
async function plainReply(conn, m, text) {
  await conn.sendMessage(m.key.remoteJid, { text }, { quoted: m });
}
async function successReply(conn, m, text, sessionName) {
  await fReply(conn, m, text.includes('\n') ? text : `*_${text}_*`, sessionName);
}
const successReplyWithFooter = successReply;
async function errorReply(conn, m, text, sessionName) {
  await fReply(conn, m, text.includes('\n') ? `۞ ${text}` : `*_۞ ${text}_*`, sessionName);
}
async function unauthorizedReply(conn, m, sessionName) {
  await fReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', sessionName);
}
async function botAdminRequiredReply(conn, m, sessionName) {
  await fReply(conn, m, '*_۞ 𝙱𝚘𝚝 𝙼𝚞𝚜𝚝 𝙱𝚎 𝙰𝚗 𝙰𝚍𝚖𝚒𝚗_*', sessionName);
}
async function smartReply(conn, m, text, sessionName) {
  if (text.includes('\n')) return plainReply(conn, m, text);
  return fReply(conn, m, text, sessionName);
}
const successSmartReply = smartReply;
const errorSmartReply = smartReply;

// ─── Message readers ────────────────────────────────────────────────────────
const getQuotedCtx = (m) => m.message?.extendedTextMessage?.contextInfo || null;
const getQuotedMsg = (m) => getQuotedCtx(m)?.quotedMessage || null;
const getMentioned = (m) => getQuotedCtx(m)?.mentionedJid || [];

function getMsgText(m) {
  return (
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    m.message?.documentMessage?.caption ||
    m.message?.buttonsResponseMessage?.selectedButtonId ||
    m.message?.templateButtonReplyMessage?.selectedId ||
    m.message?.listResponseMessage?.singleSelectReply?.selectedRowId ||
    ''
  );
}

function resolveTarget(m, args) {
  const ctx = getQuotedCtx(m);
  if (ctx?.participant) return ctx.participant;
  if (ctx?.remoteJid && !ctx.remoteJid.endsWith('@g.us')) return ctx.remoteJid;
  const men = getMentioned(m);
  if (men.length) return men[0];
  if (args?.[0]) {
    const n = rawNumber(args[0]);
    if (n) return fromJid(n);
  }
  return null;
}

function getMediaType(msg) {
  if (!msg) return null;
  for (const k of ['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage']) {
    if (msg[k]) return k.replace('Message', '');
  }
  return null;
}

async function downloadMedia(node, type) {
  const stream = await downloadContentFromMessage(node, type);
  const chunks = [];
  for await (const c of stream) chunks.push(c);
  return Buffer.concat(chunks);
}

// ─── Group checks ───────────────────────────────────────────────────────────
async function getGroupAdmins(conn, jid) {
  const meta = await conn.groupMetadata(jid);
  return meta.participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.id);
}
async function isGroupAdmin(conn, jid, participant) {
  const admins = await getGroupAdmins(conn, jid);
  return admins.some(a => rawNumber(a) === rawNumber(participant));
}
async function isBotAdmin(conn, jid) {
  try {
    const admins = await getGroupAdmins(conn, jid);
    return admins.some(a => rawNumber(a) === rawNumber(conn.user.id));
  } catch { return false; }
}
async function checkGroupAdmins(conn, jid, participant) {
  return { isAdmin: await isGroupAdmin(conn, jid, participant), isBotAdmin: await isBotAdmin(conn, jid) };
}
async function requireAdmin(conn, m, jid, participant) {
  return isGroupAdmin(conn, jid, participant);
}
async function requireBotAdmin(conn, jid) {
  return isBotAdmin(conn, jid);
}

// ─── Misc utils ─────────────────────────────────────────────────────────────
function formatUptime(sec) {
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600),
    mn = Math.floor((sec % 3600) / 60), s = Math.floor(sec % 60);
  return [d && `${d}d`, h && `${h}h`, mn && `${mn}m`, `${s}s`].filter(Boolean).join(' ');
}
async function measureSpeed(fn) {
  const t = Date.now();
  await fn();
  return Date.now() - t;
}
function getNewsletterFooter() {
  return { contextInfo: { forwardingScore: 1, isForwarded: true } };
}

// ─── Antilink ───────────────────────────────────────────────────────────────
const LINK_REGEX = /(https?:\/\/)?chat\.whatsapp\.com\/\S+|wa\.me\/\S+/i;
const antilinkWarnings = new Map();
function containsLink(text) { return LINK_REGEX.test(text || ''); }

async function handleAntilink(conn, m, sessionName, senderJid, botNumber) {
  if (getSessionSetting(sessionName, 'antilink', false) !== true) return;
  const text = getMsgText(m);
  if (!containsLink(text)) return;
  if (!(await isBotAdmin(conn, m.key.remoteJid))) return;
  if (await isGroupAdmin(conn, m.key.remoteJid, senderJid)) return;
  try {
    await conn.sendMessage(m.key.remoteJid, { delete: m.key });
    await conn.sendMessage(m.key.remoteJid, {
      text: `۞ @${rawNumber(senderJid)} link removed`,
      mentions: [senderJid]
    });
  } catch (e) { console.log('[ANTILINK]', e.message); }
}

// ─── Antigcm ────────────────────────────────────────────────────────────────
const antigcmSettings = new Map();
const antigcmWarnings = new Map();
const MAX_ANTIGCM_WARNS = 3;

async function handleAntigcm(conn, m, sessionName, senderJid) {
  const jid = m.key.remoteJid;
  const mode = antigcmSettings.get(jid);
  if (!mode) return false;
  const type = m.message ? Object.keys(m.message)[0] : '';
  if (!['messageContextInfo', 'groupStatusMentionMessage'].includes(type)) return false;

  try { await conn.sendMessage(jid, { delete: m.key }); } catch {}

  const key = `${jid}:${rawNumber(senderJid)}`;
  const count = (antigcmWarnings.get(key) || 0) + 1;
  antigcmWarnings.set(key, count);

  if (count >= MAX_ANTIGCM_WARNS) {
    antigcmWarnings.delete(key);
    try {
      await conn.groupParticipantsUpdate(jid, [senderJid], 'remove');
      await conn.sendMessage(jid, { text: `۞ @${rawNumber(senderJid)} removed — status tag`, mentions: [senderJid] });
    } catch (e) { console.log('[ANTIGCM]', e.message); }
  } else {
    await conn.sendMessage(jid, { text: `۞ @${rawNumber(senderJid)} warn ${count}/${MAX_ANTIGCM_WARNS}`, mentions: [senderJid] });
  }
  return true;
}

// ─── Silence ────────────────────────────────────────────────────────────────
const silenced = new Set();
async function handleSilence(conn, m, sessionName, senderJid, botNumber) {
  const jid = m.key.remoteJid;
  if (!silenced.has(jid)) return false;
  if (rawNumber(senderJid) === rawNumber(botNumber)) return false;
  if (await isGroupAdmin(conn, jid, senderJid)) return false;
  try { await conn.sendMessage(jid, { delete: m.key }); } catch {}
  return true;
}

// ─── Status handler ─────────────────────────────────────────────────────────
async function handleStatus(conn, m, sessionName) {
  try {
    if (getSessionSetting(sessionName, 'autoReadStatus', false)) {
      await conn.readMessages([m.key]);
    }
  } catch {}
}

// ─── Plugin loader ──────────────────────────────────────────────────────────
const PLUGINS = new Map();
let totalPluginsCount = 0;

function loadPlugins() {
  const dir = path.join(__dirname, 'plugins');
  if (!fs.existsSync(dir)) { fs.mkdirSync(dir, { recursive: true }); return 0; }
  let count = 0;
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.js'))) {
    try {
      const plugin = require(path.join(dir, file));
      if (!plugin.commands) continue;
      let n = 0;
      for (const [name, data] of Object.entries(plugin.commands)) {
        if (!COMMANDS[name]) {
          COMMANDS[name] = { handler: data.handler, category: data.category || 'plugin' };
          n++;
        }
      }
      PLUGINS.set(plugin.name || file.replace('.js', ''), {
        name: plugin.name || file.replace('.js', ''),
        version: plugin.version || '1.0',
        author: plugin.author || 'Unknown',
        commands: n
      });
      count++;
      console.log(`℘ plugin ${plugin.name} (${n}) ℘`);
    } catch (e) {
      console.error(`℘ plugin fail ${file}: ${e.message} ℘`);
    }
  }
  return count;
}

// ─── Main dispatcher ────────────────────────────────────────────────────────
async function handleMessage(conn, m, sessionName, ownerNumber) {
  try {
    if (!m?.message) return;
    const remoteJid = m.key.remoteJid;
    if (!remoteJid) return;

    if (remoteJid === 'status@broadcast') return handleStatus(conn, m, sessionName);
    if (m.message.ephemeralMessage) m.message = m.message.ephemeralMessage.message;

    const senderJid = m.key.fromMe ? conn.user.id : (m.key.participant || remoteJid);
    const senderNumber = rawNumber(senderJid);
    const botNumber = rawNumber(conn.user.id);
    const ownerRaw = rawNumber(ownerNumber);

    if (bannedUsers.has(senderNumber)) return;

    if (remoteJid.endsWith('@g.us')) {
      if (await handleSilence(conn, m, sessionName, senderJid, botNumber)) return;
      await handleAntilink(conn, m, sessionName, senderJid, botNumber);
      if (await handleAntigcm(conn, m, sessionName, senderJid)) return;
    }

    const userSettings = loadUserSettings(sessionName);
    const prefix = userSettings.prefix || settings.DEFAULT_PREFIX;
    const mode = userSettings.mode || 'public';
    const msgContent = getMsgText(m);

    let isCmd = false, command = '', args = [], text = '';

    if (msgContent.startsWith(prefix)) {
      const body = msgContent.slice(prefix.length).trim();
      const [raw, ...rest] = body.split(' ');
      command = (raw || '').toLowerCase();
      isCmd = true;
      args = rest;
      text = rest.join(' ');
    }

    if (!isCmd) return;

    const storedOwner = rawNumber(userSettings.ownerNumber || '');
    const isSudo = sudoUsers.has(senderNumber);
    const isOwner = !!(
      m.key.fromMe || senderNumber === botNumber || senderNumber === ownerRaw ||
      (storedOwner && senderNumber === storedOwner) || isSudo
    );

    if (mode === 'self' && !isOwner && !isSudo) return;

    const isUserPremium = isPremium(senderNumber);
    let isAdmin = false, botAdmin = false;
    if (remoteJid.endsWith('@g.us')) {
      const a = await checkGroupAdmins(conn, remoteJid, senderJid);
      isAdmin = a.isAdmin; botAdmin = a.isBotAdmin;
    }

    const ctx = {
      prefix, sessionName, senderNumber, botNumber,
      isOwner, isUserPremium, isAdmin, botAdmin, args, command, senderJid
    };

    if (COMMANDS[command]) await COMMANDS[command].handler(conn, m, args, ctx);
  } catch (err) {
    process.stdout.write(`[CASE ERROR] ${err.message}\n`);
  }
}

totalPluginsCount = 0;

module.exports = {
  COMMANDS, PLUGINS, registerCmd, loadPlugins,
  bannedUsers, sudoUsers, addSudo, delSudo,
  isPremium, addPremium, delPremium,
  loadUserSettings, saveUserSettings, getSessionSetting, setSessionSetting,
  fReply, fReplyWithFooter, newsletterReply, plainReply, successReply,
  successReplyWithFooter, errorReply, unauthorizedReply, botAdminRequiredReply,
  smartReply, successSmartReply, errorSmartReply,
  getMsgText, getQuotedCtx, getQuotedMsg, getMentioned, resolveTarget,
  getMediaType, downloadMedia, rawNumber, normalizeNumber, cleanJidNumber,
  fromJid, getRawId, resolveDisplayJid,
  getGroupAdmins, isGroupAdmin, isBotAdmin, checkGroupAdmins,
  requireAdmin, requireBotAdmin, isSessionOwner,
  formatUptime, measureSpeed, getNewsletterFooter,
  LINK_REGEX, containsLink, handleAntilink,
  antigcmSettings, antigcmWarnings, MAX_ANTIGCM_WARNS, handleAntigcm,
  handleSilence, silenced, handleMessage, handleStatus,
  applyFont, FONT_COUNT, getMediaType,
  proto, generateWAMessageFromContent, generateWAMessage,
  prepareWAMessageMedia, jidNormalizedUser, downloadContentFromMessage
};