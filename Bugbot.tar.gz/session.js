'use strict';
const fs = require('fs');
const path = require('path');
const pino = require('pino');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers
} = require('@whiskeysockets/baileys');
const settings = require('./settings');
const main = require('./main');

const LOG = pino({ level: 'silent' });
const ROOT = path.resolve(settings.SESSIONS_DIR || './sessions');
const PAIRED_DB = path.resolve('./database/paired.json');

const live = new Map();   // name -> record
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function dirOf(name) { return path.join(ROOT, name); }
function hasCreds(name) { return fs.existsSync(path.join(dirOf(name), 'creds.json')); }

function readPaired() {
  try { return JSON.parse(fs.readFileSync(PAIRED_DB, 'utf-8')); } catch { return {}; }
}
function writePaired(d) {
  try {
    fs.mkdirSync(path.dirname(PAIRED_DB), { recursive: true });
    fs.writeFileSync(PAIRED_DB, JSON.stringify(d, null, 2));
  } catch (e) { console.error('[PAIRED]', e.message); }
}

function registerPaired(name, meta = {}) {
  const db = readPaired();
  db[name] = { name, createdAt: Date.now(), ...meta };
  writePaired(db);
}
function unregisterPaired(name) {
  const db = readPaired();
  delete db[name];
  writePaired(db);
}
function pairedList() { return Object.values(readPaired()); }
function isRunning(name) { return live.get(name)?.running === true; }
function getSocket(name) { return live.get(name)?.sock || null; }

// ─── group greetings ───────────────────────────────────────────────────────
function greeting(file, fallback) {
  try {
    const db = JSON.parse(fs.readFileSync(path.resolve(file), 'utf-8'));
    return db.default || fallback;
  } catch { return fallback; }
}

async function onParticipants(sock, name, ev) {
  if (!ev?.id || !ev.participants?.length) return;
  if (ev.action !== 'add' && ev.action !== 'remove') return;
  try {
    if (!main.getSessionSetting(name, 'welcome', true)) return;
    const meta = await sock.groupMetadata(ev.id);
    const who = ev.participants[0];
    const num = main.rawNumber(who);
    const tpl = ev.action === 'add'
      ? greeting('./database/welcome.json', '۞ Welcome @user to *@group*')
      : greeting('./database/goodbye.json', '۞ @user left *@group*');
    const text = tpl.replace('@user', `@${num}`).replace('@group', meta.subject);
    await sock.sendMessage(ev.id, { text, mentions: [who] });
  } catch (e) { console.log('[GREET]', e.message); }
}

// ─── start ─────────────────────────────────────────────────────────────────
async function startWASession(name, phone, ownerTg, onCode) {
  if (live.get(name)?.running) return live.get(name);

  fs.mkdirSync(dirOf(name), { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(dirOf(name));
  const { version } = await fetchLatestBaileysVersion();

  const rec = { name, phone, ownerTg, running: true, retries: 0, sock: null };
  live.set(name, rec);

  const sock = makeWASocket({
    version,
    logger: LOG,
    auth: state,
    printQRInTerminal: false,
    browser: Browsers.ubuntu('TOAA'),
    syncFullHistory: false,
    markOnlineOnConnect: false
  });
  rec.sock = sock;

  sock.ev.on('creds.update', saveCreds);

  // pairing code for a fresh, unregistered session
  if (!state.creds.registered && onCode) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(main.rawNumber(phone), 'TOAAMD01');
        await onCode(code);
      } catch (e) {
        console.log('[PAIR]', e.message);
        try { await onCode(null, e.message); } catch {}
      }
    }, 1500);
  }

  sock.ev.on('connection.update', async (u) => {
    const { connection, lastDisconnect } = u;

    if (connection === 'open') {
      rec.running = true;
      rec.retries = 0;
      registerPaired(name, { phone: main.rawNumber(phone), ownerTg });
      console.log(`℘ session online: ${name} ℘`);
    }

    if (connection === 'close') {
      rec.running = false;
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code === DisconnectReason.loggedOut) {
        console.log(`℘ logged out: ${name} ℘`);
        unregisterPaired(name);
        live.delete(name);
        return;
      }
      if (rec.retries >= 2) {
        console.log(`℘ gave up: ${name} ℘`);
        live.delete(name);
        return;
      }
      rec.retries++;
      const wait = rec.retries === 1 ? 5000 : 10000;
      console.log(`℘ reconnect ${name} in ${wait}ms ℘`);
      await sleep(wait);
      try { await startWASession(name, phone, ownerTg, null); } catch (e) { console.log('[RETRY]', e.message); }
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) {
      try { await sock.sendPresenceUpdate('available'); } catch {}
      await main.handleMessage(sock, m, name, phone);
    }
  });

  sock.ev.on('group-participants.update', (ev) => onParticipants(sock, name, ev));

  return rec;
}

async function stopSession(name) {
  const rec = live.get(name);
  if (!rec) return false;
  try { await rec.sock?.logout?.(); } catch {}
  try { rec.sock?.end?.(); } catch {}
  live.delete(name);
  return true;
}

async function reloadExistingSessions() {
  fs.mkdirSync(ROOT, { recursive: true });
  const db = readPaired();
  for (const [name, meta] of Object.entries(db)) {
    if (!hasCreds(name)) continue;
    try {
      await startWASession(name, meta.phone, meta.ownerTg, null);
      console.log(`℘ resumed ${name} ℘`);
      await sleep(1200);
    } catch (e) { console.log('[RESUME]', name, e.message); }
  }
}

module.exports = {
  startWASession, stopSession, reloadExistingSessions,
  registerPaired, unregisterPaired, pairedList,
  isRunning, getSocket, live, hasCreds, dirOf
};