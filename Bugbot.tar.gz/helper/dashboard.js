'use strict';

const { sw, rule, D } = require('./swanky');

const OWNER_ID = String(process.env.OWNER_ID || '7046020356');

const PENDING = new Map();
const CFG = { rounds: 30, delay: 600, lockRounds: 75, maintenance: false };

const KEY_LABEL = {
  home: sw('home'),
  bugs: sw('bugs'),
  sessions: sw('sessions'),
  pair: sw('pair'),
  users: sw('users'),
  broadcast: sw('broadcast'),
  settings: sw('settings'),
  stats: sw('stats'),
  restart: sw('restart'),
  tools: sw('tools'),
  help: sw('help')
};
const REVERSE = Object.fromEntries(Object.entries(KEY_LABEL).map(([k, v]) => [v, k]));

const isOwner = (id) => String(id) === OWNER_ID;

function fixed(keys) {
  const rows = [];
  for (let i = 0; i < keys.length; i += 2) {
    rows.push(keys.slice(i, i + 2).map((k) => ({ text: KEY_LABEL[k] })));
  }
  return {
    reply_markup: {
      keyboard: rows,
      resize_keyboard: true,
      is_persistent: true,
      input_field_placeholder: `${D} ${sw('tap a button')}`
    }
  };
}

function kb(rows) {
  return { reply_markup: { inline_keyboard: rows.map((r) => r.map((b) => ({ text: b.t, callback_data: b.cb }))) } };
}

const OWNER_KEYS = ['bugs', 'sessions', 'pair', 'users', 'broadcast', 'settings', 'stats', 'restart', 'help'];
const USER_KEYS = ['bugs', 'sessions', 'pair', 'tools', 'help'];

/* ---------------- screens ---------------- */
const SCREENS = {
  home: (owner) => ({
    text: [
      rule(20), sw('toaa bugbot'), sw('whatsapp bug console'), rule(20), '',
      `${D} ${sw('owner')} ${D} swanky`,
      owner ? `${D} ${sw('you are owner')}` : `${D} ${sw('welcome')}`,
      '',
      sw('the keyboard below never leaves')
    ].join('\n'),
    rows: owner
      ? [[{ t: sw('bugs'), cb: 'nav:bugs' }, { t: sw('sessions'), cb: 'nav:sessions' }], [{ t: sw('owner panel'), cb: 'nav:panel' }]]
      : [[{ t: sw('bugs'), cb: 'nav:bugs' }], [{ t: sw('pair'), cb: 'nav:pair' }]]
  }),

  bugs: () => ({
    text: [rule(20), sw('bugs'), rule(20), '', `${D} ${sw('toaa freeze')}`, `${D} ${sw('ios freeze')}`, `${D} ${sw('gc ban')}`, `${D} ${sw('lock group')}`, '', sw('tap a bug, then a session')].join('\n'),
    rows: [
      [{ t: sw('toaa freeze'), cb: 'bug:toaa' }, { t: sw('ios freeze'), cb: 'bug:ios' }],
      [{ t: sw('gc ban'), cb: 'bug:gcban' }, { t: sw('lock group'), cb: 'bug:lockgroup' }],
      [{ t: sw('back'), cb: 'nav:home' }]
    ]
  }),

  tools: () => ({
    text: [rule(20), sw('tools'), rule(20), '', `${D} ${sw('ping')}`, `${D} ${sw('runtime')}`, '', sw('tap one')].join('\n'),
    rows: [[{ t: sw('ping'), cb: 'tool:ping' }, { t: sw('runtime'), cb: 'tool:runtime' }], [{ t: sw('back'), cb: 'nav:home' }]]
  }),

  help: () => ({
    text: [rule(20), sw('help'), rule(20), '', `${D} ${sw('everything is tap only')}`, `${D} ${sw('bugs need a group link or id')}`, `${D} ${sw('cancel')} ${D} ${sw('/cancel')}`, '', rule(20)].join('\n'),
    rows: [[{ t: sw('back'), cb: 'nav:home' }]]
  }),

  /* -------- owner only -------- */
  panel: () => ({
    text: [rule(20), sw('owner panel'), rule(20), '', `${D} ${sw('id')} ${OWNER_ID}`, `${D} ${sw('full control')}`, '', sw('pick a section')].join('\n'),
    rows: [
      [{ t: sw('users'), cb: 'own:users' }, { t: sw('stats'), cb: 'own:stats' }],
      [{ t: sw('broadcast'), cb: 'own:broadcast' }, { t: sw('settings'), cb: 'own:settings' }],
      [{ t: sw('restart'), cb: 'own:restart' }],
      [{ t: sw('back'), cb: 'nav:home' }]
    ]
  }),

  settings: () => ({
    text: [
      rule(20), sw('settings'), rule(20), '',
      `${D} ${sw('ban rounds')} ${D} ${CFG.rounds}`,
      `${D} ${sw('ban delay')} ${D} ${CFG.delay}ms`,
      `${D} ${sw('lock rounds')} ${D} ${CFG.lockRounds}`,
      `${D} ${sw('maintenance')} ${D} ${CFG.maintenance ? sw('on') : sw('off')}`,
      '', rule(20)
    ].join('\n'),
    rows: [
      [{ t: '-', cb: 'cfg:rounds:-' }, { t: '+', cb: 'cfg:rounds:+' }],
      [{ t: '-', cb: 'cfg:delay:-' }, { t: '+', cb: 'cfg:delay:+' }],
      [{ t: '-', cb: 'cfg:lockRounds:-' }, { t: '+', cb: 'cfg:lockRounds:+' }],
      [{ t: sw('toggle maintenance'), cb: 'cfg:maintenance' }],
      [{ t: sw('back'), cb: 'nav:panel' }]
    ]
  })
};

module.exports = function mount(bot, deps = {}) {
  const listSessions = deps.listSessions || (() => []);
  const listUsers = deps.listUsers || (() => []);
  const onBug = deps.onBug || (async () => {});
  const onRestart = deps.onRestart || (() => process.exit(0));

  const send = async (chatId, key, owner, msgId) => {
    const s = SCREENS[key](owner);
    const extra = kb(s.rows);
    if (msgId) {
      try {
        await bot.editMessageText(s.text, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', ...extra });
        return;
      } catch (_) {}
    }
    await bot.sendMessage(chatId, s.text, { parse_mode: 'HTML', ...extra });
  };

  const install = async (chatId, owner) => {
    await bot.sendMessage(chatId, `${D} ${sw('keyboard fixed')}`, { parse_mode: 'HTML', ...fixed(owner ? OWNER_KEYS : USER_KEYS) });
  };

  bot.onText(/^\/(start|menu)$/, async (msg) => {
    const owner = isOwner(msg.from.id);
    await install(msg.chat.id, owner);
    await send(msg.chat.id, 'home', owner);
  });

  /* -------- fixed keyboard taps arrive as plain text -------- */
  bot.on('message', async (msg) => {
    const text = (msg.text || '').trim();
    if (!text || text.startsWith('/')) return;

    const p = PENDING.get(msg.from.id);
    if (p && p.kind === 'target') {
      PENDING.delete(msg.from.id);
      return onBug(msg.chat.id, p.action, p.sessionId, text, isOwner(msg.from.id));
    }
    if (p && p.kind === 'broadcast') {
      PENDING.delete(msg.from.id);
      return deps.onBroadcast ? deps.onBroadcast(text, msg.chat.id) : bot.sendMessage(msg.chat.id, `${D} ${sw('no broadcast hook')}`);
    }

    const key = REVERSE[text];
    if (!key) return;
    const owner = isOwner(msg.from.id);
    if (['users', 'broadcast', 'settings', 'stats', 'restart'].includes(key) && !owner) {
      return bot.sendMessage(msg.chat.id, `${D} ${sw('owner only')}`);
    }
    if (key === 'users') return send(msg.chat.id, 'panel', owner);
    if (key === 'broadcast') {
      PENDING.set(msg.from.id, { kind: 'broadcast' });
      return bot.sendMessage(msg.chat.id, `${D} ${sw('send the broadcast text')}`);
    }
    if (key === 'settings') return send(msg.chat.id, 'settings', owner);
    if (key === 'stats') {
      const m = process.memoryUsage();
      const body = [
        rule(20), sw('stats'), rule(20), '',
        `${D} ${sw('sessions')} ${D} ${(listSessions() || []).length}`,
        `${D} ${sw('users')} ${D} ${(listUsers() || []).length}`,
        `${D} ${sw('uptime')} ${D} ${Math.floor(process.uptime())}s`,
        `${D} ${sw('rss')} ${D} ${Math.round(m.rss / 1048576)}mb`,
        '', rule(20)
      ].join('\n');
      return bot.sendMessage(msg.chat.id, body, { parse_mode: 'HTML', ...kb([[{ t: sw('back'), cb: 'nav:panel' }]]) });
    }
    if (key === 'restart') {
      await bot.sendMessage(msg.chat.id, `${D} ${sw('restarting')}`);
      return onRestart();
    }
    if (key === 'home') return send(msg.chat.id, 'home', owner);
    return send(msg.chat.id, key, owner);
  });

  /* -------- inline taps -------- */
  bot.on('callback_query', async (q) => {
    const chatId = q.message.chat.id;
    const msgId = q.message.message_id;
    const data = q.data;
    const owner = isOwner(q.from.id);
    bot.answerCallbackQuery(q.id).catch(() => {});

    if (data.startsWith('nav:')) {
      const key = data.slice(4);
      if (key === 'panel' && !owner) return bot.sendMessage(chatId, `${D} ${sw('owner only')}`);
      return send(chatId, key, owner, msgId);
    }

    if (data.startsWith('own:')) {
      if (!owner) return bot.sendMessage(chatId, `${D} ${sw('owner only')}`);
      const sub = data.slice(4);
      if (sub === 'users') {
        const users = listUsers() || [];
        if (!users.length) return bot.editMessageText(`${D} ${sw('no users yet')}`, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', ...kb([[{ t: sw('back'), cb: 'nav:panel' }]]) });
        const rows = users.slice(0, 40).map((u) => [{ t: `${u.sudo ? '℘' : '·'} ${u.id}`, cb: `usr:${u.id}` }]);
        rows.push([{ t: sw('back'), cb: 'nav:panel' }]);
        return bot.editMessageText(`${rule(20)}\n${sw('users')}\n${rule(20)}`, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', ...kb(rows) });
      }
      if (sub === 'broadcast') {
        PENDING.set(q.from.id, { kind: 'broadcast' });
        return bot.sendMessage(chatId, `${D} ${sw('send the broadcast text')}`);
      }
      if (sub === 'settings') return send(chatId, 'settings', owner, msgId);
      if (sub === 'stats') {
        const m = process.memoryUsage();
        return bot.editMessageText(
          `${rule(20)}\n${sw('stats')}\n${rule(20)}\n\n${D} ${sw('sessions')} ${(listSessions() || []).length}\n${D} ${sw('users')} ${(listUsers() || []).length}\n${D} ${sw('uptime')} ${Math.floor(process.uptime())}s\n${D} ${sw('rss')} ${Math.round(m.rss / 1048576)}mb`,
          { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', ...kb([[{ t: sw('back'), cb: 'nav:panel' }]]) }
        );
      }
      if (sub === 'restart') {
        await bot.sendMessage(chatId, `${D} ${sw('restarting')}`);
        return onRestart();
      }
      return;
    }

    if (data.startsWith('usr:')) {
      if (!owner) return;
      const id = data.slice(4);
      const res = deps.onToggleSudo ? deps.onToggleSudo(id) : null;
      return bot.sendMessage(chatId, `${D} ${sw('toggled')} ${id} ${res ? `${D} ${sw(String(res))}` : ''}`);
    }

    if (data.startsWith('cfg:')) {
      if (!owner) return;
      const [, field, dir] = data.split(':');
      if (field === 'maintenance') CFG.maintenance = !CFG.maintenance;
      else if (dir === '+') CFG[field] = CFG[field] + (field === 'delay' ? 100 : 5);
      else CFG[field] = Math.max(field === 'delay' ? 100 : 5, CFG[field] - (field === 'delay' ? 100 : 5));
      if (deps.onCfgChange) deps.onCfgChange(CFG);
      return send(chatId, 'settings', owner, msgId);
    }

    if (data.startsWith('bug:')) {
      const action = data.slice(4);
      const sessions = listSessions(owner ? null : q.from.id) || [];
      if (!sessions.length) return bot.sendMessage(chatId, `${D} ${sw('no paired session')}`);
      const rows = sessions.slice(0, 20).map((s) => [{ t: sw(String(s.label || s.id)), cb: `sess:${action}:${s.id}` }]);
      rows.push([{ t: sw('back'), cb: 'nav:bugs' }]);
      return bot.editMessageText(`${D} ${sw('pick a session for')} ${sw(action)}`, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', ...kb(rows) });
    }

    if (data.startsWith('sess:')) {
      const [, action, sessionId] = data.split(':');
      PENDING.set(q.from.id, { kind: 'target', action, sessionId });
      return bot.sendMessage(chatId, `${D} ${sw('send the group link or group id')}\n${D} ${sw('cancel')} ${D} ${sw('/cancel')}`);
    }

    if (data === 'tool:ping') return bot.sendMessage(chatId, `${D} ${sw('pong')}`);
    if (data === 'tool:runtime') return bot.sendMessage(chatId, `${D} ${sw('uptime')} ${Math.floor(process.uptime())}s`);
  });

  return { CFG, isOwner };
};