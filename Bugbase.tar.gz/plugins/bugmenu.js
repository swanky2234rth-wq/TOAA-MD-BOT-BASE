'use strict';
const settings = require('../settings');
const { swanky, PH, RULE } = require('../helper/swanky');

const ITEMS = [
  ['toaa freeze', '.freeze'],
  ['fios', '.fios'],
  ['ban group', '.bangroup'],
  ['lock group', '.lockgroup']
];

module.exports = {
  name: 'bugmenu',
  version: '1.0',
  author: 'swanky',

  commands: {
    bugmenu: {
      category: 'bug',
      handler: async (conn, m) => {
        const jid = m.key.remoteJid;
        const body = [
          PH('toaa bug engine'),
          RULE,
          ITEMS.map(([label], i) => `℘ ${i + 1}. ${swanky(label)}`).join('\n'),
          RULE,
          `℘ ${swanky('prefix')} ${settings.DEFAULT_PREFIX}`
        ].join('\n');

        await conn.sendMessage(jid, {
          image: { url: settings.BUG_IMAGE },
          caption: body,
          footer: '℘',
          buttons: ITEMS.map(([label, cmd], i) => ({
            buttonId: cmd,
            buttonText: { displayText: `${i + 1}. ${swanky(label)}` },
            type: 1
          })),
          headerType: 4
        }, { quoted: m });
      }
    }
  }
};