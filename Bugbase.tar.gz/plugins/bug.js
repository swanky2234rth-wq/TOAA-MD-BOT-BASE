'use strict';
const settings = require('../settings');
const bug = require('../helper/bugcore');
const { swanky, PH } = require('../helper/swanky');

const jidOf = (conn, m) => m.key.remoteJid;

module.exports = {
  name: 'bugs',
  version: '1.0',
  author: 'swanky',

  commands: {

    freeze: {
      category: 'bug',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner && !ctx.isUserPremium) {
          return conn.sendMessage(jidOf(conn, m), { text: `℘ ${swanky('access denied')} ℘` }, { quoted: m });
        }
        const jid = jidOf(conn, m);
        await conn.sendMessage(jid, { text: `℘ ${swanky('deploying toaa freeze')} ℘` }, { quoted: m });
        await bug.sendBugImage(conn, jid);
        await bug.toaaFreeze(conn, jid);
        await conn.sendMessage(jid, { text: PH('toaa freeze delivered') }, { quoted: m });
      }
    },

    fios: {
      category: 'bug',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner && !ctx.isUserPremium) {
          return conn.sendMessage(jidOf(conn, m), { text: `℘ ${swanky('access denied')} ℘` }, { quoted: m });
        }
        const jid = jidOf(conn, m);
        const rounds = parseInt(args[0], 10) || settings.FREEZE_ROUNDS;
        await bug.sendBugImage(conn, jid);
        await bug.fiOS(conn, jid, Math.min(rounds, 10));
        await conn.sendMessage(jid, { text: PH('fios delivered') }, { quoted: m });
      }
    },

    lockgroup: {
      category: 'bug',
      handler: async (conn, m, args, ctx) => {
        const jid = jidOf(conn, m);
        if (!ctx.isOwner) {
          return conn.sendMessage(jid, { text: `℘ ${swanky('access denied')} ℘` }, { quoted: m });
        }
        if (!jid.endsWith('@g.us')) {
          return conn.sendMessage(jid, { text: `℘ ${swanky('group only')} ℘` }, { quoted: m });
        }
        await conn.sendMessage(jid, { text: `℘ ${swanky('locking 75x')} ℘` }, { quoted: m });
        await bug.lockGroup(conn, jid, 75);
        await conn.sendMessage(jid, { text: PH('lock_group complete') }, { quoted: m });
      }
    }

  }
};