'use strict';
const fs = require('fs');
const TelegramBot = require('node-telegram-bot-api');
const settings = require('./settings');
const sessions = require('./sessions');
const pad = require('./helper/tgpad');
const { swanky, RULE } = require('./helper/swanky');

const bot = new TelegramBot(settings.TELEGRAM_TOKEN, { polling: true });
const OWNER = String(settings.OWNER_ID);
const pending = new Map(); // tgId -> 'pair' | 'delete' | 'broadcast'
const verified = new Set();

const isOwner = (id) => String(id) === OWNER;
const say = (chat, text, kb) =>
  bot.sendMessage(chat, text, { parse_mode: 'Markdown', reply_markup: kb }).catch(() => {});
const H = (t) => `℘ ${swanky(t)} ℘`;

// ─── force join ────────────────────────────────────────────────────────────
async function joined(userId) {
  if (verified.has(userId) || isOwner(userId)) return true;
  const targets = [];
  if (settings.TG_CHANNEL) targets.push('@' + settings.TG_CHANNEL);
  if (settings.TG_GROUP) targets.push('@' + settings.TG_GROUP);
  if (!targets.length) { verified.add(userId); return true; }

  for (const t of targets) {
    try {
      const m = await bot.getChatMember(t, userId);
      if (!['member', 'administrator', 'creator'].includes(m.status)) return false;
    } catch { /* bot not admin — skip */ }
  }
  verified.add(userId);
  return true;
}

function gate(chat, userId) {
  const rows = [];
  if (settings.TG_LINK) rows.push([{ text: 'channel', url: settings.TG_LINK }]);
  if (settings.TG_GROUP_LINK) rows.push([{ text: 'group', url: settings.TG_GROUP_LINK }]);
  rows.push([{ text: swanky('authorize'), callback_data: 'verify' }]);
  return say(chat, `${H('join first')}\n${RULE}\n${swanky('tap authorize once joined')}`,
    { inline_keyboard: rows });
}

// ─── screens ───────────────────────────────────────────────────────────────
const screen = {
  async status(chat, id) {
    const all = sessions.pairedList();
    const mine = all.filter(s => String(s.ownerTg) === String(id));
    await say(chat, [
      H('status'),
      RULE,
      `${swanky('sessions')}: ${mine.length}`,
      `${swanky('running')}: ${mine.filter(s => sessions.isRunning(s.name)).length}`,
      RULE,
      swanky('engine online')
    ].join('\n'));
  },

  async list(chat, id) {
    const mine = sessions.pairedList().filter(s => String(s.ownerTg) === String(id) || isOwner(id));
    if (!mine.length) return say(chat, `${H('no sessions')}\n${swanky('tap pair to begin')}`);
    const body = mine.map((s, i) =>
      `℘ ${i + 1}. ${swanky(s.phone || s.name)}\n   ${sessions.isRunning(s.name) ? 'online' : 'offline'}`
    ).join('\n');
    await say(chat, `${H('your sessions')}\n${RULE}\n${body}`);
  },

  async panel(chat) {
    await say(chat, [
      H('owner panel'),
      RULE,
      `${swanky('users')}: ${new Set(sessions.pairedList().map(s => s.ownerTg)).size}`,
      `${swanky('sessions')}: ${sessions.pairedList().length}`,
      `${swanky('running')}: ${sessions.pairedList().filter(s => sessions.isRunning(s.name)).length}`,
      RULE,
      swanky('tap the pad below')
    ].join('\n'));
  }
};

// ─── pairing ───────────────────────────────────────────────────────────────
async function doPair(chat, id, input) {
  const phone = String(input || '').replace(/\D/g, '');
  if (phone.length < 8) return say(chat, `${H('bad number')}\n${swanky('send full number with country code')}`);

  const all = sessions.pairedList();
  if (all.length >= (settings.MAX_TOTAL_SESSIONS || 30)) return say(chat, H('server full'));
  const mine = all.filter(s => String(s.ownerTg) === String(id));
  if (mine.length >= (settings.MAX_SESSIONS_PER_USER || 2)) return say(chat, H('limit reached'));

  const name = `session_${id}_${phone}`;
  if (sessions.hasCreds(name) || sessions.isRunning(name)) return say(chat, H('already paired'));

  await say(chat, `${H('requesting code')}\n${swanky(phone)}`);

  try {
    await sessions.startWASession(name, phone, String(id), async (code, err) => {
      if (!code) return say(chat, `${H('pairing failed')}\n${swanky(err || 'retry')}`);
      await say(chat, [
        H('pairing code'),
        RULE,
        `\`${code}\``,
        RULE,
        swanky('whatsapp > linked devices > link with number')
      ].join('\n'));
    });
  } catch (e) {
    await say(chat, `${H('error')}\n${swanky(e.message)}`);
  }
}

async function doDelete(chat, id, input) {
  const phone = String(input || '').replace(/\D/g, '');
  const name = `session_${id}_${phone}`;
  const rec = sessions.live.get(name);
  if (!rec && !sessions.hasCreds(name)) return say(chat, H('not found'));
  await sessions.stopSession(name);
  sessions.unregisterPaired(name);
  try { fs.rmSync(sessions.dirOf(name), { recursive: true, force: true }); } catch {}
  await say(chat, `${H('deleted')}\n${swanky(phone)}`);
}

async function doBroadcast(chat, text) {
  const owners = [...new Set(sessions.pairedList().map(s => s.ownerTg).filter(Boolean))];
  let ok = 0;
  for (const o of owners) {
    try { await bot.sendMessage(o, `${H('broadcast')}\n${RULE}\n${text}`); ok++; } catch {}
  }
  await say(chat, `${H('sent')} ${ok}/${owners.length}`);
}

// ─── commands ──────────────────────────────────────────────────────────────
bot.onText(/^\/start/, async (msg) => {
  const chat = msg.chat.id;
  if (!(await joined(msg.from.id))) return gate(chat, msg.from.id);
  await pad.install(bot, chat, isOwner(msg.from.id));
  await say(chat, `${H('toaa')}\n${RULE}\n${swanky('tap the pad')}\n${swanky('nothing is typed')}`);
});

bot.onText(/^\/pair(?:\s+(.+))?$/, async (msg, match) => {
  const chat = msg.chat.id;
  if (!(await joined(msg.from.id))) return gate(chat, msg.from.id);
  if (!match[1]) { pending.set(msg.from.id, 'pair'); return say(chat, H('send the number')); }
  return doPair(chat, msg.from.id, match[1]);
});

bot.onText(/^\/delpair(?:\s+(.+))?$/, async (msg, match) => {
  const chat = msg.chat.id;
  if (!match[1]) { pending.set(msg.from.id, 'delete'); return say(chat, H('send the number')); }
  return doDelete(chat, msg.from.id, match[1]);
});

bot.onText(/^\/sessions$/, (msg) => screen.list(msg.chat.id, msg.from.id));

bot.onText(/^\/panel$/, async (msg) => {
  if (!isOwner(msg.from.id)) return say(msg.chat.id, H('owner only'));
  await screen.panel(msg.chat.id);
});

bot.onText(/^\/addprem(?:\s+(.+))?$/, async (msg, match) => {
  if (!isOwner(msg.from.id)) return;
  const n = String(match[1] || '').replace(/\D/g, '');
  if (!n) return say(msg.chat.id, H('send a number'));
  require('./main').addPremium(n);
  await say(msg.chat.id, `${H('premium added')} ${swanky(n)}`);
});

bot.onText(/^\/delprem(?:\s+(.+))?$/, async (msg, match) => {
  if (!isOwner(msg.from.id)) return;
  const n = String(match[1] || '').replace(/\D/g, '');
  if (!n) return say(msg.chat.id, H('send a number'));
  require('./main').delPremium(n);
  await say(msg.chat.id, `${H('premium removed')} ${swanky(n)}`);
});

bot.onText(/^\/restart$/, async (msg) => {
  if (!isOwner(msg.from.id)) return;
  await say(msg.chat.id, H('restarting'));
  setTimeout(() => process.exit(0), 800);
});

bot.on('callback_query', async (q) => {
  if (q.data !== 'verify') return;
  const chat = q.message.chat.id;
  bot.answerCallbackQuery(q.id).catch(() => {});
  if (!(await joined(q.from.id))) return say(chat, H('still not joined'));
  await pad.install(bot, chat, isOwner(q.from.id));
  await say(chat, `${H('authorized')}\n${swanky('tap the pad')}`);
});

// ─── pad taps ──────────────────────────────────────────────────────────────
bot.on('message', async (msg) => {
  const chat = msg.chat.id;
  const id = msg.from?.id;
  if (!id || !msg.text || msg.text.startsWith('/')) return;
  if (!(await joined(id))) return gate(chat, id);

  if (await pad.handlePad(bot, msg, {
    onPair: async () => { pending.set(id, 'pair'); await say(chat, H('send the number')); return true; },
    onStatus: async () => { await screen.status(chat, id); return true; },
    onSessions: async () => { await screen.list(chat, id); return true; },
    onDelete: async () => { pending.set(id, 'delete'); await say(chat, H('send the number')); return true; },
    onUsers: async () => {
      const owners = [...new Set(sessions.pairedList().map(s => s.ownerTg))];
      await say(chat, `${H('users')} ${owners.length}\n${owners.map(o => `℘ ${o}`).join('\n')}`);
      return true;
    },
    onStats: async () => { await screen.panel(chat); return true; },
    onBroadcast: async () => { pending.set(id, 'broadcast'); await say(chat, H('send the text')); return true; },
    onConfig: async () => {
      await say(chat, [
        H('config'), RULE,
        `${swanky('prefix')}: ${settings.DEFAULT_PREFIX}`,
        `${swanky('max total')}: ${settings.MAX_TOTAL_SESSIONS}`,
        `${swanky('per user')}: ${settings.MAX_SESSIONS_PER_USER}`,
        `${swanky('rich')}: ${settings.RICH_ENABLED}`
      ].join('\n'));
      return true;
    },
    onRestart: async () => { await say(chat, H('restarting')); setTimeout(() => process.exit(0), 800); return true; }
  })) return;

  const p = pending.get(id);
  if (!p) return;
  pending.delete(id);

  if (p === 'pair') return doPair(chat, id, msg.text);
  if (p === 'delete') return doDelete(chat, id, msg.text);
  if (p === 'broadcast') {
    if (!isOwner(id)) return say(chat, H('owner only'));
    return doBroadcast(chat, msg.text);
  }
});

bot.on('polling_error', (e) => console.log('[TG]', e.message));

console.log('℘ telegram online ℘');

module.exports = bot;