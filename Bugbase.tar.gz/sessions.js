'use strict';

/**
 * sessions.js
 * Session engine. API-compatible with index.js and telegram.js.
 * Custom pairing code is attempted first, then a generated one.
 */

const fs = require('fs');
const path = require('path');
const pino = require('pino');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers
} = require('@whiskeysockets/baileys');
const settings = require('./settings');
const main = require('./main');

const LOG = pino({ level: 'silent' });
const ROOT = path.resolve(settings.SESSIONS_DIR || './sessions');
const PAIRED_DB = path.resolve('./database/paired.json');
const MAX_RETRIES = 5;
const PAIR_DELAY_MS = 3000;

const RAW_PAIRING_CODE = 'ACMETOAA';
const PAIRING_CODE = String(RAW_PAIRING_CODE).toUpperCase().replace(/[^A-Z0-9]/g, '').padEnd(8, 'X').slice(0, 8);

const live = new Map(); // name -> record
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function dirOf(name) { return path.join(ROOT, name); }
function hasCreds(name) { return fs.existsSync(path.join(dirOf(name), 'creds.json')); }
function credsRegistered(name) {
  try {
    return !!JSON.parse(fs.readFileSync(path.join(dirOf(name), 'creds.json'), 'utf-8'))?.registered;
  } catch { return false; }
}
function wipeDir(name) {
  try { fs.rmSync(dirOf(name), { recursive: true, force: true }); } catch {}
}

function readPaired() {
  try { return JSON.parse(fs.readFileSync(PAIRED_DB, 'utf-8')); } catch { return {}; }
}
function writePaired(d) {
  try {
    fs.mkdirSync(path.dirname(PAIRED_DB), { recursive: true });
    fs.writeFileSync(PAIRED_DB, JSON.stringify(d, null, 2));
  } catch (e) { console.error('[PAIRED]', e.message); }
}

function registerPaired(name, meta = {}) {
  const db = readPaired();
  db[name] = { ...(db[name] || {}), name, createdAt: db[name]?.createdAt || Date.now(), ...meta };
  writePaired(db);
}
function unregisterPaired(name) {
  const db = readPaired();
  delete db[name];
  writePaired(db);
}
function pairedList() { return Object.values(readPaired()); }
function isRunning(name) { return live.get(name)?.running === true; }
function getSocket(name) { return live.get(name)?.sock || null; }

// ─── group greetings ───────────────────────────────────────────────────────
function greeting(file, fallback) {
  try {
    const db = JSON.parse(fs.readFileSync(path.resolve(file), 'utf-8'));
    return db.default || fallback;
  } catch { return fallback; }
}

async function onParticipants(sock, name, ev) {
  if (!ev?.id || !ev.participants?.length) return;
  if (ev.action !== 'add' && ev.action !== 'remove') return;
  try {
    if (!main.getSessionSetting(name, 'welcome', true)) return;
    const meta = await sock.groupMetadata(ev.id);
    const who = ev.participants[0];
    const num = main.rawNumber(who);
    const tpl = ev.action === 'add'
      ? greeting('./database/welcome.json', '۞ Welcome @user to *@group*')
      : greeting('./database/goodbye.json', '۞ @user left *@group*');
    const text = tpl.replace('@user', `@${num}`).replace('@group', meta.subject);
    await sock.sendMessage(ev.id, { text, mentions: [who] });
  } catch (e) { console.log('[GREET]', e.message); }
}

// ─── connect (mutates the record in place) ─────────────────────────────────
async function connect(rec) {
  const { name, phone, ownerTg } = rec;

  fs.mkdirSync(dirOf(name), { recursive: true });

  /* A creds.json that never registered will 400 every pairing attempt. */
  if (hasCreds(name) && !credsRegistered(name) && !rec.cleared) {
    rec.cleared = true;
    wipeDir(name);
    fs.mkdirSync(dirOf(name), { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(dirOf(name));
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: LOG,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, LOG)
    },
    printQRInTerminal: false,
    browser: Browsers.ubuntu('TOAA'),
    syncFullHistory: false,
    markOnlineOnConnect: false
  });
  rec.sock = sock;

  sock.ev.on('creds.update', saveCreds);

  // pairing code for a fresh, unregistered session
  if (!state.creds.registered && rec.onCode && !rec.codeSent) {
    rec.codeSent = true;
    setTimeout(async () => {
      const number = main.rawNumber(phone);
      let pairCode;

      try {
        console.log(`[${name}] Requesting custom pairing code for ${number}`);
        pairCode = await sock.requestPairingCode(number, PAIRING_CODE);
      } catch (customErr) {
        console.log(`[${name}] Custom pairing code rejected, falling back:`, customErr.message);
        try {
          pairCode = await sock.requestPairingCode(number);
        } catch (err) {
          console.log('[PAIR]', err.message);
          rec.codeSent = false;
          try { await rec.onCode(null, err.message); } catch {}
          return;
        }
      }

      const pretty = pairCode?.match(/.{1,4}/g)?.join('-') || pairCode;
      rec.code = pretty;
      console.log(`[${name}] Pairing code: ${pretty}`);
      try { await rec.onCode(pretty); } catch {}
    }, PAIR_DELAY_MS);
  }

  sock.ev.on('connection.update', async (u) => {
    const { connection, lastDisconnect } = u;

    if (connection === 'open') {
      rec.running = true;
      rec.retries = 0;
      rec.codeSent = false;
      registerPaired(name, { phone: main.rawNumber(phone), ownerTg });
      console.log(`℘ session online: ${name} ℘`);
      return;
    }

    if (connection === 'close') {
      rec.running = false;
      const code = lastDisconnect?.error?.output?.statusCode;

      if (code === DisconnectReason.loggedOut) {
        console.log(`℘ logged out: ${name} ℘`);
        unregisterPaired(name);
        wipeDir(name);
        live.delete(name);
        return;
      }

      if (rec.stopped) return;

      if (rec.retries >= MAX_RETRIES) {
        console.log(`℘ gave up: ${name} ℘`);
        live.delete(name);
        return;
      }

      rec.retries++;
      const wait = 5000 * rec.retries;
      console.log(`℘ reconnect ${name} in ${wait}ms (${rec.retries}/${MAX_RETRIES}) ℘`);
      await sleep(wait);
      if (rec.stopped) return;
      try { await connect(rec); } catch (e) { console.log('[RETRY]', e.message); }
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) {
      try { await sock.sendPresenceUpdate('available'); } catch {}
      await main.handleMessage(sock, m, name, phone);
    }
  });

  sock.ev.on('group-participants.update', (ev) => onParticipants(sock, name, ev));

  return rec;
}

// ─── public ────────────────────────────────────────────────────────────────
async function startWASession(name, phone, ownerTg, onCode) {
  const existing = live.get(name);
  if (existing?.running) return existing;

  const rec = existing || { name, phone, ownerTg, running: false, retries: 0, sock: null };
  rec.phone = phone || rec.phone;
  rec.ownerTg = ownerTg ?? rec.ownerTg;
  rec.onCode = onCode || rec.onCode || null;
  rec.stopped = false;
  rec.cleared = false;
  if (onCode) rec.codeSent = false;

  live.set(name, rec);
  return connect(rec);
}

async function stopSession(name) {
  const rec = live.get(name);
  if (!rec) return false;
  rec.stopped = true;
  rec.running = false;
  try { await rec.sock?.logout?.(); } catch {}
  try { rec.sock?.end?.(undefined, undefined); } catch {}
  live.delete(name);
  return true;
}

async function reloadExistingSessions() {
  fs.mkdirSync(ROOT, { recursive: true });
  const db = readPaired();
  for (const [name, meta] of Object.entries(db)) {
    if (!hasCreds(name)) continue;
    if (!credsRegistered(name)) continue;
    try {
      await startWASession(name, meta.phone, meta.ownerTg, null);
      console.log(`℘ resumed ${name} ℘`);
      await sleep(1200);
    } catch (e) { console.log('[RESUME]', name, e.message); }
  }
}

module.exports = {
  startWASession, stopSession, reloadExistingSessions,
  registerPaired, unregisterPaired, pairedList,
  isRunning, getSocket, live, hasCreds, dirOf,
  PAIRING_CODE
};