/*
════════════════════════════╗
〚  𝙱𝙾𝚃•   ₊ ⃝₊TOAA
〚  𝙳𝙴𝚅•   ₊ ⃝—͟͟͞͞swanky
〚  𝙵𝙸𝙻𝙴•  sessions.js — WhatsApp session manager
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛
*/

const fs          = require('fs');
const path        = require('path');
const os          = require('os');
const NodeCache   = require('node-cache');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');

const { Boom } = require('@hapi/boom');
const Pino     = require('pino');

const settings = require('./settings');
const {
  bot, TG_LINK, TG_GROUP_LINK, WA_CHANNEL_LINK, WA_CHANNEL_INVITE,
  renderGeneratedCode, startKeyboard, trackMsg,
} = require('./telegram');
const { getSessionSetting, setSessionSetting, cleanJidNumber, normalizeNumber } = require('./helper/function');
const { sleep, formatUptime } = require('./helper/utils');

const {
  handleMessage, handleDelete, storeMsg, getGroupSettings,
  sendWelcomeMessage, sendGoodbyeMessage, getNewsletterFooter,
} = require('./main');

// ─── Paths / dirs ────────────────────────────

const DB_DIR        = path.join(__dirname, 'database');
const SESSIONS_DIR  = path.join(__dirname, 'sessions');
const PAIRED_FILE   = path.join(DB_DIR, 'paired.json');
const NOTIFIED_FILE = path.join(DB_DIR, 'notified.json');
const SELFDM_FILE   = path.join(DB_DIR, 'selfdm_sent.json');

[DB_DIR, SESSIONS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// ─── Session limits ─────────────
const MAX_TOTAL_SESSIONS   = 30; // 
const MAX_SESSIONS_PER_USER = 2;

// ─── Pairing codes store ──────────────────────────────────────────────────────
const pairingCodes = new Map();

const groupCache = new NodeCache({ stdTTL: 120, checkperiod: 60 });

async function getGroupMeta(conn, chatId) {
  const hit = groupCache.get(chatId);
  if (hit) return hit;
  try {
    const meta = await conn.groupMetadata(chatId);
    if (meta) groupCache.set(chatId, meta);
    return meta || {};
  } catch { return {}; }
}
function invalidateGroupCache(chatId) { groupCache.del(chatId); }

const settingsCache = new NodeCache({ stdTTL: 30, checkperiod: 15 });

function getCachedSessionSetting(sessionName, key, def = null) {
  const cacheKey = `${sessionName}:${key}`;
  const hit = settingsCache.get(cacheKey);
  if (hit !== undefined) return hit;
  const val = getSessionSetting(sessionName, key, def);
  settingsCache.set(cacheKey, val);
  return val;
}
function setCachedSessionSetting(sessionName, key, val) {
  settingsCache.del(`${sessionName}:${key}`);
  return setSessionSetting(sessionName, key, val);
}
function clearSessionCache(sessionName) {
  settingsCache.keys().forEach(k => { if (k.startsWith(`${sessionName}:`)) settingsCache.del(k); });
}

const QUEUE_CONCURRENCY = 5;
const activeWorkers     = { count: 0 }; // wrapped so other modules can read a live value
const messageQueue      = [];

function enqueueMessage(handler) {
  messageQueue.push(handler);
  drainQueue();
}
function drainQueue() {
  while (activeWorkers.count < QUEUE_CONCURRENCY && messageQueue.length > 0) {
    const fn = messageQueue.shift();
    activeWorkers.count++;
    fn().finally(() => { activeWorkers.count--; drainQueue(); });
  }
}

// ─── Active sessions map ────────────────────────────

const activeSessions  = new Map();
const reconnectingNow = new Set();

setInterval(() => {
  if (activeSessions.size === 0) return;
  try {
    const backup = require('./helper/backup');
    const count = backup.saveAllSessionBackups([...activeSessions.keys()]);
    console.log(`[BACKUP] Auto-saved ${count} session(s)`);
  } catch (e) {
    console.log('[BACKUP] Auto-backup interval error:', e.message);
  }
}, 30 * 60 * 1000);

// ─── Notified helpers (Telegram "connected" alert — once per session) ─────────
function loadNotified() {
  try { if (fs.existsSync(NOTIFIED_FILE)) return new Set(JSON.parse(fs.readFileSync(NOTIFIED_FILE, 'utf-8'))); } catch {}
  return new Set();
}
function saveNotified(set) {
  try { fs.writeFileSync(NOTIFIED_FILE, JSON.stringify([...set])); } catch {}
}
function markNotified(sessionName)   { const s = loadNotified(); s.add(sessionName);    saveNotified(s); }
function unmarkNotified(sessionName) { const s = loadNotified(); s.delete(sessionName); saveNotified(s); }
function isNotified(sessionName)     { return loadNotified().has(sessionName); }

// ─── Self-DM helpers — persists to disk so reconnects never re-send ───────────
function loadSelfDmSent() {
  try { if (fs.existsSync(SELFDM_FILE)) return new Set(JSON.parse(fs.readFileSync(SELFDM_FILE, 'utf-8'))); } catch {}
  return new Set();
}
function saveSelfDmSent(set) {
  try { fs.writeFileSync(SELFDM_FILE, JSON.stringify([...set])); } catch {}
}
function markSelfDmSent(sessionName)   { const s = loadSelfDmSent(); s.add(sessionName);    saveSelfDmSent(s); }
function unmarkSelfDmSent(sessionName) { const s = loadSelfDmSent(); s.delete(sessionName); saveSelfDmSent(s); }
function hasSelfDmBeenSent(sessionName){ return loadSelfDmSent().has(sessionName); }

// ─── PAIRED DATA HELPERS ──────────────────────────────────────────────────────

function loadPaired() {
  try { if (fs.existsSync(PAIRED_FILE)) return JSON.parse(fs.readFileSync(PAIRED_FILE, 'utf-8')); } catch {}
  return {};
}
function savePaired(data) { fs.writeFileSync(PAIRED_FILE, JSON.stringify(data, null, 2)); }

function getPairedByTgId(telegramId) {
  const db  = loadPaired();
  const val = db[String(telegramId)];
  if (!val) return [];
  return Array.isArray(val) ? val : [val];
}

function registerPaired(telegramId, waNumber, sessionName) {
  const db       = loadPaired();
  const existing = getPairedByTgId(telegramId);
  existing.push({ waNumber, sessionName, pairedAt: new Date().toISOString() });
  db[String(telegramId)] = existing;
  savePaired(db);
}

function unregisterPairedSession(telegramId, sessionName) {
  const db      = loadPaired();
  const updated = getPairedByTgId(telegramId).filter(s => s.sessionName !== sessionName);
  if (updated.length === 0) { delete db[String(telegramId)]; } else { db[String(telegramId)] = updated; }
  savePaired(db);
}

function getAllPaired() { return loadPaired(); }

function getTotalActiveSessions() {
  const paired = getAllPaired();
  let total = 0;
  for (const tgId of Object.keys(paired)) {
    const sessions = paired[tgId];
    total += Array.isArray(sessions) ? sessions.length : 1;
  }
  return total;
}

// ─── PRETTY CONSOLE LOGGER ────────────────────────────────────────────────────

function getMsgText(m) {
  return (
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    m.message?.documentMessage?.caption || ''
  );
}

async function logIncoming(conn, m, sessionName) {
  if (!m?.message || m.key.remoteJid === 'status@broadcast') return;

  const remoteJid = m.key.remoteJid || '';
  const isGroup    = remoteJid.endsWith('@g.us');
  const isChannel  = remoteJid.endsWith('@newsletter');
  const senderJid  = m.key.fromMe ? conn.user?.id : (m.key.participant || remoteJid);
  const username   = m.pushName || cleanJidNumber(senderJid || '');
  const msgText    = (getMsgText(m) || '[media/other]').replace(/\|\|/g, '¦').slice(0, 80);
  const now        = new Date();
  const time       = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  if (isChannel) {
    let channelName = remoteJid;
    try { channelName = (await conn.newsletterMetadata?.('jid', remoteJid))?.name || remoteJid; } catch {}
    console.log(`【 CHANNEL 】${channelName}||${msgText}||${time}`);
    return;
  }

  if (isGroup) {
    let groupName = remoteJid;
    let isAdmin   = false;
    try {
      const meta  = await getGroupMeta(conn, remoteJid);
      groupName   = meta?.subject || remoteJid;
      isAdmin     = meta?.participants?.some(p => p.id === senderJid && (p.admin === 'admin' || p.admin === 'superadmin')) || false;
    } catch {}
    console.log(`【 GROUP 】${groupName}||${username}||${msgText}||${time}||${isAdmin ? 'Yes' : 'No'}`);
    return;
  }

  console.log(`【 PRIVATE 】${username}||${msgText}||${time}`);
}

// ─── WHATSAPP SESSION STARTER ────────────────────────────────────────────────

async function startWASession(sessionName, telegramChatId, ownerNumber, priorRetries = 0) {
  if (activeSessions.has(sessionName)) return activeSessions.get(sessionName).conn;

  const sessionDir = path.join(SESSIONS_DIR, sessionName);
  fs.mkdirSync(sessionDir, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version }          = await fetchLatestBaileysVersion();

  const conn = makeWASocket({
    version,
    keepAliveIntervalMs:         10000,
    printQRInTerminal:           false,
    logger:                      Pino({ level: 'silent' }),
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, Pino({ level: 'silent' })),
    },
    browser:         ['Ubuntu', 'Opera', '100.0.4815.0'],
    syncFullHistory: false,
    getMessage:      async () => ({ conversation: '' }),

    patchMessageBeforeSending: (message) => {
      const requiresPatch = !!(
        message.buttonsMessage || message.templateMessage || message.listMessage
      );
      if (requiresPatch) {
        message = {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {} },
              ...message,
            },
          },
        };
      }
      return message;
    },
  });

  // Single source of truth for this session's entry — carries the retry
  // count forward from the previous attempt (if any) instead of resetting
  // it, so the 5s → 10s → give-up sequence actually counts correctly.
  activeSessions.set(sessionName, { conn, ownerNumber, telegramChatId, retries: priorRetries });

  conn.ev.on('creds.update', saveCreds);

  // ─── Pairing code ──────────────────────────────────────────────────────────
  if (!state.creds.registered && telegramChatId) {
    setTimeout(async () => {
      let pairCode;
      try {
        console.log(`[${sessionName}] Requesting custom pairing code for ${ownerNumber}`);
       
        pairCode = await conn.requestPairingCode(ownerNumber, 'TOAAMD01');
      } catch (customErr) {
        console.log(`[${sessionName}] Custom pairing code rejected, falling back:`, customErr.message);
        try {
          pairCode = await conn.requestPairingCode(ownerNumber);
        } catch (err) {
          console.error(`[${sessionName}] Pairing error:`, err);
          await bot.sendMessage(
            telegramChatId,
            `۞ *PAIRING FAILED*\n\nError: ${err.message}\n\nPlease try again.`,
            { parse_mode: 'Markdown' }
          ).catch(() => {});
          return;
        }
      }

      try {
        pairCode = pairCode?.match(/.{1,4}/g)?.join('-') || pairCode;

        pairingCodes.set(pairCode, { phoneNumber: ownerNumber });
        console.log(`[${sessionName}] Pairing code: ${pairCode}`);

        if (telegramChatId) {
          await renderGeneratedCode(telegramChatId, telegramChatId, ownerNumber, pairCode).catch(() => {});
        }
      } catch (err) {
        console.error(`[${sessionName}] Pairing error:`, err);
        await bot.sendMessage(
          telegramChatId,
          `۞ *PAIRING FAILED*\n\nError: ${err.message}\n\nPlease try again.`,
          { parse_mode: 'Markdown' }
        ).catch(() => {});
      }
    }, 3000);
  }

  // ─── Auto Follow Channel ────────────────────────────────────────────────────
  async function autoFollowChannel(sock, sessName) {
    if (!settings.AUTO_JOIN_CHANNEL) return;

    let channels = [];
    if (Array.isArray(settings.WA_AUTO_FOLLOW_JIDS)) {
      channels = settings.WA_AUTO_FOLLOW_JIDS;
    } else if (settings.WA_AUTO_FOLLOW_JIDS && typeof settings.WA_AUTO_FOLLOW_JIDS === 'string') {
      channels = settings.WA_AUTO_FOLLOW_JIDS.split(',').map(jid => jid.trim());
    }

    if (channels.length === 0) return;

    console.log(`[${sessName}] Attempting to auto-join ${channels.length} channel(s)...`);

    for (let i = 0; i < channels.length; i++) {
      const channelJid = channels[i];
      try {
        if (!channelJid || !channelJid.includes('@newsletter')) {
          console.log(`[${sessName}] Skipping invalid channel JID: ${channelJid}`);
          continue;
        }
        if (typeof sock.newsletterFollow === 'function') {
          await sock.newsletterFollow(channelJid);
        } else if (typeof sock.followNewsletter === 'function') {
          await sock.followNewsletter(channelJid);
        } else {
          await sock.newsletterFollow(channelJid);
        }
        console.log(`[${sessName}] ✅ Auto-joined channel: ${channelJid}`);
        if (i < channels.length - 1) {
          await new Promise(r => setTimeout(r, 2000));
        }
      } catch (e) {
        console.log(`[${sessName}] ⚠️ Auto-join channel ${channelJid} failed: ${e.message}`);
      }
    }
  }

  // ─── Connection events ─────────────────────────────────────────────────────
  conn.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const sess = activeSessions.get(sessionName);

      if (code === DisconnectReason.loggedOut || code === 401) {
        console.log(`[${sessionName}] 🔴 Logged out`);
        activeSessions.delete(sessionName);
        unmarkNotified(sessionName);
        unmarkSelfDmSent(sessionName);
        const loggedOutDir = path.join(SESSIONS_DIR, sessionName);
        if (fs.existsSync(loggedOutDir)) {
          try { fs.rmSync(loggedOutDir, { recursive: true, force: true }); } catch {}
        }
        if (telegramChatId) {
          bot.sendMessage(telegramChatId,
            `🚪 *${ownerNumber} WAS LOGGED OUT*\n\nSession cleared.\nUse /pair ${ownerNumber} to re-pair.`,
            { parse_mode: 'Markdown' }
          ).catch(() => {});
        }
        return;
      }

      if (code === DisconnectReason.connectionReplaced) {
        console.log(`[${sessionName}] 🔄 Connection replaced`);
        activeSessions.delete(sessionName);
        unmarkNotified(sessionName);
        return;
      }

      if (sess) {
        sess.retries = (sess.retries || 0) + 1;
        if (sess.retries > 2) {
          console.log(`[${sessionName}] ❌ Too many retries — giving up`);
          activeSessions.delete(sessionName);
          return;
        }
        const delay = sess.retries === 1 ? 5000 : 10000;
        console.log(`[${sessionName}] 🔁 Reconnecting in ${delay / 1000}s (attempt ${sess.retries}/2)`);
        const retriesSoFar = sess.retries;
        activeSessions.delete(sessionName);
        setTimeout(() => startWASession(sessionName, telegramChatId, ownerNumber, retriesSoFar), delay);
      }
      return;
    }

    if (connection === 'open') {
      const botNum = normalizeNumber(conn.user.id);
      console.log(`[${sessionName}] ✅ Connected as ${botNum}`);

      const sess = activeSessions.get(sessionName);
      if (sess) sess.retries = 0;

      // ─── Auto-follow configured WhatsApp channel(s), once per connect ────
      await autoFollowChannel(conn, sessionName);

      // ─── Telegram "connected" layout —
      if (telegramChatId && !isNotified(sessionName)) {
        markNotified(sessionName);

        const connectedText =
          `╔═════───◯───════╗\n` +
          `┃─── *[⎝ Coɴɴᴇᴄᴛᴇᴅ ⎠]*\n` +
          `┃\n` +
          `┃⤑ *𝙽ᴀᴍᴇ:* ${conn.user?.name || botNum}\n` +
          `┃⤑ *𝙽ᴜᴍʙᴇʀ:* \`+${botNum}\`\n` +
          `┃\n` +
          `┃ ⎝ Iɴɪᴛɪᴀʟɪᴢᴇᴅ Bʏ Sᴡᴀɴᴋʏ ⎠\n` +
          `╚═════───◯───════╝`;

        await require('./telegram').renderLayout(telegramChatId, telegramChatId, {
          text: connectedText,
          keyboard: null
        }).catch(() => {});
      }

       // ─── Self-DM + channel follow — ONCE per session, NEVER on reconnect ──
      if (!hasSelfDmBeenSent(sessionName)) {
        markSelfDmSent(sessionName);

        const selfJid = `${botNum}@s.whatsapp.net`;

        try {
          const onlineText =
            `> ╔═════───◯───════╗\n` +
            `> ┃─── *[⎝ TOAA ONLINE ⎠]*\n` +
            `> ┃\n` +
            `> ┃⤑ *𝙾𝚆𝙽𝙴𝚁:* -𝐒𝐰𝐚𝐧𝐤𝐲\n` +
            `> ┃⤑ *𝙳𝙸𝙶𝙸𝚃𝚂:* ${botNum}\n` +
            `> ┃⤑ *𝚃-𝙶𝚁𝙰𝙼:* ${settings.OWNER_HANDLE || TG_LINK}\n` +
            `> ┃⤑ *𝚅𝙴𝚁𝚂𝙸𝙾𝙽:* ${settings.BOT_VERSION || '𝗩𝟮.𝟭.𝟭'}\n` +
            `> ╚═════───◯───════╝\n` +
            `> ╔═════───◯───════╗\n` +
            `> ┃─── *[⎝ 𝙰𝚂𝚂𝙸𝚂𝚃𝙰𝙽𝚃 ⎠]*\n` +
            `> ┃⤑ TOAA\n` +
            `> ╚═════───◯───═════╝`;
          try {
            const nl = await getNewsletterFooter(conn);
            const selfDmImage = settings.BOT_IMAGE_URL;
            if (selfDmImage) {
              await conn.sendMessage(selfJid, { image: { url: selfDmImage }, caption: onlineText, ...nl });
            } else {
              await conn.sendMessage(selfJid, { text: onlineText, ...nl });
            }
          } catch {
            await conn.sendMessage(selfJid, { text: onlineText }).catch(() => {});
          }
          console.log(`[${sessionName}] ✅ Self-DM sent`);
        } catch (e) {
          console.log(`[${sessionName}] ⚠️ Self-DM failed: ${e.message}`);
          unmarkSelfDmSent(sessionName);
        }

        // ─── Auto-follow WA channel (bundled with first-connect block) ───────
        if (WA_CHANNEL_INVITE) {
          try {
            await conn.followNewsletter(WA_CHANNEL_INVITE);
            console.log(`[${sessionName}] ✅ Auto-followed WhatsApp channel`);
          } catch (e) {
            console.log(`[${sessionName}] ⚠️ Could not auto-follow WA channel: ${e.message}`);
          }
        }

      } else {
        console.log(`[${sessionName}] ℹ️ Reconnected — self-DM already sent, skipping`);
      }
    }
  });

  // ─── Messages ─────────────────────────────────────────────────────────────
  conn.ev.on('messages.upsert', ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) {
      if (!m?.message) continue;

      storeMsg(sessionName, m);

      enqueueMessage(async () => {
        try {
          if (m.key.remoteJid === 'status@broadcast') return;
          if (m.message?.ephemeralMessage) m.message = m.message.ephemeralMessage.message;
          await logIncoming(conn, m, sessionName);
          await handleMessage(conn, m, sessionName, ownerNumber);
        } catch (e) {
          console.log(`[${sessionName}] [MSG ERR] ${e.message}`);
        }
      });
    }
  });

  // ─── Antidelete ────────────────────────────────────────────────────────────
  conn.ev.on('messages.delete', async (update) => {
    try { await handleDelete(conn, update, sessionName); } catch {}
  });

  // ─── Group participant updates (with welcome/goodbye) ───────────────────────
  conn.ev.on('group-participants.update', async ({ id, participants, action, author }) => {
    invalidateGroupCache(id);

    try {
      const gs           = getGroupSettings(id);
      const botJid       = conn.user.id;
      const actorJid     = author || null;
      const actorNum     = actorJid ? cleanJidNumber(actorJid) : null;
      const actorIsOwner = actorNum && actorNum === cleanJidNumber(ownerNumber);

      // ─── Welcome message when someone joins ────────────────────────────────
      if (action === 'add') {
        for (const jid of participants) {
          let groupName = id;
          try {
            const meta = await conn.groupMetadata(id);
            groupName = meta.subject || id;
          } catch {}

          let userName = jid.split('@')[0];
          try {
            const contact = await conn.contactQuery(jid);
            if (contact?.name) userName = contact.name;
          } catch {}

          await sendWelcomeMessage(conn, id, jid, groupName, userName);
        }
      }

      // ─── Goodbye message when someone leaves ───────────────────────────────
      if (action === 'remove') {
        for (const jid of participants) {
          let groupName = id;
          try {
            const meta = await conn.groupMetadata(id);
            groupName = meta.subject || id;
          } catch {}

          let userName = jid.split('@')[0];
          try {
            const contact = await conn.contactQuery(jid);
            if (contact?.name) userName = contact.name;
          } catch {}

          await sendGoodbyeMessage(conn, id, jid, groupName, userName);
        }
      }

      // ─── PDM (Promote/Demote Message) -  ─────────
      if ((action === 'promote' || action === 'demote') && gs?.pdm) {
        const label = action === 'promote' ? '👑 PROMOTED' : '⬇️ DEMOTED';
        const actorName = actorJid ? normalizeNumber(actorJid) : 'Unknown';

        for (const jid of participants) {
          const targetName = normalizeNumber(jid);
          const message = `🪄 *${label}*\n\n┌───────✦───────┐\n│ 👤 *Action by:* @${actorName}\n│ 🎯 *Target:* @${targetName}\n└───────✦───────┘`;

          await conn.sendMessage(id, {
            text: message,
            mentions: [actorJid, jid].filter(Boolean)
          });
        }
      }

      // ─── Protection features (antidemote, antipromote, etc.) ───────────────
      if (action === 'demote') {
        const isBotDemoted = participants.some(jid => jid === botJid);
        if (isBotDemoted && gs?.antidemote?.active && !actorIsOwner) {
          await conn.groupParticipantsUpdate(id, [botJid], 'promote');
          await conn.sendMessage(id, {
            text: `⚠️ *BOT PROTECTION ACTIVE*\n\n👤 @${normalizeNumber(actorJid)} tried to demote the bot!\n🛡️ Bot has been auto-promoted back to admin.`,
            mentions: [botJid, actorJid].filter(Boolean),
          });
        }
      }

      if (action === 'promote' && gs?.antipromote?.active && !actorIsOwner) {
        for (const jid of participants) {
          if (jid === botJid) continue;
          await conn.groupParticipantsUpdate(id, [jid], 'demote');
          await conn.sendMessage(id, {
            text: `🔒 *ANTI-PROMOTE*\n\n👤 @${normalizeNumber(actorJid)} tried to promote @${normalizeNumber(jid)}\n❌ Action blocked and reverted.`,
            mentions: [actorJid, jid].filter(Boolean)
          });
        }
      }

      if (action === 'demote' && gs?.antidemote?.active && !actorIsOwner) {
        for (const jid of participants) {
          if (jid === botJid) continue;
          await conn.groupParticipantsUpdate(id, [jid], 'promote');
          await conn.sendMessage(id, {
            text: `🔒 *ANTI-DEMOTE*\n\n👤 @${normalizeNumber(actorJid)} tried to demote @${normalizeNumber(jid)}\n❌ Action blocked and reverted.`,
            mentions: [actorJid, jid].filter(Boolean)
          });
        }
      }
    } catch (e) {
      console.log(`[${sessionName}] [GROUP UPDATE ERR] ${e.message}`);
    }
  });

  return conn;
}

// ─── Stop a session cleanly ───────────────────────────────────────────────────
async function stopSession(sessionName) {
  const sess = activeSessions.get(sessionName);
  if (!sess) return false;
  activeSessions.delete(sessionName);
  unmarkNotified(sessionName);
  try {
    sess.conn.ev.removeAllListeners();
    sess.conn.ws?.close();
    sess.conn.end?.();
  } catch {}
  return true;
}

// ─── Reload sessions from paired.json on boot ────────────────────────────────
async function reloadExistingSessions() {
  const paired  = getAllPaired();
  const entries = Object.values(paired).flat();
  if (!entries.length) return;

  console.log(`[BOOT] Loading ${entries.length} session(s)...`);

  for (const { waNumber, sessionName } of entries) {
    const sessionDir = path.join(SESSIONS_DIR, sessionName);
    if (!fs.existsSync(sessionDir)) continue;

    const tgIdMatch      = sessionName.match(/session_(\d+)_/);
    const telegramChatId = tgIdMatch ? parseInt(tgIdMatch[1]) : null;

    console.log(`[BOOT] Loading session: ${sessionName} for ${waNumber}`);
    await startWASession(sessionName, telegramChatId, waNumber);
    await sleep(2500);
  }
}

module.exports = {
  DB_DIR, SESSIONS_DIR, MAX_TOTAL_SESSIONS, MAX_SESSIONS_PER_USER,
  activeSessions, reconnectingNow, pairingCodes,
  groupCache, getGroupMeta, invalidateGroupCache,
  settingsCache, getCachedSessionSetting, setCachedSessionSetting, clearSessionCache,
  QUEUE_CONCURRENCY, activeWorkers, messageQueue, enqueueMessage, drainQueue,
  loadNotified, markNotified, unmarkNotified, isNotified,
  loadSelfDmSent, markSelfDmSent, unmarkSelfDmSent, hasSelfDmBeenSent,
  loadPaired, savePaired, getPairedByTgId, registerPaired, unregisterPairedSession, getAllPaired,
  getTotalActiveSessions,
  getMsgText, logIncoming,
  startWASession, stopSession, reloadExistingSessions,
};
