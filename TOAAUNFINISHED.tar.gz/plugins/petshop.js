// ─── TOAA RPG Pet Shop ─────────
const { errorReply, fReply } = require('../main');
const { getUser, setUser, isRpgAllowed } = require('../helper/rpg');
const { getCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { PETS_FOR_SALE } = require('../helper/rpgPets');
const { getSessionSetting } = require('../helper/function');

module.exports = {
  name: 'petshop',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'petshop': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const action = args[0]?.toLowerCase();
  const petKey = args[1]?.toLowerCase();
  const balance = getCoin(jid);

  if (!action || action !== 'buy') {
    let txt = `Welcome, Adventurer! To the Pet Shop! 🐾🏪\nPick your cute new travel buddy!\n\n*Available Pets:*\n`;
    for (const [key, pet] of Object.entries(PETS_FOR_SALE)) {
      txt += `\n*${pet.name}*\n💰 Price: ${fmtCoin(pet.price)}\n📝 Traits: ${pet.desc}\n👉 Adopt: \`${prefix}petshop buy ${key}\`\n`;
    }
    txt += `\n\n💰 *Your Coin:* ${fmtCoin(balance)}`;
    return fReply(conn, m, txt, sessionName);
  }

  if (!petKey) {
    return errorReply(conn, m, `Which pet do you want to adopt? Name the species! 😂\nExample: \`${prefix}petshop buy cat\``, sessionName);
  }

  const user = getUser(jid);
  if (user.pet) {
    return errorReply(conn, m, `You already have a pet! 😭\nThey'd get jealous. Try \`${prefix}breeding\` for a new one instead.`, sessionName);
  }

  const petToBuy = PETS_FOR_SALE[petKey];
  if (!petToBuy) {
    return errorReply(conn, m, `That species isn't sold here! ❌\nCheck the list with \`${prefix}petshop\``, sessionName);
  }

  if (balance < petToBuy.price) {
    return errorReply(conn, m, `Not enough coin for adoption fees! 😭\nCost: ${fmtCoin(petToBuy.price)}, you have: ${fmtCoin(balance)}`, sessionName);
  }

  removeCoin(jid, petToBuy.price);

  user.pet = {
    type: petKey,
    name: petToBuy.name.split(' ')[1] || 'My Pet',
    level: 1,
    exp: 0,
    hunger: 80,
    stats: null
  };
  setUser(jid, user);

  return fReply(conn, m,
    `CONGRATULATIONS! 🎉🎉\n\nYou officially adopted a *${petToBuy.name}*!\n💰 Adoption fee: *-${fmtCoin(petToBuy.price)}*\n\nThey can't wait to explore with you. Feed them and check status with \`${prefix}pet\`! 🐾✨`,
    sessionName
  );
}
