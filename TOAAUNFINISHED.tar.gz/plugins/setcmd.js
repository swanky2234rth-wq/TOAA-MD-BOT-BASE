// Auto-converted from legacy registerCmd('setcmd', ...) in main.js
// Category: owner
const {
  COMMANDS,
  downloadMedia,
  fReply,
  getQuotedMsg,
  newsletterReply,
  saveStickerCmds,
  stickerCmds
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setcmd',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setcmd': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  
  // Check if replying to a sticker
  const quotedMsg = getQuotedMsg(m);
  const stickerObj = quotedMsg?.stickerMessage || m.message?.stickerMessage;
  
  if (!stickerObj) {
    return fReply(conn, m, `🎴 *Reply to a sticker!*\n\nUsage: ${ctx.prefix}setcmd <command>`, ctx.sessionName);
  }
  
  const cmd = args.join(' ').trim().toLowerCase();
  if (!cmd) {
    return fReply(conn, m, `🎴 *Enter a command!*\n\nUsage: ${ctx.prefix}setcmd <command>`, ctx.sessionName);
  }
  
  // Check if command exists
  if (!COMMANDS[cmd]) {
    return fReply(conn, m, `🎴 *Command "${cmd}" does not exist!*\n\nUse ${ctx.prefix}menu to see available commands.`, ctx.sessionName);
  }
  
  try {
    // Get sticker hash
    let stickerHash = null;
    if (stickerObj.fileSha256) {
      stickerHash = Buffer.from(stickerObj.fileSha256).toString('hex').slice(0, 16);
    } else if (stickerObj.fileEncSha256) {
      stickerHash = Buffer.from(stickerObj.fileEncSha256).toString('hex').slice(0, 16);
    } else {
      // Fallback to downloading
      const stickerBuf = await downloadMedia(stickerObj, 'sticker');
      stickerHash = crypto.createHash('sha256').update(stickerBuf).digest('hex').slice(0, 16);
    }
    
    stickerCmds.set(stickerHash, { 
      cmd: cmd, 
      setBy: ctx.senderNumber, 
      setAt: Date.now()
    });
    saveStickerCmds();
    
    await fReply(conn, m, 
      `🧩 *Sticker command set!*\n\n` +
      `📌 Command: *${ctx.prefix}${cmd}*`,
      ctx.sessionName
    );
  } catch (e) {
    console.error('[SETCMD] Error:', e);
    await fReply(conn, m, `🎴 *Failed to set sticker command!*\n\nError: ${e.message}`, ctx.sessionName);
  }

      }
    }
  }
};
