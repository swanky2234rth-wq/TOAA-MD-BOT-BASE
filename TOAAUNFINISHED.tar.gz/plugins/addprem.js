// Auto-converted from legacy registerCmd('addprem', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  resolveTarget,
  addPremium
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'addprem',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'addprem': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  let target = resolveTarget(m, args);
  if (!target) return fReply(conn, m, `Usage: ${ctx.prefix}addprem <number>`, ctx.sessionName);
  target = target.replace(/[^0-9]/g, '');
  await fReply(conn, m, addPremium(target) ? `*_💈 ${target} 𝙰𝚍𝚍𝚎𝚍 𝙰𝚜 𝙿𝚛𝚎𝚖𝚒𝚞𝚖_*` : `*_🎴 Already premium._*`, ctx.sessionName);

      }
    }
  }
};
