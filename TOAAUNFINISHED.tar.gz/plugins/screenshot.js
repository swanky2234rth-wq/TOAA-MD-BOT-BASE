// Auto-converted from legacy registerCmd('screenshot', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'screenshot',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'screenshot': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx; const url = args[0]?.trim();
  if (!url) return fReply(conn, m, `Usage: ${prefix}screenshot <url>`, sessionName);
  await fReply(conn, m, '*_💈 𝚃𝚊𝚔𝚒𝚗𝚐 𝚂𝚌𝚛𝚎𝚎𝚗𝚜𝚑𝚘𝚝..._*', sessionName);
  try { 
    await conn.sendMessage(m.key.remoteJid, { image: { url: `https://api.apiflash.com/v1/urltoimage?access_key=free&url=${encodeURIComponent(url)}&width=1280&height=720` }, caption: `📸 ${url}` }, { quoted: m }); 
  }
  catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
