// plugins/anime.js
const axios = require('axios');

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'Anime Info',
  version: '1.0.0',
  author: 'TOAA',
  
  commands: {
    'anime': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const title = args.join(' ').trim();
        
        if (!title) {
          return fReply(conn, m, `🎌 *Anime Info*\n\nUsage: ${prefix}anime <anime title>\n\nExample: ${prefix}anime Naruto`, sessionName);
        }
        
        await fReply(conn, m, '*_🔍 Searching..._*', sessionName);
        
        try {
          const { data } = await axios.get(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(title)}&limit=1`);
          
          if (!data.data || data.data.length === 0) {
            return fReply(conn, m, `❌ *Anime not found!*`, sessionName);
          }
          
          const anime = data.data[0];
          
          const scoreEmoji = anime.score >= 8 ? '🏆' : anime.score >= 6 ? '👍' : '😐';
          
          const info = `🎌 *${anime.title}* ${anime.title_japanese ? `(${anime.title_japanese})` : ''}\n\n` +
            `⭐ ${scoreEmoji} *Score:* ${anime.score}/10\n` +
            `📺 *Episodes:* ${anime.episodes || 'Unknown'}\n` +
            `🎭 *Status:* ${anime.status}\n` +
            `📅 *Aired:* ${anime.aired?.string?.split(' to')[0] || 'Unknown'}\n` +
            `🎬 *Studio:* ${anime.studios?.map(s => s.name).join(', ') || 'Unknown'}\n` +
            `🏷️ *Genres:* ${anime.genres?.map(g => g.name).join(', ') || 'Unknown'}\n\n` +
            `📝 *Synopsis:* ${anime.synopsis?.substring(0, 300) || 'No synopsis'}${anime.synopsis?.length > 300 ? '...' : ''}`;
          
          if (anime.images?.jpg?.image_url) {
            await conn.sendMessage(m.key.remoteJid, {
              image: { url: anime.images.jpg.image_url },
              caption: info
            }, { quoted: m });
          } else {
            await fReply(conn, m, info, sessionName);
          }
          
        } catch (e) {
          await fReply(conn, m, `🎴 *Error:* ${e.message}`, sessionName);
        }
      }
    }
  }
};

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}