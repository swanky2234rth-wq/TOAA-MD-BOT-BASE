// ─── TOAA Ban Chat ─────────
const { errorReply, rawNumber } = require('../main');
const { getGroup, setGroup } = require('../helper/groupProtectionStore');

// Called from main.js's handleMessage: if true, non-owners should be blocked
// from using any command in this group.
function isChatBanned(remoteJid) {
  return !!getGroup(remoteJid).isBanned;
}

module.exports = {
  name: 'banchat',
  version: '1.0.0',
  author: 'TOAA',
  isChatBanned,
  commands: {
    'banchat': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner, senderJid } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!isOwner) {
          return errorReply(conn, m, `This command is owner-only.`, sessionName);
        }
        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Groups only.`, sessionName);
        }

        let groupName = 'Unknown';
        try {
          const meta = await conn.groupMetadata(remoteJid);
          groupName = meta.subject || 'Unknown';
        } catch (e) {}

        const groupData = getGroup(remoteJid);

        if (groupData.isBanned) {
          return errorReply(conn, m, `This group is already banned.\nUse .unbanchat to lift it.`, sessionName);
        }

        setGroup(remoteJid, { isBanned: true });

        await conn.sendMessage(remoteJid, {
          text: `🚫 *GROUP BANNED*\n\n` +
            `╭┈┈⬡「 📋 Detail 」\n` +
            `┃ 📛 Group: *${groupName}*\n` +
            `┃ 📊 Status: *🔴 BANNED*\n` +
            `┃ 👤 Banned by: @${rawNumber(senderJid)}\n` +
            `╰┈┈⬡\n\n` +
            `Regular members can no longer use the bot in this group.\nOnly the owner can.`,
          mentions: [senderJid]
        }, { quoted: m });
      }
    },
    'unbanchat': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner, senderJid } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!isOwner) {
          return errorReply(conn, m, `This command is owner-only.`, sessionName);
        }
        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Groups only.`, sessionName);
        }

        let groupName = 'Unknown';
        try {
          const meta = await conn.groupMetadata(remoteJid);
          groupName = meta.subject || 'Unknown';
        } catch (e) {}

        const groupData = getGroup(remoteJid);

        if (!groupData.isBanned) {
          return errorReply(conn, m, `This group isn't banned.\nEveryone can already use the bot.`, sessionName);
        }

        setGroup(remoteJid, { isBanned: false });

        await conn.sendMessage(remoteJid, {
          text: `✅ *GROUP UNBANNED*\n\n` +
            `╭┈┈⬡「 📋 Detail 」\n` +
            `┃ 📛 Group: *${groupName}*\n` +
            `┃ 📊 Status: *✅ ACTIVE*\n` +
            `┃ 👤 Unbanned by: @${rawNumber(senderJid)}\n` +
            `╰┈┈⬡\n\n` +
            `Everyone can use the bot again.`,
          mentions: [senderJid]
        }, { quoted: m });
      }
    }
  }
};
