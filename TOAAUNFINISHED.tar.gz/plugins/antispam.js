// Auto-converted from legacy registerCmd('antispam', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'antispam',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'antispam': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const option = (args[0] || '').toLowerCase();
  if (!['on', 'off'].includes(option)) return fReply(conn, m, `Usage: ${ctx.prefix}antispam on/off`, ctx.sessionName);
  setSessionSetting(ctx.sessionName, `antispam_${m.key.remoteJid}`, option === 'on');
  await fReply(conn, m, `*_💈 𝙰𝚗𝚝𝚒-𝚂𝚙𝚊𝚖: ${option.toUpperCase()}_*`, ctx.sessionName);

      }
    }
  }
};
