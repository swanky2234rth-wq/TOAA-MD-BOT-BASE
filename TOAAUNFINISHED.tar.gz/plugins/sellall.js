// ─── TOAA RPG Sell All ─────────
const { fReply, errorReply } = require('../main');
const { getUser, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { ITEMS } = require('../helper/rpgItems');
const { getSessionSetting } = require('../helper/function');

module.exports = {
  name: 'sellall',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'sellall': {
      category: 'rpg',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const jid = m.key.participant || m.key.remoteJid;

        if (!isRpgAllowed(m, ctx, getSessionSetting)) {
          return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
        }

        const user = getUser(jid);
        let totalEarned = 0;
        const sold = [];

        for (const [key, item] of Object.entries(ITEMS)) {
          if (!item.sell) continue;
          const qty = user.inventory[key] || 0;
          if (qty > 0) {
            const earned = qty * item.sell;
            totalEarned += earned;
            sold.push({ key, name: item.name, qty, earned });
            user.inventory[key] = 0;
          }
        }

        if (sold.length === 0) {
          return errorReply(conn, m, `You don't have anything sellable right now!`, sessionName);
        }

        addCoin(jid, totalEarned);

        let txt = `💰 *SELL ALL — DONE*\n\n`;
        for (const s of sold.slice(0, 10)) {
          txt += `${s.name}: ${s.qty}x = ${fmtCoin(s.earned)}\n`;
        }
        if (sold.length > 10) txt += `...and ${sold.length - 10} more item(s)\n`;
        txt += `\n💵 Total: *${fmtCoin(totalEarned)} coin*`;

        return fReply(conn, m, txt, sessionName);
      }
    }
  }
};
