// ─── TOAA RPG Lottery (Gacha) ─────────
// NOTE: legacy pool referenced goldchest/diamondchest/divinecore items that
// don't exist in this project's registry. Swapped goldchest→legendary
// crate, diamondchest→mythic crate, dropped divinecore (no equivalent) and
// rebalanced percentages so the pool still sums to 100.
const { errorReply } = require('../main');
const { getUser, addExp, isRpgAllowed, addItem } = require('../helper/rpg');
const { getCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const GACHA_COST = 500;

const GACHA_POOL = [
  { item: 'trash', name: '🗑️ Rotten Trash', chance: 30, rarity: 'common' },
  { item: 'wood', name: '🪵 Firewood', chance: 20, qty: [3, 8], rarity: 'common' },
  { item: 'iron', name: '🔩 Scrap Iron', chance: 15, qty: [2, 5], rarity: 'common' },
  { item: 'gold', name: '🪙 Gold Bars', chance: 10, qty: [1, 3], rarity: 'uncommon' },
  { item: 'potion', name: '🧪 Magic Potion', chance: 9, qty: [1, 3], rarity: 'uncommon' },
  { item: 'diamond', name: '💎 Pure Diamond', chance: 6, qty: [1, 2], rarity: 'rare' },
  { item: 'legendary', name: '🎁 Golden Crate', chance: 4, qty: [1, 1], rarity: 'rare' },
  { item: 'mythic', name: '💎 Diamond Crate', chance: 2.5, qty: [1, 1], rarity: 'epic' },
  { item: 'mysterybox', name: '🎲 Mystery Box', chance: 2, qty: [1, 1], rarity: 'epic' },
  { item: 'goldsword', name: '🗡️ Golden Excalibur', chance: 1, qty: [1, 1], rarity: 'legendary' },
  { item: 'diamondarmor', name: '🛡️ Eternal Diamond Armor', chance: 0.5, qty: [1, 1], rarity: 'legendary' }
];

const RARITY_COLORS = { common: '⚪', uncommon: '🟢', rare: '🔵', epic: '🟣', legendary: '🟡' };
const RARITY_EXP = { common: 10, uncommon: 30, rare: 80, epic: 150, legendary: 300 };

module.exports = {
  name: 'lottery',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'lottery': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const pulls = Math.min(10, Math.max(1, parseInt(args[0]) || 1));
  const totalCost = GACHA_COST * pulls;
  const balance = getCoin(jid);

  if (balance < totalCost) {
    return errorReply(conn, m,
      `💸 *NOT ENOUGH COIN FOR GACHA!* 💸\n\nCost: *${fmtCoin(GACHA_COST)}/pull*\nYou need: *${fmtCoin(totalCost)} (${pulls}x)*\n\nYou have: *${fmtCoin(balance)}*. Go earn some first!`,
      sessionName
    );
  }

  removeCoin(jid, totalCost);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🎰', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `✨ Disco lights flash... the gacha drum spins hard... pulling *${pulls}x* prizes! 🎁✨` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const results = [];
  let totalExp = 0;

  for (let i = 0; i < pulls; i++) {
    const roll = Math.random() * 100;
    let cumulative = 0;
    let result = GACHA_POOL[0];

    for (const item of GACHA_POOL) {
      cumulative += item.chance;
      if (roll <= cumulative) { result = item; break; }
    }

    if (result.item !== 'trash') {
      const qty = result.qty ? Math.floor(Math.random() * (result.qty[1] - result.qty[0] + 1)) + result.qty[0] : 1;
      addItem(jid, result.item, qty);
      results.push({ ...result, finalQty: qty });
      totalExp += RARITY_EXP[result.rarity] || 10;
    } else {
      results.push({ ...result, finalQty: 0 });
    }
  }

  const levelResult = addExp(jid, totalExp);

  const grouped = {};
  for (const r of results) {
    if (!grouped[r.item]) grouped[r.item] = { ...r, count: 0, totalQty: 0 };
    grouped[r.item].count++;
    grouped[r.item].totalQty += r.finalQty;
  }

  let txt = `🎉 *BAMM!! DRUM OPENED!!* 🎉\n\nPulled *${pulls}x* | Spent: *${fmtCoin(totalCost)}*\n\n*🎁 YOUR RESULTS:*\n`;

  let hasRare = false, hasLegendary = false;
  for (const item of Object.values(grouped)) {
    const icon = RARITY_COLORS[item.rarity] || '⚪';
    txt += item.item === 'trash'
      ? `> ${icon} ${item.name} *(junk x${item.count})*\n`
      : `> ${icon} ${item.name} *x${item.totalQty}*\n`;
    if (['epic', 'legendary'].includes(item.rarity)) hasRare = true;
    if (item.rarity === 'legendary') hasLegendary = true;
  }

  txt += `\n📈 *Bonus EXP:* +${totalExp} ✨\n`;
  if (hasLegendary) txt += `\n🌟🌟 *WHOA!! LEGENDARY PULL!! Once-in-a-lifetime luck!!* 🌟🌟`;
  else if (hasRare) txt += `\n✨ *Ooh, decent pull, got something rare!*`;
  else txt += `\n🥲 *Meh... mostly junk this time.*`;

  await conn.sendMessage(m.key.remoteJid, { react: { text: hasLegendary ? '🌟' : hasRare ? '🎉' : '✅', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
