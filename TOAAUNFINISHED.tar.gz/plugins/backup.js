// plugins/backup.js
console.log('[BACKUP] Plugin loaded!');

const fs = require('fs');
const path = require('path');
const { fReply, errorReply } = require('../main');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

module.exports = {
  name: 'Backup',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'backup': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;

        // ─── OWNER CHECK ──────────────────────────────────────────────────────
        if (!OWNER_NUMBERS.includes(senderNumber)) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        const dbDir = path.join(__dirname, '..', 'database');
        const backupDir = path.join(__dirname, '..', 'backups');

        if (!fs.existsSync(backupDir)) {
          fs.mkdirSync(backupDir);
        }

        try {
          const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
          const backupPath = path.join(backupDir, `backup_${timestamp}`);

          if (fs.existsSync(dbDir)) {
            fs.cpSync(dbDir, backupPath, { recursive: true });
          }

          const settingsDir = path.join(__dirname, '..', 'sessions');
          if (fs.existsSync(settingsDir)) {
            const settingsBackup = path.join(backupDir, `settings_${timestamp}`);
            fs.cpSync(settingsDir, settingsBackup, { recursive: true });
          }

          await fReply(conn, m, `✅ Backup created at: backups/backup_${timestamp}`, sessionName);
        } catch (error) {
          await errorReply(conn, m, `❌ Backup failed: ${error.message}`, sessionName);
        }
      }
    }
  }
};