// ─── TOAA Ngamen (RPG busking) ─────────
const { errorReply } = require('../main');
const { getSessionSetting } = require('../helper/function');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addMoney, fmtMoney } = require('../helper/economy');
const { notifyLevelUp } = require('../helper/rpgNotify');

const STAMINA_COST = 10;
const COOLDOWN_MS = 2 * 60 * 1000;
const cooldowns = new Map();

const LOCATIONS = [
  { name: 'Red Light Intersection', min: 3000, max: 10000 },
  { name: 'Coffee Shop', min: 5000, max: 15000 },
  { name: 'Outside the Mini Mart', min: 4000, max: 12000 },
  { name: 'Trendy Café', min: 8000, max: 25000 },
  { name: 'Street Food Corner', min: 2000, max: 8000 }
];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'busking',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'busking': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;
  const number = jid.split('@')[0].split(':')[0];

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ You just finished a set! Rest for *${fmtEta(COOLDOWN_MS - elapsed)}* before your next busking session.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m,
      `Voice is hoarse, throat's dry! 🥵\n\nNgamen costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext stamina point in ~${fmtEta(eta)}.`,
      sessionName
    );
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🎸', key: m.key } });

  const loc = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];
  const earning = Math.floor(Math.random() * (loc.max - loc.min + 1)) + loc.min;

  await conn.sendMessage(m.key.remoteJid, {
    text: `Starting to strum the guitar at *${loc.name}*... 🎶\nHopefully people are feeling generous today! 💸`
  }, { quoted: m });

  await new Promise((resolve) => setTimeout(resolve, 2500));

  addMoney(number, earning);
  const expGain = Math.floor(earning / 20);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  let txt = `NGAMEN RESULTS! 🎸✨\n\n`;
  txt += `Location: *${loc.name}*\n`;
  txt += `💵 Earned: *+${fmtMoney(earning)}*\n`;
  txt += `📈 EXP: *+${expGain}*\n`;
  txt += `⚡ Stamina: *-${STAMINA_COST}* (${user.stamina}/${user.maxStamina})\n\n`;
  txt += `Not bad for a day's work! 🤤`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
