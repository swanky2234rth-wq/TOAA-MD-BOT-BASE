// plugins/movie.js
const axios = require('axios');

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'Movie Info',
  version: '1.0.0',
  author: 'TOAA',
  
  commands: {
    'movie': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const title = args.join(' ').trim();
        
        if (!title) {
          return fReply(conn, m, `🎬 *Movie Info*\n\nUsage: ${prefix}movie <movie title>\n\nExample: ${prefix}movie Inception`, sessionName);
        }
        
        await fReply(conn, m, '*_🔍 Searching..._*', sessionName);
        
        try {
          const { data } = await axios.get(`http://www.omdbapi.com/?t=${encodeURIComponent(title)}&apikey=trilogy`);
          
          if (data.Response === 'False') {
            return fReply(conn, m, `✖️ *Movie not found!*\n\nTry a different title.`, sessionName);
          }
          
          const ratingEmoji = {
            'PG': '👶', 'PG-13': '🧑', 'R': '🔞', 'G': '👼'
          };
          
          const imdbRating = parseFloat(data.imdbRating);
          const scoreEmoji = imdbRating >= 8 ? '🏆' : imdbRating >= 6 ? '👍' : '😐';
          
          const info = `🎬 *${data.Title}* (${data.Year})\n` +
            `⭐ ${scoreEmoji} *IMDB:* ${data.imdbRating}/10\n` +
            `🎭 *Genre:* ${data.Genre}\n` +
            `⏱️ *Runtime:* ${data.Runtime}\n` +
            `🎬 *Director:* ${data.Director}\n` +
            `👥 *Cast:* ${data.Actors.split(',').slice(0, 3).join(', ')}...\n` +
            `📝 *Plot:* ${data.Plot.substring(0, 300)}${data.Plot.length > 300 ? '...' : ''}\n\n` +
            `${ratingEmoji[data.Rated] || '🎫'} *Rated:* ${data.Rated || 'N/A'}`;
          
          if (data.Poster && data.Poster !== 'N/A') {
            await conn.sendMessage(m.key.remoteJid, {
              image: { url: data.Poster },
              caption: info
            }, { quoted: m });
          } else {
            await fReply(conn, m, info, sessionName);
          }
          
        } catch (e) {
          await fReply(conn, m, `🎴 *Error:* ${e.message}`, sessionName);
        }
      }
    }
  }
};

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}