// Auto-converted from legacy registerCmd('numguess', ...) in main.js
// Category: games
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'numguess',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'numguess': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx; const remoteJid = m.key.remoteJid;
  if (!global.numGuessGames) global.numGuessGames = new Map();
  if (!global.numGuessGames.has(remoteJid)) {
    global.numGuessGames.set(remoteJid, { num: Math.floor(Math.random() * 100) + 1, attempts: 0 });
    return fReply(conn, m, `🔢 *Number Guess!*\n\nI'm thinking of a number between *1 and 100*.\nType ${prefix}numguess <number>!`, sessionName);
  }
  const game = global.numGuessGames.get(remoteJid); const guess = parseInt(args[0]);
  if (isNaN(guess)) return fReply(conn, m, `Usage: ${prefix}numguess <number>`, sessionName);
  game.attempts++;
  if (guess === game.num) { global.numGuessGames.delete(remoteJid); return fReply(conn, m, `🎉 Correct! The number was *${game.num}*! (${game.attempts} attempts)`, sessionName); }
  await fReply(conn, m, guess < game.num ? `📈 Too low! (Attempt ${game.attempts})` : `📉 Too high! (Attempt ${game.attempts})`, sessionName);

      }
    }
  }
};
