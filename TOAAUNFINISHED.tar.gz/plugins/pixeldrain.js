// ─── TOAA Pixeldrain Downloader ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'pixeldraindl',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'pddl': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const url = args[0]?.trim();

        if (!url || !url.includes('pixeldrain.com')) {
          return errorReply(conn, m, `Usage: ${prefix}pddl <url>\nExample: ${prefix}pddl https://pixeldrain.com/u/xxxxx`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          // Pixeldrain has its own public API — no third-party key needed.
          const idMatch = url.match(/pixeldrain\.com\/u\/([a-zA-Z0-9]+)/);
          if (!idMatch) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Couldn't parse a file ID from that link.`, sessionName);
          }
          const fileId = idMatch[1];

          const { data: info } = await axios.get(`https://pixeldrain.com/api/file/${fileId}/info`, { timeout: 15000 });

          if (!info?.success && info?.value === undefined) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `File not found or link is invalid.`, sessionName);
          }

          const sizeInMB = (info.size || 0) / (1024 * 1024);
          const downloadUrl = `https://pixeldrain.com/api/file/${fileId}?download`;

          if (sizeInMB > 100) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '⚠️', key: m.key } });
            return errorReply(conn, m, `File is ${sizeInMB.toFixed(1)}MB — too big to send here. Direct link: ${downloadUrl}`, sessionName);
          }

          await conn.sendMessage(m.key.remoteJid, {
            document: { url: downloadUrl },
            fileName: info.name || `pixeldrain-${fileId}`,
            mimetype: info.mime_type || 'application/octet-stream',
            contextInfo: { forwardingScore: 99, isForwarded: true }
          }, { quoted: m });

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (e) {
          console.error('[PIXELDRAINDL] Error:', e.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong fetching that file — try again.`, sessionName);
        }
      }
    }
  }
};
