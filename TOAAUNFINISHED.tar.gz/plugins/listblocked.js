// plugins/listblocked.js
console.log('[LISTBLOCKED] Plugin loaded!');

const { fReply, errorReply } = require('../main');

module.exports = {
  name: 'ListBlocked',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'listblocked': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner, isSudo } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!isOwner && !isSudo) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        try {
          const blocked = await conn.fetchBlocklist();
          
          if (!blocked || blocked.length === 0) {
            return fReply(conn, m, `📋 *Blocked Numbers*\n\nNo blocked numbers found.`, sessionName);
          }

          const list = blocked.map((num, i) => `${i + 1}. ${num.split('@')[0]}`).join('\n');
          await fReply(conn, m, `📋 *Blocked Numbers (${blocked.length})*\n\n${list}`, sessionName);
        } catch (error) {
          console.error('[LISTBLOCKED] Error:', error.message);
          await errorReply(conn, m, `❌ Error: ${error.message}`, sessionName);
        }
      }
    }
  }
};