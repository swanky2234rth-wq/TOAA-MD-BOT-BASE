// ─── TOAA Add Plugin ─────────
// Writes replied-to code straight to disk as a new plugin file and hot-loads
// it into the running process. Gated to the same hardcoded owner numbers as
// eval.js — this is real code execution on the server, not just bot control,
// so it's intentionally restricted to that exact same trust boundary rather
// than the broader isOwner/isSudo check used elsewhere.
const { fReply, errorReply, successReply, getQuotedMsg, getQuotedCtx, downloadMedia } = require('../main');
const fs = require('fs');
const path = require('path');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

function extractPluginInfo(code) {
  const info = { name: null, category: null };
  const nameMatch = code.match(/name:\s*['"`]([^'"`]+)['"]/i);
  if (nameMatch) info.name = nameMatch[1];
  const categoryMatch = code.match(/category:\s*['"`]([^'"`]+)['"]/i);
  if (categoryMatch) info.category = categoryMatch[1];
  return info;
}

module.exports = {
  name: 'addplugin',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'addplugin': { category: 'owner', handler: run },
    'addpl': { category: 'owner', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix, senderNumber } = ctx;

  // ─── OWNER CHECK ──────────────────────────────────────────────────────
  if (!OWNER_NUMBERS.includes(senderNumber)) {
    return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
  }

  const quotedCtx = getQuotedCtx(m);
  const quotedMsg = getQuotedMsg(m);

  if (!quotedCtx || !quotedMsg) {
    return fReply(conn, m,
      `Reply to the plugin code you want to add.\n\n` +
      `${prefix}addplugin — auto-detect name/category from the code\n` +
      `${prefix}addplugin <filename> — custom filename\n` +
      `${prefix}addplugin <filename> <folder> — custom filename and folder`,
      sessionName
    );
  }

  let code = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text || '';

  const docMsg = quotedMsg.documentMessage;
  if (docMsg && (docMsg.mimetype === 'application/javascript' || docMsg.mimetype === 'text/javascript' || docMsg.fileName?.endsWith('.js'))) {
    try {
      const buffer = await downloadMedia(docMsg, 'document');
      code = buffer.toString('utf-8');
    } catch (e) {
      return errorReply(conn, m, `Couldn't download that file.`, sessionName);
    }
  }

  if (!code || code.length < 50) {
    return errorReply(conn, m, `That code looks too short or invalid.`, sessionName);
  }

  const hasExport = code.includes('module.exports') || code.includes('export ');
  const hasConfig = code.includes('commands') || code.includes('pluginConfig') || code.includes('config');
  if (!hasExport || !hasConfig) {
    return errorReply(conn, m, `That doesn't look like a valid plugin — make sure it has module.exports and a commands/config object.`, sessionName);
  }

  const extracted = extractPluginInfo(code);

  let fileName = args[0] || extracted.name;
  let folderName = args[1]; // TOAA plugins are flat in /plugins, folder is optional here

  if (!fileName) {
    return errorReply(conn, m, `Couldn't auto-detect a plugin name — use ${prefix}addplugin <filename>.`, sessionName);
  }

  fileName = fileName.toLowerCase().replace(/[^a-z0-9\-_]/g, '');
  if (!fileName) {
    return errorReply(conn, m, `Invalid filename.`, sessionName);
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

  try {
    const pluginsDir = folderName
      ? path.join(__dirname, '..', 'plugins', folderName.toLowerCase().replace(/[^a-z0-9\-_]/g, ''))
      : path.join(__dirname);

    const filePath = path.join(pluginsDir, `${fileName}.js`);

    if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });

    if (fs.existsSync(filePath)) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m,
        `${fileName}.js already exists${folderName ? ` in plugins/${folderName}` : ''}.\n\nDelete it manually first if you want to replace it — this command won't overwrite existing files.`,
        sessionName
      );
    }

    fs.writeFileSync(filePath, code);

    // Attempt a hot-reload via require cache clear; falls back to "needs restart"
    // if that fails, since TOAA's loadPlugins() runs once at boot, not on a watcher.
    let hotReloaded = false;
    try {
      delete require.cache[require.resolve(filePath)];
      const newPlugin = require(filePath);
      const { COMMANDS } = require('../main');
      if (newPlugin.commands) {
        for (const [cmdName, cmdData] of Object.entries(newPlugin.commands)) {
          if (!COMMANDS[cmdName]) {
            COMMANDS[cmdName] = { handler: cmdData.handler, category: cmdData.category || 'plugin' };
          }
        }
        hotReloaded = true;
      }
    } catch (e) {
      console.error('[ADDPLUGIN] Hot-reload failed:', e.message);
    }

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
    await successReply(conn, m,
      `Plugin added.\n\n` +
      `File: ${fileName}.js${folderName ? `\nFolder: plugins/${folderName}` : ''}\n` +
      `Size: ${code.length} bytes\n` +
      `Reload: ${hotReloaded ? 'Live — ready to use now' : 'Pending — restart the bot to activate it'}`,
      sessionName
    );

  } catch (error) {
    console.error('[ADDPLUGIN] Error:', error.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Failed to write that plugin: ${error.message}`, sessionName);
  }
}
