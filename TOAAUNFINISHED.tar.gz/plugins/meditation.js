// ─── TOAA RPG Meditation (Rest) ─────────
// NOTE: legacy source had both heal.js and meditation.js — same rest
// concept. Ported meditation.js since it's more complete (recovers HP +
// Stamina + Mana, scales max stats with level; heal.js only did HP +
// Stamina at a flat 100 cap). Skipped heal.js as a duplicate.
const { errorReply } = require('../main');
const { getUser, setUser, isRpgAllowed } = require('../helper/rpg');
const { getSessionSetting } = require('../helper/function');

const COOLDOWN_MS = 600 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'meditation',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'meditation': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still resting from last time! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);

  if (user.health >= user.maxHealth && user.stamina >= user.maxStamina && user.mana >= user.maxMana) {
    return errorReply(conn, m,
      `💤 *ALREADY FULL*\n\n⚡ Stamina: ${user.stamina}/${user.maxStamina}\n❤️ Health: ${user.health}/${user.maxHealth}\n💙 Mana: ${user.mana}/${user.maxMana}\n\n💡 You're already in peak condition!`,
      sessionName
    );
  }

  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '💤', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `💤 *Resting...*\n\nRecovering energy...` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const staminaRecovered = Math.min(user.maxStamina - user.stamina, 40 + Math.floor(Math.random() * 20));
  const healthRecovered = Math.min(user.maxHealth - user.health, 30 + Math.floor(Math.random() * 20));
  const manaRecovered = Math.min(user.maxMana - user.mana, 25 + Math.floor(Math.random() * 15));

  user.stamina = Math.min(user.maxStamina, user.stamina + staminaRecovered);
  user.health = Math.min(user.maxHealth, user.health + healthRecovered);
  user.mana = Math.min(user.maxMana, user.mana + manaRecovered);
  setUser(jid, user);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✨', key: m.key } });

  const txt = `✨ *REST COMPLETE!*\n\n💖 *Recovered:*\n⚡ Stamina: *+${staminaRecovered}* (${user.stamina}/${user.maxStamina})\n❤️ Health: *+${healthRecovered}* (${user.health}/${user.maxHealth})\n💙 Mana: *+${manaRecovered}* (${user.mana}/${user.maxMana})\n\nFeeling refreshed! 🌟`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
}
