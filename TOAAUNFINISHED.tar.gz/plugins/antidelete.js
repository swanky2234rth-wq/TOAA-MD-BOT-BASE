// Auto-converted from legacy registerCmd('antidelete', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin,
  getSessionSetting,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'antidelete',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'antidelete': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  const next = !getSessionSetting(ctx.sessionName, 'antidelete', false);
  setSessionSetting(ctx.sessionName, 'antidelete', next);
  await fReply(conn, m, `*_💈 𝙰𝚗𝚝𝚒𝚍𝚎𝚕𝚎𝚝𝚎: ${next ? 'ON' : 'OFF'}_*`, ctx.sessionName);

      }
    }
  }
};
