const mainCore = require('../main');

module.exports = {
  name: 'shutdown',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'shutdown': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner } = ctx;
        if (!isOwner) return mainCore.unauthorizedReply(conn, m, sessionName);

        await conn.sendMessage(m.key.remoteJid, {
          text: `🔌 Shutting down this session. Use ${ctx.prefix}pair on Telegram to reconnect whenever you're ready.`
        }, { quoted: m });

        // Lazy require to avoid the same load-order circularity as the other
        // commands that need sessions.js (restart/broadcast/getsession/etc).
        setTimeout(async () => {
          try {
            const { stopSession } = require('../sessions');
            await stopSession(sessionName);
            console.log(`[SHUTDOWN] Session ${sessionName} stopped by owner command`);
          } catch (e) {
            console.log('[SHUTDOWN] Error stopping session:', e.message);
          }
        }, 1000);
      }
    }
  }
};
