// Auto-converted from legacy registerCmd('blur', ...) in main.js
// Category: media
const {
  downloadMedia,
  fReply,
  getMediaType,
  getQuotedMsg
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'blur',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'blur': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {

  const { sessionName } = ctx;
  const quotedMsg = getQuotedMsg(m);
  const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
  if (!t || t.type !== 'image') return fReply(conn, m, '*_۞ Reply to an image_*', sessionName);
  await fReply(conn, m, '*_💈 𝙱𝚕𝚞𝚛𝚛𝚒𝚗𝚐..._*', sessionName);
  try {
    const buf = await downloadMedia(t.inner, t.type);
    const { data } = await axios.post('https://api.siputzx.my.id/api/edit/blur', { image: buf.toString('base64') });
    if (!data.status) return fReply(conn, m, '*_۞ 𝙵𝚊𝚒𝚕𝚎𝚍_*', sessionName);
    await conn.sendMessage(m.key.remoteJid, { image: Buffer.from(data.data, 'base64'), caption: '💈 *_Image blurred!' }, { quoted: m });
  } catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
