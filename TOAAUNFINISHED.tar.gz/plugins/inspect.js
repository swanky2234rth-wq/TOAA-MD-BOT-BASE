// ─── TOAA Inspect Group/Channel Link ─────────
const { errorReply } = require('../main');

module.exports = {
  name: 'inspect',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'inspect': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const text = args.join(' ').trim();

        if (!text) {
          return errorReply(conn, m,
            `Usage: ${prefix}inspect <group/channel link>\nExample: ${prefix}inspect https://chat.whatsapp.com/xxx\nOr: ${prefix}inspect https://whatsapp.com/channel/xxx`,
            sessionName
          );
        }

        const groupPattern = /chat\.whatsapp\.com\/([\w\d]*)/;
        const channelPattern = /whatsapp\.com\/channel\/([\w\d]*)/;

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🔍', key: m.key } });

        try {
          if (groupPattern.test(text)) {
            const inviteCode = text.match(groupPattern)[1];
            const groupInfo = await conn.groupGetInviteInfo(inviteCode);

            let out =
              `📋 *Group Information*\n\n` +
              `╭┈┈⬡「 📊 Detail 」\n` +
              `┃ 📝 Name: *${groupInfo.subject}*\n` +
              `┃ 🆔 ID: \`${groupInfo.id}\`\n` +
              `┃ 📅 Created: ${new Date(groupInfo.creation * 1000).toLocaleString()}\n`;

            if (groupInfo.owner) {
              out += `┃ 👑 Creator: @${groupInfo.owner.split('@')[0]}\n`;
            }

            out +=
              `┃ 🔗 Linked parent: ${groupInfo.linkedParent || 'None'}\n` +
              `┃ 🔒 Restricted: ${groupInfo.restrict ? '✅' : '❌'}\n` +
              `┃ 📢 Announce only: ${groupInfo.announce ? '✅' : '❌'}\n` +
              `┃ 🏘️ Is community: ${groupInfo.isCommunity ? '✅' : '❌'}\n` +
              `┃ ✅ Join approval: ${groupInfo.joinApprovalMode ? '✅' : '❌'}\n` +
              `┃ 👥 Participants: ${groupInfo.participants?.length || 0}\n` +
              `╰┈┈⬡\n\n`;

            if (groupInfo.desc) {
              out += `📝 *Description:*\n${groupInfo.desc}\n\n`;
            }

            const mentions = [];
            if (groupInfo.owner) mentions.push(groupInfo.owner);

            if (groupInfo.participants?.length > 0) {
              const admins = groupInfo.participants.filter(p => p.admin);
              if (admins.length > 0) {
                out += `👑 *Admins:*\n`;
                admins.forEach(a => {
                  out += `├ @${a.id.split('@')[0]} [${a.admin}]\n`;
                  mentions.push(a.id);
                });
                out += `╰┈┈⬡`;
              }
            }

            await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
            return conn.sendMessage(m.key.remoteJid, { text: out, mentions }, { quoted: m });

          } else if (channelPattern.test(text)) {
            const channelId = text.match(channelPattern)[1];
            const channelInfo = await conn.newsletterMetadata('invite', channelId);

            const out =
              `📺 *Channel Information*\n\n` +
              `╭┈┈⬡「 📊 Detail 」\n` +
              `┃ 🆔 ID: \`${channelInfo.id}\`\n` +
              `┃ 📝 Name: *${channelInfo.name || '-'}*\n` +
              `┃ 👥 Subscribers: ${channelInfo.subscriberCount || 0}\n` +
              `╰┈┈⬡\n\n` +
              `📝 *Description:*\n${channelInfo.description || 'No description'}`;

            await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
            return errorReply(conn, m, out, sessionName);

          } else {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Only WhatsApp group or channel links are supported.`, sessionName);
          }

        } catch (error) {
          console.error('[INSPECT] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });

          if (error.data === 400 || error.data === 406) {
            return errorReply(conn, m, `Group/channel not found.`, sessionName);
          }
          if (error.data === 401) {
            return errorReply(conn, m, `Bot was kicked from that group.`, sessionName);
          }
          if (error.data === 410) {
            return errorReply(conn, m, `That group's invite link has been reset.`, sessionName);
          }
          await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
        }
      }
    }
  }
};
