// Auto-converted from legacy registerCmd('antidemote', ...) in main.js
// Category: group
const {
  fReply,
  getGroupSettings,
  requireAdmin,
  updateGroupSettings
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'antidemote',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'antidemote': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const option = (args[0] || '').toLowerCase();
  const gs = getGroupSettings(remoteJid);
  if (option === 'on') { gs.antidemote.active = true; updateGroupSettings(remoteJid, { antidemote: gs.antidemote }); await fReply(conn, m, '*_💈 𝙰𝙽𝚃𝙸-𝙳𝙴𝙼𝙾𝚃𝙴 𝙾𝙽_*', ctx.sessionName); }
  else if (option === 'off') { gs.antidemote.active = false; updateGroupSettings(remoteJid, { antidemote: gs.antidemote }); await fReply(conn, m, '*_۞ Anti-demote deactivated!_*', ctx.sessionName); }
  else await fReply(conn, m, `Usage: ${ctx.prefix}antidemote on/off`, ctx.sessionName);

      }
    }
  }
};
