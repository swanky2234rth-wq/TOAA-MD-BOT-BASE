const mainCore = require('../main');
const { errorReply } = mainCore;
const econ = require('../helper/economy');

const ITEM_ALIASES = {
  booster: 'booster',
  stealth: 'stealth',
  security: 'security',
  instinct: 'instinct',
  maxsecurity: 'maxsecurity', 'max-security': 'maxsecurity', 'max security': 'maxsecurity',
  counter: 'counter',
};

const DESCRIPTIONS = {
  booster: 'For each money you make, get a quarter extra.',
  stealth: 'Protects you from counters — a countered swipe fails silently, no one loses money.',
  security: "Secures you from being swiped, unless they collab'd or used stealth.",
  instinct: 'Shows your win/loss odds before a gamble or trade.',
  maxsecurity: 'Collabs and stealth stop working against you entirely.',
  counter: "Counters an incoming swipe and steals the swiper's intended amount instead.",
};

function listShop(prefix) {
  return Object.entries(econ.PRICES)
    .map(([key, price]) => `• *${key}* — ${econ.fmtMoney(price)}\n  ${DESCRIPTIONS[key]}`)
    .join('\n\n') + `\n\nUsage: ${prefix}buy <item>`;
}

module.exports = {
  name: 'buy',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'buy': {
      category: 'economy',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber, prefix } = ctx;
        const raw = args.join(' ').toLowerCase().trim();
        const item = ITEM_ALIASES[raw] || ITEM_ALIASES[args[0]?.toLowerCase()];

        if (!item) {
          await conn.sendMessage(m.key.remoteJid, { text: `🛒 *TOAA SHOP* 🛒\n\n${listShop(prefix)}` }, { quoted: m });
          return;
        }

        const price = econ.PRICES[item];
        const acc = econ.getAccount(senderNumber);

        if (['stealth', 'security', 'maxsecurity', 'counter'].includes(item) && econ.hasEffect(senderNumber, item)) {
          const remaining = econ.fmtDuration(econ.effectRemaining(senderNumber, item));
          return errorReply(conn, m, `You already have *${item}* active! (${remaining} left)`, sessionName);
        }
        if (item === 'booster' && acc.booster) {
          return errorReply(conn, m, `You already own the *booster*!`, sessionName);
        }

        if (acc.balance < price) {
          return errorReply(conn, m, `You need ${econ.fmtMoney(price)} for *${item}* — you have ${econ.fmtMoney(acc.balance)}.`, sessionName);
        }

        econ.removeMoney(senderNumber, price);

        if (item === 'booster') {
          acc.booster = true;
          econ.save();
          await conn.sendMessage(m.key.remoteJid, { text: `✅ Booster purchased! You now earn 25% extra on every payout.` }, { quoted: m });
          return;
        }

        if (item === 'instinct') {
          acc.instinct = true;
          econ.save();
          await conn.sendMessage(m.key.remoteJid, { text: `✅ Instinct purchased! Your win/loss odds will now show before gambles and trades.` }, { quoted: m });
          return;
        }

        econ.grantEffect(senderNumber, item);
        await conn.sendMessage(m.key.remoteJid, {
          text: `✅ *${item}* activated! Lasts 48 hours.\n\n${DESCRIPTIONS[item]}`
        }, { quoted: m });
      }
    }
  }
};
