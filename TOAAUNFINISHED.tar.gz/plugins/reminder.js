const mainCore = require('../main');
const { errorReply } = mainCore;

// In-memory is fine here — reminders are short-lived by nature, and a missed
// one after a restart is a much smaller deal than the session data backup.js
// already covers for settings.
const timers = new Map(); // reminderId -> Timeout

function parseDuration(input) {
  const m = String(input).match(/^(\d+)\s*(s|sec|secs|m|min|mins|h|hr|hrs|hour|hours|d|day|days)?$/i);
  if (!m) return null;
  const n = parseInt(m[1], 10);
  const unit = (m[2] || 'm').toLowerCase();
  if (unit.startsWith('s')) return n * 1000;
  if (unit.startsWith('m')) return n * 60 * 1000;
  if (unit.startsWith('h')) return n * 60 * 60 * 1000;
  if (unit.startsWith('d')) return n * 24 * 60 * 60 * 1000;
  return null;
}

module.exports = {
  name: 'reminder',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'reminder': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber, prefix } = ctx;

        if ((args[0] || '').toLowerCase() === 'list') {
          const mine = [...timers.entries()].filter(([id]) => id.startsWith(`${senderNumber}:`));
          if (!mine.length) return errorReply(conn, m, `You have no active reminders.`, sessionName);
          const list = mine.map(([id, t]) => `• ${t.text} — due ${new Date(t.dueAt).toLocaleTimeString()}`).join('\n');
          return conn.sendMessage(m.key.remoteJid, { text: `⏰ Your reminders:\n\n${list}` }, { quoted: m });
        }

        const durationRaw = args[0];
        const text = args.slice(1).join(' ').trim();
        const ms = parseDuration(durationRaw);

        if (!ms || !text) {
          return errorReply(conn, m,
            `Usage: ${prefix}reminder <time> <what to remind you about>\nExample: ${prefix}reminder 30m stir the pot\nTime units: s, m, h, d (default: minutes)`,
            sessionName
          );
        }
        if (ms > 30 * 24 * 60 * 60 * 1000) {
          return errorReply(conn, m, `That's too far out — max 30 days.`, sessionName);
        }

        const dueAt = Date.now() + ms;
        const id = `${senderNumber}:${Date.now()}`;
        const senderJid = m.key.fromMe ? conn.user.id : (m.key.participant || m.key.remoteJid);

        const timeout = setTimeout(async () => {
          timers.delete(id);
          try {
            await conn.sendMessage(senderJid, {
              text: `⏰ *Reminder!*\n\n${text}`
            });
          } catch (e) {
            console.log('[REMINDER] Failed to deliver:', e.message);
          }
        }, ms);

        timers.set(id, { text, dueAt, timeout });

        await conn.sendMessage(m.key.remoteJid, {
          text: `⏰ Got it! I'll remind you in ${durationRaw} — "${text}"`
        }, { quoted: m });
      }
    }
  }
};
