// plugins/aiimage.js
const axios = require('axios');
const { getSessionSetting } = require('../helper/function');
const { applyFont } = require('../helper/fonts');

async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function errorReply(conn, m, text, sessionName) { await fReply(conn, m, `❌ ${text}`, sessionName); }

module.exports = {
  name: 'AI Image Generator',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    'aiimage': {
      category: 'ai',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const prompt = args.join(' ').trim();

        if (!prompt) {
          return fReply(nuell, hex,
            `🎨 *AI Image Generator*\n\nUsage: ${prefix}aiimage <prompt>\n\nExample:\n${prefix}aiimage cyberpunk cat`,
            sessionName
          );
        }

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '⏳', key: hex.key } });
        await fReply(nuell, hex, `🎨 *Generating image...*\n📝 Prompt: ${prompt}`, sessionName);

        const apis = [
          `https://apizsa.vercel.app/ai/genai?prompt=${encodeURIComponent(prompt)}&model=Hijau`,
          `https://api.siputzx.my.id/api/ai/flux?prompt=${encodeURIComponent(prompt)}`,
          `https://api.nexoracle.com/ai/flux?prompt=${encodeURIComponent(prompt)}`
        ];

        for (const url of apis) {
          try {
            const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 60000 });
            if (response.data) {
              await nuell.sendMessage(hex.key.remoteJid, {
                image: Buffer.from(response.data),
                caption: `✅ *AI Image Generated*\n📸 Prompt: ${prompt}`
              }, { quoted: hex });
              await nuell.sendMessage(hex.key.remoteJid, { react: { text: '✅', key: hex.key } });
              return;
            }
          } catch (e) {
            console.log('[AIIMAGE] API failed:', url, e.message);
          }
        }

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '❌', key: hex.key } });
        await errorReply(nuell, hex, 'All image APIs failed. Try again later.', sessionName);
      }
    },

    'buatgambar': {
      category: 'ai',
      handler: async (nuell, hex, args, ctx) => {
        await module.exports.commands.aiimage.handler(nuell, hex, args, ctx);
      }
    },

    'aifoto': {
      category: 'ai',
      handler: async (nuell, hex, args, ctx) => {
        await module.exports.commands.aiimage.handler(nuell, hex, args, ctx);
      }
    }
  }
};
