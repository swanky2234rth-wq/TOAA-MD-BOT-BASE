// ─── TOAA List Active ─────────
const { errorReply } = require('../main');
const { getGroupActivity } = require('../helper/activityTracker');

module.exports = {
  name: 'listactive',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'listactive': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isAdmin, isOwner } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Group only command.`, sessionName);
        }
        if (!isAdmin && !isOwner) {
          return errorReply(conn, m, `Admins only.`, sessionName);
        }

        const groupData = getGroupActivity(remoteJid);
        const entries = Object.entries(groupData);

        if (!entries.length) {
          return errorReply(conn, m, `No activity recorded yet.`, sessionName);
        }

        const sorted = entries
          .sort((a, b) => b[1].count - a[1].count)
          .slice(0, 50);

        let text = `📊 *Active Users in Group*\n────────────────────\n`;
        const mentions = [];

        sorted.forEach(([user, info], i) => {
          mentions.push(user);
          text += `🔹 *${i + 1}.* @${user.split('@')[0]}  —  *${info.count} messages*\n`;
        });

        await conn.sendMessage(remoteJid, { text, mentions }, { quoted: m });
      }
    }
  }
};
