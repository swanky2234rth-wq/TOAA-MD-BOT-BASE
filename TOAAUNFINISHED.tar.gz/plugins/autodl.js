// ─── TOAA Auto-Download Toggle ─────────
// NOTE: This only stores the on/off preference per group. It does NOT
// implement the actual "detect a TikTok/IG/etc link and auto-download it"
// logic — that would need a separate hook in main.js's handleMessage that
// checks this setting on every message and dispatches to the matching
// downloader plugin. Flagging this clearly since the original source's
// autodl.js was just a toggle too, with the real detection living elsewhere
// in that project (not included in what was ported).
const { errorReply, successReply, getSessionSetting, setSessionSetting, requireAdmin } = require('../main');

module.exports = {
  name: 'autodl',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'autodl': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Groups only.`, sessionName);
        }
        if (!requireAdmin(ctx, conn, m)) return;

        const arg = args[0]?.toLowerCase();
        const settingKey = `autodl_${remoteJid}`;
        const current = getSessionSetting(sessionName, settingKey, false);

        if (!arg || arg === 'status') {
          return errorReply(conn, m,
            `🔗 *Auto Download*\n\nStatus: ${current ? '✅ On' : '❌ Off'}\n\nUsage:\n${prefix}autodl on\n${prefix}autodl off`,
            sessionName
          );
        }

        if (arg === 'on') {
          setSessionSetting(sessionName, settingKey, true);
          return successReply(conn, m, `Auto download turned on for this group.`, sessionName);
        }

        if (arg === 'off') {
          setSessionSetting(sessionName, settingKey, false);
          return successReply(conn, m, `Auto download turned off.`, sessionName);
        }

        return errorReply(conn, m, `Use "on" or "off".`, sessionName);
      }
    }
  }
};
