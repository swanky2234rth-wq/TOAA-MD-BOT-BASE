// ─── TOAA Set Birthday ─────────
const { errorReply, successReply, rawNumber } = require('../main');
const { getBirthday, setBirthday } = require('../helper/birthdayStore');

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DAYS_IN_MONTH = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

module.exports = {
  name: 'setbirthday',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setbirthday': {
      category: 'user',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderJid } = ctx;
        const input = args[0]?.trim();

        if (!input) {
          const current = getBirthday(senderJid);
          let text = `🎂 *Set Birthday*\n\n`;
          if (current) text += `Your current birthday: *${current}*\n\n`;
          text += `Format: ${prefix}setbirthday DD-MM\n\nExample:\n${prefix}setbirthday 25-12\n${prefix}setbirthday 01-01`;
          return errorReply(conn, m, text, sessionName);
        }

        const match = input.match(/^(\d{1,2})[-\/](\d{1,2})$/);
        if (!match) {
          return errorReply(conn, m, `Wrong format! Use: DD-MM\nExample: ${prefix}setbirthday 25-12`, sessionName);
        }

        const day = parseInt(match[1]);
        const month = parseInt(match[2]);

        if (month < 1 || month > 12) {
          return errorReply(conn, m, `Invalid month! (1-12)`, sessionName);
        }
        if (day < 1 || day > DAYS_IN_MONTH[month - 1]) {
          return errorReply(conn, m, `Invalid day for month ${month}!`, sessionName);
        }

        const formatted = `${day.toString().padStart(2, '0')}-${month.toString().padStart(2, '0')}`;
        setBirthday(senderJid, formatted);

        const text =
          `✅ *Birthday saved!*\n\n` +
          `📅 Date: *${day} ${MONTHS[month - 1]}*\n` +
          `👤 @${rawNumber(senderJid)}\n\n` +
          `I'll wish you a happy birthday on your special day! 🎉`;

        await conn.sendMessage(m.key.remoteJid, { text, mentions: [senderJid] }, { quoted: m });
      }
    }
  }
};
