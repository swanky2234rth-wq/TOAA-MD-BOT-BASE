// Auto-converted from legacy registerCmd('sticker', ...) in main.js
// Category: media
const {
  fReply,
  getMediaType,
  getQuotedMsg,
  downloadContentFromMessage
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'sticker',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'sticker': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {

  const { sessionName, prefix } = ctx;
  const remoteJid = m.key.remoteJid;
  const quotedMsg = getQuotedMsg(m);

  let mediaSource = null, mediaType = null;

  if (quotedMsg) {
    const t = getMediaType(quotedMsg);
    if (t && (t.type === 'image' || t.type === 'video')) {
      mediaSource = t.inner; mediaType = t.type;
    }
  }
  if (!mediaSource) {
    const t = getMediaType(m.message || {});
    if (t && (t.type === 'image' || t.type === 'video')) {
      mediaSource = t.inner; mediaType = t.type;
    }
  }

  if (!mediaSource) return fReply(conn, m, `🎴 *Reply to an image or video with ${prefix}sticker*`, sessionName);

  await fReply(conn, m, '*_Creating sticker..._*', sessionName);

  try {
    const stream = await downloadContentFromMessage(mediaSource, mediaType);
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    const buf = Buffer.concat(chunks);

    if (!buf || buf.length === 0) return fReply(conn, m, '🎴 *Download returned empty buffer. Try again.*', sessionName);

    const { Sticker, StickerTypes } = require('wa-sticker-formatter');
    const sticker = new Sticker(buf, {
      pack: 'TOAA',
      author: 'TOAA',
      type: StickerTypes.FULL,
      quality: 80,
    });

    await conn.sendMessage(remoteJid, await sticker.toMessage(), { quoted: m });

  } catch (e) {
    console.error('[STICKER] Error:', e);
    await fReply(conn, m, `🎴 *Sticker Failed:* ${e.message}`, sessionName);
  }

      }
    }
  }
};
