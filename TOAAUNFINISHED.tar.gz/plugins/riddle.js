// Auto-converted from legacy registerCmd('riddle', ...) in main.js
// Category: games
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'riddle',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'riddle': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {

  try { const { data } = await axios.get('https://riddles-api.vercel.app/random'); await fReply(conn, m, `🧩 *Riddle!*\n\n${data.riddle}\n\n||${data.answer}||`, ctx.sessionName); }
  catch { await fReply(conn, m, '*_۞ 𝙰𝙿𝙸 𝙴𝚛𝚛𝚘𝚛_*', ctx.sessionName); }

      }
    }
  }
};
