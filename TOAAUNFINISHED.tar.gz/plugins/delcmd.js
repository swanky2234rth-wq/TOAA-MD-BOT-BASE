// Auto-converted from legacy registerCmd('delcmd', ...) in main.js
// Category: owner
const {
  downloadMedia,
  fReply,
  getQuotedMsg,
  newsletterReply,
  saveStickerCmds,
  stickerCmds
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'delcmd',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'delcmd': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  
  // Check if replying to a sticker
  const quotedMsg = getQuotedMsg(m);
  const stickerObj = quotedMsg?.stickerMessage || m.message?.stickerMessage;
  
  if (!stickerObj) {
    return fReply(conn, m, `🎴 *Reply to a sticker!*\n\nUsage: ${ctx.prefix}delcmd`, ctx.sessionName);
  }
  
  try {
    // Get sticker hash
    let stickerHash = null;
    if (stickerObj.fileSha256) {
      stickerHash = Buffer.from(stickerObj.fileSha256).toString('hex').slice(0, 16);
    } else if (stickerObj.fileEncSha256) {
      stickerHash = Buffer.from(stickerObj.fileEncSha256).toString('hex').slice(0, 16);
    } else {
      const stickerBuf = await downloadMedia(stickerObj, 'sticker');
      stickerHash = crypto.createHash('sha256').update(stickerBuf).digest('hex').slice(0, 16);
    }
    
    if (!stickerCmds.has(stickerHash)) {
      return fReply(conn, m, '🎴 *This sticker has no command assigned!*', ctx.sessionName);
    }
    
    const old = stickerCmds.get(stickerHash);
    stickerCmds.delete(stickerHash);
    saveStickerCmds();
    
    await fReply(conn, m, 
      `🗑️ *Sticker command removed!*\n\n` +
      `Removed: *${ctx.prefix}${old.cmd}*\n` +
      `🔖 Hash: \`${stickerHash}\``,
      ctx.sessionName
    );
  } catch (e) {
    console.error('[DELCMD] Error:', e);
    await fReply(conn, m, `🎴 *Failed to remove sticker command!*\n\nError: ${e.message}`, ctx.sessionName);
  }

      }
    }
  }
};
