// ─── TOAA Restart / Shutdown ─────────
const { errorReply, successReply } = require('../main');

module.exports = {
  name: 'power',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'restart': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner } = ctx;

        if (!isOwner) {
          return errorReply(conn, m, `This command is owner-only.`, sessionName);
        }

        await successReply(conn, m, `Restarting...`, sessionName);
        console.log(`[POWER] Restart triggered by owner in session: ${sessionName}`);

        setTimeout(() => process.exit(0), 1000);
      }
    },
    'shutdown': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner } = ctx;

        if (!isOwner) {
          return errorReply(conn, m, `This command is owner-only.`, sessionName);
        }

        await successReply(
          conn, m,
          `Shutting down. Note: if your hosting panel auto-restarts on exit, I'll come right back up — this isn't a guaranteed stay-off unless auto-restart is disabled on your end.`,
          sessionName
        );
        console.log(`[POWER] Shutdown triggered by owner in session: ${sessionName}`);

        setTimeout(() => process.exit(0), 1000);
      }
    }
  }
};
