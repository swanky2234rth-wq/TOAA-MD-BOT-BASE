// ─── TOAA RPG Casino ─────────
const { errorReply } = require('../main');
const { isRpgAllowed } = require('../helper/rpg');
const { getCoin, addCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { getSessionSetting } = require('../helper/function');

const MIN_BET = 1000;

module.exports = {
  name: 'casino',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'casino': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const balance = getCoin(jid);
  let betArg = args[0];

  if (!betArg) {
    let txt = `🎰 *TRAVELING CASINO* 🎰\n\nWelcome! Feeling lucky against the house?\n\n`;
    txt += `*How to bet:*\n👉 \`${prefix}casino <amount>\`\n\n`;
    txt += `Examples:\n👉 \`${prefix}casino 10000\`\n👉 \`${prefix}casino all\` (bold move!)`;
    return errorReply(conn, m, txt, sessionName);
  }

  let bet = /^all$/i.test(betArg) ? balance : parseInt(betArg);

  if (isNaN(bet) || bet < MIN_BET) {
    return errorReply(conn, m, `Gambling with pocket change? 💸\nMinimum bet here is *${fmtCoin(MIN_BET)}*!`, sessionName);
  }

  if (bet > balance) {
    return errorReply(conn, m, `No credit here! 😂\nYou've got *${fmtCoin(balance)}* but trying to bet *${fmtCoin(bet)}*.\nGo earn some first!`, sessionName);
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🎰', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `🎲 The house shuffles the dice and spins the roulette wheel... hold your breath!` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const playerScore = Math.floor(Math.random() * 100);
  const houseScore = Math.floor(Math.random() * 100);

  let result, emoji, change, houseTaunt;

  if (playerScore > houseScore) {
    result = 'YOU WIN!';
    emoji = '🎉';
    change = bet;
    addCoin(jid, bet);
    houseTaunt = `"Tch! Beginner's luck." — *The House* 😒`;
  } else if (playerScore < houseScore) {
    result = 'CRUSHED!';
    emoji = '💸';
    change = -bet;
    removeCoin(jid, bet);
    houseTaunt = `"HAHA! Broke and getting broker! Go home." — *The House* 😈`;
  } else {
    result = 'TIE!';
    emoji = '🤝';
    change = 0;
    houseTaunt = `"Hoo... a draw? Not bad, kid." — *The House* 👀`;
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: emoji, key: m.key } });

  let txt = `🎰 *CASINO TABLE CLOSED!* 🎰\n\n*Scoreboard:*\n`;
  txt += `👤 Your points: *${playerScore}*\n🤖 House points: *${houseScore}*\n\n`;
  txt += `*Result: ${emoji} ${result}*\n`;
  txt += change !== 0 ? `Money: *${change > 0 ? '+' : ''}${fmtCoin(change)}*\n\n` : `Money returned (broke even)\n\n`;
  txt += `${houseTaunt}\n\n*Balance:* ${fmtCoin(getCoin(jid))}`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
}
