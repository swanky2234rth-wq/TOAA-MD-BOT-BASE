// ─── TOAA GitHub Stalk ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'githubstalk',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'githubstalk': {
      category: 'stalker',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const username = args[0]?.trim();

        if (!username) {
          return errorReply(conn, m, `🐙 *GitHub Stalk*\n\nUsage: ${prefix}githubstalk <username>\nExample: ${prefix}githubstalk torvalds`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🔍', key: m.key } });

        try {
          // GitHub's own public API — no key needed, unlike the source's firefly.maiku.my.id
          const { data: d } = await axios.get(`https://api.github.com/users/${encodeURIComponent(username)}`, { timeout: 15000 });

          if (!d || d.message === 'Not Found') {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Username "${username}" not found.`, sessionName);
          }

          const caption =
            `🐙 *GitHub Stalk*\n\n` +
            `👤 *Username:* ${d.login}\n` +
            `📛 *Name:* ${d.name || '-'}\n` +
            `🏢 *Company:* ${d.company || '-'}\n` +
            `📍 *Location:* ${d.location || '-'}\n\n` +
            `📦 *Public Repos:* ${d.public_repos}\n` +
            `👥 *Followers:* ${d.followers}\n` +
            `👤 *Following:* ${d.following}\n\n` +
            `📝 *Bio:*\n${d.bio || '-'}\n\n` +
            `🔗 ${d.html_url}`;

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
          await conn.sendMessage(m.key.remoteJid, { image: { url: d.avatar_url }, caption }, { quoted: m });

        } catch (e) {
          console.error('[GITHUBSTALK] Error:', e.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
        }
      }
    }
  }
};
