// plugins/delete.js
async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}

function getQuotedCtx(m) {
  return m.message?.extendedTextMessage?.contextInfo || null;
}

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'Delete Message',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'del': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isAdmin, isOwner, botNumber } = ctx;
        const remoteJid = m.key.remoteJid;
        
        const quotedCtx = getQuotedCtx(m);
        if (!quotedCtx?.stanzaId) {
          return fReply(conn, m, '*_۞ Reply to a message you want to delete!_*', sessionName);
        }
        
        // Check if user can delete (admin, owner, or deleting their own message)
        const isDeletingOwn = quotedCtx.participant === ctx.senderJid;
        const isDeletingBot = quotedCtx.participant === `${botNumber}@s.whatsapp.net`;
        
        if (!isAdmin && !isOwner && !isDeletingOwn && !isDeletingBot) {
          return fReply(conn, m, '*_۞ You can only delete your own messages or bot messages!_*', sessionName);
        }
        
        const deleteKey = {
          remoteJid: remoteJid,
          fromMe: quotedCtx.participant === `${botNumber}@s.whatsapp.net`,
          id: quotedCtx.stanzaId,
          participant: quotedCtx.participant
        };
        
        try {
          await conn.sendMessage(remoteJid, { delete: deleteKey });
        } catch (e) {
          await fReply(conn, m, `*_۞ Failed to delete: ${e.message}_*`, sessionName);
        }
      }
    }
  }
};