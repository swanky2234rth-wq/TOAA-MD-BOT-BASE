// Auto-converted from legacy registerCmd('dare', ...) in main.js
// Category: games
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'dare',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'dare': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {

  try { const { data } = await axios.get('https://api.truthordarebot.xyz/v1/dare'); await fReply(conn, m, `🀄 *It's a Dare!*\n\n${data.question}`, ctx.sessionName); }
  catch { await fReply(conn, m, '*_۞ 𝙰𝙿𝙸 𝙴𝚛𝚛𝚘𝚛_*', ctx.sessionName); }

      }
    }
  }
};
