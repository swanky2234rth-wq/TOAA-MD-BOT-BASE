// Auto-converted from legacy registerCmd('listcmd', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  stickerCmds
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'listcmd',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'listcmd': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  
  if (stickerCmds.size === 0) {
    return fReply(conn, m, 
      `📋 *No sticker commands set yet.*\n\n` +
      `Use: ${ctx.prefix}setcmd <command> (reply to a sticker)`,
      ctx.sessionName
    );
  }
  
  const cmdList = Array.from(stickerCmds.entries()).map(([hash, data], i) => {
    const date = new Date(data.setAt).toLocaleString();
    return `${i+1}. *${ctx.prefix}${data.cmd}* — \`${hash}\`\n   📅 ${date}`;
  }).join('\n\n');
  
  await fReply(conn, m, 
    `📋 *Sticker Commands (${stickerCmds.size})*\n\n${cmdList}`,
    ctx.sessionName
  );

      }
    }
  }
};
