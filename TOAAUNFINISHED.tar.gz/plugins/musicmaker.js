// ─── TOAA Music Maker (AI song generator) ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'musicmaker',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'musicmaker': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const prompt = args.join(' ').trim();

        if (!prompt) {
          return errorReply(conn, m, `🎵 *Music Maker*\n\nUsage: ${prefix}musicmaker <description>\nExample: ${prefix}musicmaker upbeat lofi chill song about summer`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🎼', key: m.key } });
        await errorReply(conn, m, `🎵 Generating your song, this can take a minute...`, sessionName);

        try {
          const { data } = await axios.get(`https://api.nexray.eu.cc/ai/musicmaker?prompt=${encodeURIComponent(prompt)}`, {
            timeout: 120000,
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
          });

          const audioUrl = data?.result?.url || data?.result?.audio_url;

          if (!data.status || !audioUrl) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Couldn't generate that song — try a different description.`, sessionName);
          }

          await conn.sendMessage(m.key.remoteJid, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            fileName: `${prompt.slice(0, 40)}.mp3`
          }, { quoted: m });

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (error) {
          console.error('[MUSICMAKER] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Song generation timed out or failed — try again.`, sessionName);
        }
      }
    }
  }
};
