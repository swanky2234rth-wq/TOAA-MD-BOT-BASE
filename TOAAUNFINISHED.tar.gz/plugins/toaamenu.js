// ─── TOAA FULL MENU (${prefix}toaamenu) ───────────────────────────────────────
// Every command from every loaded plugin is listed here automatically —
// nothing here needs to be hand-maintained. Add a new plugin, it shows up.

const mainCore = require('../main');
const {
  COMMANDS,
  PLUGINS,
  getNewsletterFooter,
  loadUserSettings,
  applyFont,
} = mainCore;
const settings = require('../settings');

const CATEGORY_ORDER = ['utilities', 'downloader', 'group', 'media', 'games', 'ai', 'owner', 'plugin'];

function buildCategoryBlock(label, cmds) {
  const heading = applyFont(label.toUpperCase(), 12);
  const sorted = [...cmds].sort();
  const lines = sorted.map((c, i) => (i === 0 ? `║⥱${c}` : `║ ⤢${c}`));
  return (
    `╔═━═━═━═━═━═━═━═━═━╗\n` +
    `║  「☆」⌠ *${heading}* ⌡━❍\n` +
    lines.join('\n') + '\n' +
    `╚═━═━═━═━═━═━═━═━═━╝`
  );
}

module.exports = {
  name: 'toaamenu',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'toaamenu': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { prefix, senderNumber, sessionName } = ctx;
        const us = loadUserSettings(sessionName);
        const username = m.pushName || senderNumber;
        const pluginCount = mainCore.totalPluginsCount ?? (PLUGINS ? PLUGINS.size : 0);

        const categories = {};
        for (const [name, cmd] of Object.entries(COMMANDS)) {
          const cat = cmd.category || 'utilities';
          if (!categories[cat]) categories[cat] = [];
          categories[cat].push(name);
        }

        const orderedCats = [
          ...CATEGORY_ORDER.filter(c => categories[c]),
          ...Object.keys(categories).filter(c => !CATEGORY_ORDER.includes(c)).sort()
        ];

        const header =
          `┏━━═══[ *TOAA - MENU* ]═══━━\n` +
          `┃\n` +
          `┃ ╭────「 ᴍᴏʀᴇ ɪɴғᴏ 」────\n` +
          `┃  | ➻ ${applyFont('PREFIX', 12)} [ ${prefix} ]\n` +
          `┃  | ➻ ${applyFont('USER', 12)} [ ${username} ]\n` +
          `┃  | ➻ ${applyFont('PLUGINS', 12)} [ ${pluginCount} ]\n` +
          `┗━━━━━━━━━━━━━━━━━━━\n\n` +
          `  ━━━━━﹝${applyFont('COMMANDS', 12)}﹞━━━━━`;

        const body = orderedCats.map(cat => buildCategoryBlock(cat, categories[cat])).join('\n\n');

        const menuText = `${header}\n${body}`;
        const nl = getNewsletterFooter();

        const menuImg = us.menuImage || settings.MENU_IMAGE;
        try {
          if (menuImg && menuImg.startsWith('http')) {
            await conn.sendMessage(m.key.remoteJid, { image: { url: menuImg }, caption: menuText, ...nl }, { quoted: m });
          } else {
            throw new Error('no image configured');
          }
        } catch {
          await conn.sendMessage(m.key.remoteJid, { text: menuText, ...nl }, { quoted: m });
        }
      }
    }
  }
};
