// Auto-converted from legacy registerCmd('hangman', ...) in main.js
// Category: games
const {
  fReply,
  hangmanGames
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'hangman',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'hangman': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx; const remoteJid = m.key.remoteJid;
  if (args[0]?.toLowerCase() === 'end') {
    const g = hangmanGames.get(remoteJid); if (!g) return fReply(conn, m, '*_۞ 𝙽𝚘 𝙰𝚌𝚝𝚒𝚟𝚎 𝙶𝚊𝚖𝚎_*', sessionName);
    hangmanGames.delete(remoteJid); return fReply(conn, m, `🎮 Ended! Word was: *${g.word}*`, sessionName);
  }
  if (hangmanGames.has(remoteJid)) {
    const g = hangmanGames.get(remoteJid); const guess = args[0]?.toLowerCase();
    if (!guess || guess.length !== 1) return fReply(conn, m, `Guess a letter! ${prefix}hangman a`, sessionName);
    if (g.guessed.includes(guess)) return fReply(conn, m, `*_🎴 Already guessed: *${guess}*`, sessionName);
    g.guessed.push(guess); if (!g.word.includes(guess)) g.wrong++;
    const display = g.word.split('').map(l => g.guessed.includes(l) ? l : '_').join(' ');
    const won = !display.includes('_'), lost = g.wrong >= 6;
    if (won) { hangmanGames.delete(remoteJid); return fReply(conn, m, `🎉 Correct! Word: *${g.word}*!`, sessionName); }
    if (lost) { hangmanGames.delete(remoteJid); return fReply(conn, m, `💀 Game over! Word: *${g.word}*`, sessionName); }
    return fReply(conn, m, `🔤 *Hangman*\n\n${display}\n\n🎴 Wrong: ${g.wrong}/6\n🔡 Guessed: ${g.guessed.join(', ')}`, sessionName);
  }
  const words = ['javascript','whatsapp','android','telegram','discord','clover','programming','database','keyboard','monitor'];
  const word = words[Math.floor(Math.random() * words.length)];
  hangmanGames.set(remoteJid, { word, guessed: [], wrong: 0 });
  await fReply(conn, m, `🔤 *Hangman Started!*\n\n${'_ '.repeat(word.length).trim()}\n\n🎴 Wrong: 0/6\nGuess: ${prefix}hangman <letter>\nEnd: ${prefix}hangman end`, sessionName);

      }
    }
  }
};
