// Auto-converted from legacy registerCmd('vv', ...) in main.js
// Category: media
const {
  downloadMedia,
  fReply,
  getMediaType,
  getQuotedMsg,
  plainReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'vv',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'vv': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {

  const quotedMsg = getQuotedMsg(m);
  if (!quotedMsg) return fReply(conn, m, `Reply to a view-once message with ${ctx.prefix}vv`, ctx.sessionName);
  const inner = quotedMsg?.viewOnceMessageV2?.message || quotedMsg?.viewOnceMessage?.message || quotedMsg;
  const t = getMediaType(inner);
  if (!t) return fReply(conn, m, '*_۞ 𝙽𝚘 𝙼𝚎𝚍𝚒𝚊 𝙵𝚘𝚞𝚗𝚍_*', ctx.sessionName);
  try {
    const buf = await downloadMedia(t.inner, t.type);
    if (t.type === 'image') await conn.sendMessage(m.key.remoteJid, { image: buf, caption: '' }, { quoted: m });
    else if (t.type === 'video') await conn.sendMessage(m.key.remoteJid, { video: buf, caption: '' }, { quoted: m });
  } catch (e) { await plainReply(conn, m, `*_۞ 𝙵𝚊𝚒𝚕𝚎𝚍: ${e.message}_*`); }

      }
    }
  }
};
