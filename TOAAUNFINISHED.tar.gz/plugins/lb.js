/*
 * ─── LEADERBOARD PLUGIN ───────────────────────────────────────────────────────
 * Commands: lb, lb on, lb off
 * Tracks messages per user per group
 */

const fs = require('fs');
const path = require('path');

// ─── Storage ──────────────────────────────────────────────────────────────────
const DB_PATH = path.join(__dirname, '../database/lb_data.json');

function loadDB() {
  try {
    if (!fs.existsSync(DB_PATH)) {
      fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
      fs.writeFileSync(DB_PATH, JSON.stringify({}));
      return {};
    }
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
  } catch { return {}; }
}

function saveDB(data) {
  try {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
  } catch (e) { console.error('[LB] Save error:', e.message); }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

// lb_data structure:
// {
//   [groupJid]: {
//     active: true/false,
//     users: {
//       [number]: { count: 0, lastNotified: 0 }
//     }
//   }
// }

function getGroupData(db, groupJid) {
  if (!db[groupJid]) db[groupJid] = { active: false, users: {} };
  return db[groupJid];
}

function getUserData(groupData, number) {
  if (!groupData.users[number]) groupData.users[number] = { count: 0, lastNotified: 0 };
  return groupData.users[number];
}

// ─── Rank System ──────────────────────────────────────────────────────────────
const RANKS = [
  { name: 'Ⴆҽgιɳɳҽɾ',  min: 0,    max: 199  },
  { name: 'ɾҽgυℓαɾ',   min: 200,  max: 499  },
  { name: 'ρɾσ',        min: 500,  max: 999  },
  { name: 'є-ℓιƚҽ',    min: 1000, max: 1499 },
  { name: 'єℓιƚҽ-χ',   min: 1500, max: Infinity },
];

// Milestones to rank up (messages needed to reach next rank)
const RANK_UP_AT = [200, 500, 1000, 1500];

function getRank(count) {
  for (let i = RANKS.length - 1; i >= 0; i--) {
    if (count >= RANKS[i].min) return { ...RANKS[i], index: i };
  }
  return { ...RANKS[0], index: 0 };
}

// Progress bar: 15 blocks total
// filled = ▬, empty = ▭
function buildBar(count, topCount) {
  const TOTAL = 15;
  const ratio = topCount > 0 ? Math.min(count / topCount, 1) : 0;
  const filled = Math.round(ratio * TOTAL);
  return '▬'.repeat(filled) + '▭'.repeat(TOTAL - filled);
}

// ─── Leaderboard renderer ─────────────────────────────────────────────────────
async function renderLeaderboard(conn, groupJid, db) {
  const groupData = getGroupData(db, groupJid);
  const users = groupData.users;

  const sorted = Object.entries(users)
    .map(([num, data]) => ({ num, count: data.count }))
    .filter(u => u.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  if (!sorted.length) return null;

  const topCount = sorted[0].count;
  const mentions = sorted.map(u => `${u.num}@s.whatsapp.net`);

  let text = `   🪔 𝙻𝙴𝙰𝙳𝙴𝚁 𝙱𝙾𝙰𝚁𝙳 🪔\n\n`;

  for (const u of sorted) {
    const rank = getRank(u.count);
    const bar = buildBar(u.count, topCount);
    text += `@${u.num}  ${rank.name}  (${u.count} msgs)\n${bar}\n\n`;
  }

  return { text: text.trim(), mentions };
}

// ─── Rank-up notification ─────────────────────────────────────────────────────
async function checkRankUp(conn, groupJid, number, count) {
  for (const threshold of RANK_UP_AT) {
    if (count === threshold) {
      const rank = getRank(count);
      const prevRank = getRank(count - 1);
      if (rank.name !== prevRank.name) {
        await conn.sendMessage(groupJid, {
          text:
            `🏆 *Rank Up!*\n\n` +
            `@${number} has ranked up!\n\n` +
            `${prevRank.name} → *${rank.name}*\n` +
            `📊 Total messages: ${count}`,
          mentions: [`${number}@s.whatsapp.net`]
        });
      }
      break;
    }
  }
}

// ─── Message tracker (called from handleMessage hook) ─────────────────────────
async function trackMessage(conn, m, senderNumber) {
  const remoteJid = m?.key?.remoteJid;
  if (!remoteJid?.endsWith('@g.us')) return;

  const db = loadDB();
  const groupData = getGroupData(db, remoteJid);
  if (!groupData.active) return;

  const userData = getUserData(groupData, senderNumber);
  userData.count++;

  const count = userData.count;

  // Every 30 messages, notify current level
  if (count % 30 === 0) {
    const rank = getRank(count);
    await conn.sendMessage(remoteJid, {
      text:
        `📊 *Message Milestone!*\n\n` +
        `@${senderNumber}\n` +
        `💬 ${count} messages sent\n` +
        `🎖️ Level: *${rank.name}*`,
      mentions: [`${senderNumber}@s.whatsapp.net`]
    });
  }

  // Check if they just hit a rank-up threshold
  await checkRankUp(conn, remoteJid, senderNumber, count);

  saveDB(db);
}

// ─── Commands ─────────────────────────────────────────────────────────────────
const commands = {

  lb: {
    category: 'group',
    handler: async (conn, m, args, ctx) => {
      const { sessionName, isOwner, isAdmin, prefix } = ctx;
      const remoteJid = m.key.remoteJid;

      const sub = (args[0] || '').toLowerCase();

      // ── lb on ──
      if (sub === 'on') {
        if (!isOwner && !isAdmin) {
          return conn.sendMessage(remoteJid, { text: '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*' }, { quoted: m });
        }
        if (!remoteJid.endsWith('@g.us')) {
          return conn.sendMessage(remoteJid, { text: '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*' }, { quoted: m });
        }

        const db = loadDB();
        const groupData = getGroupData(db, remoteJid);

        if (groupData.active) {
          return conn.sendMessage(remoteJid, { text: '*_💈 Leaderboard is already ON_*' }, { quoted: m });
        }

        groupData.active = true;
        saveDB(db);

        return conn.sendMessage(remoteJid, {
          text:
            `⃞᯽ 𝙻𝙴𝙰𝙳𝙴𝚁 𝙱𝙾𝙰𝚁𝙳   ⃞᯽ \n\n` +
            `✅ *Leaderboard is now ACTIVE!*\n\n` +
            `📊 Messages are being tracked.\n` +
            `🔔 Every 30 messages you'll get your level.\n\n` +
            `🎖️ *Ranks:*\n` +
            `• Ⴆҽgιɳɳҽɾ → 0 msgs\n` +
            `• ɾҽgυℓαɾ → 200 msgs\n` +
            `• ρɾσ → 500 msgs\n` +
            `• є-ℓιƚҽ → 1000 msgs\n` +
            `• єℓιƚҽ-χ → 1500 msgs\n\n` +
            `Type *${prefix}lb* to see the board!`
        }, { quoted: m });
      }

      // ── lb off ──
      if (sub === 'off') {
        if (!isOwner && !isAdmin) {
          return conn.sendMessage(remoteJid, { text: '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*' }, { quoted: m });
        }
        if (!remoteJid.endsWith('@g.us')) {
          return conn.sendMessage(remoteJid, { text: '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*' }, { quoted: m });
        }

        const db = loadDB();
        const groupData = getGroupData(db, remoteJid);

        if (!groupData.active) {
          return conn.sendMessage(remoteJid, { text: '*_💈 Leaderboard is already OFF_*' }, { quoted: m });
        }

        groupData.active = false;
        saveDB(db);

        return conn.sendMessage(remoteJid, {
          text: `꧁ 𒅒 𝙻𝙴𝙰𝙳𝙴𝚁 𝙱𝙾𝙰𝚁𝙳 𒅒 ꧂\n\n❌ *Leaderboard has been turned OFF.*\nScores are saved.`
        }, { quoted: m });
      }

      // ── lb reset (owner only) ──
      if (sub === 'reset') {
        if (!isOwner) {
          return conn.sendMessage(remoteJid, { text: '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*' }, { quoted: m });
        }
        const db = loadDB();
        if (db[remoteJid]) db[remoteJid].users = {};
        saveDB(db);
        return conn.sendMessage(remoteJid, { text: '*_💈 Leaderboard scores reset!_*' }, { quoted: m });
      }

      // ── lb (show board) ──
      if (!remoteJid.endsWith('@g.us')) {
        return conn.sendMessage(remoteJid, { text: '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*' }, { quoted: m });
      }

      const db = loadDB();
      const result = await renderLeaderboard(conn, remoteJid, db);

      if (!result) {
        return conn.sendMessage(remoteJid, {
          text: `꧁ 𒅒 𝙻𝙴𝙰𝙳𝙴𝚁 𝙱𝙾𝙰𝚁𝙳 𒅒 ꧂\n\n_No data yet. Turn on with ${prefix}lb on_`
        }, { quoted: m });
      }

      await conn.sendMessage(remoteJid, {
        text: result.text,
        mentions: result.mentions
      }, { quoted: m });
    }
  }
};

// ─── Hook export (call this from your main handleMessage) ─────────────────────
// In your main.js handleMessage, before the prefix check, add:
//   await require('./plugins/lb').onMessage(conn, m, senderNumber);

async function onMessage(conn, m, senderNumber) {
  try {
    await trackMessage(conn, m, senderNumber);
  } catch (e) {
    console.error('[LB] onMessage error:', e.message);
  }
}

module.exports = {
  name: 'Leaderboard',
  version: '1.0',
  author: 'TOAA',
  commands,
  onMessage,
};
