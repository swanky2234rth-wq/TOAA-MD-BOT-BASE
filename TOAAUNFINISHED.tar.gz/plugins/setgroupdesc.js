// Auto-converted from legacy registerCmd('setgroupdesc', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setgroupdesc',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setgroupdesc': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const desc = args.join(' ').trim();
  if (!desc) return fReply(conn, m, `Usage: ${ctx.prefix}setgroupdesc <desc>`, ctx.sessionName);
  await conn.groupUpdateDescription(m.key.remoteJid, desc);
  await fReply(conn, m, '*_💈 𝙶𝚛𝚘𝚞𝚙 𝙳𝚎𝚜𝚌 𝚄𝚙𝚍𝚊𝚝𝚎𝚍_*', ctx.sessionName);

      }
    }
  }
};
