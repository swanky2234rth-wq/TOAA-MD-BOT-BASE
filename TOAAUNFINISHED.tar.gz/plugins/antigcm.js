// plugins/antigcm.js
console.log('[ANTIGCM] Plugin file is being loaded!');

const {
  antigcmSettings,
  fReply,
  requireAdmin,
  saveAntigcmSettings
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'antigcm',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'antigcm': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        
        console.log('[ANTIGCM] Command triggered by:', ctx.senderNumber);
        console.log('[ANTIGCM] Args:', args);
        console.log('[ANTIGCM] Remote JID:', m.key.remoteJid);

        // Check if user is admin
        console.log('[ANTIGCM] Checking admin status...');
        if (!requireAdmin(ctx, conn, m)) {
          console.log('[ANTIGCM] User is not admin - access denied');
          return;
        }
        console.log('[ANTIGCM] User is admin - proceeding');

        const remoteJid = m.key.remoteJid;
        console.log('[ANTIGCM] Remote JID:', remoteJid);

        // Check if it's a group
        if (!remoteJid.endsWith('@g.us')) {
          console.log('[ANTIGCM] Not a group - sending error message');
          await fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
          return;
        }
        console.log('[ANTIGCM] Target is a group');

        const option = (args[0] || '').toLowerCase();
        const mode = args[1]?.toLowerCase();
        console.log('[ANTIGCM] Option:', option);
        console.log('[ANTIGCM] Mode:', mode);

        // ─── ON ──────────────────────────────────────────────────────────────────
        if (option === 'on') {
          console.log('[ANTIGCM] Setting mode to: ON (true)');
          antigcmSettings.set(remoteJid, true);
          saveAntigcmSettings();
          console.log('[ANTIGCM] Current antigcmSettings:', antigcmSettings.get(remoteJid));
          await fReply(conn, m, `*_💈 𝙰𝚗𝚝𝚒-𝙶𝙲𝙼: ON_*\n\n🎴 Status mentions will be deleted.`, ctx.sessionName);
          console.log('[ANTIGCM] ON command completed');
        }
        
        // ─── OFF ─────────────────────────────────────────────────────────────────
        else if (option === 'off') {
          console.log('[ANTIGCM] Setting mode to: OFF (false)');
          antigcmSettings.set(remoteJid, false);
          saveAntigcmSettings();
          console.log('[ANTIGCM] Current antigcmSettings:', antigcmSettings.get(remoteJid));
          await fReply(conn, m, `*_💈 𝙰𝚗𝚝𝚒-𝙶𝙲𝙼: OFF_*`, ctx.sessionName);
          console.log('[ANTIGCM] OFF command completed');
        }

        // ─── WARN ─────────────────────────────────────────────────────────────────
        else if (option === 'warn') {
          console.log('[ANTIGCM] Setting mode to: WARN');
          antigcmSettings.set(remoteJid, 'warn');
          saveAntigcmSettings();
          console.log('[ANTIGCM] Current antigcmSettings:', antigcmSettings.get(remoteJid));
          await fReply(conn, m, `*_💈 𝙰𝚗𝚝𝚒-𝙶𝙲𝙼: WARN_*\n\n⚠️ Users will be warned before deletion.`, ctx.sessionName);
          console.log('[ANTIGCM] WARN command completed');
        }

        // ─── KICK ─────────────────────────────────────────────────────────────────
        else if (option === 'kick') {
          console.log('[ANTIGCM] Setting mode to: KICK');
          antigcmSettings.set(remoteJid, 'kick');
          saveAntigcmSettings();
          console.log('[ANTIGCM] Current antigcmSettings:', antigcmSettings.get(remoteJid));
          await fReply(conn, m, `*_💈 𝙰𝚗𝚝𝚒-𝙶𝙲𝙼: KICK_*\n\n🔨 Users will be kicked after 3 warnings.`, ctx.sessionName);
          console.log('[ANTIGCM] KICK command completed');
        }

        // ─── STATUS ───────────────────────────────────────────────────────────────
        else if (option === 'status') {
          console.log('[ANTIGCM] Checking status...');
          const currentMode = antigcmSettings.get(remoteJid) || false;
          console.log('[ANTIGCM] Current mode for', remoteJid, ':', currentMode);
          const modeText = currentMode === 'warn' ? '⚠️ WARN' : currentMode === 'kick' ? '🔨 KICK' : currentMode === true ? '🗑️ DELETE' : '❌ OFF';
          await fReply(conn, m, `*_💈 𝙰𝚗𝚝𝚒-𝙶𝙲𝙼: ${modeText}_*`, ctx.sessionName);
          console.log('[ANTIGCM] STATUS command completed');
        }

        // ─── HELP ─────────────────────────────────────────────────────────────────
        else {
          console.log('[ANTIGCM] Showing help menu');
          await fReply(conn, m, 
            `🀄 *Anti Group Chat Mention*\n\n` +
            `📌 *Usage:*\n` +
            `   • ${ctx.prefix}antigcm on - Delete only\n` +
            `   • ${ctx.prefix}antigcm warn - Warn then delete\n` +
            `   • ${ctx.prefix}antigcm kick - Kick after 3 warnings\n` +
            `   • ${ctx.prefix}antigcm off - Disable\n` +
            `   • ${ctx.prefix}antigcm status - Check current mode\n\n` +
            `💡 *What it does:*\n` +
            `   Detects when someone tags the group from their status\n` +
            `   and automatically takes action.`,
            ctx.sessionName
          );
          console.log('[ANTIGCM] Help menu displayed');
        }

        console.log('[ANTIGCM] Command handler finished');
      }
    }
  }
};