// Auto-converted from legacy registerCmd('pdm', ...) in main.js
// Category: group
const {
  fReply,
  getGroupSettings,
  requireAdmin,
  updateGroupSettings
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'pdm',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'pdm': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const option = (args[0] || '').toLowerCase();
  if (!['on', 'off'].includes(option)) return fReply(conn, m, `Usage: ${ctx.prefix}pdm on/off`, ctx.sessionName);
  const gs = getGroupSettings(remoteJid);
  gs.pdm = option === 'on';
  updateGroupSettings(remoteJid, { pdm: gs.pdm });
  await fReply(conn, m, `*_💈 𝙿𝙳𝙼 (Promote/Demote Message): ${option.toUpperCase()}_*`, ctx.sessionName);

      }
    }
  }
};
