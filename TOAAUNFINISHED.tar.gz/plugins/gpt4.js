// Auto-converted from legacy registerCmd('gpt4', ...) in main.js
// Category: ai
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'gpt4',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'gpt4': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx;
  const text = args.join(' ').trim();
  if (!text) return fReply(conn, m, `Example: ${prefix}gpt4 explain black holes`, sessionName);
  await fReply(conn, m, '*_💈 𝚃𝚑𝚒𝚗𝚔𝚒𝚗𝚐..._*', sessionName);
  try {
    const response = await axios.post('https://chateverywhere.app/api/chat/', { model: { id: 'gpt-4', name: 'GPT-4', maxLength: 32000, tokenLimit: 8000, completionTokenLimit: 5000, deploymentName: 'gpt-4' }, messages: [{ pluginId: null, content: text, role: 'user' }], prompt: 'Your name is Furina. You are a helpful AI assistant.', temperature: 0.5 }, { headers: { 'Accept': '*/*', 'User-Agent': 'Mozilla/5.0' } });
    await fReply(conn, m, response.data || '*_۞ 𝙽𝚘 𝚁𝚎𝚜𝚙𝚘𝚗𝚜𝚎_*', sessionName);
  } catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
