// ─── TOAA Fake iPhone Quote Message ─────────
const { errorReply } = require('../main');

module.exports = {
  name: 'iqc',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'iqc': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, command } = ctx;
        const text = args.join(' ').trim();

        if (!text) {
          return errorReply(conn, m, `Example:\n${prefix}${command} hidup Jokowi`, sessionName);
        }

        try {
          const url = `https://veloria-ui.vercel.app/imagecreator/fake-chat?time=12:00&messageText=${encodeURIComponent(text)}&batteryPercentage=100`;

          await conn.sendMessage(m.key.remoteJid, {
            image: { url },
            caption: '📱 *Fake iPhone Quoted Message*'
          }, { quoted: m });
        } catch (e) {
          console.error('[IQC] Error:', e.message);
          await errorReply(conn, m, `Couldn't generate that image — try again.`, sessionName);
        }
      }
    }
  }
};
