// Auto-converted from legacy registerCmd('goodbye', ...) in main.js
// Category: group
const {
  fReply,
  getDefaultGoodbyeMessage,
  goodbyeMessages,
  goodbyeSettings,
  newsletterReply,
  processCustomMessage,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'goodbye',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'goodbye': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  
  const remoteJid = m.key.remoteJid;
  const option = (args[0] || '').toLowerCase();
  
  if (option === 'on') {
    goodbyeSettings.set(remoteJid, true);
    await fReply(conn, m, `*_💈 Goodbye messages: ON_*`, ctx.sessionName);
  }
  else if (option === 'off') {
    goodbyeSettings.set(remoteJid, false);
    await fReply(conn, m, `*_💈 Goodbye messages: OFF_*`, ctx.sessionName);
  }
  else if (option === 'set') {
    if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ Owner only command_*', ctx.sessionName);
    const customMsg = args.slice(1).join(' ');
    if (!customMsg) {
      return fReply(conn, m, 
        `*📝 Goodbye Message Setup*\n\n` +
        `Usage: ${ctx.prefix}goodbye set <message>\n\n` +
        `Variables you can use:\n` +
        `• {group} - Group name\n` +
        `• {user} - User's mention tag (number)\n` +
        `• {userName} - User's name\n\n` +
        `Example: ${ctx.prefix}goodbye set Sad to see you go {userName}! {group} will miss you!`,
        ctx.sessionName
      );
    }
    goodbyeMessages.set(remoteJid, customMsg);
    await fReply(conn, m, `✅ *Custom goodbye message saved!*\n\nPreview:\n${processCustomMessage(customMsg, 'Group Name', 'User Name', '1234567890')}`, ctx.sessionName);
  }
  else if (option === 'reset') {
    if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ Owner only command_*', ctx.sessionName);
    goodbyeMessages.delete(remoteJid);
    await fReply(conn, m, `✅ *Goodbye message reset to default!*`, ctx.sessionName);
  }
  else if (option === 'view') {
    const current = goodbyeMessages.get(remoteJid);
    if (current) {
      await fReply(conn, m, `📝 *Current goodbye message:*\n\n${current}\n\nVariables: {group}, {user}, {userName}`, ctx.sessionName);
    } else {
      await fReply(conn, m, `📝 *Using default goodbye message*\n\n${getDefaultGoodbyeMessage('Group Name', '1234567890')}`, ctx.sessionName);
    }
  }
  else {
    await fReply(conn, m, 
      `*Goodbye Command Usage:*\n\n` +
      `${ctx.prefix}goodbye on - Enable goodbye messages\n` +
      `${ctx.prefix}goodbye off - Disable goodbye messages\n` +
      `${ctx.prefix}goodbye set <message> - Set custom message (owner only)\n` +
      `${ctx.prefix}goodbye reset - Reset to default (owner only)\n` +
      `${ctx.prefix}goodbye view - View current message`,
      ctx.sessionName
    );
  }

      }
    }
  }
};
