// ─── TOAA RPG Mining ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addItem } = require('../helper/rpg');
const { ITEMS } = require('../helper/rpgItems');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 20;
const COOLDOWN_MS = 60 * 1000;
const cooldowns = new Map();

const DROPS = [
  { item: 'rock', chance: 80, min: 2, max: 5 },
  { item: 'coal', chance: 50, min: 1, max: 3 },
  { item: 'iron', chance: 30, min: 1, max: 2 },
  { item: 'gold', chance: 15, min: 1, max: 1 },
  { item: 'diamond', chance: 5, min: 1, max: 1 },
  { item: 'emerald', chance: 2, min: 1, max: 1 }
];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'mining',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'mining': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still catching your breath from the last dig! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m,
      `Your body's already wrecked! 🥵\n\nMining costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext stamina point in ~${fmtEta(eta)}.`,
      sessionName
    );
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '⛏️', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Tink! Tink! ⛏️💎\nBreaking through hard rock deep in the cave...` }, { quoted: m });

  await new Promise((resolve) => setTimeout(resolve, 3000));

  const results = [];
  for (const drop of DROPS) {
    if (Math.random() * 100 <= drop.chance) {
      const qty = Math.floor(Math.random() * (drop.max - drop.min + 1)) + drop.min;
      addItem(jid, drop.item, qty);
      results.push({ item: ITEMS[drop.item], qty });
    }
  }
  if (results.length === 0) {
    addItem(jid, 'rock', 1);
    results.push({ item: ITEMS.rock, qty: 1 });
  }

  const expGain = Math.floor(Math.random() * 500) + 100;
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  let txt = `THE ROCK CRACKED OPEN! ⛏️✨\n\nYou dug up:\n`;
  for (const r of results) txt += `${r.item.emote} ${r.item.name}: *+${r.qty}*\n`;
  txt += `\n📈 EXP: *+${expGain}*\n⚡ Stamina: *-${STAMINA_COST}*\n\n`;
  txt += `Keep it safe — you can craft or sell it later! 💎💰`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
