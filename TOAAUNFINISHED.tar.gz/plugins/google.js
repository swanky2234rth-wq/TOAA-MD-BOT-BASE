// plugins/google.js
console.log('[GOOGLE] Plugin loaded!');

const axios = require('axios');
const { fReply, errorReply } = require('../main');

module.exports = {
  name: 'Google',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'google': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const remoteJid = m.key.remoteJid;
        const query = args.join(' ');

        if (!query) {
          return fReply(conn, m, 
            `🔍 *Google Search*\n\n` +
            `Usage: *${prefix}google <query>*\n` +
            `Example: *${prefix}google what is node.js*`,
            sessionName
          );
        }

        await fReply(conn, m, `🔍 Searching for: *${query}*...`, sessionName);

        try {
          const google = require('google-it');
          const results = await google({ query, limit: 5 });

          if (!results || results.length === 0) {
            return fReply(conn, m, `❌ No results found for: *${query}*`, sessionName);
          }

          let text = `🔍 *Google Search Results for: ${query}*\n\n`;
          results.forEach((item, index) => {
            text += `*${index + 1}. ${item.title}*\n`;
            text += `🔗 ${item.link}\n`;
            text += `📝 ${item.snippet}\n\n`;
          });

          await fReply(conn, m, text.slice(0, 4000), sessionName);
        } catch (error) {
          console.error('[GOOGLE] Error:', error.message);
          await errorReply(conn, m, `❌ Search failed: ${error.message}`, sessionName);
        }
      }
    }
  }
};