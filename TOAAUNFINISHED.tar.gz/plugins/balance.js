const mainCore = require('../main');
const { resolveTarget, resolveDisplayJid } = mainCore;
const econ = require('../helper/economy');

module.exports = {
  name: 'balance',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'balance': {
      category: 'economy',
      handler: async (conn, m, args, ctx) => {
        const { senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;
        const rawTargetJid = resolveTarget(m, args);

        let targetJid = rawTargetJid;
        if (rawTargetJid && remoteJid.endsWith('@g.us')) {
          const meta = await conn.groupMetadata(remoteJid).catch(() => null);
          if (meta?.participants) targetJid = resolveDisplayJid(rawTargetJid, meta.participants);
        }
        const targetNumber = targetJid ? targetJid.split('@')[0].split(':')[0] : senderNumber;
        const isSelf = targetNumber === senderNumber;

        const acc = econ.getAccount(targetNumber);
        const rareItems = Object.entries(acc.items).filter(([, v]) => v > 0);
        const rareText = rareItems.length
          ? rareItems.map(([k, v]) => `${v}x ${econ.ITEM_LABELS[k]}`).join('\n')
          : 'None';

        await conn.sendMessage(m.key.remoteJid, {
          text: `💳 *${isSelf ? 'Your Balance' : `@${targetNumber}'s Balance`}*\n\n` +
            `💰 Cash: ${econ.fmtMoney(acc.balance)}\n` +
            `💎 Rare items:\n${rareText}\n\n` +
            `🏆 Net worth: ${econ.fmtMoney(econ.netWorth(targetNumber))}`,
          mentions: isSelf ? [] : [`${targetNumber}@s.whatsapp.net`]
        }, { quoted: m });
      }
    }
  }
};
