// ─── TOAA RPG Bank ─────────
const { fReply, errorReply } = require('../main');
const { isRpgAllowed } = require('../helper/rpg');
const { getWallet, deposit, withdraw, fmtCoin } = require('../helper/rpgCoin');
const { getSessionSetting } = require('../helper/function');

module.exports = {
  name: 'bank',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'bank': {
      category: 'rpg',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const jid = m.key.participant || m.key.remoteJid;

        if (!isRpgAllowed(m, ctx, getSessionSetting)) {
          return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
        }

        const action = args[0]?.toLowerCase();
        const amountStr = args[1];
        const wallet = getWallet(jid);

        if (action === 'deposit' || action === 'depo') {
          const amount = amountStr === 'all' ? wallet.coin : parseInt(amountStr);
          if (!amount || amount <= 0) return errorReply(conn, m, `Enter a valid coin amount to deposit.`, sessionName);
          if (wallet.coin < amount) return errorReply(conn, m, `You don't have enough coin! Wallet: *${fmtCoin(wallet.coin)}*`, sessionName);

          deposit(jid, amount);
          const w = getWallet(jid);
          return fReply(conn, m, `🏦 *Deposit successful!*\n\n✅ Deposited: *${fmtCoin(amount)}*\n💳 Bank balance: *${fmtCoin(w.bank)}*`, sessionName);
        }

        if (action === 'withdraw' || action === 'tarik') {
          const amount = amountStr === 'all' ? wallet.bank : parseInt(amountStr);
          if (!amount || amount <= 0) return errorReply(conn, m, `Enter a valid coin amount to withdraw.`, sessionName);
          if (wallet.bank < amount) return errorReply(conn, m, `Your bank balance is too low! Bank: *${fmtCoin(wallet.bank)}*`, sessionName);

          withdraw(jid, amount);
          const w = getWallet(jid);
          return fReply(conn, m, `🏧 *Withdrawal successful!*\n\n✅ Withdrew: *${fmtCoin(amount)}*\n💰 Wallet: *${fmtCoin(w.coin)}*`, sessionName);
        }

        let txt = `🏦 *RPG BANK*\n\n`;
        txt += `💰 Wallet: *${fmtCoin(wallet.coin)}*\n`;
        txt += `💳 Bank: *${fmtCoin(wallet.bank)}*\n\n`;
        txt += `*Services:*\n`;
        txt += `Deposit: \`${prefix}bank deposit <amount>\`\n`;
        txt += `Withdraw: \`${prefix}bank withdraw <amount>\`\n\n`;
        txt += `_Use "all" to deposit/withdraw everything at once._`;

        return fReply(conn, m, txt, sessionName);
      }
    }
  }
};
