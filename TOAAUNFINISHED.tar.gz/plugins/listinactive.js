// ─── TOAA List Inactive ─────────
const { errorReply } = require('../main');
const { getGroupActivity } = require('../helper/activityTracker');

const INACTIVE_THRESHOLD = 24 * 60 * 60 * 1000; // 24h

module.exports = {
  name: 'listinactive',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'listinactive': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isAdmin, isOwner } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `This command can only be used in groups.`, sessionName);
        }
        if (!isAdmin && !isOwner) {
          return errorReply(conn, m, `Only group admins can use this command.`, sessionName);
        }

        let groupMetadata;
        try {
          groupMetadata = await conn.groupMetadata(remoteJid);
        } catch (e) {
          return errorReply(conn, m, `Couldn't fetch group members — try again.`, sessionName);
        }

        const activity = getGroupActivity(remoteJid);
        const inactive = [];

        for (const p of groupMetadata.participants) {
          const data = activity[p.id];
          // No recorded activity at all = treat as inactive (never sent a tracked message)
          if (!data || (Date.now() - data.lastActive >= INACTIVE_THRESHOLD)) {
            inactive.push(p.id);
          }
        }

        if (!inactive.length) {
          return errorReply(conn, m, `No inactive users found (24h+).`, sessionName);
        }

        const text = `*👥 Inactive Users (24h+)*\n\n${inactive.map(id => `@${id.split('@')[0]}`).join('\n')}`;

        await conn.sendMessage(remoteJid, { text, mentions: inactive }, { quoted: m });
      }
    }
  }
};
