// ─── TOAA Discord Stalk ─────────
// Covers both `discordstalk` and `stalkdc` (same lookup, same API — the
// legacy stalkdc.js used a fragile reCAPTCHA-bypass flow against
// dclookup.id; this uses the same neoxr endpoint as legacy discordstalk.js
// instead, since it's far more reliable and needs no captcha solving).
const { errorReply } = require('../main');
const axios = require('axios');

const NEOXR_APIKEY = 'Milik-Bot-OurinMD';

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const userId = args[0]?.trim();

  if (!userId) {
    return errorReply(conn, m, `🎮 *Discord Stalk*\n\nUsage: ${prefix}discordstalk <userid>\nExample: ${prefix}discordstalk 297574907510784000`, sessionName);
  }

  if (!/^\d+$/.test(userId)) {
    return errorReply(conn, m, `User ID must be numeric. Example: 297574907510784000`, sessionName);
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🔍', key: m.key } });

  try {
    const { data } = await axios.get(`https://api.neoxr.eu/api/dcstalk?id=${userId}&apikey=${NEOXR_APIKEY}`, { timeout: 30000 });

    if (!data?.status || !data?.data) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `User ID *${userId}* not found.`, sessionName);
    }

    const d = data.data;
    const createdDate = d.created_at ? new Date(d.created_at).toDateString() : '-';

    const caption =
      `🎮 *Discord Stalk*\n\n` +
      `👤 *Username:* ${d.username || '-'}\n` +
      `📛 *Display Name:* ${d.global_name || '-'}\n` +
      `🔢 *Discriminator:* #${d.discriminator || '0'}\n` +
      `🆔 *User ID:* ${d.id}\n\n` +
      `📅 *Created:* ${createdDate}`;

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

    if (d.avatar_url) {
      await conn.sendMessage(m.key.remoteJid, { image: { url: d.avatar_url }, caption }, { quoted: m });
    } else {
      await conn.sendMessage(m.key.remoteJid, { text: caption }, { quoted: m });
    }

  } catch (e) {
    console.error('[DISCORDSTALK] Error:', e.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
  }
}

module.exports = {
  name: 'discordstalk',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'discordstalk': { category: 'stalker', handler: run },
    'stalkdc': { category: 'stalker', handler: run },
    'dcstalk': { category: 'stalker', handler: run }
  }
};
