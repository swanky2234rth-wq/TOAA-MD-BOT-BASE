// Auto-converted from legacy registerCmd('setgroupname', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setgroupname',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setgroupname': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const name = args.join(' ').trim();
  if (!name) return fReply(conn, m, `Usage: ${ctx.prefix}setgroupname <name>`, ctx.sessionName);
  await conn.groupUpdateSubject(m.key.remoteJid, name);
  await fReply(conn, m, `*_💈 𝙶𝚛𝚘𝚞𝚙 𝙽𝚊𝚖𝚎: ${name}_*`, ctx.sessionName);

      }
    }
  }
};
