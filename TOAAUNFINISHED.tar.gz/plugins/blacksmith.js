// ─── TOAA RPG Blacksmith ─────────
// NOTE: legacy source had both craft.js and blacksmith.js — same forging
// concept, overlapping items, different mechanics. Ported blacksmith.js
// (more complete: 10 recipes, exp reward, named result item) and skipped
// craft.js as a duplicate.
const { errorReply, fReply } = require('../main');
const { getUser, addExp, isRpgAllowed, removeItem, addItem } = require('../helper/rpg');
const { BLACKSMITH_RECIPES } = require('../helper/rpgRecipes');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'blacksmith',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'blacksmith': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const itemKey = args[0]?.toLowerCase();
  const user = getUser(jid);

  if (!itemKey) {
    let txt = `🔨 *THE BLACKSMITH*\n\nWelcome, adventurer! What should I forge today?\n\n`;
    for (const [key, recipe] of Object.entries(BLACKSMITH_RECIPES)) {
      const mats = Object.entries(recipe.materials).map(([mat, qty]) => `${qty}x ${mat}`).join(', ');
      txt += `*${recipe.name}*\n📦 Needs: ${mats}\n📈 EXP: +${recipe.exp}\n👉 \`${prefix}blacksmith ${key}\`\n\n`;
    }
    txt += `💡 *Tip:* find materials via mining or hunt!`;
    return fReply(conn, m, txt.trim(), sessionName);
  }

  const recipe = BLACKSMITH_RECIPES[itemKey];
  if (!recipe) {
    return errorReply(conn, m, `I don't have a blueprint for that! Check \`${prefix}blacksmith\` for the list.`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ The forge is still hot from last time! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const missing = [];
  for (const [mat, needed] of Object.entries(recipe.materials)) {
    const have = user.inventory[mat] || 0;
    if (have < needed) missing.push(`${mat}: ${have}/${needed}`);
  }
  if (missing.length > 0) {
    return errorReply(conn, m, `Not enough materials for *${recipe.name}*!\n\n${missing.join('\n')}`, sessionName);
  }

  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🔨', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Ting! Ting! Cshhh... 🔥🔨\nForging *${recipe.name}*... this'll take a moment!` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 4000));

  for (const [mat, needed] of Object.entries(recipe.materials)) {
    removeItem(jid, mat, needed);
  }

  const resultQty = recipe.qty || 1;
  addItem(jid, recipe.result, resultQty);

  const levelResult = addExp(jid, recipe.exp);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  let txt = `FORGING COMPLETE! ⚔️🛡️\n\nClean work — here's what you made:\n`;
  txt += `🔨 Item: *${recipe.name}*\n📊 Qty: *+${resultQty}*\n📈 Crafting EXP: *+${recipe.exp}*\n\nReady for battle! 😎🔥`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
