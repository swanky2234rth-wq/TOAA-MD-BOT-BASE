// Auto-converted from legacy registerCmd('setprefix', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setprefix',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setprefix': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  if (!args[0]) return fReply(conn, m, `Usage: ${ctx.prefix}setprefix <symbol>`, ctx.sessionName);
  setSessionSetting(ctx.sessionName, 'prefix', args[0].trim());
  await fReply(conn, m, ` *_Prefix changed to: ${args[0].trim()}_*`, ctx.sessionName);

      }
    }
  }
};
