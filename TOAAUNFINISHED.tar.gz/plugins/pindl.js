// ─── TOAA Pinterest Downloader ─────────

const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'pindl',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'pindl': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const url = args.join(' ').trim();

        if (!url) {
          return errorReply(conn, m,
            `📌 *Pinterest Download*\n\nUsage: ${prefix}pindl <url>\nExample: ${prefix}pindl https://pin.it/xxx`,
            sessionName
          );
        }
        if (!url.includes('pinterest') && !url.includes('pin.it')) {
          return errorReply(conn, m, `Invalid URL — use a Pinterest link.`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          const { data: res } = await axios.get(`https://api.azbry.com/api/download/pinterest?url=${encodeURIComponent(url)}`, { timeout: 20000 });

          if (!res?.status || !res?.result) {
            throw new Error('Failed to fetch data from Pinterest API.');
          }

          const data = res.result;
          let mediaUrl = null;
          let mediaType = null;

          if (data.type === 'video') {
            mediaUrl = data.videos?.[0]?.url || data.download;
            mediaType = 'video';
          } else if (data.images?.length > 0) {
            const orig = data.images.find(img => img.name === 'orig') || data.images[data.images.length - 1];
            mediaUrl = orig?.url;
            mediaType = 'image';
          } else if (data.download) {
            mediaUrl = data.download;
            mediaType = 'image';
          }

          if (!mediaUrl) throw new Error('No media found in that pin.');

          if (mediaType === 'video' && mediaUrl.includes('.m3u8')) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `This pin's video is only available as a stream format that can't be sent directly — try a different pin.`, sessionName);
          }

          if (mediaType === 'video') {
            await conn.sendMessage(m.key.remoteJid, { video: { url: mediaUrl }, caption: '📌 Pinterest' }, { quoted: m });
          } else {
            await conn.sendMessage(m.key.remoteJid, { image: { url: mediaUrl }, caption: '📌 Pinterest' }, { quoted: m });
          }

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (e) {
          console.error('[PINDL] Error:', e.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Couldn't download that pin — try again.`, sessionName);
        }
      }
    }
  }
};
