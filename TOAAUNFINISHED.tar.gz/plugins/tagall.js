// ─── TOAA Tag All ─────────
const {
  fReply,
  requireAdmin,
  normalizeNumber
} = require('../main');

module.exports = {
  name: 'tagall',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'tagall': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!requireAdmin(ctx, conn, m)) return;

        const remoteJid = m.key.remoteJid;
        if (!remoteJid.endsWith('@g.us')) {
          return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
        }

        const meta = await conn.groupMetadata(remoteJid);
        const members = meta.participants.map(p => p.id);
        const message = args.join(' ');

        const header = `Tᴀɢ Aʟʟ Cᴍᴅ Iɴɪᴛɪᴀᴛᴇᴅ`;
        const list = members.map(id => `✷@${normalizeNumber(id)}`).join('\n');
        const text = message
          ? `${header}\n\n${message}\n\n${list}`
          : `${header}\n\n${list}`;

        await conn.sendMessage(remoteJid, { text, mentions: members }, { quoted: m });
      }
    }
  }
};
