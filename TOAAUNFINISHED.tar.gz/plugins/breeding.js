// ─── TOAA RPG Breeding ─────────
const { errorReply, resolveTarget } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed } = require('../helper/rpg');
const { getCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { PET_TYPES, BREEDING_RESULTS } = require('../helper/rpgPets');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const BREEDING_COST = 3000;
const COOLDOWN_MS = 3600 * 1000;
const cooldowns = new Map();
const RARE_TYPES = ['lion', 'wolf', 'phoenix', 'dragon', 'thunderbunny'];

function fmtEta(ms) {
  const totalMin = Math.ceil(ms / 60000);
  const h = Math.floor(totalMin / 60);
  const mm = totalMin % 60;
  return h > 0 ? `${h}h ${mm}m` : `${mm}m`;
}

module.exports = {
  name: 'breeding',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'breeding': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const target = resolveTarget(m, args);

  if (!target) {
    let txt = `💕 *PET BREEDING FARM* 💕\n\nLets your pet mate with another player's pet!\nWho knows, you might get a rare offspring! ✨\n\n`;
    txt += `*How to use:*\n👉 \`${prefix}breeding @target_user\`\n\n*Requirements:*\n1. Both of you need a pet\n2. Both pets minimum Level 5\n3. Breeding fee: *${fmtCoin(BREEDING_COST)}*`;
    return errorReply(conn, m, txt, sessionName);
  }

  if (target === jid) {
    return errorReply(conn, m, `Breeding with yourself? That's not how this works! Tag a friend! 😂❌`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ The farm needs a break! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (!user.pet) {
    return errorReply(conn, m, `You don't even have a pet! Go buy one at \`${prefix}petshop\` first! 😭`, sessionName);
  }

  const partner = getUser(target);
  if (!partner.pet) {
    return errorReply(conn, m, `The person you tagged doesn't have a pet! Poor timing. 💔`, sessionName);
  }

  const myPet = user.pet;
  const partnerPet = partner.pet;

  if ((myPet.level || 1) < 5) {
    return errorReply(conn, m, `Your pet's still too young to breed! Minimum *Level 5* (currently Level ${myPet.level || 1}). 🐣`, sessionName);
  }
  if ((partnerPet.level || 1) < 5) {
    return errorReply(conn, m, `Their pet's still too young to breed! Minimum *Level 5* (currently Level ${partnerPet.level || 1}). 🐣`, sessionName);
  }

  const balance = getCoin(jid);
  if (balance < BREEDING_COST) {
    return errorReply(conn, m, `Not enough coin for the vet bill! Needs *${fmtCoin(BREEDING_COST)}*. 😭`, sessionName);
  }

  cooldowns.set(jid, Date.now());
  removeCoin(jid, BREEDING_COST);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '💕', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, {
    text: `Awww, your *${PET_TYPES[myPet.type].name}* and their *${PET_TYPES[partnerPet.type].name}* are getting cozy... 💕✨\nHold on, the vet's checking on the delivery!`
  }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 4000));

  const breedKey = [myPet.type, partnerPet.type].sort().join('+');
  const possibleResults = BREEDING_RESULTS[breedKey] || BREEDING_RESULTS.default;
  const resultPetType = possibleResults[Math.floor(Math.random() * possibleResults.length)];
  const isRare = RARE_TYPES.includes(resultPetType);

  if (!user.petStorage) user.petStorage = [];

  const newPet = {
    type: resultPetType,
    name: PET_TYPES[resultPetType]?.name.split(' ')[1] || 'Baby',
    level: 1,
    exp: 0,
    hunger: 100,
    stats: null,
    birthDate: Date.now()
  };

  user.petStorage.push(newPet);
  setUser(jid, user);

  const expReward = isRare ? 500 : 200;
  const levelResult = addExp(jid, expReward);

  await conn.sendMessage(m.key.remoteJid, { react: { text: isRare ? '🎉' : '✅', key: m.key } });

  let txt = `AWW!! NEW BIRTH! 🍼✨\n\n`;
  if (isRare) txt += `🎉 *LUCKY!! RARE OFFSPRING!!* 🎉\n`;
  txt += `Congrats! You hatched a baby:\n🐣 Species: *${PET_TYPES[resultPetType]?.name}*\n\n`;
  txt += `Got EXP *+${expReward}*\nDelivery fee: *-${fmtCoin(BREEDING_COST)}*\n\n`;
  txt += `_(Your new baby's in Pet Storage. Total stored: ${user.petStorage.length})_`;

  await conn.sendMessage(m.key.remoteJid, { text: txt, mentions: [jid, target] }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
