const mainCore = require('../main');
const { errorReply, successReply, fReply, unauthorizedReply, botAdminRequiredReply, resolveTarget, resolveDisplayJid, getQuotedMsg, getMediaType, downloadMedia } = mainCore;

async function resolveWarnTarget(conn, m, args) {
  const rawTarget = resolveTarget(m, args);
  if (!rawTarget) return null;
  const remoteJid = m.key.remoteJid;
  let targetJid = rawTarget.includes('@') ? rawTarget : `${rawTarget}@s.whatsapp.net`;
  if (remoteJid.endsWith('@g.us')) {
    const meta = await conn.groupMetadata(remoteJid).catch(() => null);
    if (meta?.participants) targetJid = resolveDisplayJid(targetJid, meta.participants);
  }
  return targetJid;
}

module.exports = {
  name: 'Group Batch 1',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'acceptall': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!ctx.botAdmin) return botAdminRequiredReply(conn, m, ctx.sessionName);
        const remoteJid = m.key.remoteJid;
        if (!remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        await fReply(conn, m, 'Fetching pending requests...', ctx.sessionName);
        try {
          const requests = await conn.groupRequestParticipantsList(remoteJid);
          if (!requests || !requests.length) return errorReply(conn, m, 'No pending join requests.', ctx.sessionName);
          const jids = requests.map(r => r.jid);
          await conn.groupRequestParticipantsUpdate(remoteJid, jids, 'approve');
          await successReply(conn, m, `Approved ${jids.length} pending request${jids.length !== 1 ? 's' : ''}.`, ctx.sessionName);
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'rejectall': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!ctx.botAdmin) return botAdminRequiredReply(conn, m, ctx.sessionName);
        const remoteJid = m.key.remoteJid;
        if (!remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        await fReply(conn, m, 'Fetching pending requests...', ctx.sessionName);
        try {
          const requests = await conn.groupRequestParticipantsList(remoteJid);
          if (!requests || !requests.length) return errorReply(conn, m, 'No pending join requests.', ctx.sessionName);
          const jids = requests.map(r => r.jid);
          await conn.groupRequestParticipantsUpdate(remoteJid, jids, 'reject');
          await successReply(conn, m, `Rejected ${jids.length} pending request${jids.length !== 1 ? 's' : ''}.`, ctx.sessionName);
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'gcstatus': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const remoteJid = m.key.remoteJid;
        const quotedMsg = getQuotedMsg(m);
        const text = args.join(' ').trim();
        if (!quotedMsg && !text) {
          return errorReply(conn, m, `Usage:\n\n• Reply to an image/video/text with ${ctx.prefix}gcstatus\n• Or: ${ctx.prefix}gcstatus <text>`, ctx.sessionName);
        }
        try {
          const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
          let content;
          if (text && !quotedMsg) {
            content = { groupStatusMessageV2: { message: { extendedTextMessage: { text, backgroundArgb: 0xff2980b9, font: 0 } } } };
          } else {
            const t = getMediaType(quotedMsg);
            if (!t) return errorReply(conn, m, "Unsupported message type!", ctx.sessionName);
            const buffer = await downloadMedia(t.inner, t.type);
            const { prepareWAMessageMedia } = require('@whiskeysockets/baileys');
            const mediaKey = t.type === 'image' ? 'image' : t.type === 'video' ? 'video' : 'audio';
            const prepared = await prepareWAMessageMedia({ [mediaKey]: buffer, caption: text }, { upload: conn.waUploadToServer });
            content = { groupStatusMessageV2: { message: prepared } };
          }
          const statusMsg = generateWAMessageFromContent(remoteJid, content, { userJid: conn.user.id });
          await conn.relayMessage(remoteJid, statusMsg.message, { messageId: statusMsg.key.id });
          await successReply(conn, m, `Group status posted!`, ctx.sessionName);
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'warn': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const targetJid = await resolveWarnTarget(conn, m, args);
        if (!targetJid) return errorReply(conn, m, `Usage: ${ctx.prefix}warn @user`, ctx.sessionName);
        const targetNum = targetJid.split('@')[0];
        if (!global.warnSettings) global.warnSettings = new Map();
        const key = `${ctx.sessionName}_${m.key.remoteJid}_${targetNum}`;
        const warnings = (global.warnSettings.get(key) || 0) + 1;
        global.warnSettings.set(key, warnings);
        await conn.sendMessage(m.key.remoteJid, { text: `⚠️ @${targetNum} warned! (${warnings}/3 warnings)`, mentions: [targetJid] }, { quoted: m });
      }
    },

    'warnings': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const targetJid = await resolveWarnTarget(conn, m, args);
        if (!targetJid) return errorReply(conn, m, `Usage: ${ctx.prefix}warnings @user`, ctx.sessionName);
        const targetNum = targetJid.split('@')[0];
        if (!global.warnSettings) global.warnSettings = new Map();
        const key = `${ctx.sessionName}_${m.key.remoteJid}_${targetNum}`;
        const warnings = global.warnSettings.get(key) || 0;
        await successReply(conn, m, `@${targetNum} has ${warnings} warnings.`, ctx.sessionName);
      }
    },

    'clearwarns': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const targetJid = await resolveWarnTarget(conn, m, args);
        if (!targetJid) return errorReply(conn, m, `Usage: ${ctx.prefix}clearwarns @user`, ctx.sessionName);
        const targetNum = targetJid.split('@')[0];
        if (!global.warnSettings) global.warnSettings = new Map();
        const key = `${ctx.sessionName}_${m.key.remoteJid}_${targetNum}`;
        global.warnSettings.delete(key);
        await successReply(conn, m, `Warnings cleared for @${targetNum}`, ctx.sessionName);
      }
    }
  }
};
