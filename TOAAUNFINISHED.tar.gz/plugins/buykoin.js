// ─── TOAA RPG Buy Coin ─────────
const { errorReply, fReply } = require('../main');
const { getUser, setUser, isRpgAllowed } = require('../helper/rpg');
const { addCoin, getCoin, fmtCoin } = require('../helper/rpgCoin');
const { getSessionSetting } = require('../helper/function');

const EXP_PER_COIN = 2;

module.exports = {
  name: 'buykoin',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'buykoin': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);
  const amountStr = args[0];

  if (!amountStr) {
    let txt = `💱 *Buy Coin*\n\n> Exchange EXP for Coin!\n\n`;
    txt += `*📊 Rate:*\n> 💎 ${EXP_PER_COIN} EXP = 1 Coin\n\n`;
    txt += `*📋 Balance:*\n> 🚄 EXP: *${(user.exp || 0).toLocaleString('en-US')}*\n> 💰 Coin: *${fmtCoin(getCoin(jid))}*\n\n`;
    txt += `> Example: \`.buykoin 10000\`\n> Uses ${10000 * EXP_PER_COIN} EXP for 10,000 Coin`;

    return fReply(conn, m, txt, sessionName);
  }

  let coinAmount = 0;
  if (amountStr === 'all' || amountStr === 'max') {
    coinAmount = Math.floor((user.exp || 0) / EXP_PER_COIN);
  } else {
    coinAmount = parseInt(amountStr);
  }

  if (!coinAmount || coinAmount <= 0) {
    return errorReply(conn, m, `❌ Enter a valid coin amount!`, sessionName);
  }

  const expNeeded = coinAmount * EXP_PER_COIN;

  if ((user.exp || 0) < expNeeded) {
    const maxPossible = Math.floor((user.exp || 0) / EXP_PER_COIN);
    return errorReply(conn, m,
      `❌ *NOT ENOUGH EXP!*\n\n> Needed: *${expNeeded.toLocaleString('en-US')} EXP*\n> Your EXP: *${(user.exp || 0).toLocaleString('en-US')} EXP*\n\n> Max possible: *${maxPossible.toLocaleString('en-US')} Coin*`,
      sessionName
    );
  }

  user.exp = (user.exp || 0) - expNeeded;
  setUser(jid, user);
  addCoin(jid, coinAmount);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '💱', key: m.key } });

  let txt = `💱 *Exchange Successful!*\n\n*📋 Details:*\n> 🚄 EXP: *-${expNeeded.toLocaleString('en-US')}*\n> 💰 Coin: *+${fmtCoin(coinAmount)}*\n\n`;
  txt += `*📊 Current Balance:*\n> 🚄 EXP: *${user.exp.toLocaleString('en-US')}*\n> 💰 Coin: *${fmtCoin(getCoin(jid))}*`;

  return fReply(conn, m, txt, sessionName);
}
