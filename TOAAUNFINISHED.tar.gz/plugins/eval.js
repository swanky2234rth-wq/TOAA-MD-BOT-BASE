// plugins/eval.js
console.log('[EVAL] Plugin loaded!');

const { fReply, errorReply } = require('../main');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

module.exports = {
  name: 'Eval',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'eval': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;
        const code = args.join(' ');

        // ─── OWNER CHECK ──────────────────────────────────────────────────────
        if (!OWNER_NUMBERS.includes(senderNumber)) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        if (!code) {
          return fReply(conn, m, 
            `📌 *Eval - Execute JavaScript*\n\n` +
            `Usage: *${prefix}eval <code>*\n` +
            `Example: *${prefix}eval 2 + 2*`,
            sessionName
          );
        }

        try {
          let result = await eval(`(async () => { ${code} })()`);
          if (typeof result !== 'string') {
            result = require('util').inspect(result, { depth: 0 });
          }
          await fReply(conn, m, 
            `📊 *Result:*\n\`\`\`js\n${result.slice(0, 4000)}\n\`\`\``, 
            sessionName
          );
        } catch (error) {
          await errorReply(conn, m, `❌ Error: ${error.message}`, sessionName);
        }
      }
    }
  }
};