// ─── TOAA Block / Unblock ─────────
const {
  errorReply,
  resolveTarget,
  rawNumber,
  getSessionSetting,
  applyFont
} = require('../main');

async function resolveBlockTarget(conn, m, args, ctx) {
  const remoteJid = m.key.remoteJid;
  const isGroup = remoteJid.endsWith('@g.us');

  // In a DM, target the person you're chatting with — no arg needed
  if (!isGroup) return remoteJid;

  // In a group, need a quoted message, mention, or explicit number
  return resolveTarget(m, args);
}

async function mentionReply(conn, m, text, sessionName, mentions) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out, mentions }, { quoted: m });
}

module.exports = {
  name: 'block',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'block': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, isOwner } = ctx;

        if (!isOwner) {
          return errorReply(conn, m, `This command is owner-only.`, sessionName);
        }

        const target = await resolveBlockTarget(conn, m, args, ctx);
        if (!target) {
          return errorReply(conn, m, `Usage: ${prefix}block <reply/tag/number>\nExample: ${prefix}block 2347012345678`, sessionName);
        }

        try {
          await conn.updateBlockStatus(target, 'block');
          await mentionReply(conn, m, `*_Blocked @${rawNumber(target)}._*`, sessionName, [target]);
        } catch (e) {
          console.error('[BLOCK] Error:', e.message);
          await errorReply(conn, m, `Couldn't block that number — try again.`, sessionName);
        }
      }
    },
    'unblock': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, isOwner } = ctx;

        if (!isOwner) {
          return errorReply(conn, m, `This command is owner-only.`, sessionName);
        }

        const target = await resolveBlockTarget(conn, m, args, ctx);
        if (!target) {
          return errorReply(conn, m, `Usage: ${prefix}unblock <reply/tag/number>\nExample: ${prefix}unblock 2347012345678`, sessionName);
        }

        try {
          await conn.updateBlockStatus(target, 'unblock');
          await mentionReply(conn, m, `*_Unblocked @${rawNumber(target)}._*`, sessionName, [target]);
        } catch (e) {
          console.error('[UNBLOCK] Error:', e.message);
          await errorReply(conn, m, `Couldn't unblock that number — try again.`, sessionName);
        }
      }
    }
  }
};
