// ─── TOAA RPG Divorce ─────────
const { errorReply } = require('../main');
const { getUser, setUser, isRpgAllowed } = require('../helper/rpg');
const { getCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { getSessionSetting } = require('../helper/function');

const DIVORCE_COST = 25000;

module.exports = {
  name: 'divorce',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'divorce': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);

  if (!user.spouse) {
    return errorReply(conn, m, `You're not even married yet — how are you divorcing? 😂💔\nFind a partner first with \`.marry @user\``, sessionName);
  }

  const spouseJid = user.spouse;
  const balance = getCoin(jid);

  if (balance < DIVORCE_COST) {
    return errorReply(conn, m, `Lawyer fees are expensive! 😭\nNeed *${fmtCoin(DIVORCE_COST)}* to file, you've got *${fmtCoin(balance)}*.\nHold off on the fighting for now!`, sessionName);
  }

  removeCoin(jid, DIVORCE_COST);
  user.spouse = null;
  user.marriedAt = null;
  setUser(jid, user);

  const partner = getUser(spouseJid);
  if (partner) {
    partner.spouse = null;
    partner.marriedAt = null;
    setUser(spouseJid, partner);
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '💔', key: m.key } });

  let txt = `⛈️ *DIVORCE FINALIZED* ⛈️\n\nThe gavel has fallen. The relationship between:\n`;
  txt += `💔 @${jid.split('@')[0]}\n         -- ENDS WITH --\n💔 @${spouseJid.split('@')[0]}\n\n`;
  txt += `😭 *OFFICIALLY OVER! BACK TO SINGLE!* 😭\n\n💸 Legal fees: *-${fmtCoin(DIVORCE_COST)}*\n\n`;
  txt += `> _"Life goes on..." — Judge Bot_ 🥀`;

  await conn.sendMessage(m.key.remoteJid, { text: txt, mentions: [jid, spouseJid] }, { quoted: m });
}
