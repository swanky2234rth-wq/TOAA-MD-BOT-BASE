// ─── TOAA Genshin Impact Stalk ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'genshinstalk',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'genshinstalk': {
      category: 'stalker',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const uid = args[0]?.trim();

        if (!uid) {
          return errorReply(conn, m, `🌟 *Genshin Impact Stalk*\n\nUsage: ${prefix}genshinstalk <uid>\nExample: ${prefix}genshinstalk 856012067`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          const { data } = await axios.get(`https://api.nexray.eu.cc/stalker/genshin?id=${encodeURIComponent(uid)}`, {
            timeout: 30000,
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
          });

          if (!data.status || !data.result) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `UID *${uid}* not found or the profile is private.`, sessionName);
          }

          const r = data.result.player_info;
          const imageUrl = data.result.image_url;

          let caption = `🌟 *GENSHIN IMPACT STALK* 🌟\n\n`;
          caption += `👤 *PLAYER INFO*\n`;
          caption += `  - Nickname: *${r.nickname || '-'}*\n`;
          caption += `  - Adventure Rank (AR): ${r.level || '-'}\n`;
          caption += `  - World Level (WL): ${r.world_level || '-'}\n`;
          caption += `  - Signature: ${r.signature || '-'}\n\n`;

          caption += `🏆 *ACHIEVEMENTS*\n`;
          caption += `  - Total Achievements: ${r.achievements || '-'}\n`;
          caption += `  - Spiral Abyss: ${r.spiral_abyss || 'No data yet'}\n`;
          if (r.theater) caption += `  - Imaginarium Theater: ${r.theater}\n`;
          if (r.stygian_onslaught) caption += `  - Stygian Onslaught: ${r.stygian_onslaught}\n`;

          if (imageUrl) {
            await conn.sendMessage(m.key.remoteJid, { image: { url: imageUrl }, caption }, { quoted: m });
          } else {
            await errorReply(conn, m, caption, sessionName);
          }

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (error) {
          console.error('[GENSHINSTALK] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `System couldn't pull data from the Genshin Impact server — try again later.`, sessionName);
        }
      }
    }
  }
};
