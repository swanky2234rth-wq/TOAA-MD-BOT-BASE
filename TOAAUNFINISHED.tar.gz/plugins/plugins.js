// plugins/plugins.js
console.log('[PLUGINS] Plugin loaded!');

const fs = require('fs');
const path = require('path');
const { fReply, errorReply, PLUGINS } = require('../main');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

module.exports = {
  name: 'Plugins',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'plugins': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;

        // ─── OWNER CHECK ──────────────────────────────────────────────────────
        if (!OWNER_NUMBERS.includes(senderNumber)) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        const action = (args[0] || '').toLowerCase();

        if (!action || action === 'list') {
          const pluginList = Array.from(PLUGINS.entries())
            .map(([name, data]) => `• ${name} v${data.version} (${data.commands} commands)`)
            .join('\n');

          await fReply(conn, m, 
            `📦 *Loaded Plugins (${PLUGINS.size})*\n\n${pluginList || 'No plugins loaded.'}`, 
            sessionName
          );
          return;
        }

        if (action === 'reload') {
          try {
            const pluginsDir = path.join(__dirname, '..', 'plugins');
            const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));
            
            for (const file of files) {
              const filePath = path.join(pluginsDir, file);
              delete require.cache[require.resolve(filePath)];
            }
            
            const { loadPlugins } = require('../main');
            loadPlugins();
            
            await fReply(conn, m, `✅ Plugins reloaded successfully!`, sessionName);
          } catch (error) {
            await errorReply(conn, m, `❌ Failed to reload: ${error.message}`, sessionName);
          }
          return;
        }

        await fReply(conn, m, 
          `📌 *Plugin Manager*\n\n` +
          `${prefix}plugins list - List all plugins\n` +
          `${prefix}plugins reload - Reload all plugins`,
          sessionName
        );
      }
    }
  }
};