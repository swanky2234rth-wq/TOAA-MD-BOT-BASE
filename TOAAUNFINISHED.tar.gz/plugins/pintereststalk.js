// ─── TOAA Pinterest Stalk ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'pintereststalk',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'pintereststalk': {
      category: 'stalker',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const username = args[0]?.trim();

        if (!username) {
          return errorReply(conn, m, `📌 *Pinterest Stalk*\n\nUsage: ${prefix}pintereststalk <username>\nExample: ${prefix}pintereststalk dims`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          const { data } = await axios.get(`https://api.nexray.eu.cc/stalker/pinterest?username=${encodeURIComponent(username)}`, {
            timeout: 30000,
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
          });

          if (!data.status || !data.result) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Username *${username}* not found on Pinterest.`, sessionName);
          }

          const r = data.result;

          let caption = `📌 *PINTEREST STALK* 📌\n\n`;
          caption += `👤 *PROFILE INFO*\n`;
          caption += `  - Full Name: *${r.full_name || '-'}*\n`;
          caption += `  - Username: @${r.username}\n`;
          caption += `  - Bio: ${r.bio || '-'}\n`;
          caption += `  - Account Type: ${r.account_type || '-'}\n`;
          caption += `  - Created: ${r.created_at || '-'}\n\n`;

          caption += `📊 *STATS*\n`;
          caption += `  - Followers: ${r.stats?.followers || 0}\n`;
          caption += `  - Following: ${r.stats?.following || 0}\n`;
          caption += `  - Total Pins: ${r.stats?.pins || 0}\n`;
          caption += `  - Total Boards: ${r.stats?.boards || 0}\n\n`;

          caption += `🔗 ${r.profile_url}`;

          const imageUrl = r.image?.original || r.image?.large || r.image?.medium || r.image?.small;

          if (imageUrl) {
            await conn.sendMessage(m.key.remoteJid, { image: { url: imageUrl }, caption }, { quoted: m });
          } else {
            await errorReply(conn, m, caption, sessionName);
          }

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (error) {
          console.error('[PINTERESTSTALK] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `System couldn't pull data from Pinterest — try again later.`, sessionName);
        }
      }
    }
  }
};
