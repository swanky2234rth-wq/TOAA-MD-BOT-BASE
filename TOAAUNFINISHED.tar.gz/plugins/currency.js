// Auto-converted from legacy registerCmd('currency', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'currency',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'currency': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx;
  if (args.length < 3) return fReply(conn, m, `Usage: ${prefix}currency <amount> <from> <to>`, sessionName);
  const [amount, from, to] = args;
  try {
    const { data } = await axios.get(`https://api.exchangerate.host/convert?from=${from.toUpperCase()}&to=${to.toUpperCase()}&amount=${amount}`);
    if (!data.success) return fReply(conn, m, '*_۞ 𝙲𝚘𝚗𝚟𝚎𝚛𝚜𝚒𝚘𝚗 𝙵𝚊𝚒𝚕𝚎𝚍_*', sessionName);
    await fReply(conn, m, `💱 *Currency*\n\n${amount} ${from.toUpperCase()} = *${data.result.toFixed(2)} ${to.toUpperCase()}*\nRate: 1 ${from.toUpperCase()} = ${data.info.rate} ${to.toUpperCase()}`, sessionName);
  } catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
