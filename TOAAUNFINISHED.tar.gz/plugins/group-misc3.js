const mainCore = require('../main');
const { errorReply, successSmartReply, unauthorizedReply, welcomeSettings, goodbyeSettings, welcomeMessages, goodbyeMessages, getGroupSettings } = mainCore;

module.exports = {
  name: 'Group Batch 3',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'welcome-status': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const remoteJid = m.key.remoteJid;
        const welcomeEnabled = welcomeSettings.get(remoteJid) || false;
        const goodbyeEnabled = goodbyeSettings.get(remoteJid) || false;
        const hasCustomWelcome = welcomeMessages.has(remoteJid);
        const hasCustomGoodbye = goodbyeMessages.has(remoteJid);
        const msg = `Welcome/Goodbye Status\n\n👋 Welcome: ${welcomeEnabled ? '🟢 ON' : '🔴 OFF'}\n👋 Goodbye: ${goodbyeEnabled ? '🟢 ON' : '🔴 OFF'}\n📝 Custom Welcome: ${hasCustomWelcome ? '✅ Yes' : '❌ No'}\n📝 Custom Goodbye: ${hasCustomGoodbye ? '✅ Yes' : '❌ No'}\n\nUse ${ctx.prefix}welcome view or ${ctx.prefix}goodbye view to see messages.`;
        await successSmartReply(conn, m, msg, ctx.sessionName);
      }
    },

    'antilink-status': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const remoteJid = m.key.remoteJid;
        if (!global.antilinkSettings) global.antilinkSettings = new Map();
        const mode = global.antilinkSettings.get(`${ctx.sessionName}_${remoteJid}`) || 'off';
        const modeText = mode === 'off' ? '❌ OFF' : mode === 'del' ? '🗑️ DELETE ONLY' : mode === 'warn' ? '⚠️ WARN' : mode === 'kick' ? '🔨 KICK' : '❌ OFF';
        const msg = `Antilink Status\n\nMode: ${modeText}\n\n• DEL: Deletes links only\n• WARN: Deletes + warns\n• KICK: Kicks after 2 warnings\n\nGroup admins are always exempt.`;
        await successSmartReply(conn, m, msg, ctx.sessionName);
      }
    },

    'protection-status': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const remoteJid = m.key.remoteJid;
        const gs = getGroupSettings(remoteJid);
        if (!global.antilinkSettings) global.antilinkSettings = new Map();
        const antilinkMode = global.antilinkSettings.get(`${ctx.sessionName}_${remoteJid}`) || 'off';
        const antilinkText = antilinkMode === 'off' ? '❌ OFF' : antilinkMode === 'del' ? '🗑️ DELETE' : antilinkMode === 'warn' ? '⚠️ WARN' : antilinkMode === 'kick' ? '🔨 KICK' : '❌ OFF';
        const msg = `🛡️ Protection Status\n\n🔗 Antilink: ${antilinkText}\n⬇️ Anti-demote: ${gs.antidemote?.active ? '🟢 ON' : '🔴 OFF'}\n⬆️ Anti-promote: ${gs.antipromote?.active ? '🟢 ON' : '🔴 OFF'}\n🤖 Bot Protect: ${gs.botprotect?.active ? '🟢 ON' : '🔴 OFF'}\n📢 PDM Messages: ${gs.pdm ? '🟢 ON' : '🔴 OFF'}\n\n📌 Use individual commands to toggle:\n${ctx.prefix}antilink | ${ctx.prefix}antidemote | ${ctx.prefix}antipromote | ${ctx.prefix}botprotect | ${ctx.prefix}pdm`;
        await successSmartReply(conn, m, msg, ctx.sessionName);
      }
    }
  }
};
