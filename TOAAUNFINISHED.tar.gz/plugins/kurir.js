// ─── TOAA RPG Courier ─────────
const { errorReply } = require('../main');
const { getUser, setUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 15;
const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();

const PACKAGES = ['Secret Documents', 'Online Clothes Order', "Someone's Skincare", "Grandma's Pot"];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'courier',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'courier': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Truck's still loading! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Back's aching from carrying boxes! 😩\n\nCourier work costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '📦', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Package delivery!!! 📦\nLooking up the right address on maps... 🗺️` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const gacha = Math.random();

  if (gacha < 0.2) {
    const extraStamina = 10;
    const fresh = getUser(jid);
    fresh.stamina = Math.max(0, fresh.stamina - extraStamina);
    setUser(jid, fresh);

    const expGain = 500;
    const levelResult = addExp(jid, expGain);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🐕', key: m.key } });
    await conn.sendMessage(m.key.remoteJid, {
      text: `WOOF WOOF! CHASED BY AN ANGRY DOG! 🐕💨\n\nYou ran laps around the block trying to save the package!\n⚡ Extra Stamina: -${extraStamina}\n📈 Running Compensation EXP: *+${expGain}*\n💵 Earnings: 0 (package tossed over the fence)\n\nStill out of breath! 🥵`
    }, { quoted: m });
    return notifyLevelUp(conn, m, jid, levelResult);
  }

  const item = PACKAGES[Math.floor(Math.random() * PACKAGES.length)];
  const earning = Math.floor(Math.random() * 15000) + 5000;
  let tips = 0;
  if (gacha > 0.8) tips = Math.floor(Math.random() * 10000) + 2000;

  const totalEarning = earning + tips;
  addCoin(jid, totalEarning);
  const expGain = Math.floor(totalEarning / 20);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
  let txt = `PACKAGE DELIVERED SAFELY! 📦✨\n\nItem: *${item}*\n💵 Delivery fee: *+${fmtCoin(earning)}*\n`;
  if (tips > 0) txt += `🎁 Extra Tip: *+${fmtCoin(tips)}*\n`;
  txt += `📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nDelivered right on time! 🚚💨`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
