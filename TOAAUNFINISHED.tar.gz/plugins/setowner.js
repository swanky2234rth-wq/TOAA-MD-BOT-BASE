// Auto-converted from legacy registerCmd('setowner', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  resolveTarget,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setowner',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setowner': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  let target = resolveTarget(m, args);
  if (!target) return fReply(conn, m, `Usage: ${ctx.prefix}setowner <number>`, ctx.sessionName);
  target = target.replace(/[^0-9]/g, '');
  setSessionSetting(ctx.sessionName, 'ownerNumber', target);
  await fReply(conn, m, `*_💈 Owner 𝚂𝚎𝚝: ${target}_*`, ctx.sessionName);

      }
    }
  }
};
