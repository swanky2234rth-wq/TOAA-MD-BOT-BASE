// ─── TOAA Roblox Player Search ─────────
const { errorReply, fReply } = require('../main');
const axios = require('axios');

const NEOXR_APIKEY = 'Milik-Bot-OurinMD';

module.exports = {
  name: 'robloxplayer',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'robloxplayer': {
      category: 'stalker',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const query = args.join(' ').trim();

        if (!query) {
          return errorReply(conn, m, `🎮 *Roblox Player Search*\n\nUsage: ${prefix}robloxplayer <username>\nExample: ${prefix}robloxplayer linkmon`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🔍', key: m.key } });

        try {
          const { data } = await axios.get(`https://api.neoxr.eu/api/roblox-search?q=${encodeURIComponent(query)}&apikey=${NEOXR_APIKEY}`, { timeout: 30000 });

          if (!data?.status || !data?.data?.length) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `No players found for username: ${query}`, sessionName);
          }

          const players = data.data.slice(0, 10);

          let text = `🎮 *Roblox Player Search*\n\n`;
          text += `> Query: \`${query}\`\n`;
          text += `> Found: *${players.length}* player(s)\n\n`;

          players.forEach((player, i) => {
            text += `╭┈┈⬡「 ${i + 1}. *${player.displayName}* 」\n`;
            text += `┃ 🆔 ID: \`${player.id}\`\n`;
            text += `┃ 👤 Username: \`${player.name}\`\n`;
            text += `┃ 📛 Display: *${player.displayName}*\n`;
            text += `┃ ✅ Verified: ${player.hasVerifiedBadge ? 'Yes' : 'No'}\n`;
            if (player.previousUsernames?.length > 0) {
              text += `┃ 📜 Previous: ${player.previousUsernames.join(', ')}\n`;
            }
            text += `╰┈┈⬡\n\n`;
          });

          text += `> _Use \`${prefix}robloxstalk <username>\` for detailed info_`;

          await fReply(conn, m, text, sessionName);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (err) {
          console.error('[ROBLOXPLAYER] Error:', err.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong searching Roblox — try again.`, sessionName);
        }
      }
    }
  }
};
