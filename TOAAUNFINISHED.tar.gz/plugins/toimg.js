// Auto-converted from legacy registerCmd('toimg', ...) in main.js
// Category: media
const {
  downloadMedia,
  fReply,
  getQuotedMsg,
  plainReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'toimg',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'toimg': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {

  const quotedMsg = getQuotedMsg(m);
  const stickerObj = quotedMsg?.stickerMessage || m.message?.stickerMessage;
  if (!stickerObj) return fReply(conn, m, `Reply to a sticker with ${ctx.prefix}toimg`, ctx.sessionName);
  try { 
    const buf = await downloadMedia(stickerObj, 'sticker'); 
    await conn.sendMessage(m.key.remoteJid, { image: buf, caption: '🖼️ Converted' }, { quoted: m }); 
  }
  catch (e) { await plainReply(conn, m, `*_۞ 𝙵𝚊𝚒𝚕𝚎𝚍: ${e.message}_*`); }

      }
    }
  }
};
