// plugins/ghostping.js
const { getMentioned } = require('../helper/function');

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'Ghost Ping',
  version: '1.0.0',
  author: 'TOAA',
  
  commands: {
    'ghostping': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        
        if (!ctx.isOwner && !ctx.isAdmin) {
          return fReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', sessionName);
        }
        
        const remoteJid = m.key.remoteJid;
        if (!remoteJid.endsWith('@g.us')) {
          return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', sessionName);
        }

        const meta = await conn.groupMetadata(remoteJid);
        const members = meta.participants.map(p => p.id);

        // If specific users are mentioned, only ghost ping them
        const mentioned = getMentioned(m);
        const targets = mentioned.length ? mentioned : members;
        const text = args.join(' ').trim() || targets.map(id => `@${id.split('@')[0]}`).join(' ');

        try {
          const sent = await conn.sendMessage(remoteJid, { text, mentions: targets }, { quoted: m });
          // Small delay then delete so notifications fire but message disappears
          await new Promise(r => setTimeout(r, 1500));
          await conn.sendMessage(remoteJid, { delete: sent.key });
        } catch (e) {
          await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName);
        }
      }
    }
  }
};