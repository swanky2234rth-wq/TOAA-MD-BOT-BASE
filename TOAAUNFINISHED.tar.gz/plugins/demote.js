// Auto-converted from legacy registerCmd('demote', ...) in main.js
// Category: group
const {
  resolveTarget, unauthorizedReply, botAdminRequiredReply, errorReply, resolveDisplayJid
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'demote',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'demote': {
      category: 'group',
      handler: async (nuell, hex, args, ctx) => {

  if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(nuell, hex, ctx.sessionName);
  if (!ctx.botAdmin) return botAdminRequiredReply(nuell, hex, ctx.sessionName);
  
  const remoteJid = hex.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return errorReply(nuell, hex, "Groups Only", ctx.sessionName);
  
  const targetJid = resolveTarget(hex, args);
  if (!targetJid) {
    return errorReply(nuell, hex, `Usage: ${ctx.prefix}demote @user or reply to their message`, ctx.sessionName);
  }
  
  const rawTargetJid = targetJid.includes('@') ? targetJid : `${targetJid.replace(/[^0-9]/g, '')}@s.whatsapp.net`;

  const meta = await nuell.groupMetadata(remoteJid).catch(() => null);
  const cleanJid = resolveDisplayJid(rawTargetJid, meta?.participants);
  const targetNum = cleanJid.split('@')[0];
  
  if (targetNum === ctx.botNumber) {
    return errorReply(nuell, hex, "I can't demote myself!", ctx.sessionName);
  }
  
  // Check if target is the group creator (can't demote creator)
  if (meta) {
    const isCreator = meta.participants.find(p => p.id === cleanJid && p.admin === 'superadmin');
    if (isCreator && !ctx.isOwner) {
      return errorReply(nuell, hex, "I can't demote the group creator!", ctx.sessionName);
    }
  }
  
  await nuell.groupParticipantsUpdate(remoteJid, [rawTargetJid], 'demote');
  await nuell.sendMessage(remoteJid, {
    text: `🥀 @${targetNum} demoted.`,
    mentions: [cleanJid]
  }, { quoted: hex });

      }
    }
  }
};
