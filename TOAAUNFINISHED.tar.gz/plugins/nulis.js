// ─── TOAA RPG Writer ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 10;
const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'writing',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'writing': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still finding your muse! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Writer's block hit hard! 😵‍💫\n\nWriting costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '📝', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Weaving words full of meaning... ✍️\nHoping a publisher notices! 📚` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const gacha = Math.random();

  if (gacha < 0.15) {
    await conn.sendMessage(m.key.remoteJid, { react: { text: '🚮', key: m.key } });
    return conn.sendMessage(m.key.remoteJid, {
      text: `MANUSCRIPT REJECTED! 🚮🥺\n\nReason: "Too cliché and predictable."\n💵 Royalty: 0\n⚡ Stamina: -${STAMINA_COST}\n\nDon't give up, write again tomorrow! 💪`
    }, { quoted: m });
  }

  if (gacha > 0.9) {
    const viralRoyalty = Math.floor(Math.random() * 60000) + 30000;
    addCoin(jid, viralRoyalty);
    const expGain = Math.floor(viralRoyalty / 20);
    const levelResult = addExp(jid, expGain);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🌟', key: m.key } });
    await conn.sendMessage(m.key.remoteJid, {
      text: `YOUR STORY WENT VIRAL AND BECAME A BESTSELLER! 🌟📘\n\nReaders are crying over your work, royalties pouring in!\n💵 Royalty: *+${fmtCoin(viralRoyalty)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nDirectors are eyeing a film adaptation! 🎬`
    }, { quoted: m });
    return notifyLevelUp(conn, m, jid, levelResult);
  }

  const earning = Math.floor(Math.random() * 15000) + 5000;
  addCoin(jid, earning);
  const expGain = Math.floor(earning / 20);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, {
    text: `WRITING ROYALTY CASHED OUT! 📝✨\n\n💵 Earnings: *+${fmtCoin(earning)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nKeep it up, fellow wordsmith! 🎓`
  }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
