// ─── TOAA Pinterest Search ─────────
const {
  fReply,
  proto,
  generateWAMessageFromContent,
  prepareWAMessageMedia
} = require('../main');
const axios = require('axios');

module.exports = {
  name: 'pinterest',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'pinterest': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const { prefix, sessionName } = ctx;
        const text = args.join(' ').trim();

        if (!text) return fReply(conn, m, `Usage: ${prefix}pinterest <search>`, sessionName);

        await fReply(conn, m, '*_𝚂𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐..._*', sessionName);

        try {
          const { data } = await axios.get(
            `https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(text)}&type=image`
          );

          if (!data.status || !data.data?.length) {
            return fReply(conn, m, '*_۞ 𝙽𝚘 𝙸𝚖𝚊𝚐𝚎𝚜 𝙵𝚘𝚞𝚗𝚍_*', sessionName);
          }

          const images = data.data.slice(0, 15);

          const cards = await Promise.all(images.map(async (item, i) => ({
            header: proto.Message.InteractiveMessage.Header.create({
              ...(await prepareWAMessageMedia(
                { image: { url: item.image_url } },
                { upload: conn.waUploadToServer }
              )),
              title: '',
              subtitle: `Image ${i + 1}/${images.length}`,
              hasMediaAttachment: false
            }),
            body: { text: '' },
            nativeFlowMessage: { buttons: [] }
          })));

          const msg = generateWAMessageFromContent(
            m.key.remoteJid,
            {
              viewOnceMessage: {
                message: {
                  interactiveMessage: {
                    body: { text: `Pinterest: *${text}*` },
                    carouselMessage: { cards, messageVersion: 1 }
                  }
                }
              }
            },
            { quoted: m }
          );

          await conn.relayMessage(m.key.remoteJid, msg.message, { messageId: msg.key.id });

        } catch (e) {
          console.error('[PINTEREST] Error:', e);
          await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName);
        }
      }
    }
  }
};
