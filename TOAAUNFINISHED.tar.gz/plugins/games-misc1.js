const mainCore = require('../main');
const { errorReply, successReply, successSmartReply } = mainCore;

module.exports = {
  name: 'Games Batch 1',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'sudoku': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const board = Array.from({ length: 9 }, () => Array(9).fill(0));
        for (let i = 0; i < 9; i++) board[i][i] = i + 1;
        let text = '🧩 SUDOKU\n\n';
        for (let r = 0; r < 9; r++) {
          if (r % 3 === 0) text += '---+---+---\n';
          for (let c = 0; c < 9; c++) {
            if (c % 3 === 0) text += '|';
            text += board[r][c] || ' ';
          }
          text += '|\n';
        }
        text += '---+---+---';
        await successReply(conn, m, text, ctx.sessionName);
      }
    },

    'rpsls': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const choice = (args[0] || '').toLowerCase();
        const valid = ['rock', 'paper', 'scissors', 'lizard', 'spock'];
        if (!valid.includes(choice)) return errorReply(conn, m, `Usage: ${ctx.prefix}rpsls rock/paper/scissors/lizard/spock`, ctx.sessionName);
        const bot = valid[Math.floor(Math.random() * valid.length)];
        const rules = {
          rock: ['scissors', 'lizard'], paper: ['rock', 'spock'], scissors: ['paper', 'lizard'],
          lizard: ['spock', 'paper'], spock: ['scissors', 'rock']
        };
        const result = choice === bot ? 'Tie!' : rules[choice].includes(bot) ? 'You win!' : 'You lose!';
        const emojis = { rock: '🪨', paper: '📄', scissors: '✂️', lizard: '🦎', spock: '🖖' };
        await successSmartReply(conn, m, `✊ RPSLS\n\nYou: ${emojis[choice]} ${choice}\nBot: ${emojis[bot]} ${bot}\n\n${result}`, ctx.sessionName);
      }
    },

    'typingtest': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const sentences = [
          "The quick brown fox jumps over the lazy dog.", "Pack my box with five dozen liquor jugs.",
          "How vexingly quick daft zebras jump.", "The five boxing wizards jump quickly."
        ];
        const sentence = sentences[Math.floor(Math.random() * sentences.length)];
        await successSmartReply(conn, m, `⌨️ TYPING TEST\n\nType this exactly:\n"${sentence}"\n\nTime starts now!`, ctx.sessionName);
      }
    }
  }
};
