// ─── TOAA Image to Prompt ─────────
const { errorReply, fReply, getQuotedMsg, getMediaType, downloadMedia } = require('../main');
const axios = require('axios');

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;

  const quotedMsg = getQuotedMsg(m);
  const sourceMsg = quotedMsg || m.message;
  const mediaInfo = getMediaType(sourceMsg || {});

  if (!mediaInfo || mediaInfo.type !== 'image') {
    return errorReply(conn, m, `🎨 *Image to Prompt*\n\nReply to or send an image with caption ${prefix}imgtoprompt`, sessionName);
  }

  await fReply(conn, m, `🕕 *Analyzing image...*\n\nGenerating a prompt from it, hang on.`, sessionName);

  try {
    const buffer = await downloadMedia(mediaInfo.inner, 'image');
    if (!buffer || !Buffer.isBuffer(buffer)) {
      return errorReply(conn, m, `Couldn't download that image.`, sessionName);
    }

    const base64 = buffer.toString('base64');

    const { data } = await axios.post(
      'https://imageprompt.org/api/ai/prompts/image',
      { base64Url: `data:image/webp;base64,${base64}`, imageModelId: 0, language: 'en' },
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
          'Content-Type': 'application/json',
          origin: 'https://imageprompt.org',
          referer: 'https://imageprompt.org/image-to-prompt'
        },
        timeout: 30000
      }
    );

    if (!data?.prompt) {
      return errorReply(conn, m, `Couldn't generate a prompt from this image.`, sessionName);
    }

    const responseText =
      `🎨 *Image to Prompt*\n\n` +
      `\`\`\`${data.prompt}\`\`\`\n\n` +
      `_Generated at: ${data.generatedAt || new Date().toISOString()}_`;

    await fReply(conn, m, responseText, sessionName);

  } catch (e) {
    console.error('[IMGTOPROMPT] Error:', e.message);
    await errorReply(conn, m, `Something went wrong analyzing that image — try again.`, sessionName);
  }
}

module.exports = {
  name: 'imgtoprompt',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'imgtoprompt': { category: 'tools', handler: run },
    'img2prompt': { category: 'tools', handler: run },
    'i2p': { category: 'tools', handler: run }
  }
};
