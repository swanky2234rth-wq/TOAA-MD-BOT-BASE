// plugins/file.js
console.log('[FILE] Plugin loaded!');

const fs = require('fs');
const path = require('path');
const { fReply, errorReply } = require('../main');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

module.exports = {
  name: 'File',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'file': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;

        // ─── OWNER CHECK ──────────────────────────────────────────────────────
        if (!OWNER_NUMBERS.includes(senderNumber)) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        const action = (args[0] || '').toLowerCase();
        const filePath = args.slice(1).join(' ') || '.';

        if (action === 'ls') {
          try {
            const files = fs.readdirSync(filePath);
            const list = files.map(f => {
              const stats = fs.statSync(path.join(filePath, f));
              return `${stats.isDirectory() ? '📁' : '📄'} ${f} ${stats.isDirectory() ? '/' : ''}`;
            }).join('\n');
            await fReply(conn, m, `📂 *${filePath}*\n\n${list.slice(0, 4000)}`, sessionName);
          } catch (error) {
            await errorReply(conn, m, `❌ ${error.message}`, sessionName);
          }
          return;
        }

        if (action === 'cat') {
          try {
            const content = fs.readFileSync(filePath, 'utf-8');
            await fReply(conn, m, `📄 *${filePath}*\n\n\`\`\`\n${content.slice(0, 4000)}\n\`\`\``, sessionName);
          } catch (error) {
            await errorReply(conn, m, `❌ ${error.message}`, sessionName);
          }
          return;
        }

        await fReply(conn, m, 
          `📌 *File Manager*\n\n` +
          `${prefix}file ls <path> - List files\n` +
          `${prefix}file cat <file> - Read file`,
          sessionName
        );
      }
    }
  }
};