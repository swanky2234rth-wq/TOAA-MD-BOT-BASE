// Auto-converted from legacy registerCmd('getsession', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  loadUserSettings,
  formatUptime
} = require('../main');
const axios = require('axios');
const settings = require('../settings');
// NOTE: sessions.js is require()'d lazily inside the handler below to avoid a
// circular-require deadlock at boot (sessions.js -> main.js -> plugins -> sessions.js).

module.exports = {
  name: 'getsession',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'getsession': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
    const { activeSessions, stopSession, reloadExistingSessions } = require('../sessions');

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  const us = loadUserSettings(ctx.sessionName);
  await fReply(conn, m, `    ✰ *𝕾𝖊𝖘𝖘𝖎𝖔𝖓 𝕴𝖓𝖋𝖔*\n\nꖅ *Session:* ${ctx.sessionName}\n▣ *Owner:* ${us.ownerNumber || 'Not set'}\nꖅ *Prefix:* ${us.prefix || settings.DEFAULT_PREFIX}\n▣ *Mode:* ${us.mode || 'public'}\nꖅ *Uptime:* ${formatUptime(Date.now() - global.botStartTime)}`, ctx.sessionName);

      }
    }
  }
};
