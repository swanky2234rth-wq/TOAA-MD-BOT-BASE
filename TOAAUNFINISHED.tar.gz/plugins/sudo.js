// ─── Sudo / Delsudo / Listsudo ─────────────────────────────────────────────────
// .sudo      — reply to or @tag a user to grant them sudo. Owner only.
// .delsudo   — reply to or @tag a user to revoke their sudo. Owner only.
// .listsudo  — lists current sudo users. Owner only.
//
// Targets are resolved through resolveDisplayJid() so a LID-format mention
// (WhatsApp's newer privacy ID) shows the person's actual number/name in the
// reply instead of a meaningless internal LID digit string.

const {
  fReply, errorReply, resolveTarget, resolveDisplayJid, sudoUsers, addSudo, delSudo
} = require('../main');

module.exports = {
  name: 'sudo',
  version: '2.0.0',
  author: 'TOAA',
  commands: {
    'sudo': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return errorReply(conn, m, 'Access Denied', ctx.sessionName);

        const remoteJid = m.key.remoteJid;
        const targetJid = resolveTarget(m, args);
        if (!targetJid) {
          return errorReply(conn, m, `Reply to a user or @tag them: ${ctx.prefix}sudo @user`, ctx.sessionName);
        }

        const rawTargetJid = targetJid.includes('@') ? targetJid : `${targetJid.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
        const meta = remoteJid.endsWith('@g.us') ? await conn.groupMetadata(remoteJid).catch(() => null) : null;
        const cleanJid = resolveDisplayJid(rawTargetJid, meta?.participants);
        const targetNum = cleanJid.split('@')[0];

        if (targetNum === ctx.botNumber) {
          return errorReply(conn, m, "I can't sudo myself!", ctx.sessionName);
        }

        // Persist to disk first — sudoUsers Set (in-memory, hot-path lookup)
        // only gets updated once the write-through succeeds.
        const added = addSudo(targetNum, ctx.senderNumber);
        if (!added) {
          return errorReply(conn, m, `@${targetNum} already has sudo.`, ctx.sessionName);
        }
        sudoUsers.add(targetNum);

        await conn.sendMessage(remoteJid, {
          text: `*_@${targetNum} 𝙶𝚛𝚊𝚗𝚝𝚎𝚍 𝚂𝚞𝚍𝚘_*`,
          mentions: [cleanJid]
        }, { quoted: m });
      }
    },

    'delsudo': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return errorReply(conn, m, 'Access Denied', ctx.sessionName);

        const remoteJid = m.key.remoteJid;
        const targetJid = resolveTarget(m, args);
        if (!targetJid) {
          return errorReply(conn, m, `Reply to a user or @tag them: ${ctx.prefix}delsudo @user`, ctx.sessionName);
        }

        const rawTargetJid = targetJid.includes('@') ? targetJid : `${targetJid.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
        const meta = remoteJid.endsWith('@g.us') ? await conn.groupMetadata(remoteJid).catch(() => null) : null;
        const cleanJid = resolveDisplayJid(rawTargetJid, meta?.participants);
        const targetNum = cleanJid.split('@')[0];

        const removed = delSudo(targetNum);
        if (!removed) {
          return errorReply(conn, m, `@${targetNum} doesn't have sudo.`, ctx.sessionName);
        }
        sudoUsers.delete(targetNum);

        await conn.sendMessage(remoteJid, {
          text: `*_@${targetNum}'𝚜 𝚂𝚞𝚍𝚘 𝚁𝚎𝚟𝚘𝚔𝚎𝚍_*`,
          mentions: [cleanJid]
        }, { quoted: m });
      }
    },

    'listsudo': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return errorReply(conn, m, 'Access Denied', ctx.sessionName);

        if (!sudoUsers.size) return fReply(conn, m, ' No sudo users.', ctx.sessionName);

        const list = [...sudoUsers].map((n, i) => `${i + 1}. @${n}`).join('\n');
        const mentions = [...sudoUsers].map(n => `${n}@s.whatsapp.net`);
        await conn.sendMessage(m.key.remoteJid, {
          text: ` *Sudo Users:*\n\n${list}`,
          mentions
        }, { quoted: m });
      }
    }
  }
};
