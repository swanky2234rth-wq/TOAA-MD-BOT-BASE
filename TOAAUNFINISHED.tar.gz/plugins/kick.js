// Auto-converted from legacy registerCmd('kick', ...) in main.js
// Category: group
const {
  resolveTarget, unauthorizedReply, botAdminRequiredReply, errorReply, resolveDisplayJid, getRawId
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'kick',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'kick': {
      category: 'group',
      handler: async (nuell, hex, args, ctx) => {

  if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(nuell, hex, ctx.sessionName);
  if (!ctx.botAdmin) return botAdminRequiredReply(nuell, hex, ctx.sessionName);
  
  const remoteJid = hex.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return errorReply(nuell, hex, "Groups Only", ctx.sessionName);
  
  const targetJid = resolveTarget(hex, args);
  if (!targetJid) {
    return errorReply(nuell, hex, `Usage: ${ctx.prefix}kick @user or reply to their message`, ctx.sessionName);
  }
  
  // Clean JID
  const rawTargetJid = targetJid.includes('@') ? targetJid : `${targetJid.replace(/[^0-9]/g, '')}@s.whatsapp.net`;

  const meta = await nuell.groupMetadata(remoteJid).catch(() => null);
  const cleanJid = resolveDisplayJid(rawTargetJid, meta?.participants);
  const targetNum = cleanJid.split('@')[0];
  
  if (targetNum === ctx.botNumber) {
    return errorReply(nuell, hex, "I can't kick myself!", ctx.sessionName);
  }
  
  // Check if target is an admin (can't kick admins) — match on either the
  // phone-number id or the lid, since the resolved target could be in either form.
  if (meta) {
    const rawId = getRawId(rawTargetJid);
    const isTargetAdmin = meta.participants.find(p =>
      getRawId(p.id) === rawId || (p.lid && getRawId(p.lid) === rawId)
    )?.admin;
    if (isTargetAdmin && !ctx.isOwner) {
      return errorReply(nuell, hex, "I can't kick an admin!", ctx.sessionName);
    }
  }
  
  await nuell.groupParticipantsUpdate(remoteJid, [rawTargetJid], 'remove');
  await nuell.sendMessage(remoteJid, {
    text: `🪃 @${targetNum} has been kicked.`,
    mentions: [cleanJid]
  }, { quoted: hex });

      }
    }
  }
};
