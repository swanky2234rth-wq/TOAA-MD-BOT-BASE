// Auto-converted from legacy registerCmd('runtime', ...) in main.js
// Category: utilities
const {
  fReply,
  formatUptime
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'runtime',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'runtime': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const mem = process.memoryUsage();
  await fReply(conn, m,
    `🖥️ *System Info*\n\n` +
    `⏱️ Uptime: ${formatUptime(Date.now() - global.botStartTime)}\n` +
    `💾 RAM: ${(mem.heapUsed / 1024 / 1024).toFixed(2)} MB\n` +
    `💻 Platform: ${os.platform()}\n` +
    `🔢 Node.js: ${process.version}`,
    ctx.sessionName
  );

      }
    }
  }
};
