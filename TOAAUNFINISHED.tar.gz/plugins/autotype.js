// plugins/autotype.js
console.log('[AUTOTYPE] Plugin loaded!');

const { fReply, errorReply, getSessionSetting, setSessionSetting } = require('../main');

module.exports = {
  name: 'AutoType',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    // ─── AUTOTYPE ────────────────────────────────────────────────────────────
    'autotype': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner, isSudo, prefix } = ctx;
        const remoteJid = m.key.remoteJid;
        const action = (args[0] || '').toLowerCase();

        if (!isOwner && !isSudo) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        const currentStatus = getSessionSetting(sessionName, 'autoType', false);

        if (!action) {
          return fReply(conn, m, 
            `📌 *Auto Type Settings*\n\n` +
            `Status: ${currentStatus ? '🟢 ON' : '🔴 OFF'}\n\n` +
            `Usage:\n` +
            `• ${prefix}autotype on - Enable typing indicator\n` +
            `• ${prefix}autotype off - Disable typing indicator`, 
            sessionName
          );
        }

        if (action === 'on') {
          setSessionSetting(sessionName, 'autoType', true);
          await fReply(conn, m, `✅ Auto Type is now *ON*\n\nI'll show typing indicator when someone messages me.`, sessionName);
        } else if (action === 'off') {
          setSessionSetting(sessionName, 'autoType', false);
          await fReply(conn, m, `❌ Auto Type is now *OFF*`, sessionName);
        } else {
          await fReply(conn, m, `❌ Invalid option. Use *on* or *off*`, sessionName);
        }
      }
    },

    // ─── AUTORECORD ──────────────────────────────────────────────────────────
    'autorecord': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner, isSudo, prefix } = ctx;
        const remoteJid = m.key.remoteJid;
        const action = (args[0] || '').toLowerCase();

        if (!isOwner && !isSudo) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        const currentStatus = getSessionSetting(sessionName, 'autoRecord', false);

        if (!action) {
          return fReply(conn, m, 
            `📌 *Auto Record Settings*\n\n` +
            `Status: ${currentStatus ? '🟢 ON' : '🔴 OFF'}\n\n` +
            `Usage:\n` +
            `• ${prefix}autorecord on - Enable recording indicator\n` +
            `• ${prefix}autorecord off - Disable recording indicator`, 
            sessionName
          );
        }

        if (action === 'on') {
          setSessionSetting(sessionName, 'autoRecord', true);
          await fReply(conn, m, `✅ Auto Record is now *ON*\n\nI'll show recording indicator when someone messages me.`, sessionName);
        } else if (action === 'off') {
          setSessionSetting(sessionName, 'autoRecord', false);
          await fReply(conn, m, `❌ Auto Record is now *OFF*`, sessionName);
        } else {
          await fReply(conn, m, `❌ Invalid option. Use *on* or *off*`, sessionName);
        }
      }
    }
  }
};