// ─── TOAA Kick Inactive ─────────
const { errorReply, successReply } = require('../main');
const { getGroupActivity } = require('../helper/activityTracker');

const INACTIVE_THRESHOLD = 24 * 60 * 60 * 1000; // 24h

module.exports = {
  name: 'kickinactive',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'kickinactive': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isAdmin, isOwner, botAdmin } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `This command can only be used in groups.`, sessionName);
        }
        if (!isAdmin && !isOwner) {
          return errorReply(conn, m, `Only group admins can use this command.`, sessionName);
        }
        if (!botAdmin) {
          return errorReply(conn, m, `I need to be admin to kick members.`, sessionName);
        }

        let groupMetadata;
        try {
          groupMetadata = await conn.groupMetadata(remoteJid);
        } catch (e) {
          return errorReply(conn, m, `Couldn't fetch group members — try again.`, sessionName);
        }

        const activity = getGroupActivity(remoteJid);
        const targets = [];

        for (const p of groupMetadata.participants) {
          if (p.admin) continue; // never kick admins

          const data = activity[p.id];
          if (!data || (Date.now() - data.lastActive >= INACTIVE_THRESHOLD)) {
            targets.push(p.id);
          }
        }

        if (!targets.length) {
          return errorReply(conn, m, `No inactive users to kick.`, sessionName);
        }

        try {
          await conn.groupParticipantsUpdate(remoteJid, targets, 'remove');
          await successReply(conn, m, `Kicked ${targets.length} inactive users.`, sessionName);
        } catch (e) {
          console.error('[KICKINACTIVE] Error:', e.message);
          await errorReply(conn, m, `Failed to kick some inactive users.`, sessionName);
        }
      }
    }
  }
};
