// mute.js
const {
  fReply,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'mute',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'mute': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  await conn.groupSettingUpdate(m.key.remoteJid, 'announcement');
  await fReply(conn, m, '*_𝙶𝚛𝚘𝚞𝚙 𝙼𝚞𝚝𝚎𝚍_*', ctx.sessionName);

      }
    }
  }
};
