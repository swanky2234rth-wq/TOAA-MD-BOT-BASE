// Auto-converted from legacy registerCmd('copy', ...) in main.js
// Category: media
const {
  fReply,
  getQuotedMsg
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'copy',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'copy': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {

  const quotedMsg = getQuotedMsg(m);
  if (!quotedMsg) return fReply(conn, m, `Reply to a message with ${ctx.prefix}copy`, ctx.sessionName);
  await conn.sendMessage(m.key.remoteJid, { ...quotedMsg }, { quoted: m });

      }
    }
  }
};
