// plugins/account.js
const fs = require('fs');
const path = require('path');
const { getSessionSetting } = require('../helper/function');
const { applyFont } = require('../helper/fonts');
const config = require('../settings');

const ACCOUNT_FILE = path.join(__dirname, '../database/account.json');
let accountData = {};

if (fs.existsSync(ACCOUNT_FILE)) {
  try { accountData = JSON.parse(fs.readFileSync(ACCOUNT_FILE, 'utf-8')); } catch { accountData = {}; }
}

const DEFAULT_ACCOUNT = {
  bankName: 'OPAY',
  accountNumber: '7047129088',
  accountName: 'EMMANUEL DESMOND'
};

function getAccount(sessionId) {
  if (!accountData[sessionId]) { accountData[sessionId] = { ...DEFAULT_ACCOUNT }; saveAccount(); }
  return accountData[sessionId];
}
function saveAccount() {
  const dir = path.dirname(ACCOUNT_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(ACCOUNT_FILE, JSON.stringify(accountData, null, 2));
}
function getNewsletterFooter() {
  return { contextInfo: { isForwarded: false, externalAdReply: { title: config.botName || 'TOAA', mediaType: 1, showAdAttribution: false } } };
}
async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function errorReply(conn, m, text, sessionName) { await fReply(conn, m, `❌ ${text}`, sessionName); }
async function successReply(conn, m, text, sessionName) { await fReply(conn, m, `✅ ${text}`, sessionName); }
async function unauthorizedReply(conn, m, sessionName) { await fReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', sessionName); }

module.exports = {
  name: 'Account Manager',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    'account': {
      category: 'utilities',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName } = ctx;
        const account = getAccount(sessionName);
        const imageUrl = 'https://i.ibb.co/WR12hdg/f5e143b795b3.jpg';
        const caption =
          `╭━━━━[  *𝔸ℂℂ 𝔻𝔼𝕋𝔸𝕀𝕃𝕊*  ]━━━━━\n` +
          `┃𝙱𝙰𝙽𝙺 𝙽𝙰𝙼𝙴⥱ ${account.bankName}\n` +
          `┃𝙰𝙲𝙲 𝙽𝚄𝙼𝙱𝙴𝚁⥱ ${account.accountNumber}\n` +
          `┃𝙰𝙲𝙲 𝙽𝙰𝙼𝙴⥱ ${account.accountName}\n` +
          `╰━━━━━━━━━━━━━━━━━━━━`;
        try {
          const footer = getNewsletterFooter();
          await nuell.sendMessage(hex.key.remoteJid, { image: { url: imageUrl }, caption, ...footer }, { quoted: hex });
        } catch {
          await fReply(nuell, hex, caption, sessionName);
        }
      }
    },

    'setaccount': {
      category: 'owner',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, isOwner, prefix } = ctx;
        if (!isOwner) return unauthorizedReply(nuell, hex, sessionName);
        const input = args.join(' ').trim();
        if (!input) {
          const acc = getAccount(sessionName);
          return fReply(nuell, hex,
            `📌 *Set Account Details*\n\nUsage: ${prefix}setaccount <bank>|<number>|<name>\n\nExample:\n${prefix}setaccount OPAY|7047129088|EMMANUEL DESMOND\n\nCurrent:\n🏦 ${acc.bankName}\n🔢 ${acc.accountNumber}\n👤 ${acc.accountName}`,
            sessionName
          );
        }
        const parts = input.split('|').map(p => p.trim());
        if (parts.length < 3) return errorReply(nuell, hex, 'Use format: bank|number|name', sessionName);
        accountData[sessionName] = { bankName: parts[0], accountNumber: parts[1], accountName: parts[2] };
        saveAccount();
        await successReply(nuell, hex, `Account updated!\n\n🏦 ${parts[0]}\n🔢 ${parts[1]}\n👤 ${parts[2]}`, sessionName);
      }
    },

    'resetaccount': {
      category: 'owner',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, isOwner } = ctx;
        if (!isOwner) return unauthorizedReply(nuell, hex, sessionName);
        accountData[sessionName] = { ...DEFAULT_ACCOUNT };
        saveAccount();
        await successReply(nuell, hex, `Account reset!\n\n🏦 ${DEFAULT_ACCOUNT.bankName}\n🔢 ${DEFAULT_ACCOUNT.accountNumber}\n👤 ${DEFAULT_ACCOUNT.accountName}`, sessionName);
      }
    }
  }
};
