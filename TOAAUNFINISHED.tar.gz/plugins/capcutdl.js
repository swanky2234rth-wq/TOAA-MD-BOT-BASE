// ─── TOAA CapCut Downloader ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'capcutdl',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'ccdl': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const url = args.join(' ').trim();

        if (!url) {
          return errorReply(conn, m, `Usage: ${prefix}ccdl <url>\nExample: ${prefix}ccdl https://www.capcut.com/t/xxx`, sessionName);
        }
        if (!/capcut\.com/i.test(url)) {
          return errorReply(conn, m, `That doesn't look like a CapCut link.`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          // Using siputzx's free downloader API (no key needed) instead of the
          // btch-downloader npm package the source used, since that's not installed here.
          const apiUrl = `https://api.siputzx.my.id/api/d/capcut?url=${encodeURIComponent(url)}`;
          const { data } = await axios.get(apiUrl, { timeout: 20000 });

          const videoUrl = data?.data?.url || data?.result?.url || data?.data?.download_url;

          if (!data?.status || !videoUrl) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Couldn't fetch that video — try a different link.`, sessionName);
          }

          await conn.sendMessage(m.key.remoteJid, {
            video: { url: videoUrl },
            contextInfo: { forwardingScore: 99, isForwarded: true }
          }, { quoted: m });

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (e) {
          console.error('[CAPCUTDL] Error:', e.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong fetching that video — try again.`, sessionName);
        }
      }
    }
  }
};
