// ─── TOAA DeepSeek V4 (Thinking/Reasoning) ─────────
const { errorReply } = require('../main');
const { DeepSeekThinking } = require('../helper/deepseekEngine');

module.exports = {
  name: 'deepseek',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'deepseek': { category: 'ai', handler: run },
    'ds': { category: 'ai', handler: run },
    'deepthink': { category: 'ai', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const text = args.join(' ').trim();

  if (!text) {
    return errorReply(conn, m,
      `🧠 *DeepSeek V4*\n\nAn AI that thinks before it answers — good for questions that need real reasoning.\n\n*USAGE:*\n${prefix}deepseek <question>\n\n*EXAMPLE:*\n${prefix}deepseek Explain black holes\n${prefix}deepseek Write a sorting algorithm\n\n_The bot thinks first, so it takes a bit longer._`,
      sessionName
    );
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

  try {
    const result = await DeepSeekThinking(text);

    if (!result.success) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `DeepSeek failed to respond.`, sessionName);
    }

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

    let reply = '';
    if (result.reasoning) {
      const preview = result.reasoning.length > 800 ? result.reasoning.slice(0, 800) + '...' : result.reasoning;
      reply += `💭 *Thinking:*\n${preview.replace(/\n/g, '\n> ')}\n\n`;
    }
    if (result.answer) reply += result.answer;
    if (reply.length > 4096) reply = reply.slice(0, 4096) + '\n\n... (truncated)';

    await conn.sendMessage(m.key.remoteJid, { text: reply }, { quoted: m });

  } catch (e) {
    console.error('[DEEPSEEK] Error:', e.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
  }
}
