// Auto-converted from legacy registerCmd('device', ...) in main.js
// Category: utilities
const {
  fReply,
  newsletterReply,
  resolveDisplayJid
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'device',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'device': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner && !ctx.isUserPremium) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  const context = m.message?.extendedTextMessage?.contextInfo;
  if (!context?.stanzaId || !context.participant) return fReply(conn, m, '*_🎴 Reply to a user\'s recent message._*', ctx.sessionName);
  const quotedId = context.stanzaId;
  const remoteJid = m.key.remoteJid;
  const meta = remoteJid.endsWith('@g.us') ? await conn.groupMetadata(remoteJid).catch(() => null) : null;
  const userJid = resolveDisplayJid(context.participant, meta?.participants);
  const userNum = userJid.split('@')[0];
  let device = '𝙸 𝙾 𝚂';
  if (quotedId.startsWith('3EB0')) device = '𝚆 𝙰 - 𝚆 𝙴 𝙱';
  else if (quotedId.startsWith('BAE5')) device = '𝙰 𝙽 𝙳 𝚁 𝙾 𝙸 𝙳';
  else if (quotedId.startsWith('BAE9')) device = '𝙸 𝙾 𝚂';
  else if (quotedId.length > 21) device = '𝙰 𝙽 𝙳 𝚁 𝙾 𝙸 𝙳';
  await conn.sendMessage(m.key.remoteJid, { text: `✰ *𝙳𝙴𝚅𝙸𝙲𝙴 𝚂𝙿𝙸𝙻𝙻𝙴𝚁*\n\nᝪ @${userNum}\nᝪ *Device:* ${device}`, mentions: [userJid] }, { quoted: m });

      }
    }
  }
};
