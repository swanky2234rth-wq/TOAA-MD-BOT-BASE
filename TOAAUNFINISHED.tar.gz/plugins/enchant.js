// ─── TOAA RPG Enchant ─────────
const { errorReply, fReply } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed } = require('../helper/rpg');
const { getCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { ENCHANTABLE } = require('../helper/rpgRecipes');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'enchant',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'enchant': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const itemKey = args[0]?.toLowerCase();
  const user = getUser(jid);
  if (!user.enchants) user.enchants = {};

  if (!itemKey) {
    let txt = `✨ *ENCHANT — UPGRADE GEAR*\n\nBoost your equipment's stats!\n\n`;
    for (const [key, item] of Object.entries(ENCHANTABLE)) {
      const level = user.enchants[key] || 0;
      txt += `${item.name}\n`;
      txt += `📊 Level: ${level}/10\n`;
      txt += `💪 Bonus: +${item.bonus} ${item.stat}\n`;
      txt += `💰 Cost: ${fmtCoin(item.cost)}\n`;
      txt += `🎯 Rate: ${item.successRate}%\n`;
      txt += `👉 \`${prefix}enchant ${key}\`\n\n`;
    }
    return fReply(conn, m, txt.trim(), sessionName);
  }

  const item = ENCHANTABLE[itemKey];
  if (!item) {
    return errorReply(conn, m, `That item can't be enchanted! Check \`${prefix}enchant\` for the list.`, sessionName);
  }

  if ((user.inventory[itemKey] || 0) < 1) {
    return errorReply(conn, m, `You don't own a ${item.name}!`, sessionName);
  }

  const currentLevel = user.enchants[itemKey] || 0;
  if (currentLevel >= 10) {
    return errorReply(conn, m, `${item.name} is already MAX level (10)!`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still cooling down from the last enchant! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const cost = item.cost * (currentLevel + 1);
  const balance = getCoin(jid);
  if (balance < cost) {
    return errorReply(conn, m, `*NOT ENOUGH COIN*\n\nNeed: ${fmtCoin(cost)}\nYou have: ${fmtCoin(balance)}`, sessionName);
  }

  cooldowns.set(jid, Date.now());
  removeCoin(jid, cost);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✨', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `✨ *Enchanting ${item.name.toUpperCase()}...*\n\nLevel ${currentLevel} → ${currentLevel + 1}` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 2000));

  const adjustedRate = Math.max(20, item.successRate - currentLevel * 5);
  const isSuccess = Math.random() * 100 < adjustedRate;

  if (isSuccess) {
    const fresh = getUser(jid);
    if (!fresh.enchants) fresh.enchants = {};
    fresh.enchants[itemKey] = currentLevel + 1;
    fresh[item.stat] = (fresh[item.stat] || 0) + item.bonus;
    setUser(jid, fresh);

    const levelResult = addExp(jid, 150);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🎉', key: m.key } });

    let txt = `🎉 *ENCHANT SUCCESSFUL!*\n\n`;
    txt += `📦 Item: *${item.name}*\n`;
    txt += `📊 Level: *${currentLevel} → ${currentLevel + 1}*\n`;
    txt += `💪 Bonus: *+${item.bonus} ${item.stat}*\n`;
    txt += `💰 Cost: *-${fmtCoin(cost)}*\n`;
    txt += `✨ EXP: *+150*`;

    await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
    await notifyLevelUp(conn, m, jid, levelResult);
  } else {
    await conn.sendMessage(m.key.remoteJid, { react: { text: '💔', key: m.key } });

    let txt = `💔 *ENCHANT FAILED!*\n\n`;
    txt += `📦 Item: *${item.name}*\n`;
    txt += `📊 Level: *${currentLevel}* (unchanged)\n`;
    txt += `💰 Cost: *-${fmtCoin(cost)}* (lost)\n\n`;
    txt += `💡 *Tip:* Try again! Rate: ${adjustedRate}%`;

    await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
  }
}
