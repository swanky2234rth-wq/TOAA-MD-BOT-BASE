// ─── TOAA Waifu Images ─────────
// NOTE: The source supported an "nsfw" mode toggle. That branch has been
// removed entirely — this only ever serves SFW images from waifu.im.
const { errorReply } = require('../main');
const {
  generateWAMessageFromContent,
  generateWAMessage,
  jidNormalizedUser
} = require('../main');
const crypto = require('crypto');

module.exports = {
  name: 'mywaifu',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'mywaifu': {
      category: 'anime',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          const pageSize = 10;
          const params = new URLSearchParams({
            isNsfw: 'false',
            orderBy: 'Random',
            page: '1',
            pageSize: String(pageSize)
          });

          const res = await fetch(`https://api.waifu.im/images?${params}`);
          if (!res.ok) throw new Error(`API returned status ${res.status}`);

          const data = await res.json();
          if (!data.items || data.items.length === 0) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Couldn't find any images right now — try again.`, sessionName);
          }

          const imageUrls = data.items.map(item => item.url);

          await errorReply(conn, m, `🌸 *Waifu Collection*\n\nGot ${imageUrls.length} images for you! Check the album below.`, sessionName);

          const opener = generateWAMessageFromContent(
            m.key.remoteJid,
            {
              messageContextInfo: { messageSecret: crypto.randomBytes(32) },
              albumMessage: {
                expectedImageCount: imageUrls.length,
                expectedVideoCount: 0
              }
            },
            {
              userJid: jidNormalizedUser(conn.user.id),
              quoted: m,
              upload: conn.waUploadToServer
            }
          );

          await conn.relayMessage(opener.key.remoteJid, opener.message, { messageId: opener.key.id });

          for (const imgUrl of imageUrls) {
            const msg = await generateWAMessage(opener.key.remoteJid, { image: { url: imgUrl } }, {
              upload: conn.waUploadToServer
            });

            msg.message.messageContextInfo = {
              messageSecret: crypto.randomBytes(32),
              messageAssociation: {
                associationType: 1,
                parentMessageKey: opener.key
              }
            };

            await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
          }

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (error) {
          console.error('[MYWAIFU] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
        }
      }
    }
  }
};
