// Auto-converted from legacy registerCmd('antipromote', ...) in main.js
// Category: group
const {
  fReply,
  getGroupSettings,
  requireAdmin,
  updateGroupSettings
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'antipromote',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'antipromote': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const option = (args[0] || '').toLowerCase();
  const gs = getGroupSettings(remoteJid);
  if (option === 'on') { gs.antipromote.active = true; updateGroupSettings(remoteJid, { antipromote: gs.antipromote }); await fReply(conn, m, '*_💈 𝙰𝙽𝚃𝙸-𝙿𝚁𝙾𝙼𝙾𝚃𝙴 𝙾𝙽_*', ctx.sessionName); }
  else if (option === 'off') { gs.antipromote.active = false; updateGroupSettings(remoteJid, { antipromote: gs.antipromote }); await fReply(conn, m, '*_۞ Anti-promote deactivated!_*', ctx.sessionName); }
  else await fReply(conn, m, `Usage: ${ctx.prefix}antipromote on/off`, ctx.sessionName);

      }
    }
  }
};
