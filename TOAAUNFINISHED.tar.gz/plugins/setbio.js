// plugins/setbio.js
console.log('[SETBIO] Plugin loaded!');

const { fReply, errorReply } = require('../main');

module.exports = {
  name: 'SetBio',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setbio': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner, isSudo, prefix } = ctx;
        const remoteJid = m.key.remoteJid;
        const text = args.join(' ');

        if (!isOwner && !isSudo) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        if (!text) {
          return fReply(conn, m, `📌 *Set Bio*\n\nUsage: *${prefix}setbio <text>*\n\nExample: *${prefix}setbio I am a bot*`, sessionName);
        }

        try {
          await conn.updateProfileStatus(text);
          await fReply(conn, m, `✅ Bio updated to: *${text}*`, sessionName);
        } catch (error) {
          console.error('[SETBIO] Error:', error.message);
          await errorReply(conn, m, `❌ Error: ${error.message}`, sessionName);
        }
      }
    }
  }
};