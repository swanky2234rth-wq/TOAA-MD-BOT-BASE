// ─── TOAA RPG Expedition ─────────
// NOTE: legacy reward pools referenced items (gem, lava, dragonscale,
// titancore, pearl, seagem, ancientcoin, relic) that don't exist in this
// project's registry. Mapped each area's rewards to existing materials
// so nothing drops an item that can't actually be used or sold.
const { errorReply, fReply } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed, addItem } = require('../helper/rpg');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const EXPEDITIONS = {
  forest: { name: '🌲 Spider Forest', duration: 1800000, rewards: ['wood', 'herb', 'mushroom'], exp: 100, minLevel: 1 },
  cave: { name: '🏔️ Bat Cave', duration: 3600000, rewards: ['iron', 'gold', 'diamond'], exp: 200, minLevel: 5 },
  volcano: { name: '🌋 Dragon Mountain', duration: 7200000, rewards: ['gold', 'diamond'], exp: 400, minLevel: 15 },
  ocean: { name: '🌊 Kraken Sea', duration: 5400000, rewards: ['fish', 'gold'], exp: 300, minLevel: 10 },
  ruins: { name: '🏛️ Ancient Ruins', duration: 10800000, rewards: ['gold', 'mysterybox'], exp: 600, minLevel: 20 }
};

function formatTime(ms) {
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  if (hours > 0) return `${hours}h ${minutes}m`;
  return minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
}

module.exports = {
  name: 'expedition',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'expedition': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);
  if (!user.expeditions) user.expeditions = [];

  const action = args[0]?.toLowerCase();
  const expType = args[1]?.toLowerCase();

  const maxExpeditions = Math.min(5, 1 + Math.floor((user.level || 1) / 10));

  if (!action || !['start', 'claim', 'status', 'list'].includes(action)) {
    let txt = `🗺️ *EXPEDITION BASE* 🗺️\n\nSend an expedition party to find rare items while you rest!\n\n`;
    txt += `*Commands:*\n📜 \`${prefix}expedition list\` (Check Areas)\n🚀 \`${prefix}expedition start <area>\` (Start)\n`;
    txt += `⏳ \`${prefix}expedition status\` (Check Timer)\n💰 \`${prefix}expedition claim\` (Collect Results)\n\n`;
    txt += `📊 Your Capacity: *${user.expeditions.length}/${maxExpeditions} Parties*`;
    return fReply(conn, m, txt, sessionName);
  }

  if (action === 'list') {
    let txt = `📜 *WORLD EXPLORATION MAP* 📜\n\n`;
    for (const [key, exp] of Object.entries(EXPEDITIONS)) {
      const canGo = (user.level || 1) >= exp.minLevel;
      txt += `📍 ${exp.name} ${canGo ? '🔓' : '🔒'}\n   ├ ⏳ Time: ${formatTime(exp.duration)}\n`;
      txt += `   ├ 🎁 Possible Loot: ${exp.rewards.join(', ')}\n   ├ 📈 EXP: ${exp.exp} (Min Lv. ${exp.minLevel})\n   └ 🚀 Area code: \`${key}\`\n\n`;
    }
    return fReply(conn, m, txt, sessionName);
  }

  if (action === 'start') {
    if (user.expeditions.length >= maxExpeditions) {
      return errorReply(conn, m, `Your expedition capacity is full! (${user.expeditions.length}/${maxExpeditions})\nWait for another party to return first!`, sessionName);
    }

    if (!expType) {
      return errorReply(conn, m, `Pick a destination area!\nExample: \`${prefix}expedition start forest\``, sessionName);
    }

    const exp = EXPEDITIONS[expType];
    if (!exp) {
      return errorReply(conn, m, `Sorry, area *${expType}* isn't on the map!`, sessionName);
    }

    if ((user.level || 1) < exp.minLevel) {
      return errorReply(conn, m, `Your level's too low! Need *Level ${exp.minLevel}* for that expedition!`, sessionName);
    }

    user.expeditions.push({ type: expType, startedAt: Date.now(), duration: exp.duration });
    setUser(jid, user);

    let txt = `🚀 *EXPEDITION DEPARTED!* 🚀\n\nYour party set off toward the destination!\n`;
    txt += `📍 Destination: *${exp.name}*\n⏱️ Estimated Time: *${formatTime(exp.duration)}*\n\n`;
    txt += `> Relax for now, come collect the results with \`${prefix}expedition claim\`!`;

    return fReply(conn, m, txt, sessionName);
  }

  if (action === 'status') {
    if (user.expeditions.length === 0) {
      return errorReply(conn, m, `No expeditions running yet. Send one now! 🏕️`, sessionName);
    }

    let txt = `⏳ *EXPEDITION RADAR* ⏳\n\n`;
    for (let i = 0; i < user.expeditions.length; i++) {
      const exp = user.expeditions[i];
      const expInfo = EXPEDITIONS[exp.type];
      const elapsed = Date.now() - exp.startedAt;
      const remaining = Math.max(0, exp.duration - elapsed);
      const done = remaining <= 0;

      txt += `🗺️ *Party ${i + 1}* → ${expInfo.name}\n   └ Status: ${done ? '✅ DONE! (Ready to claim)' : `🕒 ${formatTime(remaining)} left`}\n\n`;
    }
    return fReply(conn, m, txt, sessionName);
  }

  if (action === 'claim') {
    const completedExps = user.expeditions.filter(e => Date.now() - e.startedAt >= e.duration);

    if (completedExps.length === 0) {
      return errorReply(conn, m, `No expeditions finished yet! Check with \`${prefix}expedition status\`!`, sessionName);
    }

    let totalExp = 0;
    const allRewards = [];

    for (const exp of completedExps) {
      const expInfo = EXPEDITIONS[exp.type];
      totalExp += expInfo.exp;

      for (const rewardItem of expInfo.rewards) {
        if (Math.random() > 0.4) {
          const qty = Math.floor(Math.random() * 5) + 1;
          addItem(jid, rewardItem, qty);
          allRewards.push(`${rewardItem} x${qty}`);
        }
      }
    }

    user.expeditions = user.expeditions.filter(e => Date.now() - e.startedAt < e.duration);
    setUser(jid, user);

    const levelResult = addExp(jid, totalExp);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

    let txt = `🎉 *EXPEDITION COMPLETE!* 🎉\n\nYour party returned with results from *${completedExps.length} expedition(s)*!\n\n`;
    txt += `*🎁 FINDINGS:*\n✨ EXP: *+${totalExp}*\n`;
    if (allRewards.length > 0) {
      txt += `📦 Items:\n${allRewards.map(r => `  • ${r}`).join('\n')}\n`;
    } else {
      txt += `📦 Items: *Aw, no luck this time...* 😭\n`;
    }

    await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
    return notifyLevelUp(conn, m, jid, levelResult);
  }
}
