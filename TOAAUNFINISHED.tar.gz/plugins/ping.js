// Auto-converted from legacy registerCmd('ping', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'ping',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'ping': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const start = Date.now();
  await conn.sendMessage(m.key.remoteJid, { text: '*_⎋ Pinging..._*' }, { quoted: m });
  const ms = Date.now() - start;
  await fReply(conn, m, `*_✷ Pong! ${ms}ms_*`, ctx.sessionName);

      }
    }
  }
};
