// ─── TOAA Notify Close Group (toggle) ─────────
// NOTE: This is the toggle only. The actual "detect group settings changed
// to closed/announcement-only and notify" logic needs a separate listener
// on Baileys' 'groups.update' event (checking for a change in `announce`)
// wired into your connection setup — not included here, same caveat as
// autodl.js. This plugin just stores the on/off preference per group.
const { errorReply, successReply, requireAdmin } = require('../main');
const { getGroup, setGroup } = require('../helper/groupProtectionStore');

module.exports = {
  name: 'notifclosegroup',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'notifclosegroup': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Groups only.`, sessionName);
        }
        if (!requireAdmin(ctx, conn, m)) return;

        const arg = args[0]?.toLowerCase();
        const current = getGroup(remoteJid).notifCloseGroup || false;

        if (!['on', 'off'].includes(arg)) {
          return errorReply(conn, m,
            `🔒 *Notify Close Group*\n\nStatus: ${current ? '✅ Active' : '❌ Inactive'}\n\nUsage:\n${prefix}notifclosegroup on\n${prefix}notifclosegroup off`,
            sessionName
          );
        }

        setGroup(remoteJid, { notifCloseGroup: arg === 'on' });
        return successReply(conn, m, `Notify close group ${arg === 'on' ? 'enabled' : 'disabled'}.`, sessionName);
      }
    }
  }
};
