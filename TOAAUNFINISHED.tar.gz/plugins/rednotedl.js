// ─── TOAA RedNote (XiaoHongShu) Downloader ─────────
const { errorReply } = require('../main');
const axios = require('axios');

const generateRandomIP = () => Array.from({ length: 4 }, () => Math.floor(Math.random() * 255)).join('.');

async function rednoteDL(xhsUrl) {
  const fakeIP = generateRandomIP();

  const response = await axios.post(
    'https://rednote.savevideodown.com/api/download',
    { url: xhsUrl },
    {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        Referer: 'https://rednote.savevideodown.com/',
        Origin: 'https://rednote.savevideodown.com',
        'X-Forwarded-For': fakeIP,
        'X-Real-IP': fakeIP,
        'Client-IP': fakeIP
      },
      timeout: 30000
    }
  );

  const resData = response.data;
  if (!resData.success) return { status: false, error: resData.error || 'Failed to fetch data' };

  return {
    status: true,
    title: resData.title,
    author: resData.author,
    type: resData.type,
    results: resData.type === 'video' ? [resData.directVideoUrl || resData.downloadUrl] : (resData.directImages || [])
  };
}

module.exports = {
  name: 'rednotedl',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'rednotedl': { category: 'downloader', handler: run },
    'rednote': { category: 'downloader', handler: run },
    'xhsdl': { category: 'downloader', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const text = args[0]?.trim();

  if (!text) {
    return errorReply(conn, m, `📕 *RedNote Downloader*\n\nUsage: ${prefix}rednotedl <link>\nExample: ${prefix}rednotedl https://www.xiaohongshu.com/xxx`, sessionName);
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

  try {
    const result = await rednoteDL(text);

    if (!result.status) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `RedNote failed: ${result.error}`, sessionName);
    }

    if (result.type === 'video' && result.results?.[0]) {
      await conn.sendMessage(m.key.remoteJid, { video: { url: result.results[0] }, caption: result.title || '' }, { quoted: m });
    } else if (result.results?.length > 0) {
      const toSend = result.results.slice(0, 5);
      for (const url of toSend) {
        await conn.sendMessage(m.key.remoteJid, { image: { url } }, { quoted: m });
      }
      if (result.results.length > 5) {
        await conn.sendMessage(m.key.remoteJid, { text: `_${result.results.length - 5} more photo(s) not sent — 5 max per request._` }, { quoted: m });
      }
    }

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error('[REDNOTEDL] Error:', e.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Couldn't fetch RedNote data — try again later.`, sessionName);
  }
}
