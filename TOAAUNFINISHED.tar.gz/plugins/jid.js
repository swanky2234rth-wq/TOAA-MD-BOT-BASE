// plugins/jid.js
console.log('[JID] Plugin loaded!');

const { fReply } = require('../main');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

module.exports = {
  name: 'JID',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'jid': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;
        const senderJid = m.key.participant || m.key.remoteJid;

        // ─── OWNER CHECK ──────────────────────────────────────────────────────
        if (!OWNER_NUMBERS.includes(senderNumber)) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        const info = `📌 *JID Information*\n\n` +
          `📱 Chat JID: ${remoteJid}\n` +
          `👤 Sender JID: ${senderJid}\n` +
          `🤖 Bot JID: ${conn.user.id}\n` +
          `📂 Is Group: ${remoteJid.endsWith('@g.us') ? 'Yes' : 'No'}`;

        await fReply(conn, m, info, sessionName);
      }
    }
  }
};