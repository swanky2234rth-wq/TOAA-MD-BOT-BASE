// ─── TOAA RPG Beg ─────────
// NOTE: legacy source had both beg.js and ngemis.js — same activity.
// Ported ngemis.js since it's more complete (stamina cost, a "free meal"
// outcome that restores stamina instead of just coin, a "chased off"
// outcome). Skipped beg.js as a duplicate.
const { errorReply } = require('../main');
const { getUser, setUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 5;
const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'beg',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'beg': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Give it a break! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m,
      `Too tired to beg! 🥺\n\nBegging costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext stamina point in ~${fmtEta(eta)}.`,
      sessionName
    );
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🤲', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Please, sir, ma'am, spare some change... 🥺\nHoping someone kind walks by... 🚶‍♂️` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const gacha = Math.random();

  if (gacha < 0.3) {
    const fresh = getUser(jid);
    const heal = Math.floor(Math.random() * 20) + 10;
    fresh.stamina = Math.min(fresh.maxStamina, fresh.stamina + heal);
    setUser(jid, fresh);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🍱', key: m.key } });
    return conn.sendMessage(m.key.remoteJid, {
      text: `PRAISE BE, SOMEONE GAVE YOU A MEAL! 🍱✨\n\nA kind soul handed you a packed lunch!\n💖 Stamina restored: *+${heal}*\n💵 Coin earned: 0\n\nFull belly, happy heart! 🥰`
    }, { quoted: m });
  }

  if (gacha > 0.9) {
    await conn.sendMessage(m.key.remoteJid, { react: { text: '💢', key: m.key } });
    return conn.sendMessage(m.key.remoteJid, {
      text: `CHASED OFF BY A LOCAL! 💢\n\n"Oi, this is my spot! Get out!"\nYou run off scared, not a cent to show for it...\n⚡ Stamina: -${STAMINA_COST}\n\nBegging spots are competitive these days! 😭`
    }, { quoted: m });
  }

  const earning = Math.floor(Math.random() * 3000) + 500;
  addCoin(jid, earning);
  const expGain = Math.floor(earning / 10);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  let txt = `TODAY'S BEGGING HAUL! 🤲✨\n\n💵 Spare change: *+${fmtCoin(earning)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\n`;
  txt += `Grateful for whatever comes, honest work is honest work! 🙏`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
