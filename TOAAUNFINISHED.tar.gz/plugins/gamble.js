const mainCore = require('../main');
const { errorReply, resolveTarget, resolveDisplayJid } = mainCore;
const econ = require('../helper/economy');

module.exports = {
  name: 'gamble',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'gamble': {
      category: 'economy',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;
        const rawTargetJid = resolveTarget(m, args);
        if (!rawTargetJid) return errorReply(conn, m, `Tag or reply to who you want to gamble with, then the amount.\nUsage: ${ctx.prefix}gamble @user <amount>`, sessionName);

        const meta = remoteJid.endsWith('@g.us') ? await conn.groupMetadata(remoteJid).catch(() => null) : null;
        const targetJid = resolveDisplayJid(rawTargetJid, meta?.participants);
        const targetNumber = targetJid.split('@')[0].split(':')[0];
        if (targetNumber === senderNumber) return errorReply(conn, m, `You can't gamble with yourself!`, sessionName);

        const amount = parseInt((args[args.length - 1] || '').replace(/[^0-9]/g, ''), 10);
        if (!amount || amount <= 0) return errorReply(conn, m, `Usage: ${ctx.prefix}gamble @user <amount>`, sessionName);

        const acc = econ.getAccount(senderNumber);
        if (acc.balance < amount) return errorReply(conn, m, `You don't have ${econ.fmtMoney(amount)}.`, sessionName);

        econ.addPendingGamble(remoteJid, targetNumber, senderNumber, amount);

        await conn.sendMessage(remoteJid, {
          text: `🎲 @${senderNumber} is challenging @${targetNumber} to gamble ${econ.fmtMoney(amount)}!\n\n@${targetNumber}, reply *Proceed* to accept or *Decline* to reject. (5 min to respond)`,
          mentions: [`${senderNumber}@s.whatsapp.net`, targetJid]
        }, { quoted: m });
      }
    }
  }
};
