// plugins/joke.js
const axios = require('axios');

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'Joke System',
  version: '1.0.0',
  author: 'TOAA',
  
  commands: {
    'joke': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const type = args[0]?.toLowerCase();
        
        if (type === 'dark') {
          await fReply(conn, m, '💀 *Fetching dark joke...* 💀', sessionName);
          
          const darkJokes = [
            "What's red and bad for your teeth? A brick.",
            "My favorite thing about my grandpa is his sense of humor. He's been dead for 3 years and still hasn't said anything bad about me.",
            "I have my grandfather's eyes. And his glass eye.",
            "What's the difference between a pizza and an orphan? A pizza can feed a family of four.",
            "My girlfriend's dog died, so I tried to cheer her up by getting her an identical one. She was furious. She said 'What am I going to do with two dead dogs?'",
            "What's red and sits in a corner? A naughty strawberry.",
            "Why don't orphans play hide and seek? Because nobody looks for them.",
            "I visited my new friend in his apartment. He told me, 'Make yourself at home.' So I threw him out. I hate having visitors.",
            "What's the hardest part of a vegetable to eat? The wheelchair.",
            "My grief counselor died. He was so good, I don't even care."
          ];
          
          const joke = darkJokes[Math.floor(Math.random() * darkJokes.length)];
          await fReply(conn, m, `💀 *DARK JOKE* 💀\n\n${joke}`, sessionName);
          
        } else {
          await fReply(conn, m, '😂 *Fetching dad joke...* 😂', sessionName);
          
          try {
            const { data } = await axios.get('https://icanhazdadjoke.com/', {
              headers: { 'Accept': 'application/json' }
            });
            await fReply(conn, m, `👨 *DAD JOKE* 👨\n\n${data.joke}`, sessionName);
          } catch {
            const dadJokes = [
              "What do you call a fake noodle? An impasta.",
              "Why don't scientists trust atoms? Because they make up everything.",
              "I'm reading a book on anti-gravity. It's impossible to put down!",
              "What do you call a fish with no eyes? A fsh.",
              "Why did the scarecrow win an award? Because he was outstanding in his field.",
              "What's orange and sounds like a parrot? A carrot.",
              "How does a penguin build its house? Igloos it together.",
              "What do you call a belt made of watches? A waist of time."
            ];
            const joke = dadJokes[Math.floor(Math.random() * dadJokes.length)];
            await fReply(conn, m, `👨 *DAD JOKE* 👨\n\n${joke}`, sessionName);
          }
        }
      }
    }
  }
};

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}