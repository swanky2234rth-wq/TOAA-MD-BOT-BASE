// Auto-converted from legacy registerCmd('kickall', ...) in main.js
// Category: group
const {
  fReply,
  rawNumber,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'kickall',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'kickall': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const meta = await conn.groupMetadata(remoteJid);
  const toKick = meta.participants.filter(p => !p.admin && rawNumber(p.id) !== ctx.botNumber && rawNumber(p.id) !== rawNumber(ctx.senderJid));
  if (!toKick.length) return fReply(conn, m, '*_💈 𝙽𝚘 𝙼𝚎𝚖𝚋𝚎𝚛𝚜 𝚃𝚘 𝙺𝚒𝚌𝚔_*', ctx.sessionName);
  await fReply(conn, m, `♻️ Kicking ${toKick.length} member(s)...`, ctx.sessionName);
  for (const p of toKick) { try { await conn.groupParticipantsUpdate(remoteJid, [p.id], 'remove'); } catch {} await new Promise(r => setTimeout(r, 500)); }
  await fReply(conn, m, `*_💈 𝙺𝚒𝚌𝚔𝚎𝚍 ${toKick.length} 𝙼𝚎𝚖𝚋𝚎𝚛𝚜_*`, ctx.sessionName);

      }
    }
  }
};
