// ─── TOAA RPG Dice ─────────
const { errorReply } = require('../main');
const { isRpgAllowed } = require('../helper/rpg');
const { getCoin, addCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { getSessionSetting } = require('../helper/function');

const MIN_BET = 1000;
const DICE_EMOJI = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

module.exports = {
  name: 'dice',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'dice': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const guess = parseInt(args[0]);
  const bet = parseInt(args[1]);

  if (!guess || guess < 1 || guess > 6) {
    return errorReply(conn, m,
      `🎲 *STREET DICE DEALER* 🎲\n\nGuess the number that comes up! (1-6)\n\n*How to play:*\n👉 \`${prefix}dice <number> <bet>\`\n\n*Example:*\n👉 \`${prefix}dice 6 5000\``,
      sessionName
    );
  }

  const balance = getCoin(jid);
  if (!bet || bet < MIN_BET) {
    return errorReply(conn, m, `No dealer takes bets that small! Minimum *${fmtCoin(MIN_BET)}* here! 🎲`, sessionName);
  }
  if (balance < bet) {
    return errorReply(conn, m, `You're short on cash! Pocket's only got *${fmtCoin(balance)}*. No tabs here! 😤`, sessionName);
  }

  removeCoin(jid, bet);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🎲', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `🎲 The dealer shakes the dice in a wooden cup... *rattle rattle rattle*...` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const result = Math.floor(Math.random() * 6) + 1;
  const isWin = guess === result;

  let txt = `*CUP LIFTED!* 🎲💥\n\nYour guess: *${guess}*\nDice landed: *${result}* ${DICE_EMOJI[result - 1]}\n\n`;

  if (isWin) {
    const winnings = bet * 5;
    addCoin(jid, winnings);
    txt += `🎉 *YOU CALLED IT PERFECTLY!*\n💰 5x payout: *+${fmtCoin(winnings)}*`;
  } else {
    txt += `🤣 *NOPE, WRONG CALL!*\n💸 Dealer takes: *-${fmtCoin(bet)}*`;
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: isWin ? '🎉' : '💸', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
}
