// ─── TOAA RPG Marry ─────────
const { errorReply, resolveTarget } = require('../main');
const { getUser, setUser, isRpgAllowed } = require('../helper/rpg');
const { getCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { getSessionSetting } = require('../helper/function');

const MARRIAGE_COST = 50000;

module.exports = {
  name: 'marry',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'marry': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const target = resolveTarget(m, args);

  if (!target) {
    let txt = `💒 *RPG REGISTRY OFFICE* 💒\n\nWant to propose? Tag them here!\n\n*How to propose:*\n👉 \`${prefix}marry @user\`\n\n*Requirements:*\n💍 Ceremony fee: *${fmtCoin(MARRIAGE_COST)}*\n(Make sure they're single!)`;
    return errorReply(conn, m, txt, sessionName);
  }

  if (target === jid) {
    return errorReply(conn, m, `Marrying yourself? That's rough. Go find a partner! 😭💔`, sessionName);
  }

  const user = getUser(jid);
  const partner = getUser(target);

  if (user.spouse) {
    return errorReply(conn, m, `You're already married to @${user.spouse.split('@')[0]}!\nPolygamy's not allowed here. Divorce first with \`.divorce\` 😡`, sessionName);
  }

  if (partner.spouse) {
    return errorReply(conn, m, `Ouch... @${target.split('@')[0]} is already married to someone else!\nFriendzoned. 🥀`, sessionName);
  }

  const balance = getCoin(jid);
  if (balance < MARRIAGE_COST) {
    return errorReply(conn, m, `Trying to get married while broke? 🤦‍♂️\nCeremony costs *${fmtCoin(MARRIAGE_COST)}*, you've got *${fmtCoin(balance)}*.\nGo earn some first!`, sessionName);
  }

  removeCoin(jid, MARRIAGE_COST);
  user.spouse = target;
  user.marriedAt = Date.now();
  setUser(jid, user);

  partner.spouse = jid;
  partner.marriedAt = Date.now();
  setUser(target, partner);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '💍', key: m.key } });

  let txt = `💒 *WEDDING ANNOUNCEMENT!!* 💒\n\nEveryone here congratulates:\n\n`;
  txt += `👰 @${jid.split('@')[0]}\n           💖 & 💖\n👰 @${target.split('@')[0]}\n\n`;
  txt += `🎉 *THEY'RE OFFICIALLY MARRIED!* 🎉\n\n💍 Ceremony cost: *-${fmtCoin(MARRIAGE_COST)}*\n\n`;
  txt += `> _"May it last forever!" — Bot Officiant_ 🥺💕`;

  await conn.sendMessage(m.key.remoteJid, { text: txt, mentions: [jid, target] }, { quoted: m });
}
