// ─── TOAA AntiBot ─────────
// ⚠️ RISK FLAG: This uses heuristic scoring on message-ID formatting patterns
// borrowed from a different bot framework's internal message construction.
// These patterns are guesses, not a verified signature of "this is a bot" —
// they could false-positive on legitimate WhatsApp clients, business API
// senders, or even messages from THIS bot itself on your specific Baileys
// fork (@innovatorssoft/baileys@7.4.4). A false positive here means kicking
// a real group member. Test carefully in a low-stakes group before relying
// on this in groups you care about. You asked for this ported as-is despite
// the risk — this comment is here so future-you remembers why.
const { errorReply, successReply, requireAdmin, rawNumber } = require('../main');
const { getGroup, setGroup } = require('../helper/groupProtectionStore');

function extractMessageId(m) {
  return String(m?.key?.id || '').trim();
}

function extractSenderDevice(m) {
  const participant = String(m?.key?.participant || '');
  const match = participant.match(/:(\d+)@/);
  if (!match) return null;
  const value = parseInt(match[1], 10);
  return Number.isNaN(value) ? null : value;
}

function isUnknownPushName(pushName) {
  const value = String(pushName || '').trim().toLowerCase();
  return !value || ['unknown', 'undefined', 'null'].includes(value);
}

function analyzeBotMessage(m) {
  const messageId = extractMessageId(m);
  if (!messageId) return { isBot: false, score: 0, reasons: [] };

  if (messageId.startsWith('WAMID.') || messageId.startsWith('false_') || messageId.startsWith('true_')) {
    return { isBot: false, score: 0, reasons: [] };
  }

  let score = 0;
  const reasons = [];
  const idUpper = messageId.toUpperCase();

  if (idUpper.startsWith('BAE5')) { score += 5; reasons.push('id-BAE5'); }
  else if (idUpper.startsWith('3EB0') && idUpper.length === 22) { score += 4; reasons.push('id-3EB0'); }
  else if (idUpper.startsWith('B24E')) { score += 5; reasons.push('id-B24E'); }
  else if (idUpper.startsWith('94DD')) { score += 5; reasons.push('id-94DD'); }
  else if (idUpper.startsWith('B1E')) { score += 5; reasons.push('id-B1E'); }
  else if (/^[A-F0-9]{28,40}$/i.test(messageId)) { score += 2; reasons.push('id-upper-hex'); }
  else if (messageId.length === 16) { score += 3; reasons.push('id-length-16'); }
  else if (messageId.length < 20 && !messageId.includes('-')) { score += 2; reasons.push('id-length-suspicious'); }

  if (/[a-z]/.test(messageId) && !messageId.startsWith('3EB0') && !messageId.includes('-')) {
    score += 4; reasons.push('id-lowercase-signature');
  }

  const len = messageId.length;
  if (len !== 16 && len !== 20 && len !== 22 && len !== 32 && !messageId.includes('-')) {
    score += 3; reasons.push('id-length-unusual');
  }

  const msg = m?.message || {};
  const actualMsg = msg.ephemeralMessage?.message || msg.viewOnceMessage?.message || msg.viewOnceMessageV2?.message || msg;
  const textMsg = actualMsg?.conversation || actualMsg?.extendedTextMessage?.text || '';
  const contextInfo = actualMsg?.extendedTextMessage?.contextInfo || actualMsg?.imageMessage?.contextInfo || actualMsg?.videoMessage?.contextInfo || {};

  if (contextInfo.externalAdReply) { score += 6; reasons.push('custom-ad-reply'); }
  if (contextInfo.isForwarded && contextInfo.forwardingScore > 100) { score += 3; reasons.push('fake-forward-score'); }
  if (/[\u200B-\u200D\uFEFF]/.test(textMsg)) { score += 3; reasons.push('invisible-characters'); }

  const botMessageTypes = [
    'buttonsMessage', 'templateMessage', 'listMessage',
    'interactiveMessage', 'buttonsResponseMessage',
    'templateButtonReplyMessage', 'listResponseMessage',
    'interactiveResponseMessage'
  ];
  for (const type of botMessageTypes) {
    if (actualMsg[type]) { score += 6; reasons.push(`message-type-${type}`); break; }
  }

  if (msg.deviceSentMessage) {
    score += 1; reasons.push('message-deviceSent');
    if (msg.deviceSentMessage?.message) { score += 1; reasons.push('message-deviceWrapper'); }
  }

  const senderDevice = extractSenderDevice(m);
  if (Number.isInteger(senderDevice) && senderDevice > 20) { score += 2; reasons.push('participant-highDevice'); }

  const lowerPushName = String(m?.pushName || '').toLowerCase();
  if (isUnknownPushName(m?.pushName)) { score += 1; reasons.push('pushname-unknown'); }
  else if (/(bot|system|admin|owner|host|panel)/i.test(lowerPushName)) { score += 2; reasons.push('pushname-suspicious'); }

  return { isBot: score >= 5, score, reasons, messageId, senderDevice };
}

// Called from main.js's handleMessage on every group message.
async function detectBot(conn, m, sessionName, senderJid, botNumber) {
  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return false;

  const groupData = getGroup(remoteJid);
  if (!groupData.antibot) return false;

  const result = analyzeBotMessage(m);
  if (!result.isBot) return false;

  if (rawNumber(senderJid) === botNumber) return false;

  try {
    const meta = await conn.groupMetadata(remoteJid);
    const botParticipant = meta.participants.find(p => rawNumber(p.id) === botNumber);
    if (!botParticipant?.admin) return false;

    const targetParticipant = meta.participants.find(p => rawNumber(p.id) === rawNumber(senderJid));
    if (targetParticipant?.admin) return false;

    const targetJid = targetParticipant?.id || senderJid;

    try { await conn.sendMessage(remoteJid, { delete: m.key }); } catch (e) {}

    await conn.groupParticipantsUpdate(remoteJid, [targetJid], 'remove');
    await conn.sendMessage(remoteJid, {
      text: `🤖 *AntiBot* — @${rawNumber(targetJid)} detected as a bot and kicked.`,
      mentions: [targetJid]
    });

    return true;
  } catch (e) {
    console.error('[ANTIBOT] Error:', e.message);
    return false;
  }
}

module.exports = {
  name: 'antibot',
  version: '1.0.0',
  author: 'TOAA',
  detectBot,
  commands: {
    'antibot': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Groups only.`, sessionName);
        }
        if (!requireAdmin(ctx, conn, m)) return;

        const arg = args[0]?.toLowerCase();
        const current = getGroup(remoteJid).antibot || false;

        if (!arg || arg === 'status') {
          return errorReply(conn, m,
            `🤖 *AntiBot*\n\nStatus: ${current ? '✅ Active' : '❌ Inactive'}\nDetection: *Smart Heuristic* (experimental — may false-positive)\n\n${ctx.prefix}antibot on/off`,
            sessionName
          );
        }
        if (arg === 'on') {
          setGroup(remoteJid, { antibot: true });
          return successReply(conn, m, `AntiBot enabled.`, sessionName);
        }
        if (arg === 'off') {
          setGroup(remoteJid, { antibot: false });
          return successReply(conn, m, `AntiBot disabled.`, sessionName);
        }
        return errorReply(conn, m, `Use "on" or "off".`, sessionName);
      }
    }
  }
};
