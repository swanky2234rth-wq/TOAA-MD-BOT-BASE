const mainCore = require('../main');
const { errorReply, successReply, unauthorizedReply, fReply } = mainCore;
const axios = require('axios');

module.exports = {
  name: 'Owner Batch 1',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'antibug': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!global.antibugSettings) global.antibugSettings = new Map();
        const option = (args[0] || '').toLowerCase();
        if (!['on', 'off'].includes(option)) {
          const current = global.antibugSettings.get(ctx.sessionName) || false;
          return successReply(conn, m,
            `Antibug Usage:\n\n${ctx.prefix}antibug on - Enable\n${ctx.prefix}antibug off - Disable\n\nCurrent: ${current ? '🟢 ON' : '🔴 OFF'}`,
            ctx.sessionName
          );
        }
        global.antibugSettings.set(ctx.sessionName, option === 'on');
        await successReply(conn, m, `Antibug: ${option.toUpperCase()}`, ctx.sessionName);
      }
    },

    'exec': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const cmd = args.join(' ');
        if (!cmd) return errorReply(conn, m, `Usage: ${ctx.prefix}exec <command>`, ctx.sessionName);
        const { exec } = require('child_process');
        exec(cmd, (error, stdout, stderr) => {
          const output = stdout || stderr || error?.message || 'Done';
          conn.sendMessage(m.key.remoteJid, { text: `💻 ${output.substring(0, 4000)}` }, { quoted: m });
        });
      }
    },

    'downloadfile': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const url = args[0];
        if (!url) return errorReply(conn, m, `Usage: ${ctx.prefix}downloadfile <url>`, ctx.sessionName);
        await fReply(conn, m, 'Downloading...', ctx.sessionName);
        try {
          const response = await axios.get(url, { responseType: 'arraybuffer' });
          const filename = url.split('/').pop() || 'download';
          await conn.sendMessage(m.key.remoteJid, {
            document: Buffer.from(response.data),
            fileName: filename,
            mimetype: response.headers['content-type'] || 'application/octet-stream'
          }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'sendmsg': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const jid = args[0];
        const msg = args.slice(1).join(' ');
        if (!jid || !msg) return errorReply(conn, m, `Usage: ${ctx.prefix}sendmsg <jid> <message>`, ctx.sessionName);
        try {
          await conn.sendMessage(jid, { text: msg });
          await successReply(conn, m, `Message sent to ${jid}`, ctx.sessionName);
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'join': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const link = args[0];
        if (!link) return errorReply(conn, m, `Usage: ${ctx.prefix}join <invite_link>`, ctx.sessionName);
        try {
          const code = link.split('chat.whatsapp.com/')[1];
          if (!code) return errorReply(conn, m, "Invalid invite link!", ctx.sessionName);
          await conn.groupAcceptInvite(code);
          await successReply(conn, m, "Joined group successfully!", ctx.sessionName);
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'left': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const jid = args[0] || m.key.remoteJid;
        if (!jid.endsWith('@g.us')) return errorReply(conn, m, "Not a group!", ctx.sessionName);
        try {
          await conn.groupLeave(jid);
          await successReply(conn, m, "Left group successfully!", ctx.sessionName);
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    }
  }
};
