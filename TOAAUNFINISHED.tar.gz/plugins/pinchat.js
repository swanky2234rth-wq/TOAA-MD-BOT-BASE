// ─── TOAA Pin Chat Message ─────────
const { errorReply, successReply, requireAdmin, getQuotedCtx } = require('../main');

module.exports = {
  name: 'pinchat',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'pinchat': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Groups only.`, sessionName);
        }
        if (!requireAdmin(ctx, conn, m)) return;

        const quotedCtx = getQuotedCtx(m);
        if (!quotedCtx?.stanzaId) {
          return errorReply(conn, m,
            `📌 Reply to the message you want to pin!\n\nUsage:\nReply a message → ${prefix}pinchat\nOptional: ${prefix}pinchat 24 (pin for 24 hours)`,
            sessionName
          );
        }

        let durationSeconds = 86400; // default 24h
        const hours = parseInt(args[0]);
        if (!isNaN(hours) && hours >= 1 && hours <= 720) {
          durationSeconds = hours * 3600;
        }

        try {
          const pinKey = {
            remoteJid,
            fromMe: false,
            id: quotedCtx.stanzaId,
            participant: quotedCtx.participant
          };

          await conn.sendMessage(remoteJid, {
            pin: pinKey,
            type: 1,
            time: durationSeconds
          });

          await successReply(conn, m, `Pinned successfully.`, sessionName);

        } catch (error) {
          console.error('[PINCHAT] Error:', error.message);
          await errorReply(conn, m, `Failed to pin that message.`, sessionName);
        }
      }
    }
  }
};
