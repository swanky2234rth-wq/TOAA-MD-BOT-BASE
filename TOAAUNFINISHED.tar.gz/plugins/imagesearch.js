// Auto-converted from legacy registerCmd('imagesearch', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'imagesearch',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'imagesearch': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { sessionName, prefix } = ctx;
  const query = args.join(' ').trim();
  
  if (!query) {
    return fReply(conn, m, 
      `🖼️ *Google Image Search*\n\n` +
      `📌 *Usage:* ${prefix}imagesearch <query>\n` +
      `💡 *Example:* ${prefix}imagesearch Ronaldo\n` +
      `🪔 *Aliases:* ${prefix}gimage, ${prefix}img`,
      sessionName
    );
  }

  await fReply(conn, m, `*_🔍 Searching for images..._*\n📝 Query: ${query}`, sessionName);

  try {
    const api = `https://api.drexapp.space/search/gimage?q=${encodeURIComponent(query)}`;
    const { data } = await axios.get(api);

    if (!data.status || !data.result?.images?.length) {
      return fReply(conn, m, '🎴 *No images found!*\n\nTry a different search term.', sessionName);
    }

    const images = data.result.images;
    const randomImage = images[Math.floor(Math.random() * images.length)];
    
    const caption = `🖼️ *IMAGE SEARCH RESULT*\n\n` +
                    `📝 *Query:* ${data.result.query || query}\n` +
                    `📌 *Title:* ${randomImage.title || 'Untitled'}\n` +
                    `🔗 *Source:* ${randomImage.source || 'Unknown'}\n\n` +
                    `🎴 *${images.length} images found*`;

    // Download the image buffer to ensure delivery
    const imageBuffer = await axios.get(randomImage.url, { responseType: 'arraybuffer' });
    
    await conn.sendMessage(m.key.remoteJid, {
      image: Buffer.from(imageBuffer.data),
      caption: caption
    }, { quoted: m });
    
    await conn.sendMessage(m.key.remoteJid, { react: { text: '🧩', key: m.key } });

  } catch (err) {
    console.error('[IMAGESEARCH] Error:', err.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '🎴', key: m.key } });
    
    // Fallback to alternative API
    try {
      const fallbackUrl = `https://api.siputzx.my.id/api/s/gimage?query=${encodeURIComponent(query)}`;
      const fallbackRes = await axios.get(fallbackUrl);
      
      if (fallbackRes.data?.status && fallbackRes.data?.data?.length) {
        const images = fallbackRes.data.data;
        const randomImage = images[Math.floor(Math.random() * images.length)];
        
        await conn.sendMessage(m.key.remoteJid, {
          image: { url: randomImage.url || randomImage },
          caption: `🖼️ *Image Search: ${query}*`
        }, { quoted: m });
        
        await conn.sendMessage(m.key.remoteJid, { react: { text: '🧩', key: m.key } });
      } else {
        throw new Error('Fallback failed');
      }
    } catch (fallbackErr) {
      await fReply(conn, m, `🎴 *Search failed!*\n\nError: ${err.message}\n\nTry a different search term.`, sessionName);
    }
  }

      }
    }
  }
};
