// plugins/fb.js
const axios = require('axios');
const { getSessionSetting } = require('../helper/function');
const { applyFont } = require('../helper/fonts');

async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function errorReply(conn, m, text, sessionName) { await fReply(conn, m, `❌ ${text}`, sessionName); }

async function fetchJson(url) {
  const response = await axios.get(url);
  return response.data;
}

module.exports = {
  name: 'Facebook Downloader',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    'facebook': {
      category: 'downloader',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const text = args.join(' ').trim();

        if (!text) {
          return fReply(nuell, hex,
            `📌 *Facebook Downloader*\n\nUsage: ${prefix}facebook <facebook_url>\nAliases: ${prefix}fb, ${prefix}fbdl`,
            sessionName
          );
        }
        if (!text.startsWith('https://'))
          return errorReply(nuell, hex, 'Invalid URL! Please provide a valid Facebook video link.', sessionName);

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '🕖', key: hex.key } });

        const apis = [
          async () => {
            const res = await fetchJson(`https://api.resellergaming.my.id/download/facebook?url=${encodeURIComponent(text)}`);
            if (res.status && res.result) return res.result.media || res.result.video?.[0]?.url || res.result.url;
          },
          async () => {
            const res = await fetchJson(`https://api.siputzx.my.id/api/d/fb?url=${encodeURIComponent(text)}`);
            if (res.status && res.data) return res.data.sd || res.data.hd || res.data.url;
          },
          async () => {
            const res = await fetchJson(`https://api.botcahx.eu.org/api/dowloader/fb?url=${encodeURIComponent(text)}`);
            if (res.status && res.result) return res.result.hd || res.result.sd || res.result.url;
          }
        ];

        for (const api of apis) {
          try {
            const videoUrl = await api();
            if (videoUrl) {
              await nuell.sendMessage(hex.key.remoteJid, {
                video: { url: videoUrl },
                mimetype: 'video/mp4',
                caption: `🎥 *Facebook Video*\n✅ Source: TOAA`
              }, { quoted: hex });
              await nuell.sendMessage(hex.key.remoteJid, { react: { text: '✅', key: hex.key } });
              return;
            }
          } catch (e) {
            console.log('[FB] API failed:', e.message);
          }
        }

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '❌', key: hex.key } });
        await errorReply(nuell, hex, 'Could not download the Facebook video. Make sure the link is valid and public.', sessionName);
      }
    },

    'fb': {
      category: 'downloader',
      handler: async (nuell, hex, args, ctx) => {
        await module.exports.commands.facebook.handler(nuell, hex, args, ctx);
      }
    },

    'fbdl': {
      category: 'downloader',
      handler: async (nuell, hex, args, ctx) => {
        await module.exports.commands.facebook.handler(nuell, hex, args, ctx);
      }
    }
  }
};
