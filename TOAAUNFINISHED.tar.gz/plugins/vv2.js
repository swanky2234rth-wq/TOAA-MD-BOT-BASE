// plugins/vv2.js
console.log('[VV2] Plugin loaded!');

const { downloadMedia, jidNormalizedUser, getSessionSetting, applyFont } = require('../main');

// Every reply for this command goes to the owner's own "You" self-chat only —
// nothing is ever sent back into the chat the command was used in.
async function selfReply(conn, selfJid, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(selfJid, { text: out });
}

async function selfErrorReply(conn, selfJid, text, sessionName) {
  const wrapped = text.includes('\n') ? `۞ ${text}` : `*_۞ ${text}_*`;
  await selfReply(conn, selfJid, wrapped, sessionName);
}

module.exports = {
  name: 'VV2',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'vv2': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner, isSudo } = ctx;
        // Send to the owner's own "You" self-chat, not the chat the command was used in.
        const selfJid = jidNormalizedUser(conn.user.id);
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!isOwner && !isSudo) {
          return selfReply(conn, selfJid, `*_۞ Access Denied_*`, sessionName);
        }

        if (!quoted) {
          return selfReply(conn, selfJid, `📌 Reply to a *view-once* message (image/video/audio).`, sessionName);
        }

        const mediaType = quoted.imageMessage ? 'image' : 
                         quoted.videoMessage ? 'video' : 
                         quoted.audioMessage ? 'audio' : null;

        if (!mediaType) {
          return selfReply(conn, selfJid, `❌ Not a view-once message.`, sessionName);
        }

        try {
          const media = await downloadMedia(quoted[`${mediaType}Message`], mediaType);

          if (mediaType === 'image') {
            await conn.sendMessage(selfJid, { 
              image: media, 
              caption: '✅ Here is the view-once image' 
            });
          } else if (mediaType === 'video') {
            await conn.sendMessage(selfJid, { 
              video: media, 
              caption: '✅ Here is the view-once video' 
            });
          } else if (mediaType === 'audio') {
            await conn.sendMessage(selfJid, { 
              audio: media, 
              mimetype: 'audio/mpeg', 
              ptt: true 
            });
          }

        } catch (error) {
          console.error('[VV2] Error:', error.message);
          await selfErrorReply(conn, selfJid, `❌ Failed to download view-once message.`, sessionName);
        }
      }
    }
  }
};
