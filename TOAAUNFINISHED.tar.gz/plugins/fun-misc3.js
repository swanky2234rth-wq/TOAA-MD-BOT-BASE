const mainCore = require('../main');
const { errorReply, successReply, successSmartReply } = mainCore;
const axios = require('axios');

module.exports = {
  name: 'Fun Batch 3',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'nerdfact': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const facts = [
          "The first computer bug was an actual moth found in a computer.",
          "A day on Venus is longer than a year on Venus.",
          "The universe is expanding faster than the speed of light.",
          "There are more stars in the universe than grains of sand on Earth.",
          "Water can boil and freeze at the same time.",
          "A human brain can hold 2.5 petabytes of information."
        ];
        await successReply(conn, m, `🤓 ${facts[Math.floor(Math.random() * facts.length)]}`, ctx.sessionName);
      }
    },

    'randomuser': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        try {
          const { data } = await axios.get('https://randomuser.me/api/');
          const user = data.results[0];
          const msg = `👤 Random User\n\nName: ${user.name.first} ${user.name.last}\nGender: ${user.gender}\nEmail: ${user.email}\nCountry: ${user.location.country}\nAge: ${user.dob.age}\nPhone: ${user.phone}`;
          if (user.picture?.thumbnail) {
            await conn.sendMessage(m.key.remoteJid, { image: { url: user.picture.large }, caption: msg }, { quoted: m });
          } else {
            await successSmartReply(conn, m, msg, ctx.sessionName);
          }
        } catch {
          await errorReply(conn, m, "Failed to fetch random user!", ctx.sessionName);
        }
      }
    },

    'pickup': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const lines = [
          "Are you a magician? Because whenever I look at you, everyone else disappears!",
          "Do you have a map? I keep getting lost in your eyes!",
          "Is your name Google? Because you have everything I'm searching for!",
          "Are you made of copper and tellurium? Because you're Cu-Te!",
          "Do you believe in love at first sight, or should I walk by again?"
        ];
        await successReply(conn, m, `💘 ${lines[Math.floor(Math.random() * lines.length)]}`, ctx.sessionName);
      }
    },

    'inspire': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const quotes = [
          "The only way to do great work is to love what you do. - Steve Jobs",
          "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
          "Believe you can and you're halfway there. - Theodore Roosevelt",
          "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
          "It does not matter how slowly you go as long as you do not stop. - Confucius",
          "The only impossible journey is the one you never begin. - Tony Robbins",
          "Your time is limited, don't waste it living someone else's life. - Steve Jobs",
          "The best way to predict the future is to create it. - Peter Drucker"
        ];
        await successReply(conn, m, `✨ ${quotes[Math.floor(Math.random() * quotes.length)]}`, ctx.sessionName);
      }
    }
  }
};
