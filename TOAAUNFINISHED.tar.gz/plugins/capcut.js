// Auto-converted from legacy registerCmd('capcut', ...) in main.js
// Category: downloader
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'capcut',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'capcut': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {

  const { sessionName, prefix } = ctx;
  const url = args[0]?.trim();
  
  if (!url) {
    return fReply(conn, m, 
      `🎬 *CapCut Video Downloader*\n\n` +
      `📌 *Usage:* ${prefix}capcut <capcut_url>\n` +
      `💡 *Example:* ${prefix}capcut https://www.capcut.com/t/xxxxx\n` +
      `🪔 *Alias:* ${prefix}cc <capcut_url>`,
      sessionName
    );
  }

  // Validate CapCut URL
  if (!url.includes('capcut.com') && !url.includes('capcut')) {
    return fReply(conn, m, '🎴 *Invalid CapCut link!*\n\nPlease provide a valid CapCut URL.', sessionName);
  }

  await fReply(conn, m, `*_⏳ Downloading CapCut video..._*`, sessionName);

  try {
    const { data } = await axios.get(
      `https://api.drexapp.space/downloader/capcut?url=${encodeURIComponent(url)}`
    );

    if (!data.status || !data.result) {
      throw new Error('Failed to fetch CapCut video');
    }

    const res = data.result;
    const videoUrl = res.no_watermark || res.best_video || res.video_url;
    
    if (!videoUrl) {
      throw new Error('No video URL found');
    }

    const title = res.title || 'CapCut Video';
    const source = res.source || 'CapCut';
    
    const videoBuffer = await axios.get(videoUrl, { responseType: 'arraybuffer' });
    const buffer = Buffer.from(videoBuffer.data);
    const fileSizeMB = buffer.length / (1024 * 1024);
    
    const caption = `🎬 *CapCut Downloader*\n\n` +
                    `📌 *Title:* ${title}\n` +
                    `🏷️ *Source:* ${source}\n` +
                    `💾 *Size:* ${fileSizeMB.toFixed(2)} MB\n` +
                    `🎥 *No Watermark* ✅`;
    
    // Send as document if file is too large (> 100MB)
    if (fileSizeMB > 100) {
      await conn.sendMessage(m.key.remoteJid, {
        document: buffer,
        fileName: `${title.replace(/[^a-zA-Z0-9]/g, '_')}.mp4`,
        mimetype: 'video/mp4',
        caption: caption
      }, { quoted: m });
    } else {
      await conn.sendMessage(m.key.remoteJid, {
        video: buffer,
        caption: caption
      }, { quoted: m });
    }
    
    await conn.sendMessage(m.key.remoteJid, { react: { text: '🧩', key: m.key } });

  } catch (err) {
    console.error('[CAPCUT] Error:', err.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '🎴', key: m.key } });
    
    // Fallback to alternative API
    try {
      const fallbackUrl = `https://api.siputzx.my.id/api/d/capcut?url=${encodeURIComponent(url)}`;
      const fallbackRes = await axios.get(fallbackUrl);
      
      if (fallbackRes.data?.status && fallbackRes.data?.data?.url) {
        const videoUrl = fallbackRes.data.data.url;
        const videoBuffer = await axios.get(videoUrl, { responseType: 'arraybuffer' });
        
        await conn.sendMessage(m.key.remoteJid, {
          video: Buffer.from(videoBuffer.data),
          caption: `🎬 *CapCut Video*\n📌 No Watermark`
        }, { quoted: m });
        
        await conn.sendMessage(m.key.remoteJid, { react: { text: '🧩', key: m.key } });
      } else {
        throw new Error('Fallback failed');
      }
    } catch (fallbackErr) {
      await fReply(conn, m, `🎴 *Download failed!*\n\nError: ${err.message}\n\nPossible reasons:\n• Invalid CapCut link\n• Video may be private/deleted\n• API may be down`, sessionName);
    }
  }

      }
    }
  }
};
