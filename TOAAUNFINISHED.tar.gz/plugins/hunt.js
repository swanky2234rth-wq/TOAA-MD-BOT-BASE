// ─── TOAA RPG Hunt ─────────
// NOTE: legacy source had both hunt.js and berburu.js — same activity,
// different item sets. berburu.js used item keys (daging_kelinci, etc.)
// that don't exist in this project's shared item registry and also
// auto-sold catches for coin, which conflicts with the inventory-based
// design everything else here follows. Ported hunt.js only, since its
// items (rabbit/deer/boar/bear/lion/dragon) already match rpgItems.js.
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed, addItem } = require('../helper/rpg');
const { ITEMS } = require('../helper/rpgItems');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 25;
const COOLDOWN_MS = 90 * 1000;
const cooldowns = new Map();

const ANIMALS = [
  { item: 'rabbit', chance: 50, exp: 100 },
  { item: 'deer', chance: 30, exp: 200 },
  { item: 'boar', chance: 20, exp: 300 },
  { item: 'bear', chance: 10, exp: 500 },
  { item: 'lion', chance: 5, exp: 800 },
  { item: 'dragon', chance: 1, exp: 2000 }
];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'hunt',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'hunt': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still tracking your last trail! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m,
      `⚡ You're out of stamina!\n\nHunting costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext stamina point in ~${fmtEta(eta)}.`,
      sessionName
    );
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🏹', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `🏹 _Sneaking through the bushes... nocking an arrow..._ 🌿🤫` }, { quoted: m });

  await new Promise((resolve) => setTimeout(resolve, 2500));

  const sorted = [...ANIMALS].sort((a, b) => a.chance - b.chance);
  const rand = Math.random() * 100;
  let caught = null;
  for (const a of sorted) {
    if (rand <= a.chance) { caught = a; break; }
  }
  if (!caught) caught = ANIMALS.find(a => a.item === 'rabbit');

  addItem(jid, caught.item, 1);
  const levelResult = addExp(jid, caught.exp);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  const item = ITEMS[caught.item];
  let txt = `🏹 *SUCCESSFUL SHOT!* 🏹\n\nGreat aim! You bagged:\n`;
  txt += `🎯 ${item.emote} *${item.name}* (+1)\n\n`;
  txt += `*Hunt Results:*\n`;
  txt += `✨ EXP: *+${caught.exp}*\n`;
  txt += `⚡ Stamina used: *-${STAMINA_COST}*`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
