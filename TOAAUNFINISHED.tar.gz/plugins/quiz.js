// plugins/quiz.js
const activeQuizzes = new Map();

const questions = [
  { question: "What is the capital of France?", options: ["London", "Berlin", "Paris", "Madrid"], answer: "Paris" },
  { question: "Which planet is known as the Red Planet?", options: ["Mars", "Jupiter", "Venus", "Saturn"], answer: "Mars" },
  { question: "Who painted the Mona Lisa?", options: ["Van Gogh", "Picasso", "Da Vinci", "Rembrandt"], answer: "Da Vinci" },
  { question: "What is the largest ocean on Earth?", options: ["Atlantic", "Indian", "Arctic", "Pacific"], answer: "Pacific" },
  { question: "Who wrote 'Romeo and Juliet'?", options: ["Charles Dickens", "Jane Austen", "William Shakespeare", "Mark Twain"], answer: "William Shakespeare" }
];

module.exports = {
  name: 'Quiz Game',
  version: '1.0.0',
  author: 'TOAA',
  handleQuizAnswer: handleQuizAnswer,
  
  commands: {
    'quiz': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;
        const option = args[0]?.toLowerCase();
        
        if (option === 'start') {
          if (activeQuizzes.has(remoteJid)) {
            return fReply(conn, m, '❌ *A quiz is already running!*', sessionName);
          }
          
          const players = new Set();
          players.add(senderNumber);
          
          const quiz = {
            players: players,
            scores: new Map(),
            currentQuestion: 0,
            active: true,
            timer: null
          };
          
          activeQuizzes.set(remoteJid, quiz);
          
          await conn.sendMessage(remoteJid, {
            text: `🎯 *QUIZ STARTED!* 🎯\n\n` +
                  `📝 Type *${prefix}quiz join* to join!\n` +
                  `⏳ Game starts in 30 seconds...\n\n` +
                  `🏆 First to answer correctly wins points!`,
            mentions: [`${senderNumber}@s.whatsapp.net`]
          });
          
          quiz.timer = setTimeout(async () => {
            const q = activeQuizzes.get(remoteJid);
            if (!q) return;
            if (q.players.size < 2) {
              activeQuizzes.delete(remoteJid);
              return conn.sendMessage(remoteJid, { text: '❌ Not enough players. Quiz cancelled.' });
            }
            await askQuestion(conn, remoteJid, quiz);
          }, 30000);
          
        } else if (option === 'join') {
          const quiz = activeQuizzes.get(remoteJid);
          if (!quiz) return fReply(conn, m, `❌ *No active quiz! Start one with ${prefix}quiz start*`, sessionName);
          if (!quiz.active) return fReply(conn, m, '❌ *Quiz already in progress!*', sessionName);
          if (quiz.players.has(senderNumber)) return fReply(conn, m, '❌ *You already joined!*', sessionName);
          
          quiz.players.add(senderNumber);
          await conn.sendMessage(remoteJid, {
            text: `✅ @${senderNumber} joined the quiz! (${quiz.players.size} players)`,
            mentions: [`${senderNumber}@s.whatsapp.net`]
          });
          
        } else {
          await fReply(conn, m, `🎯 *Quiz Commands*\n\n${prefix}quiz start - Start a new quiz\n${prefix}quiz join - Join the quiz`, sessionName);
        }
      }
    }
  }
};

async function askQuestion(conn, remoteJid, quiz) {
  const q = questions[quiz.currentQuestion];
  if (!q) return endQuiz(conn, remoteJid, quiz);
  
  const options = q.options.map((opt, i) => `${String.fromCharCode(65 + i)}. ${opt}`).join('\n');
  
  quiz.currentAnswer = q.answer;
  quiz.waitingForAnswer = true;
  
  await conn.sendMessage(remoteJid, {
    text: `📚 *Question ${quiz.currentQuestion + 1}/${questions.length}*\n\n` +
          `${q.question}\n\n${options}\n\n` +
          `⏳ Reply with the letter (A/B/C/D) or the answer!`
  });
  
  quiz.timer = setTimeout(() => {
    if (quiz.waitingForAnswer) {
      quiz.waitingForAnswer = false;
      conn.sendMessage(remoteJid, { text: `⏰ *Time's up!* The answer was *${quiz.currentAnswer}*` });
      quiz.currentQuestion++;
      askQuestion(conn, remoteJid, quiz);
    }
  }, 30000);
}

async function handleQuizAnswer(conn, m, senderNumber) {
  const remoteJid = m.key.remoteJid;
  const quiz = activeQuizzes.get(remoteJid);
  if (!quiz || !quiz.waitingForAnswer) return false;
  if (!quiz.players.has(senderNumber)) return false;
  
  const text = getMsgText(m).trim();
  const currentQuestion = questions[quiz.currentQuestion];
  if (!currentQuestion) return false;
  const answer = currentQuestion.answer;
  
  let isCorrect = false;
  if (text.toUpperCase() === answer.toUpperCase()) isCorrect = true;
  if (text.toUpperCase() === answer.toUpperCase().charAt(0)) isCorrect = true;
  
  if (isCorrect) {
    clearTimeout(quiz.timer);
    quiz.waitingForAnswer = false;
    
    const score = (quiz.scores.get(senderNumber) || 0) + 1;
    quiz.scores.set(senderNumber, score);
    
    await conn.sendMessage(remoteJid, {
      text: `🎉 *CORRECT!* @${senderNumber} gets 1 point!\n📊 Score: ${score}`,
      mentions: [`${senderNumber}@s.whatsapp.net`]
    });
    
    quiz.currentQuestion++;
    await askQuestion(conn, remoteJid, quiz);
    return true;
  }
  
  return false;
}

async function endQuiz(conn, remoteJid, quiz) {
  activeQuizzes.delete(remoteJid);
  
  const sorted = [...quiz.scores.entries()].sort((a, b) => b[1] - a[1]);
  let results = `🏆 *QUIZ COMPLETE!* 🏆\n\n`;
  
  for (let i = 0; i < sorted.length; i++) {
    results += `${i + 1}. @${sorted[i][0]} — ${sorted[i][1]} points\n`;
  }
  
  await conn.sendMessage(remoteJid, {
    text: results,
    mentions: sorted.map(s => `${s[0]}@s.whatsapp.net`)
  });
}

function getMsgText(m) {
  return m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption || '';
}

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}