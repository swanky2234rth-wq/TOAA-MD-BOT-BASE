// Auto-converted from legacy registerCmd('listonline', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'listonline',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'listonline': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;

  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) 
    return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);

  await fReply(conn, m, '🔍 *Subscribing to members... Please wait ~20s*', ctx.sessionName);

  try {
    const groupMeta = await conn.groupMetadata(remoteJid);
    const participants = groupMeta.participants
      .map(p => p.id)
      .filter(id => id !== conn.user.id)
      .slice(0, 25); // keep it safe

    const onlineSet = new Set();

    // Collect presence updates
    const handler = ({ id, presences }) => {
      for (const [jid, data] of Object.entries(presences)) {
        if (data.lastKnownPresence === 'available') {
          onlineSet.add(jid);
        }
      }
    };

    conn.ev.on('presence.update', handler);

    // Subscribe one by one to each member's personal JID
    for (const jid of participants) {
      try {
        await conn.presenceSubscribe(jid);
      } catch {}
      await new Promise(r => setTimeout(r, 400));
    }

    // Give WhatsApp time to push presence updates back
    await new Promise(r => setTimeout(r, 15000));
    conn.ev.off('presence.update', handler);

    const onlineUsers = participants.filter(jid => {
      const bare = jid.split('@')[0] + '@s.whatsapp.net';
      return onlineSet.has(jid) || onlineSet.has(bare);
    });

    if (!onlineUsers.length) {
      return fReply(conn, m,
        '🟢 *No online members detected*\n\n_(Users with private status won\'t appear)_',
        ctx.sessionName
      );
    }

    const text =
      `🟢 *ONLINE MEMBERS* (${onlineUsers.length} of ${participants.length} checked)\n\n` +
      onlineUsers.map(jid => `• @${jid.split('@')[0]}`).join('\n');

    await conn.sendMessage(remoteJid, { text, mentions: onlineUsers }, { quoted: m });

  } catch (e) {
    await fReply(conn, m, `🎴 *Error:* ${e.message}`, ctx.sessionName);
  }

      }
    }
  }
};
