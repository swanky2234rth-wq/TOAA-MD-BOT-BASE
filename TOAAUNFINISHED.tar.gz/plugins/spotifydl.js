// ─── TOAA Spotify Downloader ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'spotifydl',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'spdl': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const text = args.join(' ').trim();

        if (!text || !/open\.spotify\.com\/track/i.test(text)) {
          return errorReply(conn, m,
            `Give me a valid Spotify track link.\nExample: ${prefix}spdl https://open.spotify.com/track/3RY0NyQQXxuAiyk5eAS4fC`,
            sessionName
          );
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          const apiUrl = `https://api.nexray.eu.cc/downloader/spotify?url=${encodeURIComponent(text)}`;
          const { data } = await axios.get(apiUrl, { timeout: 20000 });

          if (!data.status || !data.result || !data.result.url) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Server didn't return a valid download link.`, sessionName);
          }

          const { title, artist, url } = data.result;
          const filename = `${artist || 'Spotify'} - ${title || 'Audio'}.mp3`;

          await conn.sendMessage(m.key.remoteJid, {
            audio: { url },
            mimetype: 'audio/mpeg',
            fileName: filename,
            ptt: false
          }, { quoted: m });

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (error) {
          console.error('[SPOTIFYDL] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong fetching that track — try again later.`, sessionName);
        }
      }
    }
  }
};
