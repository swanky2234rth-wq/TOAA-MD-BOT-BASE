// ─── TOAA RPG Level-Up Notification Toggle ─────────
const { fReply } = require('../main');
const { getUser, setUser } = require('../helper/rpg');

module.exports = {
  name: 'leveluprpg',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'leveluprpg': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;
  const sub = args[0]?.toLowerCase();

  const user = getUser(jid);

  if (sub === 'on') {
    setUser(jid, { levelupNotif: true });
    return fReply(conn, m, `✅ *RPG LEVEL UP NOTIF*\n\n> Status: *ON* ✅\n> You'll get notified when you level up in RPG!`, sessionName);
  }

  if (sub === 'off') {
    setUser(jid, { levelupNotif: false });
    return fReply(conn, m, `❌ *RPG LEVEL UP NOTIF*\n\n> Status: *OFF* ❌\n> Level-up notifications are now disabled.`, sessionName);
  }

  const status = user.levelupNotif !== false ? 'ON ✅' : 'OFF ❌';
  return fReply(conn, m,
    `🔔 *RPG LEVEL UP NOTIF*\n\n` +
    `> Current status: *${status}*\n\n` +
    `*📋 Usage:*\n` +
    `> \`${prefix}leveluprpg on\` — Enable\n` +
    `> \`${prefix}leveluprpg off\` — Disable`,
    sessionName
  );
}
