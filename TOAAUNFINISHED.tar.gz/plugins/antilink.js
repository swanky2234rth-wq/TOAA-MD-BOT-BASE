// Auto-converted from legacy registerCmd('antilink', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'antilink',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'antilink': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  const option = (args[0] || '').toLowerCase();
  
  if (!['off', 'del', 'warn', 'kick', 'on'].includes(option)) {
    return fReply(conn, m, `🀄 *Usage:* ${ctx.prefix}antilink off/del/warn/kick/on`, ctx.sessionName);
  }
  
  let mode = option;
  if (option === 'on') mode = 'kick';
  
  // ✅ Save per group JID, not per session
  setSessionSetting(ctx.sessionName, `antilink_${m.key.remoteJid}`, mode);
  await fReply(conn, m, `🪔 *𝙰𝚗𝚝𝚒𝚕𝚒𝚗𝚔: ${mode.toUpperCase()}*`, ctx.sessionName);

      }
    }
  }
};
