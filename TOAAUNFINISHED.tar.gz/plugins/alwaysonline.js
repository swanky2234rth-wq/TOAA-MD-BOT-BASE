// plugins/alwaysonline.js
console.log('[ALWAYSONLINE] Plugin loaded!');

const { fReply, errorReply } = require('../main');

module.exports = {
  name: 'AlwaysOnline',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'alwaysonline': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner, isSudo, prefix } = ctx;
        const remoteJid = m.key.remoteJid;
        const action = (args[0] || '').toLowerCase();

        if (!isOwner && !isSudo) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        const currentStatus = await conn.sendPresenceUpdate('available', remoteJid).then(() => true).catch(() => false);

        if (!action) {
          return fReply(conn, m, `📌 *Always Online*\n\nStatus: ${currentStatus ? '🟢 ON' : '🔴 OFF'}\n\nUsage: *${prefix}alwaysonline on/off*`, sessionName);
        }

        if (action === 'on') {
          // Keep presence active
          const interval = setInterval(async () => {
            try {
              await conn.sendPresenceUpdate('available', remoteJid);
            } catch (e) {}
          }, 30000);
          
          // Store interval in global
          if (!global.alwaysOnlineIntervals) global.alwaysOnlineIntervals = new Map();
          global.alwaysOnlineIntervals.set(sessionName, interval);
          
          await fReply(conn, m, `✅ Always Online is now *ON*`, sessionName);
        } else if (action === 'off') {
          if (global.alwaysOnlineIntervals && global.alwaysOnlineIntervals.has(sessionName)) {
            clearInterval(global.alwaysOnlineIntervals.get(sessionName));
            global.alwaysOnlineIntervals.delete(sessionName);
          }
          await fReply(conn, m, `❌ Always Online is now *OFF*`, sessionName);
        } else {
          await fReply(conn, m, `❌ Invalid option. Use *on* or *off*`, sessionName);
        }
      }
    }
  }
};