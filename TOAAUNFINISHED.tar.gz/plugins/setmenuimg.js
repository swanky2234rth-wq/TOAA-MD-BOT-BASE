// Auto-converted from legacy registerCmd('setmenuimg', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setmenuimg',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setmenuimg': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  const imgUrl = args[0];
  if (!imgUrl) return fReply(conn, m, `Usage: ${ctx.prefix}setmenuimg <url>`, ctx.sessionName);
  setSessionSetting(ctx.sessionName, 'menuImage', imgUrl);
  await fReply(conn, m, `*_💈 𝙼𝚎𝚗𝚞 𝙸𝚖𝚊𝚐𝚎 𝚄𝚙𝚍𝚊𝚝𝚎𝚍_*`, ctx.sessionName);

      }
    }
  }
};
