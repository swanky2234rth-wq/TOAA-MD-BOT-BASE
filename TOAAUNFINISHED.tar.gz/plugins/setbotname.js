// Auto-converted from legacy registerCmd('setbotname', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setbotname',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setbotname': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  const name = args.join(' ').trim();
  if (!name) return fReply(conn, m, `Usage: ${ctx.prefix}setbotname <name>`, ctx.sessionName);
  setSessionSetting(ctx.sessionName, 'botName', name);
  await fReply(conn, m, `*_💈 Bot name 𝚂𝚎𝚝: ${name}_*`, ctx.sessionName);

      }
    }
  }
};
