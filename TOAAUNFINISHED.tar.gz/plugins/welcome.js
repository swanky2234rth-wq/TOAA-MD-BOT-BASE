// Auto-converted from legacy registerCmd('welcome', ...) in main.js
// Category: group
const {
  fReply,
  getDefaultWelcomeMessage,
  newsletterReply,
  processCustomMessage,
  requireAdmin,
  welcomeMessages,
  welcomeSettings
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'welcome',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'welcome': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  
  const remoteJid = m.key.remoteJid;
  const option = (args[0] || '').toLowerCase();
  
  if (option === 'on') {
    welcomeSettings.set(remoteJid, true);
    await fReply(conn, m, `*_💈 Welcome messages: ON_*`, ctx.sessionName);
  }
  else if (option === 'off') {
    welcomeSettings.set(remoteJid, false);
    await fReply(conn, m, `*_💈 Welcome messages: OFF_*`, ctx.sessionName);
  }
  else if (option === 'set') {
    if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ Owner only command_*', ctx.sessionName);
    const customMsg = args.slice(1).join(' ');
    if (!customMsg) {
      return fReply(conn, m, 
        `*📝 Welcome Message Setup*\n\n` +
        `Usage: ${ctx.prefix}welcome set <message>\n\n` +
        `Variables you can use:\n` +
        `• {group} - Group name\n` +
        `• {user} - User's mention tag (number)\n` +
        `• {userName} - User's name\n\n` +
        `Example: ${ctx.prefix}welcome set Welcome {userName} to {group}! Enjoy your stay!`,
        ctx.sessionName
      );
    }
    welcomeMessages.set(remoteJid, customMsg);
    await fReply(conn, m, `✅ *Custom welcome message saved!*\n\nPreview:\n${processCustomMessage(customMsg, 'Group Name', 'User Name', '1234567890')}`, ctx.sessionName);
  }
  else if (option === 'reset') {
    if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ Owner only command_*', ctx.sessionName);
    welcomeMessages.delete(remoteJid);
    await fReply(conn, m, `✅ *Welcome message reset to default!*`, ctx.sessionName);
  }
  else if (option === 'view') {
    const current = welcomeMessages.get(remoteJid);
    if (current) {
      await fReply(conn, m, `📝 *Current welcome message:*\n\n${current}\n\nVariables: {group}, {user}, {userName}`, ctx.sessionName);
    } else {
      await fReply(conn, m, `📝 *Using default welcome message*\n\n${getDefaultWelcomeMessage('Group Name', '1234567890')}`, ctx.sessionName);
    }
  }
  else {
    await fReply(conn, m, 
      `*Welcome Command Usage:*\n\n` +
      `${ctx.prefix}welcome on - Enable welcome messages\n` +
      `${ctx.prefix}welcome off - Disable welcome messages\n` +
      `${ctx.prefix}welcome set <message> - Set custom message (owner only)\n` +
      `${ctx.prefix}welcome reset - Reset to default (owner only)\n` +
      `${ctx.prefix}welcome view - View current message`,
      ctx.sessionName
    );
  }

      }
    }
  }
};
