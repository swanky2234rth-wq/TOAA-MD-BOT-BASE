// ─── TOAA AntiMedia ─────────
const { errorReply, successReply, requireAdmin, rawNumber, getMediaType } = require('../main');
const { getGroup, setGroup } = require('../helper/groupProtectionStore');

// Called from main.js's handleMessage on every group message.
async function checkAntimedia(conn, m, sessionName, senderJid, isAdmin, isOwner) {
  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return false;
  if (isAdmin || isOwner || m.key.fromMe) return false;

  const groupData = getGroup(remoteJid);
  if (!groupData.antimedia) return false;

  const mediaType = getMediaType(m.message || {});
  if (!mediaType) return false;

  try { await conn.sendMessage(remoteJid, { delete: m.key }); } catch (e) {}

  await conn.sendMessage(remoteJid, {
    text: `⚠️ *AntiMedia* — Media from @${rawNumber(senderJid)} was removed.`,
    mentions: [senderJid]
  });

  return true;
}

module.exports = {
  name: 'antimedia',
  version: '1.0.0',
  author: 'TOAA',
  checkAntimedia,
  commands: {
    'antimedia': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Groups only.`, sessionName);
        }
        if (!requireAdmin(ctx, conn, m)) return;

        const arg = args[0]?.toLowerCase();
        const current = getGroup(remoteJid).antimedia || false;

        if (!arg || arg === 'status') {
          return errorReply(conn, m, `🖼️ *AntiMedia*\n\nStatus: ${current ? '✅ ON' : '❌ OFF'}\n\n${ctx.prefix}antimedia on/off`, sessionName);
        }
        if (arg === 'on') {
          setGroup(remoteJid, { antimedia: true });
          return successReply(conn, m, `AntiMedia enabled — images/videos/audio/documents will be removed.`, sessionName);
        }
        if (arg === 'off') {
          setGroup(remoteJid, { antimedia: false });
          return successReply(conn, m, `AntiMedia disabled.`, sessionName);
        }
        return errorReply(conn, m, `Use "on" or "off".`, sessionName);
      }
    }
  }
};
