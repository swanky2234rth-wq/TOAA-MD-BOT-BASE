// ─── TOAA Lyrics (LRCLIB) ─────────
const { fReply, errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'lyrics',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'lyrics': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const query = args.join(' ').trim();

        if (!query) {
          return errorReply(conn, m, `Usage: ${prefix}lyrics <song name>\nExample: ${prefix}lyrics The Chain Fleetwood Mac`, sessionName);
        }

        await fReply(conn, m, '*_💈 𝚂𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐 𝚏𝚘𝚛 𝚕𝚢𝚛𝚒𝚌𝚜..._*', sessionName);

        try {
          const { data } = await axios.get('https://lrclib.net/api/search', {
            params: { q: query },
            timeout: 15000,
            headers: { 'User-Agent': 'TOAA WhatsApp Bot (contact: t.me/swanky_is_TOAA)' }
          });

          if (!Array.isArray(data) || data.length === 0) {
            return errorReply(conn, m, `No lyrics found for "${query}".`, sessionName);
          }

          // Prefer the first result that actually has lyrics (plain or synced)
          const match = data.find(r => r.plainLyrics || r.syncedLyrics) || data[0];

          if (match.instrumental) {
            return fReply(conn, m,
              `*${match.trackName}* — *${match.artistName}*\n\n_This track is instrumental — no lyrics available._`,
              sessionName
            );
          }

          const lyricsText = match.plainLyrics || match.syncedLyrics;

          if (!lyricsText) {
            return errorReply(conn, m, `Found "${match.trackName}" by ${match.artistName}, but no lyrics text is available for it.`, sessionName);
          }

          // Strip LRC timestamps if only synced lyrics were available
          const cleanLyrics = match.plainLyrics
            ? lyricsText
            : lyricsText.replace(/\[\d{2}:\d{2}\.\d{2,3}\]\s?/g, '');

          const header = `🎵 *${match.trackName}*\n👤 ${match.artistName}${match.albumName ? `\n💿 ${match.albumName}` : ''}\n\n`;
          const fullText = header + cleanLyrics;

          // WhatsApp text messages have a practical limit; trim very long lyrics
          const MAX_LEN = 4000;
          const finalText = fullText.length > MAX_LEN
            ? fullText.slice(0, MAX_LEN) + '\n\n_[Lyrics truncated — too long to send in full]_'
            : fullText;

          await fReply(conn, m, finalText, sessionName);

        } catch (e) {
          console.error('[LYRICS] Error:', e.message);
          await errorReply(conn, m, `Couldn't fetch lyrics right now — try again in a bit.`, sessionName);
        }
      }
    }
  }
};
