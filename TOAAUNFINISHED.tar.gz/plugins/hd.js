// ─── TOAA Image Upscale (HD) ─────────
const { errorReply } = require('../main');

module.exports = {
  name: 'hd',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'hd': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const link = args.join(' ').trim();

        if (!link || !/^https?:\/\//i.test(link)) {
          return errorReply(conn, m, `Usage: ${prefix}hd <image link>\nExample: ${prefix}hd https://example.com/photo.jpg`, sessionName);
        }

        try {
          await conn.sendMessage(m.key.remoteJid, { react: { text: '🔄', key: m.key } });

          const url = `https://api.siputzx.my.id/api/iloveimg/upscale?image=${encodeURIComponent(link)}`;

          await conn.sendMessage(
            m.key.remoteJid,
            { image: { url }, caption: '✅ Upscaled to HD!' },
            { quoted: m }
          );
        } catch (e) {
          console.error('[HD] Error:', e.message);
          await errorReply(conn, m, `Something went wrong upscaling that image — try again.`, sessionName);
        } finally {
          try { await conn.sendMessage(m.key.remoteJid, { react: { text: '', key: m.key } }); } catch {}
        }
      }
    },
    'tohd': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        return module.exports.commands.hd.handler(conn, m, args, ctx);
      }
    }
  }
};
