const mainCore = require('../main');
const { errorReply, resolveTarget, resolveDisplayJid } = mainCore;
const econ = require('../helper/economy');

module.exports = {
  name: 'collab',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'collab': {
      category: 'economy',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;
        // Usage: .collab @partner @victim   (tag the person you want to team up
        // with, plus the person you both want to swipe)
        const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (mentioned.length < 2) {
          return errorReply(conn, m,
            `Tag the person you want to collab with, then who you want to swipe.\nUsage: ${ctx.prefix}collab @partner @victim`,
            sessionName
          );
        }

        const meta = remoteJid.endsWith('@g.us') ? await conn.groupMetadata(remoteJid).catch(() => null) : null;
        const partnerJid = resolveDisplayJid(mentioned[0], meta?.participants);
        const victimJid = resolveDisplayJid(mentioned[1], meta?.participants);
        const partnerNumber = partnerJid.split('@')[0];
        const victimNumber = victimJid.split('@')[0];

        if (partnerNumber === senderNumber) return errorReply(conn, m, `You can't collab with yourself!`, sessionName);
        if (victimNumber === senderNumber || victimNumber === partnerNumber) {
          return errorReply(conn, m, `The target can't be you or your partner!`, sessionName);
        }

        econ.addPendingCollab(remoteJid, partnerNumber, senderNumber, victimNumber);

        await conn.sendMessage(remoteJid, {
          text: `🤝 @${senderNumber} wants to collab with @${partnerNumber} to swipe @${victimNumber}!\n\n@${partnerNumber}, reply *Accept* to team up or *Decline* to reject. (5 min to respond)\n\n_Collabs hit harder and get past regular Security — but not Max Security._`,
          mentions: [`${senderNumber}@s.whatsapp.net`, partnerJid, victimJid]
        }, { quoted: m });
      }
    }
  }
};
