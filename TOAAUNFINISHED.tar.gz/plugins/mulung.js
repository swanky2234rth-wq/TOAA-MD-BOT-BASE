// ─── TOAA RPG Scavenger ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed, addItem } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { ITEMS } = require('../helper/rpgItems');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 15;
const COOLDOWN_MS = 300 * 1000;
const cooldowns = new Map();

const DROPS = [
  { item: 'bottle', chance: 90, min: 1, max: 10 },
  { item: 'can', chance: 80, min: 1, max: 8 },
  { item: 'cardboard', chance: 60, min: 1, max: 5 },
  { item: 'junk', chance: 95, min: 1, max: 15 },
  { item: 'newspaper', chance: 40, min: 0, max: 3 }
];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'scavenge',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'scavenge': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Cart's full, drop it off first! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Even scavenging needs energy! 🥵🗑️\n\nScavenging costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🗑️', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Digging through the trash can hopefully... 🗑️👀\nFingers crossed for something good today! ✨` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const results = [];
  let moneyEarned = 0;

  for (const drop of DROPS) {
    if (Math.random() * 100 <= drop.chance) {
      const qty = Math.floor(Math.random() * (drop.max - drop.min + 1)) + drop.min;
      if (qty > 0) {
        addItem(jid, drop.item, qty);
        results.push({ item: ITEMS[drop.item], qty });
        moneyEarned += qty * (ITEMS[drop.item].sell || 10);
      }
    }
  }

  addCoin(jid, moneyEarned);
  const expGain = Math.floor(Math.random() * 200) + 50;
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  let txt = `NICE SCRAP HAUL! 🗑️💸\n\nYou collected:\n`;
  for (const r of results) txt += `• ${r.item.emote} ${r.item.name}: *+${r.qty}*\n`;
  txt += `\nSold straight to the junk collector!\n💵 Sale total: *+${fmtCoin(moneyEarned)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina used: *-${STAMINA_COST}*\n\nKeep grinding, riches await! 🔥🚀`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
