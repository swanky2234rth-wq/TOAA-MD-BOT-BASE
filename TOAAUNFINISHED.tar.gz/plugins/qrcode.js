// Auto-converted from legacy registerCmd('qrcode', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'qrcode',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'qrcode': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx; const text = args.join(' ').trim();
  if (!text) return fReply(conn, m, `Usage: ${prefix}qrcode <text>`, sessionName);
  try { 
    await conn.sendMessage(m.key.remoteJid, { image: { url: `https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${encodeURIComponent(text)}` }, caption: `🔳 QR Code for:\n${text}` }, { quoted: m }); 
  }
  catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
