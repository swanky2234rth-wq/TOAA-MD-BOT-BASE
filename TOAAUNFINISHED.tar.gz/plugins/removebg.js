// Auto-converted from legacy registerCmd('removebg', ...) in main.js
// Category: media
const {
  downloadMedia,
  fReply,
  getMediaType,
  getQuotedMsg
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'removebg',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'removebg': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {

  const { sessionName } = ctx;
  const quotedMsg = getQuotedMsg(m);
  const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
  if (!t || t.type !== 'image') return fReply(conn, m, '*_۞ Reply to an image_*', sessionName);
  await fReply(conn, m, '*_💈 𝚁𝚎𝚖𝚘𝚟𝚒𝚗𝚐 𝙱𝙶..._*', sessionName);
  try {
    const buf = await downloadMedia(t.inner, t.type);
    const tmpPath = `/tmp/rmbg_${Date.now()}.jpg`; fs.writeFileSync(tmpPath, buf);
    const form = new FormData(); form.append('image_file', fs.createReadStream(tmpPath), 'image.jpg'); form.append('size', 'auto');
    const res = await axios.post('https://api.remove.bg/v1.0/removebg', form, { headers: { ...form.getHeaders(), 'X-Api-Key': 'sbMGJQhTzayqAR5oqGE3huhK' }, responseType: 'arraybuffer' });
    fs.unlinkSync(tmpPath);
    await conn.sendMessage(m.key.remoteJid, { image: Buffer.from(res.data), caption: '💈 *_Background removed!' }, { quoted: m });
  } catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
