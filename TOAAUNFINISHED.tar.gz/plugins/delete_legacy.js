// Auto-converted from legacy registerCmd('delete', ...) in main.js
// Category: utilities
const {
  fReply,
  getQuotedCtx
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'delete',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'delete': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const quotedCtx = getQuotedCtx(m);
  if (!quotedCtx?.stanzaId) return fReply(conn, m, '*_۞ 𝚁𝚎𝚙𝚕𝚢 𝚃𝚘 𝙰 𝙼𝚎𝚜𝚜𝚊𝚐𝚎 𝚃𝚘 𝙳𝚎𝚕𝚎𝚝𝚎 𝙸𝚝_*', ctx.sessionName);
  const deleteKey = { remoteJid: m.key.remoteJid, fromMe: quotedCtx.participant === ctx.botNumber + '@s.whatsapp.net', id: quotedCtx.stanzaId, participant: quotedCtx.participant };
  await conn.sendMessage(m.key.remoteJid, { delete: deleteKey });

      }
    }
  }
};
