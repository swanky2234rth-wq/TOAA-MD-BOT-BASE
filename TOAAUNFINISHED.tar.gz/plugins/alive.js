// Auto-converted from legacy registerCmd('alive', ...) in main.js
// Category: utilities
const {
  getNewsletterFooter,
  newsletterReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'alive',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'alive': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { sessionName } = ctx;
  let aliveConfig;
  try {
    const configFile = './database/alive_config.json';
    let configs = {};
    if (fs.existsSync(configFile)) configs = JSON.parse(fs.readFileSync(configFile, 'utf-8'));
    aliveConfig = configs[sessionName] || { name: 'TOAA', quote: '> 𝙳𝚘𝚠𝚗 𝚝𝚘 𝚎𝚊𝚛𝚝𝚑 𝚕𝚊𝚍... ', imageUrl: 'https://i.ibb.co/qYzpksy5/0c1dba58db96.jpg' };
  } catch {
    aliveConfig = { name: swanky TOAA', quote: '> 𝙷𝚞𝚖𝚊𝚗𝚜>>>', imageUrl: 'https://i.imgur.com/v2kKCOL.jpeg' };
  }

  const uptime = process.uptime();
  const h = Math.floor(uptime / 3600);
  const min = Math.floor((uptime % 3600) / 60);
  const sec = Math.floor(uptime % 60);
  let uptimeStr = '';
  if (h > 0) uptimeStr += `${h}h:`;
  if (min > 0) uptimeStr += `${min}m:`;
  uptimeStr += `${sec}s`;

  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Africa/Lagos' }));
  const hours = now.getHours();
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const hours12 = hours % 12 || 12;
  const timeStr = `${hours12}:${minutes} ${ampm}`;

  const aliveText =
    `≡ {${aliveConfig.name}}\n` +
    `${aliveConfig.quote}\n` +
    `*_${uptimeStr}_*\n` +
    `\`${timeStr}\``;

  const nl = getNewsletterFooter();

  try {
    await conn.sendMessage(m.key.remoteJid, {
      image: { url: aliveConfig.imageUrl },
      caption: aliveText,
      ...nl
    }, { quoted: m });
  } catch {
    await newsletterReply(conn, m, aliveText, sessionName);
  }

      }
    }
  }
};
