// ─── TOAA NSFW Collection ─────────
const { errorReply, fReply, getSessionSetting, setSessionSetting, requireAdmin } = require('../main');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'helper', 'nsfwData');
const jsonCache = new Map();

function loadJsonUrls(filename) {
  if (jsonCache.has(filename)) return jsonCache.get(filename);
  try {
    const filePath = path.join(DATA_DIR, filename);
    if (!fs.existsSync(filePath)) return [];
    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    if (Array.isArray(data) && data.length > 0) {
      jsonCache.set(filename, data);
      return data;
    }
    return [];
  } catch {
    return [];
  }
}

function getRandomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

const JSON_CATEGORIES = {
  ass: { file: 'ass.json', emoji: '🍑', label: 'Ass Anime' },
  bdsm: { file: 'bdsm.json', emoji: '⛓️', label: 'BDSM Anime' },
  hentai: { file: 'hentai.json', emoji: '🔞', label: 'Hentai' },
  opaianime: { file: 'opaianime.json', emoji: '🍈', label: 'Oppai Anime' }
};

const API_CATEGORIES = {
  blowjob: { endpoint: 'blowjob', emoji: '👄', label: 'Blowjob Anime' },
  neko: { endpoint: 'neko', emoji: '🐱', label: 'Neko NSFW' },
  trap: { endpoint: 'trap', emoji: '🎭', label: 'Trap Anime' },
  waifunsfw: { endpoint: 'waifu', emoji: '💕', label: 'Waifu NSFW' }
};

async function fetchFromApi(endpoint) {
  const res = await axios.get(`https://api.waifu.pics/nsfw/${endpoint}`, { timeout: 15000 });
  if (!res.data?.url) throw new Error('Failed to fetch image URL from API');
  return res.data.url;
}

function buildCategoryList(prefix) {
  let text = `🔞 *NSFW MENU*\n\n`;
  text += `A collection of NSFW anime images across categories.\n`;
  text += `This feature is for users *18 years and older* only.\n\n`;
  text += `*📂 CATEGORIES:*\n\n`;

  text += `*— Local database —*\n`;
  for (const [cmd, info] of Object.entries(JSON_CATEGORIES)) {
    const count = loadJsonUrls(info.file).length;
    text += `- ${info.emoji} *${prefix}${cmd}* — ${info.label} (${count} images)\n`;
  }

  text += `\n*— Online API —*\n`;
  for (const [cmd, info] of Object.entries(API_CATEGORIES)) {
    text += `- ${info.emoji} *${prefix}${cmd}* — ${info.label}\n`;
  }

  text += `\n*⚙️ GROUP SETTINGS:*\n`;
  text += `- *${prefix}nsfwon* — Enable NSFW in this group\n`;
  text += `- *${prefix}nsfwoff* — Disable NSFW in this group\n`;

  text += `\n*📌 NOTE:*\n`;
  text += `- Available directly in bot DMs\n`;
  text += `- In groups, an admin must enable it first with *${prefix}nsfwon*\n`;
  text += `- 18+ only`;

  return text;
}

function isNsfwAllowed(m, ctx) {
  const jid = m.key.remoteJid;
  if (!jid.endsWith('@g.us')) return true;
  return getSessionSetting(ctx.sessionName, `nsfw_${jid}`, false) === true;
}

async function sendNsfwImage(conn, m, ctx, category) {
  await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

  try {
    let url, info;

    if (JSON_CATEGORIES[category]) {
      info = JSON_CATEGORIES[category];
      const urls = loadJsonUrls(info.file);
      if (urls.length === 0) throw new Error('Local image data is empty');
      url = getRandomItem(urls);
    } else if (API_CATEGORIES[category]) {
      info = API_CATEGORIES[category];
      url = await fetchFromApi(info.endpoint);
    } else {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `Category *${category}* not found.`, ctx.sessionName);
    }

    await conn.sendMessage(m.key.remoteJid, {
      image: { url },
      caption: `${info.emoji} *${info.label.toUpperCase()}*\n\n🔞 _18+ only — use responsibly_`
    }, { quoted: m });

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
  } catch (err) {
    console.error('[NSFW] Error:', err.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Couldn't fetch an image for that category — try again.`, ctx.sessionName);
  }
}

async function handleToggle(conn, m, ctx, turnOn) {
  const jid = m.key.remoteJid;

  if (!jid.endsWith('@g.us')) {
    return errorReply(conn, m, `This command is for groups only. NSFW is always available in DMs.`, ctx.sessionName);
  }
  if (!requireAdmin(ctx, conn, m)) return;

  setSessionSetting(ctx.sessionName, `nsfw_${jid}`, turnOn);

  return fReply(conn, m,
    turnOn
      ? `✅ *NSFW ENABLED*\n\nNSFW commands are now usable in this group.\nMake sure everyone here is 18+. Use *${ctx.prefix}nsfwoff* to turn it back off.`
      : `✅ *NSFW DISABLED*\n\nNSFW commands are now blocked in this group.`,
    ctx.sessionName
  );
}

const commands = {};
for (const cmd of Object.keys(JSON_CATEGORIES)) {
  commands[cmd] = { category: 'nsfw', handler: (conn, m, args, ctx) => routeCategory(conn, m, ctx, cmd) };
}
for (const cmd of Object.keys(API_CATEGORIES)) {
  commands[cmd] = { category: 'nsfw', handler: (conn, m, args, ctx) => routeCategory(conn, m, ctx, cmd) };
}
commands['nsfw'] = { category: 'nsfw', handler: handleMenu };
commands['nsfwmenu'] = { category: 'nsfw', handler: handleMenu };
commands['nsfwon'] = { category: 'nsfw', handler: (conn, m, args, ctx) => handleToggle(conn, m, ctx, true) };
commands['nsfwoff'] = { category: 'nsfw', handler: (conn, m, args, ctx) => handleToggle(conn, m, ctx, false) };

async function routeCategory(conn, m, ctx, category) {
  if (!isNsfwAllowed(m, ctx)) {
    return errorReply(conn, m, `🔒 NSFW isn't enabled in this group.\nAsk an admin to enable it with *${ctx.prefix}nsfwon*, or use this in DMs.`, ctx.sessionName);
  }
  return sendNsfwImage(conn, m, ctx, category);
}

async function handleMenu(conn, m, args, ctx) {
  if (!isNsfwAllowed(m, ctx)) {
    return errorReply(conn, m, `🔒 NSFW isn't enabled in this group.\nAsk an admin to enable it with *${ctx.prefix}nsfwon*, or use this in DMs.`, ctx.sessionName);
  }
  const sub = args[0]?.toLowerCase();
  if (sub && (JSON_CATEGORIES[sub] || API_CATEGORIES[sub])) {
    return sendNsfwImage(conn, m, ctx, sub);
  }
  return fReply(conn, m, buildCategoryList(ctx.prefix), ctx.sessionName);
}

module.exports = {
  name: 'nsfw',
  version: '1.0.0',
  author: 'TOAA',
  commands
};
