// plugins/statusbroadcast.js
const mainCore = require('../main');
const { fReply, errorReply, successReply, getQuotedMsg, getMediaType, downloadMedia } = mainCore;
const { prepareWAMessageMedia, generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const sharp = require('sharp');

const COLOR_MAP = {
  red:    0xffe74c3c,
  blue:   0xff2980b9,
  green:  0xff27ae60,
  purple: 0xff8e44ad,
  orange: 0xffe67e22,
  pink:   0xffe91e8c,
  black:  0xff1a1a1a,
  teal:   0xff16a085,
  gold:   0xfff39c12,
  dark:   0xff1a2a3a,
  navy:   0xff2c3e50,
  brown:  0xff6d4c41,
};
const ALL_COLORS = Object.values(COLOR_MAP);

function getColor(colorName) {
  if (!colorName) return ALL_COLORS[Math.floor(Math.random() * ALL_COLORS.length)];
  return COLOR_MAP[colorName.toLowerCase()] || ALL_COLORS[Math.floor(Math.random() * ALL_COLORS.length)];
}

function withUrlPreview(ext, msgText) {
  const urlMatch = msgText.match(/(https?:\/\/[^\s]+)/);
  if (urlMatch) {
    ext.matchedText = urlMatch[0];
    ext.canonicalUrl = urlMatch[0];
    ext.title = 'Link Preview';
    ext.previewType = 1;
  }
  return ext;
}

async function handler(conn, m, args, ctx) {
  const { sessionName, prefix, isOwner } = ctx;
  const isSudo = global.sudoUsers && global.sudoUsers.has(ctx.senderNumber);

  if (!isOwner && !isSudo) return errorReply(conn, m, 'Owner only!', sessionName);

  const quotedMsg = getQuotedMsg(m);
  const text = args.join(' ').trim();

  if (!quotedMsg && !text) {
    return errorReply(conn, m,
      `Usage:\n\n` +
      `Text: ${prefix}statusbroadcast <text> [color]\n` +
      `Example: ${prefix}statusbroadcast Hello everyone! green\n\n` +
      `Reply: Reply to any image/video/audio/sticker/document/text with ${prefix}statusbroadcast\n\n` +
      `Colors: red, blue, green, purple, orange, pink, black, teal, gold, dark, navy, brown\n\n` +
      `Posts to the status of every group the bot's owner is in — works from any chat.`,
      sessionName
    );
  }

  try {
    // Pull a trailing color keyword off the text args, if present.
    const colorKeywords = Object.keys(COLOR_MAP);
    let statusText = text;
    let chosenColorName = null;
    if (text) {
      const lastWord = args[args.length - 1]?.toLowerCase();
      if (colorKeywords.includes(lastWord)) {
        chosenColorName = lastWord;
        statusText = args.slice(0, -1).join(' ');
      }
    }

    // Build the status content ONCE — same content gets relayed to every group.
    // IMPORTANT: content must be the full { groupStatusMessageV2: { message: {...} } }
    // shape at build time — that's what makes this post to the group's status
    // feed instead of sending a normal chat message.
    let content;
    let mediaBuffer, mediaType, mediaCaption, mediaMime;

    if (quotedMsg) {
      const t = getMediaType(quotedMsg);
      const quotedText = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text;

      if (t?.type === 'image') {
        mediaBuffer = await downloadMedia(t.inner, 'image');
        mediaType = 'image';
        mediaCaption = statusText || t.inner.caption || '';

      } else if (t?.type === 'video') {
        mediaBuffer = await downloadMedia(t.inner, 'video');
        mediaType = 'video';
        mediaCaption = statusText || t.inner.caption || '';

      } else if (t?.type === 'audio') {
        mediaBuffer = await downloadMedia(t.inner, 'audio');
        mediaType = 'audio';
        mediaMime = 'audio/mpeg';

      } else if (t?.type === 'sticker') {
        const rawBuffer = await downloadMedia(t.inner, 'sticker');
        mediaBuffer = await sharp(rawBuffer).png().toBuffer();
        mediaType = 'image';

      } else if (t?.type === 'document') {
        const docCaption = statusText || t.inner.fileName || 'Document';
        const ext = withUrlPreview({ text: '📄 ' + docCaption, backgroundArgb: getColor(chosenColorName), font: 0 }, docCaption);
        content = { groupStatusMessageV2: { message: { extendedTextMessage: ext } } };

      } else if (quotedText) {
        const msgText = statusText || quotedText;
        const ext = withUrlPreview({ text: msgText, backgroundArgb: getColor(chosenColorName), font: 0 }, msgText);
        content = { groupStatusMessageV2: { message: { extendedTextMessage: ext } } };

      } else {
        return errorReply(conn, m, 'Unsupported message type!\nSupported: image, video, audio, sticker, document, text', sessionName);
      }

    } else if (statusText) {
      const ext = withUrlPreview({ text: statusText, backgroundArgb: getColor(chosenColorName), font: 0 }, statusText);
      content = { groupStatusMessageV2: { message: { extendedTextMessage: ext } } };
    }

    if (!content && !mediaBuffer) return errorReply(conn, m, 'No content to post.', sessionName);

    await fReply(conn, m, 'Broadcasting status to all groups...', sessionName);

    const groups = await conn.groupFetchAllParticipating();
    const groupIds = Object.keys(groups);

    if (groupIds.length === 0) {
      return errorReply(conn, m, 'Bot owner isn\'t in any groups!', sessionName);
    }

    let posted = 0;
    for (const groupId of groupIds) {
      try {
        let groupContent = content;

        // Media has to be re-prepared per group — prepareWAMessageMedia's
        // upload is tied to a single relay, it can't be reused across
        // multiple groupFetchAllParticipating targets.
        if (mediaBuffer) {
          const mediaMsg = mediaType === 'image'
            ? { image: mediaBuffer, caption: mediaCaption || '' }
            : mediaType === 'video'
            ? { video: mediaBuffer, caption: mediaCaption || '' }
            : { audio: mediaBuffer, mimetype: mediaMime };
          const prepared = await prepareWAMessageMedia(mediaMsg, { upload: conn.waUploadToServer });
          groupContent = { groupStatusMessageV2: { message: prepared } };
        }

        const statusMsg = generateWAMessageFromContent(groupId, groupContent, { userJid: conn.user.id });
        await conn.relayMessage(groupId, statusMsg.message, { messageId: statusMsg.key.id });
        posted++;
      } catch (e) {
        console.error(`[STATUSBROADCAST] Failed for group ${groupId}:`, e.message);
      }
      await new Promise(r => setTimeout(r, 1000));
    }

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
    await successReply(conn, m, `Status posted to ${posted}/${groupIds.length} group(s).${chosenColorName ? `\nColor: ${chosenColorName}` : ''}`, sessionName);

  } catch (error) {
    console.error('[STATUSBROADCAST] Error:', error);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Failed: ${error.message}`, sessionName);
  }
}

module.exports = {
  name: 'Status Broadcast',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'broadcast': { category: 'owner', handler }
  }
};