// Auto-converted from legacy registerCmd('botprotect', ...) in main.js
// Category: group
const {
  fReply,
  getGroupSettings,
  requireAdmin,
  updateGroupSettings
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'botprotect',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'botprotect': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

    if (!requireAdmin(ctx, conn, m)) return;
    if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ Groups Only_*', ctx.sessionName);
    const option = (args[0] || '').toLowerCase();
    const remoteJid = m.key.remoteJid;
    const gs = getGroupSettings(remoteJid);
    if (option === 'on') {
        gs.botprotect.active = true; gs.antidemote.active = true;
        updateGroupSettings(remoteJid, { botprotect: { active: true }, antidemote: { active: true } });
        await fReply(conn, m, '*_💈 BOT SELF-PROTECTION ACTIVATED_*', ctx.sessionName);
    } else if (option === 'off') {
        gs.botprotect.active = false;
        updateGroupSettings(remoteJid, { botprotect: { active: false } });
        await fReply(conn, m, '*_۞ BOT SELF-PROTECTION DEACTIVATED_*', ctx.sessionName);
    } else {
        await fReply(conn, m, `*_💈 STATUS:_* ${gs.botprotect.active ? '🟢 ACTIVE' : '🔴 INACTIVE'}\n\nUsage: ${ctx.prefix}botprotect on/off`, ctx.sessionName);
    }

      }
    }
  }
};
