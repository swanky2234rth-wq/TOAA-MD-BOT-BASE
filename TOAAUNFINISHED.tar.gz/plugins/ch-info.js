// ─── Ch-info — full WhatsApp channel information ──────────────────────────
// Accepts a channel link (https://whatsapp.com/channel/xxxxx) as an arg, or
// runs with no args when used inside the channel itself.
//
// IMPORTANT: newsletterMetadata()'s real return shape (confirmed against
// Baileys' own source, src/Socket/newsletter.ts) is FLAT — there is no
// nested "picture.url", no "state"/"active" field, and the subscriber count
// is a plain number at `subscribers`, not `subscribers.toLocaleString` on a
// nested object or `subscribers_count`. `verification` is a raw string from
// WhatsApp's backend (commonly "VERIFIED" or "UNVERIFIED"), not a boolean.
// A prior version of this plugin used wrong field names for everything but
// id/name, which is why most fields showed "Unknown" — this version reads
// the real fields: id, name, description, creation_time (unix seconds),
// invite, subscribers, verification, picture ({ id, directPath } | undef),
// mute_state, owner (usually undefined on a metadata fetch, only populated
// on creation).

const { fReply } = require('../main');

module.exports = {
  name: 'ch-info',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'ch-info': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const from = m.key.remoteJid;
        const text = args.join(' ').trim();

        let type, key;

        if (text && text.includes('https://whatsapp.com/channel/')) {
          type = 'invite';
          key = text.split('https://whatsapp.com/channel/')[1].split('/')[0].split('?')[0];
        } else if (from.endsWith('@newsletter')) {
          type = 'jid';
          key = from;
        } else {
          return fReply(conn, m,
            `📌 *Usage:* ${prefix}ch-info <channel_link>\n\nExample: ${prefix}ch-info https://whatsapp.com/channel/xxxxx\n\nOr use this command from inside the channel itself.`,
            sessionName
          );
        }

        try {
          const meta = await conn.newsletterMetadata(type, key);

          if (!meta || !meta.id) {
            return fReply(conn, m, '🎴 *Failed to fetch channel information!* Check the link is correct.', sessionName);
          }

          const verified = /verified/i.test(meta.verification || '') ? '✅ Yes' : '❌ No';
          const created = meta.creation_time
            ? new Date(meta.creation_time * 1000).toLocaleDateString()
            : 'Unknown';
          const subscribers = typeof meta.subscribers === 'number'
            ? meta.subscribers.toLocaleString()
            : 'Unknown';

          const infoText =
            `📢 *WHATSAPP CHANNEL INFO*\n\n` +
            `📛 *Name:* ${meta.name || 'Unknown'}\n` +
            `🆔 *ID:* ${meta.id}\n` +
            `📝 *Description:* ${meta.description || 'None'}\n` +
            `👥 *Subscribers:* ${subscribers}\n` +
            `✅ *Verified:* ${verified}\n` +
            `📅 *Created:* ${created}\n` +
            (meta.invite ? `🔗 *Invite Code:* ${meta.invite}\n` : '');

          await fReply(conn, m, infoText, sessionName);

        } catch (e) {
          console.error('[CH-INFO] Error:', e);
          await fReply(conn, m, `🎴 *Failed to get channel info:* ${e.message}`, sessionName);
        }
      }
    }
  }
};
