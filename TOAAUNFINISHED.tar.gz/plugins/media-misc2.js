const mainCore = require('../main');
const { errorReply, fReply, getQuotedMsg, getMediaType, downloadMedia } = mainCore;
const sharp = require('sharp');

module.exports = {
  name: 'Media Batch 2',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'tojpg': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'image') return errorReply(conn, m, "Reply to an image", ctx.sessionName);
        await fReply(conn, m, 'Converting to JPG...', ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'image');
          const jpg = await sharp(buf).jpeg({ quality: 90 }).toBuffer();
          await conn.sendMessage(m.key.remoteJid, { image: jpg, caption: '🖼️ Converted to JPG!' }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'topng': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'image') return errorReply(conn, m, "Reply to an image", ctx.sessionName);
        await fReply(conn, m, 'Converting to PNG...', ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'image');
          const png = await sharp(buf).png().toBuffer();
          await conn.sendMessage(m.key.remoteJid, { image: png, caption: '🖼️ Converted to PNG!' }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'compress': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'image') return errorReply(conn, m, "Reply to an image", ctx.sessionName);
        const quality = parseInt(args[0]) || 50;
        if (quality < 10 || quality > 90) return errorReply(conn, m, "Quality must be 10-90", ctx.sessionName);
        await fReply(conn, m, `Compressing image (${quality}%)...`, ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'image');
          const compressed = await sharp(buf).jpeg({ quality }).toBuffer();
          const originalSize = (buf.length / 1024).toFixed(1);
          const newSize = (compressed.length / 1024).toFixed(1);
          await conn.sendMessage(m.key.remoteJid, {
            image: compressed,
            caption: `📦 Compressed!\nOriginal: ${originalSize}KB\nNew: ${newSize}KB (${quality}% quality)`
          }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'memegen': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'image') return errorReply(conn, m, "Reply to an image", ctx.sessionName);
        const text = args.join(' ');
        if (!text) return errorReply(conn, m, `Usage: ${ctx.prefix}memegen <top text> | <bottom text>`, ctx.sessionName);
        const parts = text.split('|').map(p => p.trim());
        const topText = parts[0] || '';
        const bottomText = parts[1] || '';
        await fReply(conn, m, 'Generating meme...', ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'image');
          const img = sharp(buf);
          const metadata = await img.metadata();
          const fontSize = Math.floor(metadata.width / 12);
          const svg = `<svg width="${metadata.width}" height="${metadata.height}">
            <style>text { font-family: Impact, Arial; fill: white; stroke: black; stroke-width: 2; font-size: ${fontSize}px; text-anchor: middle; }</style>
            ${topText ? `<text x="50%" y="${fontSize + 20}" dominant-baseline="top">${topText}</text>` : ''}
            ${bottomText ? `<text x="50%" y="${metadata.height - 20}" dominant-baseline="bottom">${bottomText}</text>` : ''}
          </svg>`;
          const result = await img.composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).toBuffer();
          await conn.sendMessage(m.key.remoteJid, { image: result, caption: '😂 Meme created!' }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    }
  }
};
