// Auto-converted from legacy registerCmd('setalive', ...) in main.js
// Category: owner
const {
  fReply,
  getCurrentAliveConfig,
  newsletterReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setalive',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setalive': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

    if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
    const text = args.join(' ').trim();
    if (!text) {
        const cur = await getCurrentAliveConfig(ctx.sessionName);
        return fReply(conn, m,
            `*𝗔𝗟𝗜𝗩𝗘 𝗦𝗘𝗧𝗨𝗣:*\n\n${ctx.prefix}setalive name|quote|imageurl\n\n*Current:*\nName: ${cur.name}\nQuote: ${cur.quote}`,
            ctx.sessionName
        );
    }
    const [name, quote, imageUrl] = text.split('|');
    const config = {
        name: name?.trim() || 'TOAA',
        quote: quote?.trim() || '𝙴𝚟𝚎𝚛𝚢𝚘𝚗𝚎 𝚒𝚜 𝚊 𝚜𝚕𝚊𝚟𝚎 𝚝𝚘 𝚜𝚘𝚖𝚎𝚝𝚑𝚒𝚗𝚐',
        imageUrl: imageUrl?.trim() || 'https://i.ibb.co/60pgqPj9/photo-2026-04-29-00-18-01-7633969691903393816.jpg'
    };
    const configFile = './database/alive_config.json';
    let configs = {};
    if (fs.existsSync(configFile)) configs = JSON.parse(fs.readFileSync(configFile, 'utf-8'));
    configs[ctx.sessionName] = config;
    fs.writeFileSync(configFile, JSON.stringify(configs, null, 2));
    await fReply(conn, m,
        `✦ *Alive config saved!*\n\n≡ {${config.name}}\n${config.quote}\n✨ Updated!`,
        ctx.sessionName
    );

      }
    }
  }
};
