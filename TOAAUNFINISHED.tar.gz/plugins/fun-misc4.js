const mainCore = require('../main');
const { errorReply, successReply } = mainCore;
const axios = require('axios');

module.exports = {
  name: 'Fun Batch 4',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'fact': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        try {
          const { data } = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en');
          await successReply(conn, m, `🧠 ${data.text}`, ctx.sessionName);
        } catch {
          const facts = [
            "Octopuses have three hearts.", "A day on Venus is longer than a year on Venus.",
            "The shortest war in history lasted 38 minutes.", "Bananas are berries, but strawberries are not.",
            "Honey never spoils.", "The average cloud weighs about 1.1 million pounds."
          ];
          await successReply(conn, m, `🧠 ${facts[Math.floor(Math.random() * facts.length)]}`, ctx.sessionName);
        }
      }
    },

    'showerthought': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const thoughts = [
          "The word 'bed' looks like a bed.", "You're always in the middle of your own timeline.",
          "Every breath you take is a gift from the trees.", "Your future self is watching you right now.",
          "The person you are now is the result of every decision you've ever made.", "You are the universe experiencing itself."
        ];
        await successReply(conn, m, `🚿 ${thoughts[Math.floor(Math.random() * thoughts.length)]}`, ctx.sessionName);
      }
    }
  }
};
