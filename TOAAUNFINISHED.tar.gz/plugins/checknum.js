// Auto-converted from legacy registerCmd('checknum', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'checknum',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'checknum': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

    const { sessionName, prefix } = ctx;
    const number = args[0]?.replace(/[^0-9]/g, '');
    
    if (!number) {
        return fReply(conn, m,
            `🀄 *Check WhatsApp User*\n\n` +
            `📌 *Usage:* ${prefix}checknum <number>\n` +
            `💡 *Example:* ${prefix}checknum 234757𝘹𝘹𝘹𝘹𝘹`,
            sessionName
        );
    }
    
    await fReply(conn, m, `*_🔍 Checking +${number}..._*`, sessionName);
    
    try {
        const jid = `${number}@s.whatsapp.net`;
        
        // Try to get user's profile name
        let userName = null;
        let ppUrl = null;
        
        try {
            // Get profile picture URL (throws error if user doesn't exist or is banned)
            ppUrl = await conn.profilePictureUrl(jid, 'image');
        } catch (err) {
            // Error means user doesn't exist or is banned
            if (err.message?.includes('404') || err.message?.includes('not-found')) {
                return fReply(conn, m,
                    `۞ *𝘚𝘛𝘈𝘛𝘜𝘚 𝘜𝘕𝘒𝘕𝘖𝘞𝘕*\n\n` +
                    `۞ *𝘋𝘐𝘎𝘐𝘛𝘚:* +${number}\n` +
                    `۞ *𝘚𝘜𝘚𝘗𝘐𝘊𝘐𝘖𝘕:* 𝘕𝘶𝘮𝘣𝘦𝘳 𝘗𝘳𝘰𝘭𝘭𝘺 𝘖𝘯 𝘉𝘢𝘯𝘴.`,
                    sessionName
                );
            }
        }
        
        // Try to get contact name from WhatsApp
        try {
            const contact = await conn.contactQuery(jid);
            if (contact?.name) {
                userName = contact.name;
            }
        } catch (err) {
            // Try alternative method to get name
            try {
                const presence = await conn.presenceSubscribe(jid);
                if (presence?.presences?.[jid]?.name) {
                    userName = presence.presences[jid].name;
                }
            } catch (e) {}
        }
        
        // If we got here, user exists on WhatsApp
        const statusEmoji = ppUrl ? '🟢' : '⚪';
        
        await conn.sendMessage(m.key.remoteJid, {
            text: `✰ *𝘚𝘛𝘈𝘛𝘜𝘚:* 𝘕𝘶𝘮𝘣𝘦𝘳 𝘪𝘴 𝘳𝘦𝘨𝘪𝘴𝘵𝘦𝘳𝘦𝘥 𝘢𝘯𝘥 𝘢𝘤𝘵𝘪𝘷𝘦 𝘰𝘯 𝘸𝘩𝘢𝘵𝘴𝘢𝘱𝘱 \n\n` +
                  `✰ *𝘋𝘐𝘎𝘐𝘛𝘚:* +${number}\n` +
                  `✰ *𝘕𝘈𝘔𝘌:* ${userName || 'Unknown'}\n` +
                  `${statusEmoji} *Status:* Active ${ppUrl ? '(Has profile picture)' : '(No profile picture)'}\n\n` +
                  `🔍 *𝘕𝘰𝘵𝘦:* This number is a valid WhatsApp user.`,
            mentions: [jid]
        }, { quoted: m });
        
        await conn.sendMessage(m.key.remoteJid, { react: { text: '🧩', key: m.key } });
        
    } catch (err) {
        console.error('[CHECKNUM] Error:', err);
        await conn.sendMessage(m.key.remoteJid, { react: { text: '🎴', key: m.key } });
        
        await fReply(conn, m,
            `۞ *𝘚𝘛𝘈𝘛𝘜𝘚 𝘜𝘕𝘒𝘕𝘖𝘞𝘕*\n\n` +
            `۞ *𝘋𝘐𝘎𝘐𝘛𝘚:* +${number}\n` +
            `۞ *𝘚𝘜𝘚𝘗𝘐𝘊𝘐𝘖𝘕:* 𝘕𝘶𝘮𝘣𝘦𝘳 𝘗𝘳𝘰𝘭𝘭𝘺 𝘖𝘯 𝘉𝘢𝘯𝘴.`,
            sessionName
        );
    }

      }
    }
  }
};
