// ─── Ch-id — just the channel's name and ID ────────────────────────────────
// Simpler counterpart to ch-info: only shows name + id, nothing else.
// Same link/JID resolution as ch-info.

const { fReply } = require('../main');

module.exports = {
  name: 'ch-id',
  version: '2.0.0',
  author: 'TOAA',
  commands: {
    'ch-id': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const from = m.key.remoteJid;
        const text = args.join(' ').trim();

        let type, key;

        if (text && text.includes('https://whatsapp.com/channel/')) {
          type = 'invite';
          key = text.split('https://whatsapp.com/channel/')[1].split('/')[0].split('?')[0];
        } else if (from.endsWith('@newsletter')) {
          type = 'jid';
          key = from;
        } else {
          return fReply(conn, m,
            `📌 *Usage:* ${prefix}ch-id <channel_link>\n\nExample: ${prefix}ch-id https://whatsapp.com/channel/xxxxx\n\nOr use this command from inside the channel itself.`,
            sessionName
          );
        }

        try {
          const meta = await conn.newsletterMetadata(type, key);

          if (!meta || !meta.id) {
            return fReply(conn, m, '🎴 *Failed to fetch channel information!* Check the link is correct.', sessionName);
          }

          await fReply(conn, m,
            `┏━━━「ＣＨ-ＩＤ」━━━\n` +
            `┃ 📡 *Channel:* ${meta.name || 'Unknown'}\n` +
            `┃ 🆔 *ID:*\n` +
            `┃ \`${meta.id}\`\n` +
            `┗━━━━━━━━━━━━━━━━`,
            sessionName
          );

        } catch (e) {
          console.error('[CH-ID] Error:', e);
          await fReply(conn, m, `🎴 *Failed to get channel info:* ${e.message}`, sessionName);
        }
      }
    }
  }
};
