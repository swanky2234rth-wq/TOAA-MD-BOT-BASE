// Auto-converted from legacy registerCmd('dict', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'dict',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'dict': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx; const word = args[0]?.trim();
  if (!word) return fReply(conn, m, `Usage: ${prefix}dict <word>`, sessionName);
  try {
    const { data } = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
    const entry = data[0]; const meaning = entry.meanings[0]; const def = meaning.definitions[0];
    await fReply(conn, m, `📖 *${entry.word}*\n🔤 ${meaning.partOfSpeech}\n\n📝 ${def.definition}${def.example ? `\n\n💬 Example: ${def.example}` : ''}`, sessionName);
  } catch { await fReply(conn, m, `*_۞ Word not found: ${word}_*`, sessionName); }

      }
    }
  }
};
