// ─── TOAA Auto Forward (toggle) ─────────
// NOTE: Toggle only. The actual "forward every message in this chat to
// another target" logic needs a hook in main.js's handleMessage that reads
// this setting and calls conn.sendMessage with a forwarded copy — not
// included here, same caveat as autodl.js/notifclosegroup.js.
const { errorReply, successReply, requireAdmin } = require('../main');
const { getGroup, setGroup } = require('../helper/groupProtectionStore');

module.exports = {
  name: 'autoforward',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'autoforward': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!requireAdmin(ctx, conn, m)) return;

        const arg = args[0]?.toLowerCase();
        const current = getGroup(remoteJid).autoforward || false;

        if (!['on', 'off'].includes(arg)) {
          return errorReply(conn, m,
            `↪️ *Auto Forward*\n\nStatus: ${current ? '✅ On' : '❌ Off'}\n\nUsage:\n${prefix}autoforward on\n${prefix}autoforward off`,
            sessionName
          );
        }

        setGroup(remoteJid, { autoforward: arg === 'on' });
        return successReply(conn, m, `Auto forward ${arg === 'on' ? 'enabled' : 'disabled'}.`, sessionName);
      }
    }
  }
};
