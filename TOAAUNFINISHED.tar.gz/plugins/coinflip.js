// ─── TOAA RPG Coinflip ─────────
const { errorReply } = require('../main');
const { isRpgAllowed } = require('../helper/rpg');
const { getCoin, addCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { getSessionSetting } = require('../helper/function');

const MIN_BET = 1000;

module.exports = {
  name: 'coinflip',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'coinflip': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const choiceRaw = args[0]?.toLowerCase();
  const bet = parseInt(args[1]);

  const valid = ['heads', 'tails', 'h', 't'];
  if (!choiceRaw || !valid.includes(choiceRaw)) {
    return errorReply(conn, m,
      `🪙 *DEALER'S COIN GUESS* 🪙\n\nCall heads or tails!\n\n*How to play:*\n👉 \`${prefix}coinflip heads <bet>\`\n👉 \`${prefix}coinflip tails <bet>\``,
      sessionName
    );
  }

  const balance = getCoin(jid);
  if (!bet || bet < MIN_BET) {
    return errorReply(conn, m, `Pocket change bets don't fly here! Minimum *${fmtCoin(MIN_BET)}*! 🪙`, sessionName);
  }
  if (balance < bet) {
    return errorReply(conn, m, `Where's your coin? Pocket's only got *${fmtCoin(balance)}*, but you're betting *${fmtCoin(bet)}*! 😜`, sessionName);
  }

  removeCoin(jid, bet);

  const userChoice = (choiceRaw === 'heads' || choiceRaw === 'h') ? 'heads' : 'tails';
  const result = Math.random() < 0.5 ? 'heads' : 'tails';
  const emoji = result === 'heads' ? '🦅' : '🪙';

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🪙', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `*CLING!* Gold coin flipped high into the air, spinning... 🪙✨` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const isWin = userChoice === result;

  let txt = `*SLAP!* The dealer covers the coin! 👋\n\nYour call: *${userChoice.toUpperCase()}*\nCoin shows: *${result.toUpperCase()}* ${emoji}\n\n`;

  if (isWin) {
    const winnings = bet * 2;
    addCoin(jid, winnings);
    txt += `🎉 *NICE CALL, YOU GOT IT!*\n💰 Winnings: *+${fmtCoin(winnings)}*`;
  } else {
    txt += `🤣 *WRONG GUESS!*\n💸 Dealer takes: *-${fmtCoin(bet)}*`;
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: isWin ? '🎉' : '💸', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
}
