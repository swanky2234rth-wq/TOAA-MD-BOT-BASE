// Auto-converted from legacy registerCmd('promote', ...) in main.js
// Category: group
const {
  resolveTarget, unauthorizedReply, botAdminRequiredReply, errorReply, resolveDisplayJid
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'promote',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'promote': {
      category: 'group',
      handler: async (nuell, hex, args, ctx) => {

  if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(nuell, hex, ctx.sessionName);
  if (!ctx.botAdmin) return botAdminRequiredReply(nuell, hex, ctx.sessionName);
  
  const remoteJid = hex.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return errorReply(nuell, hex, "Groups Only", ctx.sessionName);
  
  const targetJid = resolveTarget(hex, args);
  if (!targetJid) {
    return errorReply(nuell, hex, `Usage: ${ctx.prefix}promote @user or reply to their message`, ctx.sessionName);
  }
  
  const rawTargetJid = targetJid.includes('@') ? targetJid : `${targetJid.replace(/[^0-9]/g, '')}@s.whatsapp.net`;

  // Resolve LID-format jids to a real phone-number jid where possible, so
  // the reply mentions/shows an actual WhatsApp number instead of a LID.
  const meta = await nuell.groupMetadata(remoteJid).catch(() => null);
  const cleanJid = resolveDisplayJid(rawTargetJid, meta?.participants);
  const targetNum = cleanJid.split('@')[0];
  
  if (targetNum === ctx.botNumber) {
    return errorReply(nuell, hex, "I can't promote myself!", ctx.sessionName);
  }
  
  await nuell.groupParticipantsUpdate(remoteJid, [rawTargetJid], 'promote');
  await nuell.sendMessage(remoteJid, {
    text: `🀄 @${targetNum} promoted to admin!`,
    mentions: [cleanJid]
  }, { quoted: hex });

      }
    }
  }
};
