// plugins/ig.js
const axios = require('axios');
const { getSessionSetting } = require('../helper/function');
const { applyFont } = require('../helper/fonts');

async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function errorReply(conn, m, text, sessionName) { await fReply(conn, m, `❌ ${text}`, sessionName); }

async function fetchJson(url) {
  const response = await axios.get(url);
  return response.data;
}

module.exports = {
  name: 'Instagram Downloader',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    'instagram': {
      category: 'downloader',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const text = args.join(' ').trim();

        if (!text)
          return fReply(nuell, hex, `📸 *Instagram Downloader*\n\nUsage: ${prefix}instagram <instagram_url>\nAliases: ${prefix}igdl, ${prefix}ig`, sessionName);
        if (!text.startsWith('https://'))
          return errorReply(nuell, hex, 'Invalid URL! Please provide a valid Instagram link.', sessionName);

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '🕖', key: hex.key } });

        const tryApis = [
          async () => {
            const res = await fetchJson(`https://api.resellergaming.my.id/download/instagram?url=${encodeURIComponent(text)}`);
            const url = res?.result?.[0]?.url_download;
            if (!url) return null;
            return { type: 'video', url, caption: `📸 *Instagram*\n📺 ${res.result[0]?.kualitas || 'Video'}` };
          },
          async () => {
            const res = await fetchJson(`https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(text)}`);
            if (!res.status || !res.data?.length) return null;
            const media = res.data[0];
            return { type: media.type === 'video' ? 'video' : 'image', url: media.url, caption: `📸 Instagram ${media.type === 'video' ? 'Video' : 'Photo'}` };
          }
        ];

        for (const api of tryApis) {
          try {
            const result = await api();
            if (!result) continue;
            if (result.type === 'video') {
              await nuell.sendMessage(hex.key.remoteJid, { video: { url: result.url }, mimetype: 'video/mp4', caption: result.caption }, { quoted: hex });
            } else {
              await nuell.sendMessage(hex.key.remoteJid, { image: { url: result.url }, caption: result.caption }, { quoted: hex });
            }
            await nuell.sendMessage(hex.key.remoteJid, { react: { text: '✅', key: hex.key } });
            return;
          } catch (e) {
            console.log('[IG] API failed:', e.message);
          }
        }

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '❌', key: hex.key } });
        await errorReply(nuell, hex, 'No media found. Try a different link.', sessionName);
      }
    },

    'igdl': {
      category: 'downloader',
      handler: async (nuell, hex, args, ctx) => { await module.exports.commands.instagram.handler(nuell, hex, args, ctx); }
    },
    'ig': {
      category: 'downloader',
      handler: async (nuell, hex, args, ctx) => { await module.exports.commands.instagram.handler(nuell, hex, args, ctx); }
    }
  }
};
