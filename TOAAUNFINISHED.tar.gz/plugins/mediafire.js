// plugins/mediafire.js
const axios = require('axios');
const cheerio = require('cheerio');
const { getSessionSetting } = require('../helper/function');
const { applyFont } = require('../helper/fonts');

async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function errorReply(conn, m, text, sessionName) { await fReply(conn, m, `❌ ${text}`, sessionName); }

async function mediafire(url) {
  const response = await axios.get(url);
  const $ = cheerio.load(response.data);
  const link = $('a#downloadButton').attr('href') ||
    $('.download_link a').attr('href') ||
    $('a[aria-label="Download file"]').attr('href');
  const title = $('.download_filename').text().trim() || $('.filename').text().trim() || 'Unknown';
  const mime = title.split('.').pop() || 'bin';
  if (!link) throw new Error('Download link not found');
  return { link, judul: title, mime };
}

module.exports = {
  name: 'MediaFire Downloader',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    'mediafire': {
      category: 'downloader',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const text = args.join(' ').trim();

        if (!text)
          return fReply(nuell, hex, `📌 *MediaFire Downloader*\n\nUsage: ${prefix}mediafire <mediafire_url>`, sessionName);
        if (!text.includes('mediafire.com'))
          return errorReply(nuell, hex, 'Invalid link! Please provide a valid MediaFire link.', sessionName);

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '⏳', key: hex.key } });

        try {
          const result = await mediafire(text);
          await nuell.sendMessage(hex.key.remoteJid, {
            document: { url: result.link },
            fileName: result.judul,
            mimetype: `application/${result.mime.toLowerCase()}`
          }, { quoted: hex });
          await nuell.sendMessage(hex.key.remoteJid, { react: { text: '✅', key: hex.key } });
        } catch (error) {
          console.error('[MEDIAFIRE] Error:', error.message);
          await nuell.sendMessage(hex.key.remoteJid, { react: { text: '❌', key: hex.key } });
          await errorReply(nuell, hex, `Error: ${error.message}`, sessionName);
        }
      }
    }
  }
};
