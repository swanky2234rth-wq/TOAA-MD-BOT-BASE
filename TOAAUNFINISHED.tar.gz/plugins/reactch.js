// plugins/reactch.js
const { getSessionSetting } = require('../helper/function');
const { applyFont } = require('../helper/fonts');

async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function errorReply(conn, m, text, sessionName) { await fReply(conn, m, `❌ ${text}`, sessionName); }
async function successReply(conn, m, text, sessionName) { await fReply(conn, m, `✅ ${text}`, sessionName); }
async function unauthorizedReply(conn, m, sessionName) { await fReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', sessionName); }

module.exports = {
  name: 'Channel React',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    'reactch': {
      category: 'owner',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, prefix, isOwner } = ctx;
        if (!isOwner) return unauthorizedReply(nuell, hex, sessionName);

        const text = args.join(' ').trim();

        if (!text) {
          return fReply(nuell, hex,
            `📌 *Channel React*\n\nUsage: ${prefix}reactch <channel_link> <emoji/reaction>\n\nExample:\n${prefix}reactch https://whatsapp.com/channel/0029Va7s2asHltYIdOQ6yo0M 😂`,
            sessionName
          );
        }

        const parts = text.split(' ');
        if (parts.length < 2)
          return errorReply(nuell, hex, `Invalid format! Usage: ${prefix}reactch <channel_link> <reaction>`, sessionName);

        const link = parts[0];
        const reaction = parts.slice(1).join(' ');

        if (!link.includes('https://whatsapp.com/channel/'))
          return errorReply(nuell, hex, 'Invalid channel link! Example: https://whatsapp.com/channel/0029Va7s2asHltYIdOQ6yo0M', sessionName);

        try {
          const pathParts = link.split('/');
          const channelCode = pathParts[4];
          const serverId = pathParts[5];

          if (!channelCode || !serverId)
            return errorReply(nuell, hex, 'Invalid channel link format! Should be: https://whatsapp.com/channel/XXXXXXXX/YYYYY', sessionName);

          await fReply(nuell, hex, `🔄 *Fetching channel info...*`, sessionName);

          const channelInfo = await nuell.newsletterMetadata('invite', channelCode);
          if (!channelInfo)
            return errorReply(nuell, hex, 'Channel not found! Make sure the link is valid.', sessionName);

          await nuell.newsletterReactMessage(channelInfo.id, serverId, reaction);
          await nuell.sendMessage(hex.key.remoteJid, { react: { text: '✅', key: hex.key } });

          await successReply(nuell, hex, `Reaction sent!\n\n📢 Channel: ${channelInfo.name || 'Unknown'}\n🔖 Reaction: ${reaction}`, sessionName);

        } catch (error) {
          console.error('[REACTCH] Error:', error.message);
          await nuell.sendMessage(hex.key.remoteJid, { react: { text: '❌', key: hex.key } });

          try {
            const pathParts = link.split('/');
            const channelCode = pathParts[4];
            if (channelCode) {
              const channelInfo = await nuell.newsletterMetadata('invite', channelCode);
              if (channelInfo?.id) {
                await nuell.newsletterReactMessage(channelInfo.id, 'latest', reaction);
                await successReply(nuell, hex, `Reaction sent to latest post!\n\n📢 Channel: ${channelInfo.name || 'Unknown'}\n🔖 Reaction: ${reaction}`, sessionName);
                return;
              }
            }
          } catch (fbErr) {
            console.log('[REACTCH] Fallback failed:', fbErr.message);
          }

          await errorReply(nuell, hex, `Failed to send reaction: ${error.message}`, sessionName);
        }
      }
    },

    'rch': {
      category: 'owner',
      handler: async (nuell, hex, args, ctx) => { await module.exports.commands.reactch.handler(nuell, hex, args, ctx); }
    }
  }
};
