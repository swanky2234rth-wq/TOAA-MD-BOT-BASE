// Auto-converted from legacy registerCmd('say', ...) in main.js
// Category: utilities
const {
  fReply,
  getMsgText,
  getQuotedMsg
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'say',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'say': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

    const { sessionName, prefix } = ctx;
    const text = args.join(' ').trim();
    let ttsText = text;
    if (!ttsText) {
        const quotedMsg = getQuotedMsg(m);
        if (quotedMsg) ttsText = getMsgText({ message: quotedMsg });
    }
    if (!ttsText) return fReply(conn, m, `📢 *Text to Speech*\n\nUsage: ${prefix}say <text>\n\n_Or reply to a message with ${prefix}say_`, sessionName);
    if (ttsText.length > 200) return fReply(conn, m, '🎴 *Text too long!*\n\nMaximum 200 characters allowed.', sessionName);
    await fReply(conn, m, '*_💈 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚒𝚗𝚐 𝚂𝚙𝚎𝚎𝚌𝚑..._*', sessionName);
    try {
        const gttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(ttsText)}&tl=en&client=tw-ob`;
        const ttsRes = await axios.get(gttsUrl, { responseType: 'arraybuffer', headers: { 'User-Agent': 'Mozilla/5.0' } });
        await conn.sendMessage(m.key.remoteJid, { audio: Buffer.from(ttsRes.data), mimetype: 'audio/mpeg', ptt: false, fileName: 'voice.mp3' }, { quoted: m });
    } catch (e) {
        try {
            const fallbackUrl = `https://api.streamelements.com/kappa/v2/speech?voice=Brian&text=${encodeURIComponent(ttsText)}`;
            const fallbackRes = await axios.get(fallbackUrl, { responseType: 'arraybuffer' });
            await conn.sendMessage(m.key.remoteJid, { audio: Buffer.from(fallbackRes.data), mimetype: 'audio/mpeg', ptt: false }, { quoted: m });
        } catch (err) {
            await fReply(conn, m, `🎴 *TTS Failed!*\n\nError: ${e.message}`, sessionName);
        }
    }

      }
    }
  }
};
