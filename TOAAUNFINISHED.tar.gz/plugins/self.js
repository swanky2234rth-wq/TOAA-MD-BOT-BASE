// Auto-converted from legacy registerCmd('self', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'self',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'self': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  setSessionSetting(ctx.sessionName, 'mode', 'self');
  await fReply(conn, m, '*_𝙱𝚘𝚝 𝙸𝚜 𝙽𝚘𝚠 𝚂𝚎𝚕𝚏_*', ctx.sessionName);

      }
    }
  }
};
