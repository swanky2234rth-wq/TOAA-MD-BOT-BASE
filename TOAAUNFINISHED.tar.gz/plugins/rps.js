// Auto-converted from legacy registerCmd('rps', ...) in main.js
// Category: games
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'rps',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'rps': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {

  const choice = (args[0] || '').toLowerCase();
  if (!['rock', 'paper', 'scissors'].includes(choice)) return fReply(conn, m, `Usage: ${ctx.prefix}rps rock/paper/scissors`, ctx.sessionName);
  const options = ['rock', 'paper', 'scissors']; const bot = options[Math.floor(Math.random() * 3)];
  const emoji = { rock: '🪨', paper: '📄', scissors: '✂️' };
  let result = choice === bot ? "It's a *tie!* 🤝" : ((choice==='rock'&&bot==='scissors')||(choice==='paper'&&bot==='rock')||(choice==='scissors'&&bot==='paper')) ? 'You *win!* 🎉' : 'You *lose!* 😔';
  await fReply(conn, m, `✊ *RPS*\n\nYou: ${emoji[choice]} ${choice}\nBot: ${emoji[bot]} ${bot}\n\n${result}`, ctx.sessionName);

      }
    }
  }
};
