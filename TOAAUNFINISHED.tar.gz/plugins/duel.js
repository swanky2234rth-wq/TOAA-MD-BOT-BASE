// ─── TOAA RPG Duel ─────────
const { errorReply, resolveTarget } = require('../main');
const { getUser, addExp, isRpgAllowed } = require('../helper/rpg');
const { getCoin, addCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();
const MIN_BET = 1000;

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'duel',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'duel': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const target = resolveTarget(m, args);
  const bet = parseInt(args[1]) || MIN_BET;

  if (!target) {
    let txt = `⚔️ *WAGER DUEL* ⚔️\n\nChallenge a friend to a duel with coin on the line!\n\n*How to challenge:*\n👉 \`${prefix}duel @user 5000\`\n_(Challenges them to a duel with a ${fmtCoin(5000)} wager)_`;
    return errorReply(conn, m, txt, sessionName);
  }

  if (target === jid) {
    return errorReply(conn, m, `Dueling your own reflection? Tag someone else! 😂`, sessionName);
  }

  if (bet < MIN_BET) {
    return errorReply(conn, m, `Bet's too small! Minimum wager for a duel is *${fmtCoin(MIN_BET)}*.`, sessionName);
  }

  const myBalance = getCoin(jid);
  const theirBalance = getCoin(target);

  if (myBalance < bet) {
    return errorReply(conn, m, `You don't have enough to cover that bet!\nYour coin: *${fmtCoin(myBalance)}*`, sessionName);
  }
  if (theirBalance < bet) {
    return errorReply(conn, m, `Your opponent can't cover that bet. Try a smaller wager or a different target.`, sessionName);
  }

  const user = getUser(jid);
  if (user.health < 30) {
    return errorReply(conn, m, `Whoa, hold on! Your HP's critical (*${user.health} HP*). Need at least *30 HP* to duel. Go heal up first! 💉`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still catching your breath! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  cooldowns.set(jid, Date.now());

  const targetNum = target.split('@')[0];
  await conn.sendMessage(m.key.remoteJid, { react: { text: '⚔️', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, {
    text: `⚔️ *DUEL BEGINS!* ⚔️\n\n@${jid.split('@')[0]} boldly challenges @${targetNum}!\n💰 Total pot on the line: *${fmtCoin(bet * 2)}*`,
    mentions: [jid, target]
  }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 2000));

  const opponent = getUser(target);
  const myPower = user.level * 10 + Math.random() * 50;
  const theirPower = opponent.level * 10 + Math.random() * 50;

  const winner = myPower > theirPower ? jid : target;
  const loser = winner === jid ? target : jid;

  addCoin(winner, bet);
  removeCoin(loser, bet);

  const expGain = 500;
  let levelResult = null;
  if (winner === jid) {
    levelResult = addExp(jid, expGain);
  }

  let txt = `⚔️ *BLOODY DUEL RESULT* ⚔️\n\n`;
  txt += `🏆 *Winner:* @${winner.split('@')[0]}\n`;
  txt += `💀 *Loser:* @${loser.split('@')[0]} (retreats, badly wounded)\n\n`;
  txt += `🎁 *Winner takes home:*\n> 💰 Opponent's wager: *+${fmtCoin(bet)}*\n`;
  txt += winner === jid ? `> ✨ Duel bonus: *+${expGain} EXP*` : ``;

  await conn.sendMessage(m.key.remoteJid, { text: txt, mentions: [jid, target] }, { quoted: m });

  if (levelResult) await notifyLevelUp(conn, m, jid, levelResult);
}
