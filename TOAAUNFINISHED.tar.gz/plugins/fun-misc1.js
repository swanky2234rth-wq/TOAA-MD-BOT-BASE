const mainCore = require('../main');
const { errorReply, successReply } = mainCore;
const axios = require('axios');

module.exports = {
  name: 'Fun Batch 1',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'dadjoke': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        try {
          const { data } = await axios.get('https://icanhazdadjoke.com/', { headers: { 'Accept': 'application/json' } });
          await successReply(conn, m, `👨 ${data.joke}`, ctx.sessionName);
        } catch {
          await errorReply(conn, m, "Couldn't fetch dad joke!", ctx.sessionName);
        }
      }
    },

    'randomword': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const words = ['serendipity', 'ephemeral', 'mellifluous', 'petrichor', 'effervescent', 'sonorous', 'ineffable', 'reverie', 'ethereal', 'sonder', 'nostalgia', 'eloquence', 'luminous', 'resplendent', 'cascade'];
        const word = words[Math.floor(Math.random() * words.length)];
        try {
          const { data } = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
          const def = data[0]?.meanings[0]?.definitions[0]?.definition || 'Beautiful word!';
          await successReply(conn, m, `📚 ${word}\n\n${def}`, ctx.sessionName);
        } catch {
          await successReply(conn, m, `📚 ${word}\n\nA beautiful word to know!`, ctx.sessionName);
        }
      }
    },

    'randomcolor': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const randomHex = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
        await conn.sendMessage(m.key.remoteJid, { text: `🎨 Random Color\n\nHex: ${randomHex.toUpperCase()}` }, { quoted: m });
      }
    },

    'motivate': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const quotes = [
          "You are stronger than you think!", "Every day is a new beginning.", "Your potential is endless.",
          "Believe in yourself!", "You've got this!", "Great things never come from comfort zones.",
          "Success starts with self-belief.", "You are capable of amazing things!"
        ];
        await successReply(conn, m, `💪 ${quotes[Math.floor(Math.random() * quotes.length)]}`, ctx.sessionName);
      }
    }
  }
};
