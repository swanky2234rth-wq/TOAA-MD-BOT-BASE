// Auto-converted from legacy registerCmd('owner', ...) in main.js
// Category: utilities
const axios = require('axios');
const settings = require('../settings');

const {
  loadUserSettings
} = require('../main');
module.exports = {
  name: 'owner',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'owner': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

    const { sessionName } = ctx;
    const us = loadUserSettings(sessionName);
    const ownerNum = us.ownerNumber || settings.OWNER_NUMBER || '2347047129088';
    const ownerName = settings.OWNER_NAME || 'swanky';
    const ownerNumberClean = ownerNum.replace(/[^0-9]/g, '');
    const waMeLink = `https://wa.me/${ownerNumberClean}`;
    const interactiveMessage = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: ` *${ownerName}*\n\n *Number:* ${ownerNumberClean}\n *Status:* Online 🟢\n\nTap the button below to message me!` },
                    footer: { text: 'TOAA BOT' },
                    nativeFlowMessage: {
                        buttons: [{
                            name: 'cta_url',
                            buttonParamsJson: JSON.stringify({ display_text: '💬 MESSAGE OWNER', url: waMeLink, merchant_url: waMeLink })
                        }]
                    }
                }
            }
        }
    };
    try {
        await conn.relayMessage(m.key.remoteJid, interactiveMessage, {});
    } catch (err) {
        await conn.sendMessage(m.key.remoteJid, { text: ` *${ownerName}*\n\n *Contact:* ${waMeLink}` }, { quoted: m });
    }

      }
    }
  }
};
