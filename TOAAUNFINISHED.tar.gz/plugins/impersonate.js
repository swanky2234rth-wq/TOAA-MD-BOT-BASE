// plugins/impersonate.js
const { resolveTarget, getMsgText, resolveDisplayJid } = require('../helper/function');

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'Impersonate',
  version: '1.0.0',
  author: 'TOAA',
  
  commands: {
    'impersonate': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        
        if (!ctx.isOwner) {
          return fReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', sessionName);
        }

        const target = resolveTarget(m, args);
        if (!target) {
          return fReply(conn, m, `Usage: ${prefix}impersonate @user <message>`, sessionName);
        }
        
        const rawTargetJid = target.includes('@') ? target : `${target.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
        const remoteJid = m.key.remoteJid;
        const meta = remoteJid.endsWith('@g.us') ? await conn.groupMetadata(remoteJid).catch(() => null) : null;
        const targetJid = resolveDisplayJid(rawTargetJid, meta?.participants);
        const targetNum = targetJid.split('@')[0];

        // Remove first arg (the mention) from text
        const rawText = getMsgText(m);
        const prefixStripped = rawText.slice(prefix.length + 'impersonate'.length).trim();
        // Strip the @mention from beginning
        const text = prefixStripped.replace(/^@\d+\s*/, '').trim();

        if (!text) {
          return fReply(conn, m, `Usage: ${prefix}impersonate @user <message>`, sessionName);
        }

        try {
          const pfp = await conn.profilePictureUrl(targetJid, 'image').catch(() => null);

          await conn.sendMessage(m.key.remoteJid, {
            text,
            contextInfo: {
              mentionedJid: [targetJid],
              externalAdReply: {
                title: `@${targetNum}`,
                body: text.length > 60 ? text.substring(0, 60) + '...' : text,
                thumbnailUrl: pfp || 'https://i.ibb.co/60pgqPj9/photo-2026-04-29-00-18-01-7633969691903393816.jpg',
                sourceUrl: `https://wa.me/${targetNum}`,
                mediaType: 1,
                renderLargerThumbnail: false
              }
            }
          });
        } catch (e) {
          await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName);
        }
      }
    }
  }
};