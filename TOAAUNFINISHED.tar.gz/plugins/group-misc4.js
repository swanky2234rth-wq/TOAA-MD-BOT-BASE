const mainCore = require('../main');
const { errorReply, successReply, unauthorizedReply } = mainCore;

module.exports = {
  name: 'Group Batch 4',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setwelcomeimg': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const imgUrl = args[0]?.trim();
        if (!imgUrl) return errorReply(conn, m, `Usage: ${ctx.prefix}setwelcomeimg <image_url>`, ctx.sessionName);
        if (!global.welcomeImages) global.welcomeImages = new Map();
        global.welcomeImages.set(m.key.remoteJid, imgUrl);
        await successReply(conn, m, `Welcome image updated!`, ctx.sessionName);
      }
    },

    'setgoodbyeimg': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const imgUrl = args[0]?.trim();
        if (!imgUrl) return errorReply(conn, m, `Usage: ${ctx.prefix}setgoodbyeimg <image_url>`, ctx.sessionName);
        if (!global.goodbyeImages) global.goodbyeImages = new Map();
        global.goodbyeImages.set(m.key.remoteJid, imgUrl);
        await successReply(conn, m, `Goodbye image updated!`, ctx.sessionName);
      }
    },

    'resetwelcomeimg': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        if (global.welcomeImages) global.welcomeImages.delete(m.key.remoteJid);
        await successReply(conn, m, `Welcome image reset to default!`, ctx.sessionName);
      }
    },

    'resetgoodbyeimg': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        if (global.goodbyeImages) global.goodbyeImages.delete(m.key.remoteJid);
        await successReply(conn, m, `Goodbye image reset to default!`, ctx.sessionName);
      }
    }
  }
};
