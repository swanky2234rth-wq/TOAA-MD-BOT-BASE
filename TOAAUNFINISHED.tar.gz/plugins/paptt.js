// ─── TOAA Paptt (random NSFW image) ─────────
const { errorReply, getSessionSetting } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'paptt',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'paptt': {
      category: 'nsfw',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;

        const isGroup = m.key.remoteJid.endsWith('@g.us');
        const nsfwOn = getSessionSetting(sessionName, `nsfw_${m.key.remoteJid}`, false);
        if (isGroup && !nsfwOn) {
          return errorReply(conn, m, `🔒 NSFW isn't enabled in this group. An admin can turn it on with .nsfwon`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          const res = await axios.get('https://kyzznekoo.zone.id/api/asupan/paptt', {
            responseType: 'arraybuffer',
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
          });

          await conn.sendMessage(m.key.remoteJid, { image: Buffer.from(res.data), caption: '🔞 *Paptt*' }, { quoted: m });
          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
        } catch (e) {
          console.error('[PAPTT] Error:', e.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Couldn't fetch an image — try again.`, sessionName);
        }
      }
    }
  }
};
