// plugins/play.js
const yts = require('yt-search');
const { ytmp3 } = require('@vreden/youtube_scraper');

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}

function getFooterReply() {
  try {
    const { getFooterReply: footer } = require('../main');
    if (footer) return footer();
  } catch (e) {}
  return {};
}

function buildLoadingCard(video) {
  return (
    `╔═━═━═━═━═━═━═━═━═━╗\n` +
    `║  「⎝☆ 𝙼𝚄𝚂𝙸𝙲 𝙻𝙾𝙰𝙳𝙸𝙽𝙶...⎠」\n` +
    `║ ᴀʀᴛɪsᴛ : ${video.author?.name || 'Unknown'}\n` +
    `║ ᴛɪᴛʟᴇ : ${video.title}\n` +
    `║ ᴅᴜʀᴀᴛɪᴏɴ : ${video.timestamp || 'Unknown'}\n` +
    `║                  \`𝖉𝖔𝖜𝖓𝖑𝖆𝖉𝖔𝖎𝖓𝖌....\`\n` +
    `╚═━═━═━═━═━═━═━═━═━╝`
  );
}

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const query = args.join(' ').trim();

  if (!query) {
    return fReply(conn, m, `🎵 *Play a song!*\n\nUsage: ${prefix}play <song name>\nExample: ${prefix}play love story`, sessionName);
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🔍', key: m.key } });

  try {
    const search = await yts(query);
    if (!search?.videos?.length) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return fReply(conn, m, '❌ *No results found!*', sessionName);
    }

    const video = search.videos[0];

    await conn.sendMessage(m.key.remoteJid, { text: buildLoadingCard(video) }, { quoted: m });

    const result = await ytmp3(video.url, 128);

    if (!result?.status || !result?.download) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return fReply(conn, m, `❌ *Download failed:* ${result?.result || 'no download link returned'}`, sessionName);
    }

    const audioUrl = result.download;
    const title = result.metadata?.title || video.title;
    const footer = getFooterReply();

    await conn.sendMessage(m.key.remoteJid, {
      audio: { url: audioUrl },
      mimetype: 'audio/mpeg',
      fileName: `${title.replace(/[\\/:*?"<>|]/g, '').slice(0, 120)}.mp3`,
      ptt: false,
      contextInfo: {
        externalAdReply: {
          title: title || 'YouTube Audio',
          body: video.author?.name || 'YouTube',
          thumbnailUrl: video.thumbnail,
          sourceUrl: video.url,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      },
      ...footer
    }, { quoted: m });

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  } catch (error) {
    console.error('[PLAY] Error:', error.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await fReply(conn, m, `❌ *Play failed:* ${error.message}`, sessionName);
  }
}

module.exports = {
  name: 'YouTube Music Player',
  version: '2.0.0',
  author: 'TOAA',
  commands: {
    'song': { category: 'downloader', handler: run }
  }
};
