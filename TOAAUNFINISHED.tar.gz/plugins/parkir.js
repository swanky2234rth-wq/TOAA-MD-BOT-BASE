// ─── TOAA RPG Parking Attendant ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 12;
const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'parking',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'parking': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Feet still sore from standing! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Legs are killing you from standing all day! 😫\n\nParking work costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🅿️', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Whistle blows! Straight, straight, turn left a bit! 🏁\nStarting to collect parking fees at the minimart... 💰` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const gacha = Math.random();

  if (gacha < 0.1) {
    const fine = Math.floor(Math.random() * 5000) + 1000;
    removeCoin(jid, fine);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🚨', key: m.key } });
    return conn.sendMessage(m.key.remoteJid, {
      text: `RAID INCOMING! 🚓💨\n\nYou bolt and drop your change worth *${fmtCoin(fine)}* while running!\n⚡ Stamina: -${STAMINA_COST}\n\nRough day today! 😭`
    }, { quoted: m });
  }

  if (gacha > 0.9) {
    const jackpot = Math.floor(Math.random() * 50000) + 20000;
    addCoin(jid, jackpot);
    const expGain = Math.floor(jackpot / 20);
    const levelResult = addExp(jid, expGain);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🤑', key: m.key } });
    await conn.sendMessage(m.key.remoteJid, {
      text: `JACKPOT! A SPORTS CAR SHOWED UP! 🏎️✨\n\nAs they left, the window rolled down and they handed you a huge bill!\n💵 Earnings: *+${fmtCoin(jackpot)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nWhat a blessed day! 🙏`
    }, { quoted: m });
    return notifyLevelUp(conn, m, jid, levelResult);
  }

  const earning = Math.floor(Math.random() * 8000) + 2000;
  addCoin(jid, earning);
  const expGain = Math.floor(earning / 20);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, {
    text: `TODAY'S PARKING EARNINGS! 🅿️✨\n\n💵 Earnings: *+${fmtCoin(earning)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nSpare change adds up over time! 💪`
  }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
