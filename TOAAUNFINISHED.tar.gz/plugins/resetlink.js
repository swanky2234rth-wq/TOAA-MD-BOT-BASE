// Auto-converted from legacy registerCmd('resetlink', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'resetlink',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'resetlink': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  await conn.groupRevokeInvite(m.key.remoteJid);
  await fReply(conn, m, '*_💈 𝙸𝚗𝚟𝚒𝚝𝚎 𝙻𝚒𝚗𝚔 𝚁𝚎𝚜𝚎𝚝_*', ctx.sessionName);

      }
    }
  }
};
