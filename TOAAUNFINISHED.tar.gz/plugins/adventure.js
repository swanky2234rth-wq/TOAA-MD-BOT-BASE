// ─── TOAA RPG Adventure ─────────
const { errorReply } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();

const LOCATIONS = ['🌲 Dark Forest', '🏔️ Eternal Ice Mountain', '🏜️ Desert of Death', '🌋 Volcanic Peak', '🏰 Haunted Old Castle', '🌊 Mysterious Beach'];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'adventure',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'adventure': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);

  if (user.health < 30) {
    return errorReply(conn, m, `Whoa, your HP's critical! 😭💔\n\nYou need at least *30 HP* to adventure safely.\nCurrently you only have *${user.health} HP*. Go heal up first! 💉✨`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still catching your breath! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  cooldowns.set(jid, Date.now());

  const location = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🗺️', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Packing your bag, lighting the torch... Entering *${location}*... ⚔️🗺️\nBe careful, the air feels heavy...` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const isWin = Math.random() < 0.6;

  if (isWin) {
    const expGain = Math.floor(Math.random() * 2000) + 500;
    const coinGain = Math.floor(Math.random() * 10000) + 2000;

    addCoin(jid, coinGain);
    const levelResult = addExp(jid, expGain);

    let txt = `🗡️ *ADVENTURE SUCCESSFUL!!* 🗡️\n\n📍 Location: *${location}*\n\n`;
    txt += `Amazing! You defeated the guardian monster and found a treasure chest!\n`;
    txt += `💰 Coin: *+${fmtCoin(coinGain)}*\n📈 EXP: *+${expGain.toLocaleString('en-US')}*\n\n`;
    txt += `Made it back safe! Ready for another adventure whenever! 🚀✨`;

    await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
    return notifyLevelUp(conn, m, jid, levelResult);
  }

  const healthLoss = Math.floor(Math.random() * 30) + 10;
  const fresh = getUser(jid);
  fresh.health = Math.max(0, fresh.health - healthLoss);

  let msg = `☠️ *AMBUSHED BY MONSTERS!!* ☠️\n\n📍 Location: *${location}*\n\n`;
  msg += `Uh oh! You were spotted, and a pack of monsters attacked all at once!\n`;
  msg += `❤️ HP Lost: *-${healthLoss} HP* (Remaining: ${fresh.health})\n\n`;

  if (fresh.health <= 0) {
    fresh.health = 0;
    fresh.exp = Math.floor((fresh.exp || 0) / 2);
    msg += `💀 *YOU DIED!*\nOh no... you fell right there. Your EXP took a 50% penalty. 💔🥀`;
  } else {
    msg += `Lucky you managed to escape! Better rest and heal up first! 🏃💨`;
  }

  setUser(jid, fresh);
  await conn.sendMessage(m.key.remoteJid, { text: msg }, { quoted: m });
}
