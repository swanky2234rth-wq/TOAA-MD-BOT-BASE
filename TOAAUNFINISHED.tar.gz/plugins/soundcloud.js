// Auto-converted from legacy registerCmd('soundcloud', ...) in main.js
// Category: downloader
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'soundcloud',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'soundcloud': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx;
  const text = args.join(' ').trim();
  if (!text) return fReply(conn, m, `Usage: ${prefix}soundcloud <song>`, sessionName);
  try {
    const { data } = await axios.get(`https://api.siputzx.my.id/api/d/soundcloud?query=${encodeURIComponent(text)}`);
    if (!data.status || !data.data) return fReply(conn, m, '*_۞ 𝙽𝚘 𝚁𝚎𝚜𝚞𝚕𝚝𝚜_*', sessionName);
    await conn.sendMessage(m.key.remoteJid, { audio: { url: data.data.url }, mimetype: 'audio/mpeg', fileName: `${data.data.title || 'soundcloud'}.mp3` }, { quoted: m });
  } catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
