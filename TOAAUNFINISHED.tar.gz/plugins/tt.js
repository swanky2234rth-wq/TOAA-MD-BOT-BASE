// plugins/tt.js
console.log('[TT] Plugin loaded!');

const axios = require('axios');
const { fReply, errorReply } = require('../main');

// ─── TIKTOK DOWNLOAD FUNCTION ──────────────────────────────────────────────
async function tiktokDl(url) {
  return new Promise(async (resolve, reject) => {
    try {
      let data = [];
      
      function formatNumber(integer) {
        let numb = parseInt(integer);
        return Number(numb).toLocaleString().replace(/,/g, '.');
      }
      
      function formatDate(n, locale = 'en') {
        let d = new Date(n * 1000);
        return d.toLocaleDateString(locale, {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
          hour: 'numeric',
          minute: 'numeric',
          second: 'numeric'
        });
      }
      
      let domain = 'https://www.tikwm.com/api/';
      let res = await (await axios.post(domain, {}, {
        headers: {
          'Accept': 'application/json, text/javascript, */*; q=0.01',
          'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Origin': 'https://www.tikwm.com',
          'Referer': 'https://www.tikwm.com/',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
          'X-Requested-With': 'XMLHttpRequest'
        },
        params: {
          url: url,
          count: 12,
          cursor: 0,
          web: 1,
          hd: 1
        }
      })).data.data;
      
      if (res?.duration == 0) {
        res.images.map(v => {
          data.push({ type: 'photo', url: v });
        });
      } else {
        data.push({
          type: 'watermark',
          url: 'https://www.tikwm.com' + res?.wmplay || "/undefined",
        }, {
          type: 'nowatermark',
          url: 'https://www.tikwm.com' + res?.play || "/undefined",
        }, {
          type: 'nowatermark_hd',
          url: 'https://www.tikwm.com' + res?.hdplay || "/undefined"
        });
      }
      
      let json = {
        status: true,
        title: res.title,
        taken_at: formatDate(res.create_time),
        region: res.region,
        id: res.id,
        durations: res.duration,
        duration: res.duration + ' Seconds',
        cover: 'https://www.tikwm.com' + res.cover,
        size_wm: res.wm_size,
        size_nowm: res.size,
        size_nowm_hd: res.hd_size,
        data: data,
        music_info: {
          id: res.music_info.id,
          title: res.music_info.title,
          author: res.music_info.author,
          album: res.music_info.album ? res.music_info.album : null,
          url: 'https://www.tikwm.com' + res.music || res.music_info.play
        },
        stats: {
          views: formatNumber(res.play_count),
          likes: formatNumber(res.digg_count),
          comment: formatNumber(res.comment_count),
          share: formatNumber(res.share_count),
          download: formatNumber(res.download_count)
        },
        author: {
          id: res.author.id,
          fullname: res.author.unique_id,
          nickname: res.author.nickname,
          avatar: 'https://www.tikwm.com' + res.author.avatar
        }
      };
      resolve(json);
    } catch (e) {
      reject(e);
    }
  });
}

module.exports = {
  name: 'TikTok Downloader',
  version: '1.0.0',
  author: 'swanky',
  commands: {
    'tt': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {
        const { prefix, sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const text = args.join(' ').trim();
        
        if (!text) {
          return fReply(conn, m, `📌 *TikTok Downloader*\n\nUsage: *${prefix}tt <tiktok_url>*\nExample: *${prefix}tt https://vt.tiktok.com/ZS4vT3Rjc/*`, sessionName);
        }
        
        if (!text.startsWith("https://")) {
          return fReply(conn, m, `❌ *Invalid URL!*\n\nPlease provide a valid TikTok link.`, sessionName);
        }
        
        await conn.sendMessage(remoteJid, { react: { text: '⏳', key: m.key } });
        
        try {
          const result = await tiktokDl(text);
          
          if (!result.status) {
            throw new Error('Download failed');
          }
          
          // ─── Slideshow (multiple photos) ────────────────────────────────────
          if (result.durations == 0 && result.duration == "0 Seconds") {
            for (const item of result.data) {
              await conn.sendMessage(remoteJid, {
                image: { url: item.url }
              }, { quoted: m });
              await new Promise(r => setTimeout(r, 500));
            }
            await fReply(conn, m, `✅ *Sent ${result.data.length} photos!*`, sessionName);
          } 
          // ─── Video ──────────────────────────────────────────────────────────
          else {
            const videoUrl = result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark");
            if (!videoUrl) throw new Error('No video URL found');
            
            // Build caption with stats
            const caption = 
              `🎵 *${result.title || 'TikTok Video'}*\n\n` +
              `👤 *Author:* ${result.author?.fullname || 'Unknown'}\n` +
              `📊 *Views:* ${result.stats?.views || 0}\n` +
              `❤️ *Likes:* ${result.stats?.likes || 0}\n` +
              `💬 *Comments:* ${result.stats?.comment || 0}\n` +
              `🔗 *Share:* ${result.stats?.share || 0}`;
            
            await conn.sendMessage(remoteJid, {
              video: { url: videoUrl.url },
              mimetype: 'video/mp4',
              caption: caption
            }, { quoted: m });
          }
          
          await conn.sendMessage(remoteJid, { react: { text: '✅', key: m.key } });
          
        } catch (error) {
          console.error('[TT] Error:', error.message);
          await conn.sendMessage(remoteJid, { react: { text: '❌', key: m.key } });
          await fReply(conn, m, `❌ *Error:* ${error.message}`, sessionName);
        }
      }
    }
  }
};