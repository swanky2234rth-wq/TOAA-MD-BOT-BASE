const mainCore = require('../main');
const { errorReply, successReply, unauthorizedReply, resolveTarget, resolveDisplayJid, getRawId } = mainCore;

module.exports = {
  name: 'Group Batch 2',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'members': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isAdmin && !ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const meta = await conn.groupMetadata(m.key.remoteJid);
        const list = meta.participants.map((p, i) => `${i + 1}. @${p.id.split('@')[0]}`).join('\n');
        await conn.sendMessage(m.key.remoteJid, {
          text: `👥 Members (${meta.participants.length})\n\n${list}`,
          mentions: meta.participants.map(p => p.id)
        }, { quoted: m });
      }
    },

    'admins': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const meta = await conn.groupMetadata(m.key.remoteJid);
        const admins = meta.participants.filter(p => p.admin);
        if (!admins.length) return errorReply(conn, m, "No admins found!", ctx.sessionName);
        const list = admins.map((p, i) => `${i + 1}. @${p.id.split('@')[0]} (${p.admin})`).join('\n');
        await conn.sendMessage(m.key.remoteJid, {
          text: `👮 Admins (${admins.length})\n\n${list}`,
          mentions: admins.map(p => p.id)
        }, { quoted: m });
      }
    },

    'grouprank': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        const rawTarget = resolveTarget(m, args) || `${ctx.senderNumber}@s.whatsapp.net`;
        const meta = await conn.groupMetadata(m.key.remoteJid);
        // Match against either the phone-number id OR the lid, since a
        // resolved target could be in either form.
        const rawId = getRawId(rawTarget);
        const member = meta.participants.find(p =>
          getRawId(p.id) === rawId || (p.lid && getRawId(p.lid) === rawId)
        );
        if (!member) return errorReply(conn, m, "User not in group!", ctx.sessionName);
        const displayJid = resolveDisplayJid(rawTarget, meta.participants);
        const rank = member.admin ? `Admin (${member.admin})` : 'Member';
        await conn.sendMessage(m.key.remoteJid, {
          text: `👤 @${displayJid.split('@')[0]}\nRank: ${rank}`,
          mentions: [displayJid]
        }, { quoted: m });
      }
    },

    'grouppic': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        if (!m.key.remoteJid.endsWith('@g.us')) return errorReply(conn, m, "Groups Only", ctx.sessionName);
        try {
          const pp = await conn.profilePictureUrl(m.key.remoteJid, 'image');
          await conn.sendMessage(m.key.remoteJid, { image: { url: pp }, caption: '🖼️ Group Picture' }, { quoted: m });
        } catch {
          await errorReply(conn, m, "No group picture found!", ctx.sessionName);
        }
      }
    }
  }
};
