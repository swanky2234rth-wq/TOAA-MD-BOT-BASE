// ─── TOAA RPG Rideshare ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 15;
const COOLDOWN_MS = 120 * 1000;
const cooldowns = new Map();

const ORDERS = [
  { type: '🍔 Food Delivery', distance: '2km', min: 5000, max: 15000 },
  { type: '👤 Passenger Ride', distance: '5km', min: 10000, max: 25000 },
  { type: '📦 Package Send', distance: '3km', min: 8000, max: 20000 },
  { type: '🛒 Grocery Run', distance: '4km', min: 12000, max: 30000 },
  { type: '👥 Group Ride', distance: '10km', min: 20000, max: 50000 }
];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'rideshare',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'rideshare': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Bike's still cooling down! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Engine's overheating, better rest! 🥵🏍️\n\nRideshare work costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);

  const order = ORDERS[Math.floor(Math.random() * ORDERS.length)];
  const earning = Math.floor(Math.random() * (order.max - order.min + 1)) + order.min;
  const tips = Math.random() > 0.7 ? Math.floor(Math.random() * 5000) + 1000 : 0;
  const totalEarning = earning + tips;

  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🏍️', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Bike started, gas on! Looking for a passenger... 🏍️💨\nGot a *${order.type}* order, *${order.distance}* away, let's go! 🗺️` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  addCoin(jid, totalEarning);
  const expGain = Math.floor(totalEarning / 20);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  let txt = `RIDE COMPLETE! 🏍️✨\n\nToday's earnings breakdown:\n📱 Type: *${order.type}*\n💵 Fare: *+${fmtCoin(earning)}*\n`;
  if (tips > 0) txt += `🎁 Customer Tip: *+${fmtCoin(tips)}*\n`;
  txt += `📈 EXP: *+${expGain}*\n⚡ Stamina: *-${STAMINA_COST}*\n\nNot bad for extra pocket money! Keep riding! 🔥💪`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
