// ─── TOAA RPG Toggle (group) ─────────
const { errorReply, fReply, requireAdmin, getSessionSetting, setSessionSetting } = require('../main');

module.exports = {
  name: 'rpg',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'rpg': {
      category: 'rpg',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const jid = m.key.remoteJid;
        const sub = args[0]?.toLowerCase();

        if (!jid.endsWith('@g.us')) {
          return errorReply(conn, m, `⚔️ RPG is always available in DMs — this toggle only applies to groups.`, sessionName);
        }

        if (sub !== 'on' && sub !== 'off') {
          return fReply(conn, m,
            `⚔️ *GROUP RPG FEATURE*\n\n` +
            `Use this to control member access to RPG commands.\n\n` +
            `• *${prefix}rpg on* — Members can play RPG\n` +
            `• *${prefix}rpg off* — Members can't play RPG\n\n` +
            `*Note:* Admins can always access RPG regardless of this setting.`,
            sessionName
          );
        }

        if (!requireAdmin(ctx, conn, m)) return;

        const key = `rpg_${jid}`;
        const isEnable = sub === 'on';
        const current = getSessionSetting(sessionName, key, true);

        if (current === isEnable) {
          return fReply(conn, m, `⚔️ RPG is already *${isEnable ? 'ON' : 'OFF'}* in this group.`, sessionName);
        }

        setSessionSetting(sessionName, key, isEnable);
        await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        return fReply(conn, m,
          `✅ *${isEnable ? 'ENABLED' : 'DISABLED'}* RPG in this group!\n\n` +
          (isEnable
            ? `Members can now use all RPG commands.`
            : `Members can no longer use RPG commands.`),
          sessionName
        );
      }
    }
  }
};
