// Auto-converted from legacy registerCmd('save', ...) in main.js
// Category: utilities
const {
  downloadMedia,
  fReply,
  getQuotedMsg,
  resolveDisplayJid
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'save',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'save': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { sessionName, prefix } = ctx;
  
  // Check if replying to a message
  const quotedMsg = getQuotedMsg(m);
  if (!quotedMsg) {
    return fReply(conn, m, `🎴 *Reply to a status/media message!*\n\nUsage: ${prefix}save (reply to a status or media)`, sessionName);
  }
  
  // Check if it's a status message (from status@broadcast)
  const isStatus = m.key.remoteJid === 'status@broadcast' || quotedMsg.key?.remoteJid === 'status@broadcast';
  
  // Get media type from quoted message
  const mediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage'];
  let mediaSource = null;
  let mediaType = null;
  let caption = '';
  
  for (const type of mediaTypes) {
    if (quotedMsg[type]) {
      mediaSource = quotedMsg[type];
      mediaType = type.replace('Message', '');
      caption = mediaSource.caption || '';
      break;
    }
  }
  
  // Check for view-once messages
  const viewOnceMsg = quotedMsg.viewOnceMessageV2?.message || quotedMsg.viewOnceMessage?.message;
  if (viewOnceMsg) {
    for (const type of mediaTypes) {
      if (viewOnceMsg[type]) {
        mediaSource = viewOnceMsg[type];
        mediaType = type.replace('Message', '');
        caption = mediaSource.caption || '';
        break;
      }
    }
  }
  
  if (!mediaSource) {
    // If no media, try to save text
    const textContent = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text;
    if (textContent) {
      return fReply(conn, m, `📝 *Saved Text:*\n\n${textContent}`, sessionName);
    }
    return fReply(conn, m, '🎴 *No media or text found in replied message!*', sessionName);
  }
  
  await fReply(conn, m, '⏳ *Downloading and saving...*', sessionName);
  
  try {
    const mediaBuffer = await downloadMedia(mediaSource, mediaType);
    const rawSender = quotedMsg.key?.participant || quotedMsg.key?.remoteJid || 'unknown';
    const remoteJid = m.key.remoteJid;
    const meta = remoteJid.endsWith('@g.us') ? await conn.groupMetadata(remoteJid).catch(() => null) : null;
    const sender = meta?.participants ? resolveDisplayJid(rawSender, meta.participants) : rawSender;
    const senderName = sender.split('@')[0];
    const timestamp = new Date().toLocaleString();
    const fileExt = {
      image: 'jpg',
      video: 'mp4',
      audio: 'mp3',
      sticker: 'webp',
      document: mediaSource.fileName?.split('.').pop() || 'bin'
    }[mediaType] || 'bin';
    
    const fileName = `${mediaType}_${Date.now()}.${fileExt}`;
    
    // Send based on media type
    if (mediaType === 'image') {
      await conn.sendMessage(m.key.remoteJid, {
        image: mediaBuffer,
        caption: `💾 *Saved!*\n\n📱 From: @${senderName}\n🕐 Time: ${timestamp}\n📝 Caption: ${caption || 'None'}`,
        mentions: [sender]
      }, { quoted: m });
    } 
    else if (mediaType === 'video') {
      await conn.sendMessage(m.key.remoteJid, {
        video: mediaBuffer,
        caption: `💾 *Saved!*\n\n📱 From: @${senderName}\n🕐 Time: ${timestamp}\n📝 Caption: ${caption || 'None'}`,
        mentions: [sender]
      }, { quoted: m });
    }
    else if (mediaType === 'audio') {
      await conn.sendMessage(m.key.remoteJid, {
        audio: mediaBuffer,
        mimetype: 'audio/mpeg',
        ptt: false,
        caption: `💾 *Saved!*\n\n📱 From: @${senderName}\n🕐 Time: ${timestamp}`
      }, { quoted: m });
    }
    else if (mediaType === 'sticker') {
      await conn.sendMessage(m.key.remoteJid, {
        sticker: mediaBuffer,
        caption: `💾 *Saved!*\n\n📱 From: @${senderName}\n🕐 Time: ${timestamp}`
      }, { quoted: m });
    }
    else if (mediaType === 'document') {
      await conn.sendMessage(m.key.remoteJid, {
        document: mediaBuffer,
        mimetype: mediaSource.mimetype || 'application/octet-stream',
        fileName: mediaSource.fileName || fileName,
        caption: `💾 *Saved!*\n\n📱 From: @${senderName}\n🕐 Time: ${timestamp}`
      }, { quoted: m });
    }
    
  } catch (e) {
    console.error('[SAVE] Error:', e);
    await fReply(conn, m, `🎴 *Failed to save media:* ${e.message}`, sessionName);
  }

      }
    }
  }
};
