// Auto-converted from legacy registerCmd('tag', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'tag',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'tag': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const text = args.join(' ').trim() || '👋';
  const meta = await conn.groupMetadata(m.key.remoteJid);
  await conn.sendMessage(m.key.remoteJid, { text, mentions: meta.participants.map(p => p.id) }, { quoted: m });

      }
    }
  }
};
