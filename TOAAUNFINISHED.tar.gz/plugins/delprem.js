// Auto-converted from legacy registerCmd('delprem', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  resolveTarget,
  delPremium
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'delprem',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'delprem': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  let target = resolveTarget(m, args);
  if (!target) return fReply(conn, m, `Usage: ${ctx.prefix}delprem <number>`, ctx.sessionName);
  target = target.replace(/[^0-9]/g, '');
  await fReply(conn, m, delPremium(target) ? `*_💈 ${target} 𝚁𝚎𝚖𝚘𝚟𝚎𝚍_*` : `*_🎴 Not in list._*`, ctx.sessionName);

      }
    }
  }
};
