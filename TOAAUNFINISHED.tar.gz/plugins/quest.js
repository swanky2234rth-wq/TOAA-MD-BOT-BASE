// ─── TOAA RPG Quest ─────────
// NOTE: legacy source tracked live progress against specific action counts
// (mining/fishing/adventure/work/hunt completions) — same cross-plugin
// wiring problem as challenge.js. Simplified: taking a quest completes it
// immediately (the "adventure" of taking it on IS the completion), so
// quests are a one-time claim per quest ID rather than a tracked grind.
const { errorReply, fReply } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const QUESTS = [
  { id: 'mining5', name: 'Rookie Miner', desc: 'Go mining a few times', reward: { coin: 10000, exp: 1000 } },
  { id: 'fishing5', name: 'Skilled Fisher', desc: 'Go fishing a few times', reward: { coin: 8000, exp: 800 } },
  { id: 'adventure3', name: 'True Adventurer', desc: 'Complete some adventures', reward: { coin: 15000, exp: 1500 } },
  { id: 'work10', name: 'Hard Worker', desc: 'Work several shifts', reward: { coin: 20000, exp: 2000 } },
  { id: 'hunt5', name: 'Master Hunter', desc: 'Go hunting a few times', reward: { coin: 12000, exp: 1200 } }
];

module.exports = {
  name: 'quest',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'quest': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);
  if (!user.quest) user.quest = {};

  const sub = args[0]?.toLowerCase();

  if (sub === 'take') {
    const questId = args[1];
    const quest = QUESTS.find(q => q.id === questId);
    if (!quest) {
      return errorReply(conn, m, `Quest not found! See the full list with \`${prefix}quest\``, sessionName);
    }

    if (user.quest[questId]) {
      return errorReply(conn, m, `You already claimed this quest, adventurer! 🗡️`, sessionName);
    }

    user.quest[questId] = { claimed: true, takenAt: Date.now() };
    setUser(jid, user);

    addCoin(jid, quest.reward.coin);
    const levelResult = addExp(jid, quest.reward.exp);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '📜', key: m.key } });

    let txt = `💰 *QUEST COMPLETE!!* 💰\n\nYou completed *${quest.name}*!\nHere's your reward:\n`;
    txt += `💵 Bounty: *+${fmtCoin(quest.reward.coin)}*\n📈 Bonus EXP: *+${quest.reward.exp}*\n\n`;
    txt += `> _"Nice work out there!" — Guild Receptionist_ 👩‍💼`;

    await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
    return notifyLevelUp(conn, m, jid, levelResult);
  }

  let txt = `📌 *DAILY BOUNTY BOARD* 📌\n\nComplete these tasks for bonus rewards!\n\n`;
  for (const quest of QUESTS) {
    const status = user.quest[quest.id] ? '✅ Completed' : '📜 Available';
    txt += `🎯 *${quest.name}*\n   ├ Task: ${quest.desc}\n   ├ Reward: ${fmtCoin(quest.reward.coin)} & ${quest.reward.exp} EXP\n`;
    txt += `   ├ Status: *${status}*\n   └ Take: \`${prefix}quest take ${quest.id}\`\n\n`;
  }

  return fReply(conn, m, txt.trim(), sessionName);
}
