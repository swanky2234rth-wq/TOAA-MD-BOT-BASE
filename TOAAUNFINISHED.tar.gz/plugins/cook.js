// ─── TOAA RPG Cook ─────────
// NOTE: legacy source had both cook.js (auto-picks first affordable recipe)
// and cooking.js (explicit recipe arg, needs invented farm items like
// wheat/rice/egg). Ported cooking.js's better UX (explicit `.cook <recipe>`)
// but swapped its recipe materials to only use items that actually exist
// in this project's registry — see helper/rpgRecipes.js COOK_RECIPES.
const { errorReply, fReply } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed, removeItem } = require('../helper/rpg');
const { COOK_RECIPES } = require('../helper/rpgRecipes');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

module.exports = {
  name: 'cook',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'cook': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const recipeKey = args[0]?.toLowerCase();
  const user = getUser(jid);

  if (!recipeKey) {
    let txt = `👨‍🍳 *COOKING MENU*\n\nWhat do you want to make, Chef?\n\n`;
    for (const [key, recipe] of Object.entries(COOK_RECIPES)) {
      const mats = Object.entries(recipe.materials).map(([mat, qty]) => `${qty}x ${mat}`).join(', ');
      const effects = Object.entries(recipe.effect).map(([e, v]) => `+${v} ${e}`).join(', ');
      txt += `*${recipe.name}*\n📦 Needs: ${mats}\n💫 Effect: ${effects}\n👉 \`${prefix}cook ${key}\`\n\n`;
    }
    return fReply(conn, m, txt.trim(), sessionName);
  }

  const recipe = COOK_RECIPES[recipeKey];
  if (!recipe) {
    return errorReply(conn, m, `That's not a recipe I know! Check \`${prefix}cook\` for the menu.`, sessionName);
  }

  const missing = [];
  for (const [mat, needed] of Object.entries(recipe.materials)) {
    const have = user.inventory[mat] || 0;
    if (have < needed) missing.push(`${mat}: ${have}/${needed}`);
  }
  if (missing.length > 0) {
    return errorReply(conn, m, `You're missing ingredients for *${recipe.name}*!\n\n${missing.join('\n')}`, sessionName);
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '👨‍🍳', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Sizzle sizzle... 🔥🍳\nCooking *${recipe.name}*, smells amazing! 🤤` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  for (const [mat, needed] of Object.entries(recipe.materials)) {
    removeItem(jid, mat, needed);
  }

  const fresh = getUser(jid);
  if (recipe.effect.health) fresh.health = Math.min(fresh.health + recipe.effect.health, fresh.maxHealth);
  if (recipe.effect.stamina) fresh.stamina = Math.min(fresh.stamina + recipe.effect.stamina, fresh.maxStamina);
  if (recipe.effect.mana) fresh.mana = Math.min(fresh.mana + recipe.effect.mana, fresh.maxMana);
  setUser(jid, fresh);

  const levelResult = addExp(jid, recipe.exp);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  const effectTxt = Object.entries(recipe.effect).map(([e, v]) => `${e.toUpperCase()}: +${v}`).join('\n');
  let txt = `TA-DA! FOOD'S READY! 🍽️✨\n\nYou devoured *${recipe.name}*!\n\n${effectTxt}\n\n📈 Cooking EXP: *+${recipe.exp}*\n\nFull and ready to go! 🔥`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
