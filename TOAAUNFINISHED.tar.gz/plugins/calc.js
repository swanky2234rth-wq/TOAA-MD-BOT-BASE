// Auto-converted from legacy registerCmd('calc', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'calc',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'calc': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx; const expr = args.join(' ').trim();
  if (!expr) return fReply(conn, m, `Usage: ${prefix}calc <expression>`, sessionName);
  try { const safe = expr.replace(/[^0-9+\-*/().\s]/g, ''); const result = Function(`"use strict"; return (${safe})`)(); await fReply(conn, m, `🧮 *Calculator*\n\n📝 ${expr}\n🧩 = *${result}*`, sessionName); }
  catch { await fReply(conn, m, '*_۞ 𝙸𝚗𝚟𝚊𝚕𝚒𝚍 𝙴𝚡𝚙𝚛𝚎𝚜𝚜𝚒𝚘𝚗_*', sessionName); }

      }
    }
  }
};
