// Auto-converted from legacy registerCmd('ban', ...) in main.js
// Category: owner
const {
  bannedUsers,
  fReply,
  newsletterReply,
  resolveTarget
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'ban',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'ban': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  let target = resolveTarget(m, args);
  if (!target) return fReply(conn, m, `Usage: ${ctx.prefix}ban <number>`, ctx.sessionName);
  target = target.replace(/[^0-9]/g, '');
  bannedUsers.add(target);
  await fReply(conn, m, `*_💈 ${target} 𝙱𝚊𝚗𝚗𝚎𝚍_*`, ctx.sessionName);

      }
    }
  }
};
