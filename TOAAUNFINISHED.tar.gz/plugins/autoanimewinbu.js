// ─── TOAA Auto Anime (winbu.net) ─────────
const { errorReply, successReply } = require('../main');
const {
  loadSent, saveSent, loadState, saveState,
  getOngoingAnimeList, startAutoCheck, stopAutoCheck,
  runCheck, isRunning
} = require('../helper/animeScraper');

module.exports = {
  name: 'autoanimewinbu',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'autoanimewinbu': { category: 'anime', handler: run },
    'aaw': { category: 'anime', handler: run },
    'autoanime': { category: 'anime', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix, isOwner } = ctx;
  const remoteJid = m.key.remoteJid;

  if (!isOwner) {
    return errorReply(conn, m, `This command is owner-only.`, sessionName);
  }

  const sub = args[0]?.toLowerCase();
  const state = loadState();

  switch (sub) {
    case 'start': {
      if (isRunning()) {
        return errorReply(conn, m, `AutoAnime is already running!`, sessionName);
      }

      const groups = state.groups || [];
      if (groups.length === 0) {
        return errorReply(conn, m,
          `No target groups set yet!\n\nAdd one first:\n${prefix}aaw addgroup (inside the target group)\n${prefix}aaw addgroup 120363xxx@g.us`,
          sessionName
        );
      }

      const interval = state.interval || 5;
      startAutoCheck(conn, interval);
      saveState({ ...state, enabled: true });

      return conn.sendMessage(remoteJid, {
        text: `✅ *AutoAnime Started*\n\nTarget groups: ${groups.length}\nInterval: ${interval} min\nFilter: Pixeldrain 720p+\nMax age: 24h\n\nFirst check starting now...`,
        interactiveButtons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({ display_text: '📊 Status', id: `${prefix}autoanimewinbu status` })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({ display_text: '🛑 Stop', id: `${prefix}autoanimewinbu stop` })
          }
        ]
      }, { quoted: m });
    }

    case 'stop': {
      stopAutoCheck();
      saveState({ ...state, enabled: false });
      return successReply(conn, m, `AutoAnime stopped.`, sessionName);
    }

    case 'status': {
      const sent = loadSent();
      const running = isRunning();
      const groups = state.groups || [];

      let txt = `📊 *AutoAnime Status*\n\n`;
      txt += `Status: ${running ? '🟢 ON' : '🔴 OFF'}\n`;
      txt += `Auto-start: ${state.enabled ? 'Yes' : 'No'}\n`;
      txt += `Already sent: ${sent.size} episodes\n`;
      txt += `Interval: ${state.interval || 5} min\n`;
      txt += `Target groups: ${groups.length}\n`;

      if (groups.length > 0) {
        txt += `\n*Groups:*\n`;
        groups.forEach((g, i) => { txt += `${i + 1}. ${g}\n`; });
      }

      return errorReply(conn, m, txt, sessionName);
    }

    case 'cek':
    case 'check': {
      if (!isRunning()) startAutoCheck(conn, state.interval || 5);

      await errorReply(conn, m, `Checking for new anime...`, sessionName);
      try {
        await runCheck();
        return successReply(conn, m, `Check complete.`, sessionName);
      } catch (e) {
        console.error('[AUTOANIME] check error:', e.message);
        return errorReply(conn, m, `Something went wrong during the check.`, sessionName);
      }
    }

    case 'list': {
      await errorReply(conn, m, `Fetching anime list...`, sessionName);
      try {
        const list = await getOngoingAnimeList();
        if (list.length === 0) return errorReply(conn, m, `No anime found.`, sessionName);

        let txt = `📺 *Latest Anime List*\n\nTotal: ${list.length}\n\n`;
        list.slice(0, 15).forEach((a, i) => { txt += `${i + 1}. ${a.title}\n`; });
        if (list.length > 15) txt += `\n...and ${list.length - 15} more`;

        return errorReply(conn, m, txt, sessionName);
      } catch (e) {
        console.error('[AUTOANIME] list error:', e.message);
        return errorReply(conn, m, `Something went wrong fetching the list.`, sessionName);
      }
    }

    case 'reset': {
      const sent = loadSent();
      const count = sent.size;
      saveSent(new Set());
      return successReply(conn, m, `Reset! ${count} episodes cleared from history — everything can be re-sent.`, sessionName);
    }

    case 'addgroup':
    case 'addgrup': {
      let groupId = args.slice(1).join(' ').trim();
      if (!groupId && remoteJid.endsWith('@g.us')) groupId = remoteJid;

      if (!groupId || !groupId.includes('@g.us')) {
        return errorReply(conn, m,
          `Invalid group ID.\n\nUse this inside a group, or:\n${prefix}aaw addgroup 120363xxx@g.us`,
          sessionName
        );
      }

      const groups = state.groups || [];
      if (groups.includes(groupId)) {
        return errorReply(conn, m, `That group is already on the target list.`, sessionName);
      }

      groups.push(groupId);
      saveState({ ...state, groups });
      return successReply(conn, m, `Group added.\nTotal: ${groups.length} groups.`, sessionName);
    }

    case 'delgroup':
    case 'delgrup': {
      let groupId = args.slice(1).join(' ').trim();
      if (!groupId && remoteJid.endsWith('@g.us')) groupId = remoteJid;

      const groups = state.groups || [];
      const idx = groups.indexOf(groupId);
      if (idx === -1) {
        return errorReply(conn, m, `That group isn't on the target list.`, sessionName);
      }

      groups.splice(idx, 1);
      saveState({ ...state, groups });
      return successReply(conn, m, `Group removed.\nRemaining: ${groups.length} groups.`, sessionName);
    }

    case 'interval': {
      const mins = parseInt(args[1]);
      if (!mins || mins < 1 || mins > 60) {
        return errorReply(conn, m, `Interval must be 1-60 minutes.\nExample: ${prefix}aaw interval 10`, sessionName);
      }

      saveState({ ...state, interval: mins });

      if (isRunning()) {
        stopAutoCheck();
        startAutoCheck(conn, mins);
      }

      return successReply(conn, m, `Interval changed to ${mins} minutes.`, sessionName);
    }

    default: {
      const running = isRunning();
      const txt =
        `🎬 *Auto Anime (winbu.net)*\n\n` +
        `Status: ${running ? '🟢 ON' : '🔴 OFF'}\n\n` +
        `*Commands:*\n` +
        `${prefix}aaw start — Start auto-check\n` +
        `${prefix}aaw stop — Stop\n` +
        `${prefix}aaw status — View status\n` +
        `${prefix}aaw cek — Manual check now\n` +
        `${prefix}aaw list — Latest anime list\n` +
        `${prefix}aaw addgroup — Add target group\n` +
        `${prefix}aaw delgroup — Remove target group\n` +
        `${prefix}aaw interval 10 — Change interval\n` +
        `${prefix}aaw reset — Reset sent history`;

      return conn.sendMessage(remoteJid, {
        text: txt,
        interactiveButtons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
              display_text: running ? '🛑 Stop' : '▶️ Start',
              id: `${prefix}autoanimewinbu ${running ? 'stop' : 'start'}`
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({ display_text: '📊 Status', id: `${prefix}autoanimewinbu status` })
          }
        ]
      }, { quoted: m });
    }
  }
}
