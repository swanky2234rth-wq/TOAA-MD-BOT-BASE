// ─── TOAA Clear Chat ─────────
const {
  errorReply,
  successReply,
  antideleteStore
} = require('../main');

// Finds the most recently cached message for a specific chat (remoteJid),
// scoped to this session. Only looks at what's in-memory since last restart —
// this is a best-effort cache, not a full chat history fetch.
function findLastCachedMessage(sessionName, remoteJid) {
  const store = antideleteStore.get(sessionName);
  if (!store) return null;

  let latest = null;
  for (const msg of store.values()) {
    if (msg?.key?.remoteJid !== remoteJid) continue;
    if (!latest || (msg.messageTimestamp || 0) > (latest.messageTimestamp || 0)) {
      latest = msg;
    }
  }
  return latest;
}

module.exports = {
  name: 'clearchat',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'clearchat': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!isOwner) {
          return errorReply(conn, m, `This command is owner-only.`, sessionName);
        }

        const lastMsg = findLastCachedMessage(sessionName, remoteJid);

        if (!lastMsg) {
          return errorReply(
            conn, m,
            `No cached messages found for this chat yet — the bot hasn't seen any messages here since it last restarted, so there's nothing safe to base the clear on.`,
            sessionName
          );
        }

        try {
          await conn.chatModify(
            {
              delete: true,
              lastMessages: [{
                key: lastMsg.key,
                messageTimestamp: lastMsg.messageTimestamp
              }]
            },
            remoteJid
          );
          await successReply(conn, m, `Chat cleared.`, sessionName);
        } catch (e) {
          console.error('[CLEARCHAT] Error:', e.message);
          await errorReply(conn, m, `Couldn't clear this chat — WhatsApp rejected the request. Try again later.`, sessionName);
        }
      }
    }
  }
};
