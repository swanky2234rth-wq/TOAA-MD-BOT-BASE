// ─── TOAA MAIN MENU (short info card + real tappable buttons) ───────────────
// Full auto-generated command listing lives in toaamenu.js / ${prefix}toaamenu.
// Buttons use the buttonsMessage + faked interactiveResponseMessage context
// trick to keep classic button rendering working even though WhatsApp
// deprecated buttonsMessage officially — tapping TOAA-MENU sends ${prefix}toaamenu,
// tapping OWNER sends ${prefix}owner, same as typing them.
//
// IMPORTANT: the text card below always sends first, unconditionally, before
// anything button-related is attempted. Nothing about the buttons — cooldown,
// thumbnail fetch, the buttonsMessage trick itself — is allowed to prevent
// ${prefix}menu from showing something.

const mainCore = require('../main');
const {
  loadUserSettings,
  formatUptime,
  applyFont,
} = mainCore;
const settings = require('../settings');
const { generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys');

// Per-chat tracking so a re-sent menu deletes its own previous button card
// instead of piling up, plus a short per-user cooldown on the BUTTON send
// only (button-mash protection) — never on the guaranteed text reply.
global.toaaMenuLastId = global.toaaMenuLastId || {};
global.toaaMenuCooldown = global.toaaMenuCooldown || {};

module.exports = {
  name: 'menu',
  version: '2.3.0',
  author: 'TOAA',
  commands: {
    'menu': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { prefix, senderNumber, sessionName } = ctx;
        const from = m.key.remoteJid;

        const us = loadUserSettings(sessionName);
        const mode = us.mode || 'public';
        const uptime = formatUptime(Date.now() - global.botStartTime);
        const username = m.pushName || senderNumber;

        const card =
          `╔═════───◯───════╗\n` +
          `┃─── *[⎝ ${applyFont('TOAA', 12)} ⎠]*\n` +
          `┃\n` +
          `┃⤑ *${applyFont('OWNER', 12)}:* ${settings.OWNER_NAME || 'swanky'}\n` +
          `┃⤑ *${applyFont('VERSION', 12)}:* V2.2.1\n` +
          `┃⤑ *${applyFont('PREFIX', 12)}:* [ ${prefix} ]\n` +
          `┃⤑ *${applyFont('USER', 12)}:* ${username}\n` +
          `┃⤑ *${applyFont('TYPE', 12)}:* Plugins.\n` +
          `┃⤑ *${applyFont('RUNTIME', 12)}:* ${uptime}\n` +
          `┃⤑ *${applyFont('MODE', 12)}:* ${mode}\n` +
          `╚═════───◯───════╝\n` +
          `╔═════───◯───════╗\n` +
          `┃─── *[⎝ ${applyFont('ASSISTANT', 12)} ⎠]*\n` +
          `┃⤑ ${applyFont('TOAA', 12)}\n` +
          `┃⤑ ${applyFont('TOAA-MENU', 12)}\n` +
          `╚═════───◯───════╝`;

        // ─── Try the single buttoned card first: the info card itself as the
        // buttonsMessage body, with TOAA-MENU/OWNER attached to the same
        // bubble. Falls back to a guaranteed plain-text send if this fails
        // for any reason (deprecated buttonsMessage rejected, thumbnail
        // fetch failure, etc.) — the menu must never fail to show entirely.
        const lastTime = global.toaaMenuCooldown[senderNumber] || 0;
        const offCooldown = Date.now() - lastTime >= 10000;
        if (offCooldown) global.toaaMenuCooldown[senderNumber] = Date.now();

        let sentButtons = false;

        if (offCooldown) {
          try {
            const menuImg = us.menuImage || settings.MENU_IMAGE;

            // Full-size image banner header, built via Baileys' own media
            // uploader — a real header, not a small location-card thumbnail.
            // Falls back to a plain text header (no image) if no menu image
            // is configured, or if the upload itself fails.
            let imageMedia = null;
            if (menuImg && menuImg.startsWith('http')) {
              try {
                imageMedia = await prepareWAMessageMedia({ image: { url: menuImg } }, { upload: conn.waUploadToServer });
              } catch (e) {
                console.log('[MENU] Image header upload failed, using text header:', e.message);
              }
            }

            const buttonsMessage = {
              contentText: card,
              contextInfo: {
                quotedMessage: {
                  interactiveResponseMessage: {
                    body: { text: 'TOAA', format: 1 },
                    nativeFlowResponseMessage: {
                      name: 'galaxy_message',
                      paramsJson: JSON.stringify({ wa_flow_response_params: { title: 'TOAA' } })
                    }
                  }
                },
                remoteJid: 'status@broadcast',
                participant: conn.user.id
              },
              buttons: [
                { buttonId: `${prefix}toaamenu`, buttonText: { displayText: 'TOAA-MENU' }, type: 1 },
                { buttonId: `${prefix}owner`, buttonText: { displayText: '𝐎𝐖𝐍𝐄𝐑' }, type: 1 }
              ],
              headerType: imageMedia ? 4 : 1,
            };
            if (imageMedia) buttonsMessage.imageMessage = imageMedia.imageMessage;

            const msg = await generateWAMessageFromContent(from, { buttonsMessage }, {});

            const newId = msg.key.id;
            await conn.relayMessage(from, msg.message, { messageId: newId });

            const prevId = global.toaaMenuLastId[from];
            if (prevId) {
              try {
                await conn.sendMessage(from, { delete: { remoteJid: from, fromMe: true, id: prevId } });
              } catch (e) {
                console.log('[MENU] Failed to delete previous menu message:', e.message);
              }
            }
            global.toaaMenuLastId[from] = newId;
            sentButtons = true;
          } catch (e) {
            console.log('[MENU] Button send failed, falling back to plain text:', e.message);
          }
        }

        // ─── Guaranteed fallback — only fires if the buttoned card above
        // didn't send (cooldown active, or the button send failed). ────────
        if (!sentButtons) {
          try {
            await conn.sendMessage(from, { text: card }, { quoted: m });
          } catch (e) {
            console.log('[MENU] Even the plain text card failed to send:', e.message);
          }
        }
      }
    }
  }
};
