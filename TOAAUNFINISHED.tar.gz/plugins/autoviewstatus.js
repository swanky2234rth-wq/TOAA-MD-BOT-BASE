// Auto-converted from legacy registerCmd('autoviewstatus', ...) in main.js
// Category: utilities
const {
  fReply,
  newsletterReply,
  getSessionSetting,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'autoviewstatus',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'autoviewstatus': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  const next = !getSessionSetting(ctx.sessionName, 'autoViewStatus', false);
  setSessionSetting(ctx.sessionName, 'autoViewStatus', next);
  await fReply(conn, m, `*_💈 𝙰𝚞𝚝𝚘 𝚅𝚒𝚎𝚠 𝚂𝚝𝚊𝚝𝚞𝚜: ${next ? 'ON' : 'OFF'}_*`, ctx.sessionName);

      }
    }
  }
};
