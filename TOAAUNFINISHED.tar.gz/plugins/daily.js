// ─── TOAA RPG Daily ─────────
const { errorReply } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const COOLDOWN_MS = 24 * 60 * 60 * 1000;
const EXP_REWARD = 1000;
const COIN_REWARD = 5000;

function msToTime(duration) {
  const hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((duration / (1000 * 60)) % 60);
  const seconds = Math.floor((duration / 1000) % 60);
  return `${hours}h ${minutes}m ${seconds}s`;
}

module.exports = {
  name: 'daily',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'daily': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);
  const lastClaim = user.lastDaily || 0;
  const now = Date.now();

  if (now - lastClaim < COOLDOWN_MS) {
    const remaining = COOLDOWN_MS - (now - lastClaim);
    return errorReply(conn, m, `Easy there — you already claimed today! 😂\n\nNext daily in *${msToTime(remaining)}*.`, sessionName);
  }

  user.lastDaily = now;
  setUser(jid, user);

  addCoin(jid, COIN_REWARD);
  const levelResult = addExp(jid, EXP_REWARD);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🎁', key: m.key } });

  let txt = `DAILY CLAIMED! 🎉✨\n\nToday's payout:\n`;
  txt += `💸 Coin: *+${fmtCoin(COIN_REWARD)}*\n📈 EXP: *+${EXP_REWARD.toLocaleString('en-US')}*\n\n`;
  txt += `Come back tomorrow for another one!`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
