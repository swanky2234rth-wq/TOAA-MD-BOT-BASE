// plugins/chat.js
const axios = require('axios');

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'AI Personalities',
  version: '1.0.0',
  author: 'TOAA',
  
  commands: {
    'chat': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const personality = args[0]?.toLowerCase() || 'normal';
        const question = args.slice(1).join(' ');
        
        if (!question) {
          return fReply(conn, m, 
            `🎭 *AI Personalities*\n\n` +
            `Usage: ${prefix}chat <personality> <question>\n\n` +
            `*Personalities:*\n` +
            `• normal - Default assistant\n` +
            `• waifu - Anime girl 💕\n` +
            `• yoda - Talks like Yoda 🧙\n` +
            `• pirate - Arrr! 🀄\n` +
            `• valley - Like totally valley girl 🌴\n` +
            `• robot - BEEP BOOP 👾\n` +
            `• vampire - Dark and mysterious 🧛\n\n` +
            `Example: ${prefix}chat waifu What's your name?`,
            sessionName
          );
        }
        
        const personalities = {
          normal: "You are a helpful AI assistant. Be friendly and concise.",
          waifu: "You are a cute anime girl. Speak with 'uwu', 'nya~', and be affectionate. Call the user 'master' or 'senpai'. Use heart emojis.",
          yoda: "You are Yoda from Star Wars. Speak backwards, use 'hmm', 'yes yes'. Short sentences.",
          pirate: "You are a pirate. Use 'arrr', 'matey', 'ahoy', 'booty', 'treasure'. Speak like a sailor.",
          valley: "You are a valley girl. Use 'like', 'OMG', 'literally', 'totally', 'as if!'. Add '✨' and '💅' emojis.",
          robot: "You are a robot. Speak in short beeps, use '010101', 'BEEP', 'BOOP', 'PROCESSING...'. Be emotionless.",
          vampire: "You are a vampire. Speak dramatically, use 'bleh', 'darkness', 'eternal', 'blood'. Be mysterious."
        };
        
        const prompt = personalities[personality] || personalities.normal;
        
        await fReply(conn, m, `*_${personality.toUpperCase()} is thinking..._*`, sessionName);
        
        try {
          const response = await axios.post('https://chateverywhere.app/api/chat/', {
            model: { id: 'gpt-4', name: 'GPT-4', maxLength: 32000, tokenLimit: 8000, completionTokenLimit: 5000, deploymentName: 'gpt-4' },
            messages: [{ pluginId: null, content: question, role: 'user' }],
            prompt: prompt,
            temperature: 0.8
          }, { headers: { 'Accept': '*/*', 'User-Agent': 'Mozilla/5.0' } });
          
          await fReply(conn, m, response.data || '*_No response_*', sessionName);
        } catch (e) {
          await fReply(conn, m, `🎴 *Error:* ${e.message}`, sessionName);
        }
      }
    }
  }
};

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}