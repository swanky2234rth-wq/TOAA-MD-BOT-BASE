// Auto-converted from legacy registerCmd('take', ...) in main.js
// Category: media
const {
  downloadMedia,
  fReply,
  getQuotedMsg
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'take',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'take': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {

  const { sessionName, prefix } = ctx;
  
  // Check if replying to a sticker
  const quotedMsg = getQuotedMsg(m);
  const stickerObj = quotedMsg?.stickerMessage || m.message?.stickerMessage;
  
  if (!stickerObj) {
    return fReply(conn, m, `🎴 *Reply to a sticker!*\n\nUsage: ${prefix}take <packname> | <author>\nExample: ${prefix}take My Pack | My Name`, sessionName);
  }
  
  let packname = args[0] || 'TOAA';
  let author = args[1] || ctx.senderNumber;
  
  // Check if using pipe format: "packname | author"
  const fullText = args.join(' ');
  if (fullText.includes('|')) {
    const parts = fullText.split('|');
    packname = parts[0].trim();
    author = parts[1]?.trim() || ctx.senderNumber;
  }
  
  try {
    const stickerBuf = await downloadMedia(stickerObj, 'sticker');
    const { Sticker, StickerTypes } = require('wa-sticker-formatter');
    
    const sticker = new Sticker(stickerBuf, {
      pack: packname,
      author: author,
      type: StickerTypes.FULL,
      quality: 80
    });
    
    await conn.sendMessage(m.key.remoteJid, await sticker.toMessage(), { quoted: m });
    
  } catch (e) {
    await fReply(conn, m, `🎴 *Failed to modify sticker:* ${e.message}`, sessionName);
  }

      }
    }
  }
};
