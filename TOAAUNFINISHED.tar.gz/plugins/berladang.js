// ─── TOAA RPG Field Farming ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed, addItem } = require('../helper/rpg');
const { ITEMS } = require('../helper/rpgItems');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 20;
const COOLDOWN_MS = 180 * 1000;
const cooldowns = new Map();

const CROPS = [
  { item: 'padi', chance: 90, min: 2, max: 8 },
  { item: 'jagung', chance: 70, min: 1, max: 5 },
  { item: 'tomat', chance: 50, min: 1, max: 4 },
  { item: 'wortel', chance: 40, min: 1, max: 3 },
  { item: 'fieldstrawberry', chance: 20, min: 1, max: 2 },
  { item: 'melon', chance: 10, min: 1, max: 1 }
];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'farmwork',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'farmwork': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Field's still resting! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Aching all over from farming! 🥵\n\nField work costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🌾', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Grabbing the hoe, watering the soil... 🌱💧\nHoping for a bountiful harvest today!` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const results = [];
  let totalValue = 0;

  for (const crop of CROPS) {
    if (Math.random() * 100 <= crop.chance) {
      const qty = Math.floor(Math.random() * (crop.max - crop.min + 1)) + crop.min;
      addItem(jid, crop.item, qty);
      const value = qty * (ITEMS[crop.item]?.sell || 0);
      totalValue += value;
      results.push({ item: ITEMS[crop.item], qty, value });
    }
  }

  if (results.length === 0) {
    addItem(jid, 'padi', 1);
    const value = ITEMS.padi.sell;
    results.push({ item: ITEMS.padi, qty: 1, value });
    totalValue = value;
  }

  const expGain = Math.floor(totalValue / 10) + Math.floor(Math.random() * 100);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  let txt = `BIG HARVEST TODAY! 🚜🌾\n\nWow, your field produced a lot:\n`;
  for (const r of results) txt += `• ${r.item.emote} ${r.item.name}: *+${r.qty}* (Est. ${r.value.toLocaleString('en-US')})\n`;
  txt += `\n💰 Est. Total Value: *${totalValue.toLocaleString('en-US')}*\n📈 Farmer EXP: *+${expGain}*\n⚡ Stamina: *-${STAMINA_COST}*\n\n`;
  txt += `Sell your harvest with \`${prefix}sellall\`! 🧺✨`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
