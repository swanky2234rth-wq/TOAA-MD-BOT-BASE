// Auto-converted from legacy registerCmd('gcinfo', ...) in main.js
// Category: group
const {
  fReply,
  normalizeNumber,
  resolveDisplayJid
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'gcinfo',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'gcinfo': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);

  const meta = await conn.groupMetadata(remoteJid);

  // Resolve every admin's jid to its phone-number form (LID-aware) so the
  // mentions actually render as names/numbers instead of raw LID digits.
  const adminEntries = meta.participants
    .filter(p => p.admin)
    .map(p => resolveDisplayJid(p.id, meta.participants));
  const adminMentionText = adminEntries.length
    ? adminEntries.map(jid => `@${jid.split('@')[0]}`).join(', ')
    : 'None';

  // Get group owner/creator
  const ownerRaw = meta.owner || meta.creator || (meta.participants.find(p => p.admin === 'superadmin')?.id);
  const ownerJid = ownerRaw ? resolveDisplayJid(ownerRaw, meta.participants) : null;
  const ownerNumber = ownerJid ? ownerJid.split('@')[0] : 'Unknown';

  // Get creation date if available
  const createdDate = meta.creation ? new Date(meta.creation * 1000).toLocaleDateString() : 'Unknown';

  const mentions = [...new Set([...(ownerJid ? [ownerJid] : []), ...adminEntries])];

  await conn.sendMessage(remoteJid, {
    text:
      `📋 *Group Info*\n\n` +
      `🏷️ Name: ${meta.subject}\n` +
      `🆔 ID: ${remoteJid}\n` +
      `👑 Owner: @${ownerNumber}\n` +
      `👥 Members: ${meta.participants.length}\n` +
      `👮 Admins: ${adminMentionText}\n` +
      `📅 Created: ${createdDate}\n` +
      `📝 Desc: ${meta.desc || 'None'}`,
    mentions
  }, { quoted: m });

      }
    }
  }
};
