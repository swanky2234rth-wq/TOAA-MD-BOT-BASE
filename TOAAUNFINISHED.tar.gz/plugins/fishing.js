// ─── TOAA RPG Fishing ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed, addItem } = require('../helper/rpg');
const { ITEMS } = require('../helper/rpgItems');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 15;
const COOLDOWN_MS = 60 * 1000;
const cooldowns = new Map();

const CATCHES = [
  { item: 'trash', chance: 20, exp: 10 },
  { item: 'fish', chance: 50, exp: 100 },
  { item: 'prawn', chance: 30, exp: 150 },
  { item: 'octopus', chance: 15, exp: 300 },
  { item: 'shark', chance: 5, exp: 800 },
  { item: 'whale', chance: 1, exp: 2000 }
];

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'fishing',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'fishing': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Your line's still out! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m,
      `You're out of stamina! 😭⚡\n\nFishing costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext stamina point in ~${fmtEta(eta)}.`,
      sessionName
    );
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🎣', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Casting the line into the calm water... 🌊🎣\nShh, stay quiet so the fish bite! 🤫👀` }, { quoted: m });

  await new Promise((resolve) => setTimeout(resolve, 4000));

  const sorted = [...CATCHES].sort((a, b) => a.chance - b.chance);
  const rand = Math.random() * 100;
  let caught = sorted[0];
  for (const c of sorted) {
    if (rand <= c.chance) { caught = c; break; }
  }

  addItem(jid, caught.item, 1);
  const levelResult = addExp(jid, caught.exp);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  const item = ITEMS[caught.item];
  let txt = `GOT ONE! Reeling it in! 🎣💦\n\nYou caught:\n`;
  if (caught.item === 'trash') {
    txt += `${item.emote} ${item.name} 🤢\nJust trash this time... at least you got *+${caught.exp} EXP* for keeping the water clean! 😂\n\n`;
  } else {
    txt += `${item.emote} *${item.name}* 🎉✨\nNice catch! You also got *+${caught.exp} EXP*!\n\n`;
  }
  txt += `⚡ Stamina used: *-${STAMINA_COST}*\n\nCheck your bag with inventory — go fish again later! 💖🌊`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
