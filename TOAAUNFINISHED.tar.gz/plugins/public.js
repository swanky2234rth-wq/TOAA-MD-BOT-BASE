// Auto-converted from legacy registerCmd('public', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'public',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'public': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  setSessionSetting(ctx.sessionName, 'mode', 'public');
  await fReply(conn, m, '*_𝙱𝚘𝚝 𝙸𝚜 𝙽𝚘𝚠 𝙿𝚞𝚋𝚕𝚒𝚌_*', ctx.sessionName);

      }
    }
  }
};
