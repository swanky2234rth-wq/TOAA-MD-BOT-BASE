// Auto-converted from legacy registerCmd('getlink', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'getlink',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'getlink': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const code = await conn.groupInviteCode(m.key.remoteJid);
  await fReply(conn, m, `🔗 *Invite Link:*\nhttps://chat.whatsapp.com/${code}`, ctx.sessionName);

      }
    }
  }
};
