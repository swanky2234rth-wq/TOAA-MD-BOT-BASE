// Auto-converted from legacy registerCmd('autolikestatus', ...) in main.js
// Category: utilities
const {
  fReply,
  newsletterReply,
  getSessionSetting,
  setSessionSetting
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'autolikestatus',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'autolikestatus': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  const next = !getSessionSetting(ctx.sessionName, 'autoLikeStatus', false);
  setSessionSetting(ctx.sessionName, 'autoLikeStatus', next);
  await fReply(conn, m, `*_💈 𝙰𝚞𝚝𝚘 𝙻𝚒𝚔𝚎 𝚂𝚝𝚊𝚝𝚞𝚜: ${next ? 'ON' : 'OFF'}_*`, ctx.sessionName);

      }
    }
  }
};
