// plugins/clearconsole.js
console.log('[CLEARCONSOLE] Plugin loaded!');

const { fReply } = require('../main');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

module.exports = {
  name: 'ClearConsole',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'clearconsole': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;

        // ─── OWNER CHECK ──────────────────────────────────────────────────────
        if (!OWNER_NUMBERS.includes(senderNumber)) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        console.clear();
        await fReply(conn, m, `✅ Console cleared!`, sessionName);
      }
    }
  }
};