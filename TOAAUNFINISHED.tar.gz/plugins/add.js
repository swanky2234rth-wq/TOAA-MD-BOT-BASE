// Auto-converted from legacy registerCmd('add', ...) in main.js
// Category: group
const {
  fReply,
  requireAdmin
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'add',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'add': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!requireAdmin(ctx, conn, m)) return;
  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  let target = (args[0] || '').replace(/[^0-9]/g, '');
  if (!target) return fReply(conn, m, `Usage: ${ctx.prefix}add <number>`, ctx.sessionName);
  await conn.groupParticipantsUpdate(remoteJid, [`${target}@s.whatsapp.net`], 'add');
  await fReply(conn, m, `*_💈 ${target} 𝙰𝚍𝚍𝚎𝚍_*`, ctx.sessionName);

      }
    }
  }
};
