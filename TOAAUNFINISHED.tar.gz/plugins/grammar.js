// Auto-converted from legacy registerCmd('grammar', ...) in main.js
// Category: ai
const {
  fReply,
  getMsgText,
  getQuotedMsg
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'grammar',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'grammar': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx;
  const text = args.join(' ').trim() || getMsgText(getQuotedMsg(m) || {});
  if (!text) return fReply(conn, m, `Usage: ${prefix}grammar <text>`, sessionName);
  await fReply(conn, m, '*_💈 𝙲𝚑𝚎𝚌𝚔𝚒𝚗𝚐..._*', sessionName);
  try {
    const response = await axios.post('https://chateverywhere.app/api/chat/', { model: { id: 'gpt-4', name: 'GPT-4', maxLength: 32000, tokenLimit: 8000, completionTokenLimit: 5000, deploymentName: 'gpt-4' }, messages: [{ pluginId: null, content: `Fix grammar and explain corrections:\n\n${text}`, role: 'user' }], prompt: 'You are an expert grammar checker.', temperature: 0.3 }, { headers: { 'Accept': '*/*', 'User-Agent': 'Mozilla/5.0' } });
    await fReply(conn, m, `✏️ *Grammar Check:*\n\n${response.data}`, sessionName);
  } catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
