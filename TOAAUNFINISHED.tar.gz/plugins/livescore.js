// ─── TOAA Live Score (Football, via Goal.com) ─────────
const { errorReply } = require('../main');
const axios = require('axios');

const HEADERS = {
  'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'accept-language': 'en-US,en;q=0.9',
  'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
};

const STATUS_MAP = {
  FIXTURE: 'Not started', LIVE: 'Live', FINISHED: 'Finished',
  POSTPONED: 'Postponed', CANCELLED: 'Cancelled', HALF_TIME: 'Half-time'
};

async function fetchLivescore(edition = 'id') {
  const url = edition === 'id' ? 'https://www.goal.com/id/livescore' : `https://www.goal.com/${edition}/live-scores`;
  const res = await axios.get(url, { headers: HEADERS, timeout: 15000 });
  const match = res.data.match(/__NEXT_DATA__" type="application\/json">(.*?)<\/script>/s);
  if (!match) throw new Error('Could not locate score data.');
  const json = JSON.parse(match[1]);
  const liveScores = json?.props?.pageProps?.content?.liveScores;
  if (!liveScores) throw new Error('No live score data available.');
  return liveScores;
}

function tidyMatches(rawData) {
  return rawData.map(group => ({
    competition: group.competition?.name || '-',
    matches: (group.matches || []).map(mt => ({
      status: STATUS_MAP[mt.status] || mt.status,
      home: mt.teamA?.name,
      away: mt.teamB?.name,
      scoreHome: (typeof mt.score?.teamA === 'object' && mt.score?.teamA !== null)
        ? (mt.score.teamA.current ?? mt.score.teamA.normalTime ?? mt.score.teamA.score ?? '-')
        : (mt.score?.teamA ?? '-'),
      scoreAway: (typeof mt.score?.teamB === 'object' && mt.score?.teamB !== null)
        ? (mt.score.teamB.current ?? mt.score.teamB.normalTime ?? mt.score.teamB.score ?? '-')
        : (mt.score?.teamB ?? '-'),
      redCardsHome: mt.redCards?.teamA ?? 0,
      redCardsAway: mt.redCards?.teamB ?? 0,
      period: (typeof mt.period === 'object' && mt.period !== null) ? (mt.period.name ?? mt.period.short ?? mt.period.long ?? '-') : (mt.period || '')
    }))
  }));
}

module.exports = {
  name: 'livescore',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'livescore': { category: 'info', handler: run },
    'skorbola': { category: 'info', handler: run },
    'livebola': { category: 'info', handler: run },
    'skor': { category: 'info', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

  try {
    const raw = await fetchLivescore('id');
    const tidy = tidyMatches(raw);

    if (!tidy || tidy.length === 0) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `⚽ *LIVE SCORE* ⚽\n\nNo matches currently live or scheduled.`, sessionName);
    }

    let caption = `⚽ *LIVE SCORE TODAY* ⚽\n\n`;
    let count = 0;

    for (const group of tidy) {
      if (count >= 15) break;
      if (group.matches.length === 0) continue;

      caption += `🏆 *${group.competition.toUpperCase()}*\n`;

      for (const mt of group.matches) {
        const redHome = mt.redCardsHome > 0 ? ` 🟥${mt.redCardsHome}` : '';
        const redAway = mt.redCardsAway > 0 ? ` 🟥${mt.redCardsAway}` : '';

        caption += `▪️ ${mt.home}${redHome} *[ ${mt.scoreHome} - ${mt.scoreAway} ]* ${mt.away}${redAway}\n`;
        caption += `   └ ⏳ _Status: ${mt.status}_`;
        if (mt.period) caption += ` | ⏱️ _${mt.period}_`;
        caption += `\n`;
      }
      caption += `\n`;
      count++;
    }

    caption += `_Source: Goal.com_`;

    await conn.sendMessage(m.key.remoteJid, { text: caption.trim() }, { quoted: m });
    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error('[LIVESCORE] Error:', e.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Couldn't fetch live score data right now: ${e.message}`, sessionName);
  }
}
