// Auto-converted from legacy registerCmd('compliment', ...) in main.js
// Category: ai
const {
  resolveTarget,
  resolveDisplayJid
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'compliment',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'compliment': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {

  const { sessionName } = ctx;
  const remoteJid = m.key.remoteJid;
  const rawTarget = resolveTarget(m, args);
  let target = rawTarget;
  if (rawTarget && remoteJid.endsWith('@g.us')) {
    const meta = await conn.groupMetadata(remoteJid).catch(() => null);
    if (meta?.participants) target = resolveDisplayJid(rawTarget.includes('@') ? rawTarget : `${rawTarget}@s.whatsapp.net`, meta.participants);
  }
  const targetNum = target ? target.split('@')[0] : null;
  const compliments = ["You light up every room! ✨","Your smile could end wars. 😊","You're genuinely one of a kind! 🌟","The world is better with you in it. 💫","Your vibe is absolutely immaculate. 🔥"];
  await conn.sendMessage(remoteJid, { text: `🪔 *Compliment${targetNum ? ` for @${targetNum}` : ''}*\n\n${compliments[Math.floor(Math.random()*compliments.length)]}`, mentions: target ? [target.includes('@') ? target : `${target}@s.whatsapp.net`] : [] }, { quoted: m });

      }
    }
  }
};
