// Auto-converted from legacy registerCmd('setfonts', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  plainReply,
  setSessionSetting,
  applyFont,
  FONT_COUNT
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'setfonts',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'setfonts': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  const num = parseInt(args[0]);
  if (!num || num < 1 || num > FONT_COUNT) {
    return plainReply(conn, m, `Usage: ${ctx.prefix}setfonts <1-${FONT_COUNT}>`);
  }
  setSessionSetting(ctx.sessionName, 'font', num);
  const sample = num > 1 ? applyFont('Font active! Hello World 123', num) : 'Font active! Hello World 123 (Normal)';
  await fReply(conn, m, `💈 *_${sample}_*`, ctx.sessionName);

      }
    }
  }
};
