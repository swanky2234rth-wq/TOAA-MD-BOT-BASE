// ─── TOAA RPG Daily Challenge ─────────
// NOTE: legacy source tracked live progress against specific actions
// (kill/fish/mine/harvest/craft/earn/expedition counters) that would
// require wiring a progress-increment call into every other RPG plugin
// already shipped. Simplified to a once-a-day flat bonus claim instead —
// still rotates a random "theme" for flavor, but doesn't gate on progress
// that nothing in this project currently tracks.
const { errorReply } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const CHALLENGES = [
  { name: '⚔️ Slay Some Monsters', reward: { gold: 500, exp: 200 } },
  { name: '🎣 Catch Some Fish', reward: { gold: 300, exp: 150 } },
  { name: '⛏️ Mine Some Ore', reward: { gold: 400, exp: 180 } },
  { name: '🌱 Gather Some Materials', reward: { gold: 350, exp: 160 } },
  { name: '🧪 Brew Some Potions', reward: { gold: 450, exp: 190 } },
  { name: '💰 Earn Some Coin', reward: { gold: 500, exp: 250 } }
];

function getTodayChallenge() {
  const dayIndex = new Date().getDate() % CHALLENGES.length;
  return { ...CHALLENGES[dayIndex], date: new Date().toDateString() };
}

module.exports = {
  name: 'challenge',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'challenge': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);
  const today = new Date().toDateString();
  const challenge = getTodayChallenge();
  const alreadyClaimed = user.lastChallengeClaim === today;

  const action = args[0]?.toLowerCase();

  if (action === 'claim') {
    if (alreadyClaimed) {
      return errorReply(conn, m, `You already claimed today's Guild bonus! New one shows up tomorrow. 😉`, sessionName);
    }

    user.lastChallengeClaim = today;
    setUser(jid, user);

    addCoin(jid, challenge.reward.gold);
    const levelResult = addExp(jid, challenge.reward.exp);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🎉', key: m.key } });
    await conn.sendMessage(m.key.remoteJid, {
      text: `🎉 *DAILY CHALLENGE CLAIMED!!* 🎉\n\nNice work! Here's your Guild bonus:\n💰 Coin: *+${fmtCoin(challenge.reward.gold)}*\n✨ EXP: *+${challenge.reward.exp}*\n\n> _New challenge tomorrow!_`
    }, { quoted: m });

    return notifyLevelUp(conn, m, jid, levelResult);
  }

  let txt = `📋 *DAILY GUILD CHALLENGE* 📋\n\nDo today's task for some extra spending money!\n\n`;
  txt += `*Today's task:*\n🎯 *${challenge.name}*\n`;
  txt += `Status: ${alreadyClaimed ? '✅ *Already claimed*' : '⏳ *Available*'}\n\n`;
  txt += `*🎁 Reward:*\n💰 Coin: *${fmtCoin(challenge.reward.gold)}*\n✨ EXP: *${challenge.reward.exp}*\n\n`;
  txt += alreadyClaimed
    ? `> ✅ You're all set! Tomorrow brings a new one.`
    : `> 💡 Type \`${prefix}challenge claim\` to grab today's reward!`;

  return errorReply(conn, m, txt, sessionName);
}
