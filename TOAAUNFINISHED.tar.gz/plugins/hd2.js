// plugins/hd2.js
const axios = require('axios');
const { getSessionSetting } = require('../helper/function');
const { applyFont } = require('../helper/fonts');

async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function errorReply(conn, m, text, sessionName) { await fReply(conn, m, `❌ ${text}`, sessionName); }

module.exports = {
  name: 'HD Image Enhancer (URL)',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    'hd2': {
      category: 'media',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const text = args.join(' ').trim();

        if (!text)
          return errorReply(nuell, hex, `Usage: ${prefix}hd2 <image_url>\nExample: ${prefix}hd2 https://example.com/image.jpg`, sessionName);
        if (!text.startsWith('http://') && !text.startsWith('https://'))
          return errorReply(nuell, hex, 'Invalid URL! Please provide a valid image URL.', sessionName);

        await fReply(nuell, hex, '*_💈 Enhancing image to HD..._*', sessionName);
        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '🔄', key: hex.key } });

        const apis = [
          `https://api.siputzx.my.id/api/iloveimg/upscale?image=${encodeURIComponent(text)}`,
          `https://api.remini.ai/upscale?url=${encodeURIComponent(text)}`
        ];

        for (const apiUrl of apis) {
          try {
            const response = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 60000, headers: { 'User-Agent': 'Mozilla/5.0' } });
            await nuell.sendMessage(hex.key.remoteJid, {
              image: Buffer.from(response.data),
              caption: '✅ Image enhanced to HD!'
            }, { quoted: hex });
            await nuell.sendMessage(hex.key.remoteJid, { react: { text: '✅', key: hex.key } });
            return;
          } catch (e) {
            console.log('[HD2] API failed:', e.message);
          }
        }

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '❌', key: hex.key } });
        await errorReply(nuell, hex, 'Failed to enhance image. Try again later.', sessionName);
      }
    },

    'tohd2': {
      category: 'media',
      handler: async (nuell, hex, args, ctx) => {
        await module.exports.commands.hd2.handler(nuell, hex, args, ctx);
      }
    }
  }
};
