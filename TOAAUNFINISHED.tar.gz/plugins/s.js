// plugins/s.js — aliases for the sticker command (kept separate from the
// canonical sticker.js implementation, which already handles both images
// and video via a pure-buffer ffmpeg pipeline — that one avoids the
// wa-sticker-formatter native-binary issues seen on Pterodactyl, so these
// aliases just delegate to it instead of duplicating sticker logic here).

module.exports = {
  name: 'Sticker Aliases',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    's': {
      category: 'media',
      handler: async (nuell, hex, args, ctx) => {
        const mainCore = require('../main');
        await mainCore.COMMANDS.sticker.handler(nuell, hex, args, ctx);
      }
    },
    'sticker': {
      category: 'media',
      handler: async (nuell, hex, args, ctx) => {
        const mainCore = require('../main');
        await mainCore.COMMANDS.sticker.handler(nuell, hex, args, ctx);
      }
    }
  }
};
