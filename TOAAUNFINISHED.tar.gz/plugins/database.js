// plugins/database.js
console.log('[DATABASE] Plugin loaded!');

const fs = require('fs');
const path = require('path');
const { fReply, errorReply } = require('../main');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

module.exports = {
  name: 'Database',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'db': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;

        // ─── OWNER CHECK ──────────────────────────────────────────────────────
        if (!OWNER_NUMBERS.includes(senderNumber)) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        const dbDir = path.join(__dirname, '..', 'database');

        if (!fs.existsSync(dbDir)) {
          return fReply(conn, m, `📂 *Database*\n\nNo database files found.`, sessionName);
        }

        const files = fs.readdirSync(dbDir);
        let output = `📊 *Database Files*\n\n`;

        for (const file of files) {
          const filePath = path.join(dbDir, file);
          const stats = fs.statSync(filePath);
          const size = (stats.size / 1024).toFixed(2);
          output += `📄 ${file} (${size}KB)\n`;
        }

        await fReply(conn, m, output, sessionName);
      }
    }
  }
};