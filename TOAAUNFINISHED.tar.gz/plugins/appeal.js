// Auto-converted from legacy registerCmd('appeal', ...) in main.js
// Category: utilities
const {
  fReply,
  generateAppealEmail,
  initEmailTransporter,
  saveAppealRecord
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'appeal',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'appeal': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

    const { sessionName, prefix, senderNumber } = ctx;
    const bannedNumber = args[0]?.replace(/[^0-9]/g, '');
    
    if (!bannedNumber) {
        return fReply(conn, m,
            `🀄 *_WhatsApp Ban Appeal System_*\n\n` +
            `📌 *Usage:* ${prefix}appeal <banned_number>\n` +
            `💡 *Example:* ${prefix}appeal 2347793𝘹𝘹𝘹𝘹𝘹\n\n.`,
            sessionName
        );
    }
    
    await fReply(conn, m, `*_📨 Processing appeal for +${bannedNumber}..._*`, sessionName);
    
    try {
        const appealText = generateAppealEmail(bannedNumber, senderNumber);
        
        // Try to send email automatically
        const transporter = initEmailTransporter();
        let emailSent = false;
        let emailId = null;
        
        if (transporter && settings.SENDER_EMAIL) {
            try {
                const mailOptions = {
                    from: `"TOAA Appeal" <${settings.SENDER_EMAIL}>`,
                    to: 'smb_web@support.whatsapp.com',
                    cc: 'smb@support.whatsapp.com',
                    subject: `Appeal for Banned WhatsApp Number: +${bannedNumber}`,
                    text: appealText,
                    html: appealText.replace(/\n/g, '<br>')
                };
                const info = await transporter.sendMail(mailOptions);
                emailSent = true;
                emailId = info.messageId;
                console.log(`[APPEAL] Email sent: ${info.messageId}`);
            } catch (emailErr) {
                console.error('[APPEAL] Email failed:', emailErr.message);
            }
        }
        
        let responseText = `📨 *𝘈𝘗𝘗𝘌𝘈𝘓 𝘚𝘠𝘚𝘛𝘌𝘔 𝘚𝘛𝘈𝘛𝘜𝘚*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        if (emailSent) {
            responseText += ` *_۞ 𝘜𝘯𝘣𝘢𝘯 𝘙𝘦𝘲𝘶𝘦𝘴𝘵 𝘚𝘦𝘯𝘵_*\n` +
                           `📅 Time: ${new Date().toLocaleString()}\n\n` +
                           `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                           `• WhatsApp support responds in 3-7 business days\n` +
                           `• Do NOT submit multiple appeals\n` +
                           `• Keep +${bannedNumber} active for SMS verification\n\n` +
                           `📊 *Check status:* ${prefix}appealstatus ${bannedNumber}`;
        } else {
            responseText += `⚠️ *EMAIL NOT SENT*\n` +
                           `📧 Please manually email to: smb_web@support.whatsapp.com\n` +
                           `📝 Copy the appeal text below.\n\n` +
                           `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                           `📝 *APPEAL TEXT (Copy this)*\n` +
                           `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
                           `${appealText}\n\n` +
                           `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                           `📌 *After sending, use:* ${prefix}appealstatus ${bannedNumber} to track.`;
        }
        
        await conn.sendMessage(m.key.remoteJid, { text: responseText }, { quoted: m });
        
        await saveAppealRecord(bannedNumber, senderNumber, emailId, appealText);
        await conn.sendMessage(m.key.remoteJid, { react: { text: '🧩', key: m.key } });
        
    } catch (err) {
        console.error('[APPEAL] Error:', err);
        await conn.sendMessage(m.key.remoteJid, { react: { text: '🎴', key: m.key } });
        await fReply(conn, m, `🎴 *Failed:* ${err.message}`, sessionName);
    }

      }
    }
  }
};
