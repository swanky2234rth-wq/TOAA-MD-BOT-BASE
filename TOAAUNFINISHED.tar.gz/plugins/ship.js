// plugins/ship.js
const { getMentioned, getQuotedCtx, resolveDisplayJid } = require('../helper/function');

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'Ship',
  version: '1.0.0',
  author: 'TOAA',
  
  commands: {
    'ship': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const remoteJid = m.key.remoteJid;
        const mentioned = getMentioned(m);

        let user1, user2;
        if (mentioned.length >= 2) {
          user1 = mentioned[0];
          user2 = mentioned[1];
        } else if (mentioned.length === 1) {
          user1 = mentioned[0];
          user2 = m.key.participant || m.key.remoteJid;
        } else {
          const quotedCtx = getQuotedCtx(m);
          if (quotedCtx?.participant) {
            user1 = quotedCtx.participant;
            user2 = m.key.participant || m.key.remoteJid;
          } else {
            return fReply(conn, m, `Usage: ${prefix}ship @user1 @user2`, sessionName);
          }
        }

        const num1 = user1.split('@')[0];
        const num2 = user2.split('@')[0];

        // Resolve LID-format targets against the group's participant list so
        // mentions/text show a real number instead of raw LID digits.
        let resolved1 = user1, resolved2 = user2;
        if (remoteJid.endsWith('@g.us')) {
          const meta = await conn.groupMetadata(remoteJid).catch(() => null);
          if (meta?.participants) {
            resolved1 = resolveDisplayJid(user1, meta.participants);
            resolved2 = resolveDisplayJid(user2, meta.participants);
          }
        }
        const dispNum1 = resolved1.split('@')[0];
        const dispNum2 = resolved2.split('@')[0];

        // Deterministic so same pair always gets same %
        const seed = (num1 + num2).split('').reduce((a, c) => a + c.charCodeAt(0), 0);
        const percent = seed % 101;

        let emoji, verdict;
        if (percent >= 90)      { emoji = '💘'; verdict = 'SOULMATES!! 🔥'; }
        else if (percent >= 75) { emoji = '❤️'; verdict = 'Perfect match!'; }
        else if (percent >= 60) { emoji = '💕'; verdict = 'Great couple!'; }
        else if (percent >= 45) { emoji = '💞'; verdict = 'Pretty good!'; }
        else if (percent >= 30) { emoji = '💛'; verdict = 'Could work...'; }
        else if (percent >= 15) { emoji = '🤔'; verdict = 'Needs effort.'; }
        else                    { emoji = '💔'; verdict = 'Not a match.'; }

        const filled = Math.floor(percent / 10);
        const bar = '█'.repeat(filled) + '░'.repeat(10 - filled);

        await conn.sendMessage(remoteJid, {
          text:
            `${emoji} *𝚂𝙷𝙸𝙿 𝙼𝙴𝚃𝙴𝚁*\n\n` +
            `👤 @${dispNum1}\n` +
            `👤 @${dispNum2}\n\n` +
            `❤️ [${bar}] *${percent}%*\n\n` +
            `💬 *${verdict}*`,
          mentions: [resolved1, resolved2]
        }, { quoted: m });
      }
    }
  }
};