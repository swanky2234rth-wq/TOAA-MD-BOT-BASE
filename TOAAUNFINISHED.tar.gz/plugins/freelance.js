// ─── TOAA RPG Freelance ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 25;
const COOLDOWN_MS = 200 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'freelance',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'freelance': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still on a client call! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Brain's fried thinking about bugs! 🤯\n\nFreelancing costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '💻', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Typing away, designing on the laptop... ⌨️\nHope they don't ask for revisions! 🙏` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 4000));

  const gacha = Math.random();

  if (gacha < 0.2) {
    await conn.sendMessage(m.key.remoteJid, { react: { text: '📉', key: m.key } });
    return conn.sendMessage(m.key.remoteJid, {
      text: `CLIENT GHOSTED WITHOUT PAYING! 📉😡\n\nWorked all-nighters for 3 days straight, and they just vanished!\n💵 Payment: 0\n⚡ Stamina lost: -${STAMINA_COST}\n\nOuch. Always get a deposit next time! 😭`
    }, { quoted: m });
  }

  if (gacha > 0.85) {
    const payment = Math.floor(Math.random() * 10) + 5;
    const totalPay = payment * 1000;

    addCoin(jid, totalPay);
    const expGain = Math.floor(totalPay / 30);
    const levelResult = addExp(jid, expGain);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '💸', key: m.key } });
    await conn.sendMessage(m.key.remoteJid, {
      text: `PAID IN FOREIGN CURRENCY!! 💸✨\n\nAn overseas client loved the work and paid $${payment}!\n💵 Payment: *+${fmtCoin(totalPay)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nLiving that international-client life! 🤑`
    }, { quoted: m });
    return notifyLevelUp(conn, m, jid, levelResult);
  }

  const earning = Math.floor(Math.random() * 40000) + 15000;
  addCoin(jid, earning);
  const expGain = Math.floor(earning / 20);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, {
    text: `PROJECT DELIVERED AND APPROVED! 💻✨\n\n💵 Local payment: *+${fmtCoin(earning)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nEnough for a decent coffee! ☕`
  }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
