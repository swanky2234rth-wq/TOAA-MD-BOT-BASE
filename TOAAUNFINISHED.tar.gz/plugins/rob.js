// ─── TOAA RPG Rob ─────────
const { errorReply, resolveTarget } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed } = require('../helper/rpg');
const { getCoin, addCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const COOLDOWN_MS = 600 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'rob',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'rob': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const target = resolveTarget(m, args);
  if (!target) {
    return errorReply(conn, m, `Who are we robbing? 🦹‍♂️🔪\nTag or reply to your target!\nExample: \`${prefix}rob @user\``, sessionName);
  }

  if (target === jid) {
    return errorReply(conn, m, `Robbing your own wallet? That's just sad. 😂❌`, sessionName);
  }

  const victimCoin = getCoin(target);
  if (victimCoin < 1000) {
    return errorReply(conn, m, `Your target's broke! Under 1,000 coin — not worth the risk. Find a richer mark. 😤`, sessionName);
  }

  const robber = getUser(jid);
  if (robber.health < 30) {
    return errorReply(conn, m, `You're barely standing! 🤒\nNeed at least *30 HP* to rob someone, you've got *${robber.health}*. Heal up first!`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Lay low for a bit! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  cooldowns.set(jid, Date.now());

  const targetNum = target.split('@')[0];

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🦹', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `*Ssshhh...* Hiding in a dark alley, waiting for the target to walk by... 🦹‍♂️🔪` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const isSuccess = Math.random() < 0.4;

  if (isSuccess) {
    const maxSteal = Math.floor(victimCoin * 0.3);
    const stolen = Math.floor(Math.random() * maxSteal) + 1000;

    removeCoin(target, stolen);
    addCoin(jid, stolen);

    const expGain = 300;
    const levelResult = addExp(jid, expGain);

    let txt = `SUCCESSFUL HIT! TARGET ROBBED! 🦹‍♂️💰\n\nYou scared @${targetNum} half to death!\n`;
    txt += `Loot: *+${fmtCoin(stolen)}*\nBonus EXP: *+${expGain}*\n\n`;
    txt += `*Run before the cops show up!!!* 🚓💨`;

    await conn.sendMessage(m.key.remoteJid, { text: txt, mentions: [target] }, { quoted: m });
    await notifyLevelUp(conn, m, jid, levelResult);
  } else {
    const fine = Math.floor(Math.random() * 10000) + 5000;
    const balance = getCoin(jid);
    const actualFine = Math.min(fine, balance);
    const healthLoss = 25;

    removeCoin(jid, actualFine);

    const fresh = getUser(jid);
    fresh.health = Math.max(0, fresh.health - healthLoss);
    setUser(jid, fresh);

    let txt = `BUSTED BY THE NEIGHBORHOOD!! 🚨🤬\n\nInstead of loot, you got caught red-handed and beaten up by a mob!\n`;
    txt += `💸 Seized: *-${fmtCoin(actualFine)}*\n🤕 Beat up: *-${healthLoss} HP*\n\n`;
    txt += `*Ouch. Don't mess around here again!* 🤣`;

    await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });
  }
}
