// plugins/song.js
console.log('[PLAY] Plugin loaded!');

const axios = require('axios');
const { fReply, errorReply } = require('../main');

function buildLoadingCard({ title, artist, duration }) {
  return (
    `╔═━═━═━═━═━═━═━═━═━╗\n` +
    `║  「⎝☆ 𝙼𝚄𝚂𝙸𝙲 𝙻𝙾𝙰𝙳𝙸𝙽𝙶...⎠」\n` +
    `║ ᴀʀᴛɪsᴛ : ${artist || 'Unknown'}\n` +
    `║ ᴛɪᴛʟᴇ : ${title || 'Unknown'}\n` +
    `║ ᴅᴜʀᴀᴛɪᴏɴ : ${duration || 'Unknown'}\n` +
    `║                  \`𝖉𝖔𝖜𝖓𝖑𝖆𝖉𝖔𝖎𝖓𝖌....\`\n` +
    `╚═━═━═━═━═━═━═━═━═━╝`
  );
}

module.exports = {
  name: 'Play',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'play': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const remoteJid = m.key.remoteJid;
        const query = args.join(' ');

        if (!query) {
          return fReply(conn, m, 
            `🎵 *SoundCloud Player*\n\n` +
            `Usage: *${prefix}play <song name>*\n` +
            `Example: *${prefix}play Lil Tony Official - Count me out*\n\n` +
            `🎶 Searches and plays from SoundCloud`,
            sessionName
          );
        }

        await conn.sendMessage(remoteJid, { react: { text: '🔍', key: m.key } });

        try {
          // ─── API Call ──────────────────────────────────────────────────────
          const url = `https://api-faa.my.id/faa/soundcloud-play?query=${encodeURIComponent(query)}`;
          const { data } = await axios.get(url, { timeout: 30000 });

          // ─── Check Response ───────────────────────────────────────────────
          if (!data.status || !data.result) {
            throw new Error('No results found for your query.');
          }

          const result = data.result;
          
          // ─── Check if we have a download URL ─────────────────────────────
          if (!result.download_url) {
            throw new Error('No download URL found for this track.');
          }

          // ─── Format Duration ──────────────────────────────────────────────
          const duration = result.duration ? formatDuration(result.duration) : 'Unknown';

          // ─── Send Loading Card ────────────────────────────────────────────
          await conn.sendMessage(remoteJid, {
            text: buildLoadingCard({
              title: result.title,
              artist: result.user,
              duration
            })
          }, { quoted: m });

          // ─── Download and Send Audio ──────────────────────────────────────
          const audioResponse = await axios({
            method: 'GET',
            url: result.download_url,
            responseType: 'arraybuffer',
            timeout: 60000
          });

          const audioBuffer = Buffer.from(audioResponse.data);

          await conn.sendMessage(remoteJid, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${result.title || 'soundcloud'}.mp3`,
            ptt: false
          }, { quoted: m });

          await conn.sendMessage(remoteJid, { react: { text: '✅', key: m.key } });

        } catch (error) {
          console.error('[PLAY] Error:', error.message);
          
          if (error.code === 'ECONNABORTED') {
            await errorReply(conn, m, `⏰ Request timed out. Please try again.`, sessionName);
          } else if (error.response?.status === 404) {
            await errorReply(conn, m, `❌ No results found for: *${query}*`, sessionName);
          } else {
            await errorReply(conn, m, `❌ Failed to play: ${error.message}`, sessionName);
          }
          
          await conn.sendMessage(remoteJid, { react: { text: '❌', key: m.key } });
        }
      }
    }
  }
};

// ─── Helper Functions ─────────────────────────────────────────────────────────

function formatDuration(seconds) {
  if (!seconds || seconds === 0) return 'Unknown';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
