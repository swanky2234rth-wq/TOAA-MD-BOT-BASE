const backup = require('../helper/backup');

module.exports = {
  name: 'savedatabase',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'savedatabase': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner } = ctx;
        const mainCore = require('../main');
        if (!isOwner) return mainCore.unauthorizedReply(conn, m, sessionName);

        const snap = backup.saveSessionBackup(sessionName);
        await conn.sendMessage(m.key.remoteJid, {
          text: `✅ Database saved!\n\n🕐 ${new Date(snap.savedAt).toLocaleString()}\n\n_This also happens automatically every 30 minutes._`
        }, { quoted: m });
      }
    }
  }
};
