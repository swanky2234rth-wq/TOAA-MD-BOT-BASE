// ─── TOAA Instagram Stalk ─────────
const { errorReply } = require('../main');
const settings = require('../settings');
const axios = require('axios');

const FIREFLY_KEY_PRIMARY = settings.FIREFLY_API_KEY || process.env.FIREFLY_API_KEY || 'OurinNextGen';
const FIREFLY_KEY_FALLBACK = settings.FIREFLY_API_KEY_FALLBACK || process.env.FIREFLY_API_KEY_FALLBACK || '';

function shortNum(num) {
  if (!num) return '0';
  num = parseInt(num);
  if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(1).replace('.0', '') + 'B';
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(1).replace('.0', '') + 'M';
  if (num >= 1_000) return (num / 1_000).toFixed(1).replace('.0', '') + 'K';
  return num.toString();
}

async function fetchWithFallback(pathAndQuery) {
  try {
    const res = await axios.get(`https://firefly.maiku.my.id${pathAndQuery}&apikey=${FIREFLY_KEY_PRIMARY}`, { timeout: 30000 });
    if (res.data?.status) return res.data;
  } catch (e) {}

  if (FIREFLY_KEY_FALLBACK) {
    const res = await axios.get(`https://firefly.maiku.my.id${pathAndQuery}&apikey=${FIREFLY_KEY_FALLBACK}`, { timeout: 30000 });
    return res.data;
  }
  return null;
}

module.exports = {
  name: 'igstalk',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'igstalk': {
      category: 'stalker',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const username = args[0]?.replace('@', '').trim();

        if (!username) {
          return errorReply(conn, m, `📸 *Instagram Stalk*\n\nUsage: ${prefix}igstalk <username>\nExample: ${prefix}igstalk cristiano`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🔍', key: m.key } });

        try {
          const data = await fetchWithFallback(`/api/stalk-instagram?username=${encodeURIComponent(username)}`);
          const d = data?.data;

          if (!data?.status || !d?.username) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Account @${username} not found.`, sessionName);
          }

          const caption = `📸 *INSTAGRAM STALK*\n\n` +
            `👤 *Username:* ${d.username}\n` +
            `📛 *Name:* ${d.full_name || '-'}\n` +
            `✅ *Verified:* ${d.is_verified ? 'Yes' : 'No'}\n` +
            `🔒 *Private:* ${d.is_private ? 'Yes' : 'No'}\n\n` +
            `👥 *Followers:* ${shortNum(d.stats?.followers)}\n` +
            `👤 *Following:* ${shortNum(d.stats?.following)}\n` +
            `📷 *Posts:* ${shortNum(d.stats?.posts)}\n\n` +
            `📝 *Bio:*\n${d.bio || '-'}\n\n` +
            `🔗 https://instagram.com/${d.username}`;

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

          if (d.profile_pic) {
            await conn.sendMessage(m.key.remoteJid, { image: { url: d.profile_pic }, caption }, { quoted: m });
          } else {
            await errorReply(conn, m, caption, sessionName);
          }

        } catch (error) {
          console.error('[IGSTALK] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
        }
      }
    }
  }
};
