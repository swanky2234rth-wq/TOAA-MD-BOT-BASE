const mainCore = require('../main');
const { errorReply } = mainCore;
const badwords = require('../helper/badwords');

module.exports = {
  name: 'antibadword',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'antibadword': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isAdmin, isOwner, prefix } = ctx;
        const remoteJid = m.key.remoteJid;
        if (!remoteJid.endsWith('@g.us')) return errorReply(conn, m, `Groups only.`, sessionName);
        if (!isAdmin && !isOwner) return mainCore.unauthorizedReply(conn, m, sessionName);

        const sub = (args[0] || '').toLowerCase();

        if (sub === 'on' || sub === 'off') {
          badwords.setEnabled(remoteJid, sub === 'on');
          return conn.sendMessage(m.key.remoteJid, { text: `Antibadword: ${sub.toUpperCase()}` }, { quoted: m });
        }

        if (sub === 'add') {
          const word = args.slice(1).join(' ').trim();
          if (!word) return errorReply(conn, m, `Usage: ${prefix}antibadword add <word>`, sessionName);
          badwords.addWord(remoteJid, word);
          return conn.sendMessage(m.key.remoteJid, { text: `✅ Added "${word}" to the bad word list.` }, { quoted: m });
        }

        if (sub === 'remove') {
          const word = args.slice(1).join(' ').trim();
          if (!word) return errorReply(conn, m, `Usage: ${prefix}antibadword remove <word>`, sessionName);
          badwords.removeWord(remoteJid, word);
          return conn.sendMessage(m.key.remoteJid, { text: `✅ Removed "${word}" from the bad word list.` }, { quoted: m });
        }

        if (sub === 'list') {
          const cfg = badwords.getGroupConfig(remoteJid);
          const list = cfg.words.length ? cfg.words.join(', ') : 'None set.';
          return conn.sendMessage(m.key.remoteJid, {
            text: `🚫 *Antibadword*\n\nStatus: ${cfg.enabled ? '🟢 ON' : '🔴 OFF'}\nWords: ${list}`
          }, { quoted: m });
        }

        await conn.sendMessage(m.key.remoteJid, {
          text: `🚫 *Antibadword Usage*\n\n` +
            `${prefix}antibadword on/off — toggle filtering\n` +
            `${prefix}antibadword add <word> — ban a word\n` +
            `${prefix}antibadword remove <word> — unban a word\n` +
            `${prefix}antibadword list — show current settings\n\n` +
            `3 warnings and the user gets removed.`
        }, { quoted: m });
      }
    }
  }
};
