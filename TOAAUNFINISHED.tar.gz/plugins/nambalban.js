// ─── TOAA RPG Tire Repair ─────────
const { errorReply } = require('../main');
const { getUser, setUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 14;
const COOLDOWN_MS = 150 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'tirerepair',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'tirerepair': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Still cleaning the shop! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Air pump's jammed, hands are calloused! 🤕\n\nTire repair costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🛠️', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Sssshh... checking for the leak with soapy water... 🫧\nFound a nail stuck in there! 📍` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const gacha = Math.random();

  if (gacha < 0.15) {
    const healthLoss = 15;
    const fresh = getUser(jid);
    fresh.health = Math.max(0, fresh.health - healthLoss);
    setUser(jid, fresh);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '💥', key: m.key } });
    return conn.sendMessage(m.key.remoteJid, {
      text: `BOOM! THE TIRE EXPLODED! 💥😭\n\nYou pumped too hard and that truck tire blew up right in your face!\n💔 HP lost: -${healthLoss}\n⚡ Stamina: -${STAMINA_COST}\n💵 Earnings: 0\n\nFace covered in soot, rough day! 💀`
    }, { quoted: m });
  }

  const earning = Math.floor(Math.random() * 20000) + 10000;
  addCoin(jid, earning);
  const expGain = Math.floor(earning / 25);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, {
    text: `TIRE FIXED! 🛠️✨\n\n💵 Earnings: *+${fmtCoin(earning)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nHope they don't get another flat! 💨`
  }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
