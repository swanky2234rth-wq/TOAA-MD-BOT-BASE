// Auto-converted from legacy registerCmd('roast', ...) in main.js
// Category: ai
const {
  fReply,
  resolveTarget,
  resolveDisplayJid
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'roast',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'roast': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {

  const { sessionName } = ctx;
  const remoteJid = m.key.remoteJid;
  const rawTarget = resolveTarget(m, args);
  let target = rawTarget;
  if (rawTarget && remoteJid.endsWith('@g.us')) {
    const meta = await conn.groupMetadata(remoteJid).catch(() => null);
    if (meta?.participants) target = resolveDisplayJid(rawTarget.includes('@') ? rawTarget : `${rawTarget}@s.whatsapp.net`, meta.participants);
  }
  const targetNum = target ? target.split('@')[0] : null;
  try {
    const { data } = await axios.get('https://api.siputzx.my.id/api/ai/roast');
    const roast = data.data || data.result || 'Your existence is a participation trophy.';
    await conn.sendMessage(remoteJid, { text: `🀄 *Roast${targetNum ? ` for @${targetNum}` : ''}*\n\n${roast}`, mentions: target ? [target.includes('@') ? target : `${target}@s.whatsapp.net`] : [] }, { quoted: m });
  } catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
