// ─── TOAA Image Style Transforms (3D / Cartoon / Chibi / Manga) ─────────
const { buildStyleCommand } = require('../helper/styleCommandFactory');

const PROMPT_3D = `Transform this image into a high-quality 3D rendered style like Pixar or DreamWorks CGI. Apply realistic lighting, smooth textures, and that polished 3D animated movie look. Keep the original composition but make it look like a frame from a modern 3D animated film with subsurface scattering on skin, detailed hair, and cinematic lighting.`;

const PROMPT_CARTOON = `Transform this image into a vibrant cartoon style like Disney or Pixar animation. Apply bold colors, smooth shading, exaggerated features, and that playful cartoon aesthetic. Keep the original composition but make it look like a frame from an animated movie with clean lines, expressive faces, and bright cheerful colors.`;

const PROMPT_CHIBI = `Transform into chibi style, big head and small body proportions, cute expression, big sparkling eyes, smooth shading, soft lighting, highly detailed, high quality`;

const PROMPT_MANGA = `Transform this image into Japanese manga style illustration. Apply black and white manga aesthetics with dramatic shading, speed lines, expressive eyes, and detailed screentones. Keep the original composition but convert it to look like a page from a Japanese manga with bold ink lines.`;

module.exports = {
  name: 'imageStyles',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'to3d': { category: 'ai', handler: buildStyleCommand('To 3D', '🎮', PROMPT_3D) },
    'tocartoon': { category: 'ai', handler: buildStyleCommand('To Cartoon', '🎨', PROMPT_CARTOON) },
    'tochibi': { category: 'ai', handler: buildStyleCommand('To Chibi', '✨', PROMPT_CHIBI) },
    'tomanga': { category: 'ai', handler: buildStyleCommand('To Manga', '📖', PROMPT_MANGA) }
  }
};
