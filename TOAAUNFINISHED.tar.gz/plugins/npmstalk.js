// ─── TOAA NPM Stalk ─────────
const { errorReply } = require('../main');
const axios = require('axios');

function shortNum(num) {
  if (!num) return '0';
  num = parseInt(num);
  if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(1).replace('.0', '') + 'B';
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(1).replace('.0', '') + 'M';
  if (num >= 1_000) return (num / 1_000).toFixed(1).replace('.0', '') + 'K';
  return num.toString();
}

module.exports = {
  name: 'npmstalk',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'npmstalk': {
      category: 'stalker',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const username = args[0]?.trim();

        if (!username) {
          return errorReply(conn, m, `📦 *NPM Stalk*\n\nUsage: ${prefix}npmstalk <username>\nExample: ${prefix}npmstalk sindresorhus`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🔍', key: m.key } });

        try {
          // NOTE: swapped the source's firefly.maiku.my.id (key-gated) for npm's own
          // public search API. This can list packages by author, but npm's public API
          // doesn't expose an aggregated "total monthly downloads across all packages"
          // stat the way firefly's custom endpoint did — that figure is dropped here.
          const { data } = await axios.get(
            `https://registry.npmjs.org/-/v1/search?text=author:${encodeURIComponent(username)}&size=5`,
            { timeout: 15000 }
          );

          const packages = data?.objects || [];

          if (packages.length === 0) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `No packages found for author "${username}".`, sessionName);
          }

          let caption = `📦 *NPM Stalk*\n\n👤 *Author:* ${username}\n📦 *Packages found:* ${packages.length}\n\n`;
          caption += `*Package list:*\n`;

          for (const pkg of packages) {
            const p = pkg.package;
            caption += `> 📦 *${p.name}* (v${p.version})\n> 📝 ${p.description || 'No description'}\n> 🔗 ${p.links?.npm || ''}\n\n`;
          }

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
          await errorReply(conn, m, caption, sessionName);

        } catch (e) {
          console.error('[NPMSTALK] Error:', e.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
        }
      }
    }
  }
};
