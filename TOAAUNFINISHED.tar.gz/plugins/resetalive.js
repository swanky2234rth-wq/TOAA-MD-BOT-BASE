// Auto-converted from legacy registerCmd('resetalive', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'resetalive',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'resetalive': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

    if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
    const configFile = './database/alive_config.json';
    let configs = {};
    if (fs.existsSync(configFile)) configs = JSON.parse(fs.readFileSync(configFile, 'utf-8'));
    configs[ctx.sessionName] = { name: 'TOAA', quote: '𝙴𝚟𝚎𝚛𝚢𝚘𝚗𝚎 𝚒𝚜 𝚊 𝚜𝚕𝚊𝚟𝚎 𝚝𝚘 𝚜𝚘𝚖𝚎𝚝𝚑𝚒𝚗𝚐.', imageUrl: 'https://i.ibb.co/60pgqPj9/photo-2026-04-29-00-18-01-7633969691903393816.jpg' };
    fs.writeFileSync(configFile, JSON.stringify(configs, null, 2));
    await fReply(conn, m, `✦ *Alive config reset to default!*`, ctx.sessionName);

      }
    }
  }
};
