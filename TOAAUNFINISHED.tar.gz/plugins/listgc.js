// Auto-converted from legacy registerCmd('listgc', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply,
  resolveDisplayJid
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'listgc',
  version: '1.1.0',
  author: 'TOAA',
  commands: {
    'listgc': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  
  try {
    const groups = await conn.groupFetchAllParticipating();
    const groupList = Object.values(groups);
    
    if (groupList.length === 0) {
      return fReply(conn, m, '📭 *No groups found*', ctx.sessionName);
    }
    
    let teks = `📋 *LIST OF GROUPS*\n\n`;
    teks += `📊 Total Groups: *${groupList.length}*\n`;
    teks += `━━━━━━━━━━━━━━━━━━━━\n\n`;

    const mentions = [];

    for (const group of groupList) {
      const status = group.announce === false ? '🟢 Open' : '🔒 Closed';
      // group.owner from groupFetchAllParticipating doesn't always come with
      // a full participants list attached, so resolveDisplayJid degrades
      // gracefully to the raw jid if it can't cross-reference a LID here.
      const ownerJid = group.owner ? resolveDisplayJid(group.owner, group.participants) : null;
      const creator = ownerJid ? ownerJid.split('@')[0] : 'Left/Unknown';
      if (ownerJid) mentions.push(ownerJid);
      
      teks += `📌 *${group.subject || 'Unknown'}*\n`;
      teks += `   🆔 ID: ${group.id}\n`;
      teks += `   👥 Members: ${group.participants?.length || 0}\n`;
      teks += `   🔓 Status: ${status}\n`;
      teks += `   👑 Creator: @${creator}\n`;
      teks += `   ────────────────────\n\n`;
    }
    
    await conn.sendMessage(m.key.remoteJid, { text: teks, mentions }, { quoted: m });
    
  } catch (e) {
    await fReply(conn, m, `🎴 *Failed to list groups:* ${e.message}`, ctx.sessionName);
  }

      }
    }
  }
};
