// ─── TOAA HD Video Enhancer (pure FFMPEG upscale) ─────────
const { errorReply, getQuotedMsg, getMediaType, downloadMedia } = require('../main');
const fs = require('fs');
const os = require('os');
const path = require('path');
let ffmpeg, ffmpegPath;
try {
  ffmpeg = require('fluent-ffmpeg');
  try { ffmpegPath = require('@ffmpeg-installer/ffmpeg').path; } catch (e) { ffmpegPath = null; }
  if (ffmpegPath) ffmpeg.setFfmpegPath(ffmpegPath);
} catch (e) { ffmpeg = null; }

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;

  if (!ffmpeg) {
    return errorReply(conn, m, `This command needs 'fluent-ffmpeg' installed on the server.`, sessionName);
  }

  const quotedMsg = getQuotedMsg(m);
  const sourceMsg = quotedMsg || m.message;
  const mediaInfo = getMediaType(sourceMsg || {});

  if (!mediaInfo || mediaInfo.type !== 'video') {
    return errorReply(conn, m,
      `📹 *HD Video Enhancer*\n\nUpscale a blurry video to HD.\n\n*How to use:*\n1. Send a video with caption ${prefix}hdvid\n2. Or reply to a video with ${prefix}hdvid\n\n⚠️ _Processing time depends on video size._`,
      sessionName
    );
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

  const tempDir = os.tmpdir();
  const inputPath = path.join(tempDir, `input-hd-${Date.now()}.mp4`);
  const outputPath = path.join(tempDir, `output-hd-${Date.now()}.mp4`);

  try {
    const videoBuffer = await downloadMedia(mediaInfo.inner, 'video');

    if (!videoBuffer || videoBuffer.length === 0) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `Couldn't download that video, try sending it again.`, sessionName);
    }

    if (videoBuffer.length > 50 * 1024 * 1024) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `Video is too big — 50MB max.`, sessionName);
    }

    await conn.sendMessage(m.key.remoteJid, { text: `🎞️ *Enhance started*\n\nYour video is being upscaled to HD ✨. Sit tight, this can take a bit depending on size.` }, { quoted: m });

    fs.writeFileSync(inputPath, videoBuffer);

    await new Promise((resolve, reject) => {
      ffmpeg(inputPath)
        .videoFilters(['scale=iw*2:ih*2:flags=lanczos', 'unsharp=5:5:1.0:5:5:0.0'])
        .outputOptions(['-c:v libx264', '-preset fast', '-crf 23', '-c:a copy'])
        .save(outputPath)
        .on('end', () => resolve())
        .on('error', (err) => reject(err));
    });

    const resultBuffer = fs.readFileSync(outputPath);

    await conn.sendMessage(m.key.remoteJid, {
      video: resultBuffer,
      mimetype: 'video/mp4',
      fileName: `HDVID-${Date.now()}.mp4`,
      caption: `✨ *Done!* Video's noticeably sharper now.`
    }, { quoted: m });

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error('[HDVID] Error:', err.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Enhance failed: ${err.message}`, sessionName);
  } finally {
    try { fs.unlinkSync(inputPath); } catch (e) {}
    try { fs.unlinkSync(outputPath); } catch (e) {}
  }
}

module.exports = {
  name: 'hdvid',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'hdvid': { category: 'tools', handler: run },
    'hdvideo': { category: 'tools', handler: run },
    'enhancevid': { category: 'tools', handler: run }
  }
};
