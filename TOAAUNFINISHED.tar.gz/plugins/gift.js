// ─── TOAA RPG Gift ─────────
const { errorReply, fReply } = require('../main');
const { getUser, setUser, isRpgAllowed, removeItem, addItem } = require('../helper/rpg');
const { ITEMS } = require('../helper/rpgItems');
const { getSessionSetting } = require('../helper/function');

module.exports = {
  name: 'gift',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'gift': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);

  if (!user.spouse) {
    return errorReply(conn, m, `*NOT MARRIED*\n\nYou're not married yet!\nGet married first with \`.marry @user\``, sessionName);
  }

  const itemKey = args[0]?.toLowerCase();
  const amount = parseInt(args[1]) || 1;

  if (!itemKey) {
    return fReply(conn, m, `🎁 *GIFT*\n\n*Usage:*\nPick an item to give\n👉 \`${prefix}gift diamond 1\``, sessionName);
  }

  const have = user.inventory[itemKey] || 0;
  if (have < amount) {
    return errorReply(conn, m, `*NOT ENOUGH ITEMS*\n\nYour *${itemKey}*: ${have}\nNeed: ${amount}`, sessionName);
  }

  const spouseJid = user.spouse;
  const partner = getUser(spouseJid);

  removeItem(jid, itemKey, amount);
  addItem(spouseJid, itemKey, amount);

  const loveGain = amount * 10;
  user.love = (user.love || 0) + loveGain;
  setUser(jid, user);

  partner.love = (partner.love || 0) + loveGain;
  setUser(spouseJid, partner);

  const itemName = ITEMS[itemKey]?.name || itemKey;

  let txt = `🎁 *GIFT SENT*\n\n`;
  txt += `💝 You gave ${amount}x ${itemName}\n`;
  txt += `👤 To: @${spouseJid.split('@')[0]}\n`;
  txt += `💕 Love: +${loveGain}\n\n`;
  txt += `_So sweet! 💖_`;

  await conn.sendMessage(m.key.remoteJid, { text: txt, mentions: [spouseJid] }, { quoted: m });
}
