// ─── TOAA AntiDocument ─────────
const { errorReply, successReply, requireAdmin, rawNumber, getMediaType } = require('../main');
const { getGroup, setGroup } = require('../helper/groupProtectionStore');

// Called from main.js's handleMessage on every group message.
async function checkAntidocument(conn, m, sessionName, senderJid, isAdmin, isOwner) {
  const remoteJid = m.key.remoteJid;
  if (!remoteJid.endsWith('@g.us')) return false;
  if (isAdmin || isOwner || m.key.fromMe) return false;

  const groupData = getGroup(remoteJid);
  if (!groupData.antidocument) return false;

  const mediaType = getMediaType(m.message || {});
  if (!mediaType || mediaType.type !== 'document') return false;

  try { await conn.sendMessage(remoteJid, { delete: m.key }); } catch (e) {}

  await conn.sendMessage(remoteJid, {
    text: `⚠️ *AntiDocument* — Document from @${rawNumber(senderJid)} was removed.`,
    mentions: [senderJid]
  });

  return true;
}

module.exports = {
  name: 'antidocument',
  version: '1.0.0',
  author: 'TOAA',
  checkAntidocument,
  commands: {
    'antidocument': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;

        if (!remoteJid.endsWith('@g.us')) {
          return errorReply(conn, m, `Groups only.`, sessionName);
        }
        if (!requireAdmin(ctx, conn, m)) return;

        const arg = args[0]?.toLowerCase();
        const current = getGroup(remoteJid).antidocument || false;

        if (!arg || arg === 'status') {
          return errorReply(conn, m, `📄 *AntiDocument*\n\nStatus: ${current ? '✅ ON' : '❌ OFF'}\n\n${ctx.prefix}antidocument on/off`, sessionName);
        }
        if (arg === 'on') {
          setGroup(remoteJid, { antidocument: true });
          return successReply(conn, m, `AntiDocument enabled.`, sessionName);
        }
        if (arg === 'off') {
          setGroup(remoteJid, { antidocument: false });
          return successReply(conn, m, `AntiDocument disabled.`, sessionName);
        }
        return errorReply(conn, m, `Use "on" or "off".`, sessionName);
      }
    }
  }
};
