// Auto-converted from legacy registerCmd('appealstatus', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'appealstatus',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'appealstatus': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

    const { sessionName, prefix } = ctx;
    const number = args[0]?.replace(/[^0-9]/g, '');
    if (!number) return fReply(conn, m, `📌 *Usage:* ${prefix}appealstatus <number>`, sessionName);
    
    const APPEAL_FILE = path.join(__dirname, 'database', 'appeals_sent.json');
    if (!fs.existsSync(APPEAL_FILE)) return fReply(conn, m, `📋 *No appeals found for +${number}*`, sessionName);
    
    try {
        const appeals = JSON.parse(fs.readFileSync(APPEAL_FILE, 'utf-8'));
        const userAppeals = appeals.filter(a => a.number === number);
        if (userAppeals.length === 0) return fReply(conn, m, `📋 *No appeals found for +${number}*`, sessionName);
        
        const lastAppeal = userAppeals[userAppeals.length - 1];
        const daysAgo = Math.floor((Date.now() - lastAppeal.sentAt) / (1000 * 60 * 60 * 24));
        
        await fReply(conn, m,
            `📋 *Appeal Status for +${number}*\n\n` +
            `📧 *Last Appeal:* ${new Date(lastAppeal.sentAt).toLocaleString()}\n` +
            `⏱️ *Days ago:* ${daysAgo} day${daysAgo !== 1 ? 's' : ''}\n` +
            `📨 *Email ID:* ${lastAppeal.emailId || 'N/A'}\n\n` +
            `💡 *Next Steps:*\n` +
            `• Check email (including spam) for Meta's response\n` +
            `• Timeline: 3-7 business days\n` +
            `• If no response after 14 days, submit a new appeal\n\n` +
            `📌 *New appeal:* ${prefix}appeal ${number}`,
            sessionName
        );
    } catch (e) {
        await fReply(conn, m, `🎴 *Error reading appeal records*`, sessionName);
    }

      }
    }
  }
};
