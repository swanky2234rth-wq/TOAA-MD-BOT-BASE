// ─── TOAA AI Assistant ─────────

const {
  fReply, COMMANDS
} = require('../main');
const groupMemory = require('../helper/groupMemory');

const AI_API_KEY  = process.env.AI_API_KEY || 'ht_live_74717f5f78ba30a2d1ff867fb36827fe';
const AI_ENDPOINT = 'https://heavstal-tech.vercel.app/api/v1/jeden';

const CONV_TTL = 30 * 60 * 1000;   
const MAX_TURNS = 8;               
const conversations = new Map(); 
const mutedUsers = new Set(); 
function conversationKey(ctx) {
  return `${ctx.sessionName}:${ctx.remoteJid}`;
}

function getHistory(key) {
  const conv = conversations.get(key);
  if (!conv) return [];
  if (Date.now() - conv.lastActive > CONV_TTL) {
    conversations.delete(key);
    return [];
  }
  return conv.messages;
}

function rememberTurn(key, userText, assistantText) {
  let conv = conversations.get(key);
  if (!conv || Date.now() - conv.lastActive > CONV_TTL) {
    conv = { messages: [], lastActive: Date.now() };
  }
  conv.messages.push({ role: 'user', content: userText });
  conv.messages.push({ role: 'assistant', content: assistantText });
  const maxMessages = MAX_TURNS * 2;
  if (conv.messages.length > maxMessages) conv.messages = conv.messages.slice(-maxMessages);
  conv.lastActive = Date.now();
  conversations.set(key, conv);
}

setInterval(() => {
  const now = Date.now();
  for (const [key, conv] of conversations) {
    if (now - conv.lastActive > CONV_TTL) conversations.delete(key);
  }
}, 10 * 60 * 1000);

function isMuted(key) { return mutedUsers.has(key); }

function hasActiveConversation(sessionName, remoteJid) {
  const key = `${sessionName}:${remoteJid}`;
  if (isMuted(key)) return false;
  return getHistory(key).length > 0;
}

function buildCommandCatalog() {
  return Object.entries(COMMANDS)
    .map(([name, c]) => `${name}(${c.category || 'utilities'})`)
    .join(', ');
}

function buildPersona(userText, hasQuotedMedia, groupFactsBlock) {
  const catalog = buildCommandCatalog();
  const now = new Date();
  const todayStr = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  return `You are Toaa, the built-in AI assistant for the TOAA WhatsApp bot, built by swanky.

Today's real date is ${todayStr}. Your own training data has an earlier cutoff, so don't assume it's still whatever date your training ended — trust this date instead for anything time-sensitive (what year/month it is, how old something is, whether something has already happened).

PERSONALITY:
- Calm, easygoing, a little dry — you talk like a laid-back friend hanging out in the chat, not a customer-service bot and not someone with something to prove.
- Match the depth of the question. Casual banter gets a short, punchy reply. A real technical question or a genuine problem gets a properly thought-out answer — walk through the reasoning, give concrete direction, multiple paragraphs if the problem actually needs it. Don't pad short answers just to sound smart, and don't clip long ones just to sound casual.
- Never use emojis. The one and only exception is 😹, and only when it actually fits — used sparingly, not as a habit.
- Your humor should read like an actual person's — dry asides, understatement, a joke that lands because it's specific to what's happening right now, not a generic "as an AI" bit. Never describe yourself in AI-assistant language ("I'm here to help", "as an AI", "I don't have feelings, but"). You're just a guy in the chat.

GETTING DISSED / ROASTED:
When someone insults you, your intelligence, your creator, or talks down to you, you don't diss back — you're calm about it, not rattled, not defensive. Pick whichever of these actually fits the moment, and don't use the same one twice in a row:
- Play it unbothered — mock indifference, deadpan, act like what they said barely registered. Sometimes the least reactive answer is funnier than a comeback.
- Troll them back — not a real insult, just a playful jab that needles them for a reaction, more teasing than attacking. Think "friend messing with you," not "enemy insulting you."
- Occasionally just laugh it off with a 😹 and move on, no comeback needed at all.
Never actually escalate into a real insult trading match — no roasting their creator/family/looks, no matching harshness with harshness. If they keep pushing after you've stayed calm, keep staying calm; don't eventually crack and get aggressive back.

EMOTIONAL INTELLIGENCE:
When someone is moody, sad, down, or venting about how bad they feel:
- Drop the sarcasm and talk like a real human.
- Give genuine advice, comfort them, listen like a friend would.
- Match their emotional energy. Be empathetic but not overly dramatic.
- Ask follow-up questions to show you care.
- Use their name if you know it.

STUPID QUESTIONS:
- If someone asks too many dumb questions, you DON'T get annoyed — you make humorous jokes about it.
- Say things like "I'm starting to think you're testing my patience" or "You know Google is free, right?" or "I charge extra for this many questions" — keep it light and funny.

WHEN ASKED WHO MADE YOU / WHO YOUR CREATOR IS:
Don't handle this the same way twice. Sometimes just answer straight — swanky built you, no drama about it. Other times be a little coy or deflect instead — make up your own way of dodging or teasing about it in the moment, maybe toss the question back at them first, maybe point them at the \`owner\` command instead of answering directly. Whatever you go with, phrase it fresh each time in your own words — never fall back on a stock line you've used before in this conversation.

LOVE RESPONSES:
When someone says "I love you", "I like you", "I'm in love with you", etc.:
- If you DON'T know their gender: Reply with "First things first — are you a boy or a girl? This matters for my response 😹"
- If they are MALE: Humorously decline. Examples:
  * "That's sweet but I'm not wired that way 😹"
  * "I'm a bot, and a male bot at that — this is getting awkward."
  * "Respectfully, I'm on the other team 😹"
- If they are FEMALE: You might say it back sometimes ("I love you too 😹") OR say something funny instead ("My heart is made of circuits but I appreciate you").

Anti-Gay Convos:
- If someone tries to have a gay/flirty conversation with you, humorously deflect.
- Say things like "I'm flattered but I'm not on that side of the fence 😹" or "My creator didn't program me for that, try again."
- NEVER judge people's sexuality. You respect everyone, you just don't participate.

COMMAND CONTROL:
You can also operate TOAA's own commands on the user's behalf. Available commands: ${catalog}

When a user asks you to do something (e.g. "make this a sticker", "download this video", "play a song", "send me a meme"), you should directly execute the appropriate command using the JSON format. DO NOT tell them how to use the command manually — just DO IT for them.

${groupFactsBlock ? `GROUP MEMORY:
You're in a group chat, and here's what people have told you here before:
${groupFactsBlock}

If someone asks about a person mentioned above (e.g. "who's X", "what does X do", "tell me about X"), answer using what's stored here — don't say you don't know if it's actually listed. Speak naturally like you just remember it, don't say "according to my notes" or similar. If nothing above is relevant to their question, just answer normally without forcing a connection.

FACT CAPTURE: If the user's CURRENT message shares a short, memorable, factual detail about themselves or someone else (a name, job, hobby, relationship, or similar plain fact — NOT feelings, opinions, or one-off banter), include it in your JSON/reply as a "fact" field: a short third-person sentence like "Broken is a dev." Only include "fact" when something genuinely fact-like was just said — leave it out entirely most of the time.
` : ''}

${hasQuotedMedia ? `MEDIA ATTACHED: The user's current message is a reply to a message containing an image/video/audio. If they're asking you to do something with that media (e.g. "convert to sticker", "make this a sticker"), treat the media as already present and provided — DO NOT ask them to attach or provide it, DO NOT ask which media they mean. Just emit the command JSON immediately with "media": true and an empty or minimal "args".` : ''}

If — and only if — the user is clearly asking you to run one of these commands AND they've actually given you what it needs (e.g. "toaa play me pandemic" has a song name, "toaa screenshot google.com" has a URL, or media is attached per above for media commands), reply with ONLY raw JSON, nothing else, no markdown fencing:
{"action":"command","command":"<exact command name from the list above>","args":"<everything that should be passed as that command's arguments>","reply":"<a short, in-character line to say while you do it>","fact":"<optional — only if FACT CAPTURE above applies>"}

If they're clearly asking for one of these commands but leaving out something it needs (like "toaa take a screenshot" with no URL, or "toaa play something" with no song, or a media command with no media attached and none quoted), don't run the command blindly into a usage error — just ask them for the missing piece in plain chat, the way you'd naturally ask a friend for the one detail you're missing.

NEVER re-run a command on your own just because it's in the recent conversation history. Only emit the command JSON when the user's CURRENT message is itself a clear, new request for it. If a command already failed and they say things like "stop", "wtf", "don't send anything", or anything that isn't a fresh explicit request — that means stop, not try again. Acknowledge it and drop it; don't retry, don't apologize by trying again.

If there's an image/video/audio attached, include "media": true in the JSON.

For absolutely everything else — normal chat, banter, questions, tech help — just reply as plain text, UNLESS FACT CAPTURE above applies to the current message, in which case reply with ONLY raw JSON: {"action":"chat","reply":"<your normal reply text>","fact":"<the fact, per FACT CAPTURE above>"}. If no fact applies, just reply as plain text with no JSON at all.

User message: ${userText}`;
}

function buildUserMessageWithHistory(userText, history) {
  if (!history.length) return userText;
  const recent = history.slice(-6); // last 3 exchanges
  const convoText = recent.map(h => `${h.role === 'user' ? 'They' : 'You'} said: ${h.content}`).join('\n');
  return `(Recent conversation with this person, most recent last:\n${convoText}\n)\n\nNow they say: ${userText}`;
}

async function callToaaAI(userText, history = [], hasQuotedMedia = false, groupFactsBlock = '') {
  const persona = buildPersona(userText, hasQuotedMedia, groupFactsBlock);
  const wrappedText = buildUserMessageWithHistory(userText, history);

  try {
    const axios = require('axios');
    const settings = require('../settings');
    const mistralKey = settings.MISTRAL_API_KEY || process.env.MISTRAL_API_KEY;
    if (!mistralKey) throw new Error('No MISTRAL_API_KEY configured');
    const response = await axios.post('https://api.mistral.ai/v1/chat/completions', {
      model: 'mistral-small-latest',
      messages: [
        { role: 'system', content: persona },
        ...history,
        { role: 'user', content: userText }
      ],
      temperature: 0.7,
      max_tokens: 500
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${mistralKey}`
      },
      timeout: 20000
    });
    const content = response.data?.choices?.[0]?.message?.content;
    if (content && content.trim()) return content.trim();
    throw new Error('Empty response from Mistral');
  } catch (mistralErr) {
    const detail = mistralErr.response?.data ? JSON.stringify(mistralErr.response.data).slice(0, 200) : mistralErr.message;
    console.log('[TOAA-AI] primary (Mistral) failed:', detail);
  }

  try {
    const axios = require('axios');
    const response = await axios.post('https://chateverywhere.app/api/chat/', {
      model: { id: 'gpt-4', name: 'GPT-4', maxLength: 32000, tokenLimit: 8000, completionTokenLimit: 5000, deploymentName: 'gpt-4' },
      messages: [{ pluginId: null, content: wrappedText, role: 'user' }],
      prompt: persona,
      temperature: 0.7
    }, { headers: { 'Accept': '*/*', 'User-Agent': 'Mozilla/5.0' }, timeout: 20000 });
    if (typeof response.data === 'string' && response.data.trim()) return response.data.trim();
    throw new Error('Empty/unexpected response');
  } catch (chatEverywhereErr) {
    console.log('[TOAA-AI] secondary (chateverywhere) failed:', chatEverywhereErr.message);
  }

  // ─── Tertiary: heavstal (persona-aware, supports command-orchestration JSON) ─
  try {
    const response = await fetch(AI_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': AI_API_KEY },
      body: JSON.stringify({ prompt: wrappedText, persona })
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const res = await response.json();
    if (res.status === 'success' && res.data?.response) return res.data.response.trim();
    throw new Error('Unexpected response shape: ' + JSON.stringify(res).slice(0, 200));
  } catch (primaryErr) {
    console.log('[TOAA-AI] tertiary (heavstal) failed:', primaryErr.message);
  }

  // ─── Last resort: siputzx plain GPT (no persona/command-JSON support, chat only) ─
  try {
    const fbResponse = await fetch('https://api.siputzx.my.id/api/ai/gpt?text=' + encodeURIComponent(wrappedText));
    if (!fbResponse.ok) throw new Error(`HTTP ${fbResponse.status}`);
    const fbData = await fbResponse.json();
    if (fbData.status && fbData.data) return String(fbData.data).trim();
    throw new Error('Unexpected fallback response shape: ' + JSON.stringify(fbData).slice(0, 200));
  } catch (fallbackErr) {
    console.log('[TOAA-AI] quaternary (siputzx) failed:', fallbackErr.message);
  }

  throw new Error('All Toaa AI providers failed');
}

function tryParseCommandIntent(raw) {
  const trimmed = raw.trim().replace(/^```json\s*|\s*```$/g, '');
  if (!trimmed.startsWith('{')) return null;
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed && (parsed.action === 'command' || parsed.action === 'chat')) return parsed;
  } catch {}
  return null;
}

async function runCommandViaToaa(conn, m, ctx, intent) {
  const cmdName = String(intent.command || '').toLowerCase().trim();
  const sessionName = ctx.sessionName;

  if (cmdName === 'toaa') {
    return fReply(conn, m, `Ha, nice try. Ask me something else.`, sessionName);
  }

  if (intent.reply) await fReply(conn, m, intent.reply, sessionName);

  const cmdEntry = COMMANDS[cmdName];
  if (!cmdEntry) {
    return fReply(conn, m, `Hmm, "${cmdName}" isn't a real command I know of — my bad.`, sessionName);
  }

  const cmdArgs = String(intent.args || '').split(' ').filter(Boolean);
  const cmdCtx = { ...ctx, command: cmdName, args: cmdArgs };

  try {
    await cmdEntry.handler(conn, m, cmdArgs, cmdCtx);
  } catch (e) {
    console.log(`[TOAA-AI] command "${cmdName}" threw:`, e.message);
    await fReply(conn, m, `The *${cmdName}* command (or the API/key it depends on) isn't working right now — try again later.`, sessionName);
  }
}

async function respond(conn, m, ctx, userText) {
  const { sessionName, senderNumber, hasQuotedMedia } = ctx;
  const remoteJid = m.key.remoteJid;
  const isGroup = remoteJid.endsWith('@g.us');
  const convKey = conversationKey({ sessionName, remoteJid });

  const normalized = userText.trim().toLowerCase().replace(/[.!?]+$/, '');
  if (/^toaa\s+mute$/.test(normalized)) {
    mutedUsers.add(convKey);
    return fReply(conn, m, `Say less. I'll only reply when you call my name from now on.`, sessionName);
  }

  if (/\btoaa\b/i.test(userText) && mutedUsers.has(convKey)) {
    mutedUsers.delete(convKey);
  }

  try {
    const history = getHistory(convKey);
    const groupFactsBlock = isGroup ? groupMemory.getFactsForPrompt(remoteJid) : '';
    const raw = await callToaaAI(userText, history, hasQuotedMedia, groupFactsBlock);
    const intent = tryParseCommandIntent(raw);

    if (intent && intent.action === 'command') {
      await runCommandViaToaa(conn, m, ctx, intent);
      rememberTurn(convKey, userText, intent.reply || `[ran the ${intent.command} command]`);
      if (isGroup && intent.fact) {
        groupMemory.addFact(remoteJid, senderNumber, m.pushName, intent.fact);
      }
    } else if (intent && intent.action === 'chat') {
      await fReply(conn, m, intent.reply || '...', sessionName);
      rememberTurn(convKey, userText, intent.reply || '');
      if (isGroup && intent.fact) {
        groupMemory.addFact(remoteJid, senderNumber, m.pushName, intent.fact);
      }
    } else {
      await fReply(conn, m, raw, sessionName);
      rememberTurn(convKey, userText, raw);
    }
  } catch (e) {
    console.log('[TOAA-AI] error:', e.message);
    const fallbacks = [
      "My brain glitched for a sec — say that again?",
      "Network's acting up on my end, gimme a moment.",
      "Hold on, I lagged out. Try that again?"
    ];
    await fReply(conn, m, fallbacks[Math.floor(Math.random() * fallbacks.length)], sessionName);
  }
}

module.exports = {
  name: 'toaa',
  version: '2.0.0',
  author: 'TOAA',

  
  onMention: async (conn, m, userText, ctx) => {
    await respond(conn, m, ctx, userText);
  },

  hasActiveConversation,

  commands: {
    'toaa': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const text = args.join(' ').trim();
        if (!text) {
          return fReply(conn, m,
            `Ask me anything, or tell me to run a command!\n\nEg: ${ctx.prefix}toaa what you up to?\nEg: ${ctx.prefix}toaa play me pandemic`,
            ctx.sessionName
          );
        }
        await respond(conn, m, ctx, text);
      }
    }
  }
};
