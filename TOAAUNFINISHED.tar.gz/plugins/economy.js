// plugins/economy.js
const fs = require('fs');
const path = require('path');

const ECONOMY_FILE = path.join(__dirname, '../database/economy.json');
let economy = {};

if (fs.existsSync(ECONOMY_FILE)) {
  economy = JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf-8'));
}

function saveEconomy() {
  fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
}

function getUserBalance(userId) {
  if (!economy[userId]) economy[userId] = { coins: 1000, lastDaily: 0 };
  return economy[userId].coins;
}

function addCoins(userId, amount) {
  if (!economy[userId]) economy[userId] = { coins: 1000, lastDaily: 0 };
  economy[userId].coins += amount;
  saveEconomy();
  return economy[userId].coins;
}

function removeCoins(userId, amount) {
  if (!economy[userId]) economy[userId] = { coins: 1000, lastDaily: 0 };
  if (economy[userId].coins < amount) return false;
  economy[userId].coins -= amount;
  saveEconomy();
  return true;
}

const {
  getSessionSetting,
  applyFont
} = require('../main');
module.exports = {
  name: 'Economy System',
  version: '1.0.0',
  author: 'TOAA',
  
  commands: {
    'daily': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber } = ctx;
        const now = Date.now();
        const DAY = 24 * 60 * 60 * 1000;
        
        if (!economy[senderNumber]) economy[senderNumber] = { coins: 1000, lastDaily: 0 };
        
        if (now - economy[senderNumber].lastDaily < DAY) {
          const remaining = Math.ceil((DAY - (now - economy[senderNumber].lastDaily)) / 1000 / 60 / 60);
          return fReply(conn, m, `⏰ *Daily reward already claimed!*\n\nCome back in ${remaining} hours.`, sessionName);
        }
        
        const reward = Math.floor(Math.random() * 500) + 500;
        economy[senderNumber].coins += reward;
        economy[senderNumber].lastDaily = now;
        saveEconomy();
        
        await fReply(conn, m, `🎁 *Daily Reward!*\n\n💰 +${reward} coins\n💎 Total: ${economy[senderNumber].coins} coins`, sessionName);
      }
    },
    
    'bal': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber } = ctx;
        const balance = getUserBalance(senderNumber);
        await fReply(conn, m, `💰 *Your Balance*\n\n💎 ${balance} coins`, sessionName);
      }
    },
    
    'slots': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber } = ctx;
        const bet = parseInt(args[0]);
        
        if (!bet || isNaN(bet) || bet < 10) {
          return fReply(conn, m, `🎰 *Slots*\n\nUsage: ${ctx.prefix}slots <amount>\nMinimum bet: 10 coins`, sessionName);
        }
        
        if (!removeCoins(senderNumber, bet)) {
          return fReply(conn, m, `❌ *Insufficient coins!*\n\nYou need ${bet} coins.`, sessionName);
        }
        
        const emojis = ['🍒', '🍋', '🍊', '🍉', '⭐', '💎', '7️⃣'];
        const slot1 = emojis[Math.floor(Math.random() * emojis.length)];
        const slot2 = emojis[Math.floor(Math.random() * emojis.length)];
        const slot3 = emojis[Math.floor(Math.random() * emojis.length)];
        
        let win = 0;
        if (slot1 === slot2 && slot2 === slot3) {
          win = bet * 10;
        } else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) {
          win = bet * 2;
        } else if (slot1 === '7️⃣' || slot2 === '7️⃣' || slot3 === '7️⃣') {
          win = bet * 1.5;
        }
        
        if (win > 0) {
          addCoins(senderNumber, win);
          await fReply(conn, m, `🎰 *SLOTS*\n\n┌─────┐\n│ ${slot1} │ ${slot2} │ ${slot3} │\n└─────┘\n\n✨ *YOU WIN!* ✨\n💰 +${win} coins`, sessionName);
        } else {
          await fReply(conn, m, `🎰 *SLOTS*\n\n┌─────┐\n│ ${slot1} │ ${slot2} │ ${slot3} │\n└─────┘\n\n💀 *You lost!* 💀\n💸 -${bet} coins`, sessionName);
        }
      }
    },
    
    'blackjack': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber, prefix } = ctx;
        const bet = parseInt(args[0]);
        
        if (!bet || isNaN(bet) || bet < 50) {
          return fReply(conn, m, `🃏 *Blackjack*\n\nUsage: ${prefix}blackjack <amount>\nMinimum bet: 50 coins`, sessionName);
        }
        
        if (!removeCoins(senderNumber, bet)) {
          return fReply(conn, m, `🔻 *Insufficient coins!*\n\nYou need ${bet} coins.`, sessionName);
        }
        
        function drawCard() {
          const cards = [2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K', 'A'];
          return cards[Math.floor(Math.random() * cards.length)];
        }
        
        function getValue(card) {
          if (card === 'A') return 11;
          if (['J', 'Q', 'K'].includes(card)) return 10;
          return card;
        }
        
        let playerCards = [drawCard(), drawCard()];
        let dealerCards = [drawCard(), drawCard()];
        
        let playerValue = playerCards.reduce((sum, c) => sum + getValue(c), 0);
        if (playerValue > 21 && playerCards.includes('A')) playerValue -= 10;
        
        let dealerValue = getValue(dealerCards[0]);
        
        let gameActive = true;
        let gameResult = null;
        
        if (playerValue === 21) {
          gameResult = 'blackjack';
          gameActive = false;
        }
        
        const gameMsg = await conn.sendMessage(m.key.remoteJid, {
          text: `🃏 *BLACKJACK* | Bet: ${bet} coins\n\n` +
                `🎴 *Your hand:* ${playerCards.join(', ')} = ${playerValue}\n` +
                `🃟 *Dealer shows:* ${dealerCards[0]} = ${dealerValue}\n\n` +
                `Reply with *hit* or *stand*`,
          mentions: [`${senderNumber}@s.whatsapp.net`]
        }, { quoted: m });
        
        // Simplified - for full implementation would need message collector
        // This is a basic version
        setTimeout(async () => {
          if (gameResult === 'blackjack') {
            const winAmount = bet * 2.5;
            addCoins(senderNumber, winAmount);
            await fReply(conn, m, `🃏 *BLACKJACK!*\n\n🎉 You got Blackjack!\n💰 +${winAmount} coins`, sessionName);
          } else if (playerValue > 21) {
            await fReply(conn, m, `🥀 *BUST!* You lost ${bet} coins`, sessionName);
          } else {
            while (dealerValue < 17) {
              const newCard = drawCard();
              dealerCards.push(newCard);
              dealerValue += getValue(newCard);
              if (dealerValue > 21 && dealerCards.includes('A')) dealerValue -= 10;
            }
            
            if (dealerValue > 21 || playerValue > dealerValue) {
              const winAmount = bet * 2;
              addCoins(senderNumber, winAmount);
              await fReply(conn, m, `🎉 *YOU WIN!*\n💰 +${winAmount} coins\n\nYour: ${playerValue} | Dealer: ${dealerValue}`, sessionName);
            } else if (playerValue < dealerValue) {
              await fReply(conn, m, `💀 *YOU LOSE!*\n💸 -${bet} coins\n\nYour: ${playerValue} | Dealer: ${dealerValue}`, sessionName);
            } else {
              addCoins(senderNumber, bet);
              await fReply(conn, m, `🤝 *PUSH!* Bet returned\n\nYour: ${playerValue} | Dealer: ${dealerValue}`, sessionName);
            }
          }
        }, 30000);
      }
    },
    
    'leaderboard': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        
        const sorted = Object.entries(economy)
          .sort((a, b) => b[1].coins - a[1].coins)
          .slice(0, 10);
        
        if (!sorted.length) {
          return fReply(conn, m, '📋 *No players yet!*', sessionName);
        }
        
        let text = `🏆 *RICH LIST* 🏆\n\n`;
        for (let i = 0; i < sorted.length; i++) {
          const [user, data] = sorted[i];
          text += `${i + 1}. @${user.slice(0, 10)} — 💰 ${data.coins}\n`;
        }
        
        await conn.sendMessage(m.key.remoteJid, {
          text: text,
          mentions: sorted.map(s => `${s[0]}@s.whatsapp.net`)
        }, { quoted: m });
      }
    }
  }
};

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}