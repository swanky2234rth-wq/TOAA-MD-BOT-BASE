// ─── TOAA RPG Alchemy ─────────
const { errorReply, fReply } = require('../main');
const { getUser, addExp, isRpgAllowed, removeItem, addItem } = require('../helper/rpg');
const { ALCHEMY_RECIPES } = require('../helper/rpgRecipes');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const COOLDOWN_MS = 60 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'alchemy',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'alchemy': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const potionKey = args[0]?.toLowerCase();
  const user = getUser(jid);

  if (!potionKey) {
    let txt = `🧪 *THE ALCHEMIST'S BENCH*\n\nWhat should we brew today?\n\n`;
    for (const [key, potion] of Object.entries(ALCHEMY_RECIPES)) {
      const mats = Object.entries(potion.materials).map(([mat, qty]) => `${qty}x ${mat}`).join(', ');
      txt += `*${potion.name}*\n📦 Needs: ${mats}\n💫 Effect: ${potion.effect}\n👉 \`${prefix}alchemy ${key}\`\n\n`;
    }
    txt += `💡 *Tip:* herbs come from dungeon/adventure drops!`;
    return fReply(conn, m, txt.trim(), sessionName);
  }

  const potion = ALCHEMY_RECIPES[potionKey];
  if (!potion) {
    return errorReply(conn, m, `That's not a recipe in the book! Check \`${prefix}alchemy\` for the list.`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ The cauldron's still bubbling! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const missing = [];
  for (const [mat, needed] of Object.entries(potion.materials)) {
    const have = user.inventory[mat] || 0;
    if (have < needed) missing.push(`${mat}: ${have}/${needed}`);
  }
  if (missing.length > 0) {
    return errorReply(conn, m, `Not enough ingredients for *${potion.name}*!\n\n${missing.join('\n')}`, sessionName);
  }

  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🧪', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Bubble bubble... FIZZ! 🧪✨\nBrewing *${potion.name}*... careful, don't let it explode! 💥` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  for (const [mat, needed] of Object.entries(potion.materials)) {
    removeItem(jid, mat, needed);
  }

  addItem(jid, potion.result, 1);
  const levelResult = addExp(jid, potion.exp);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  let txt = `CLINK! POTION BREWED! 🎉🧪\n\nYou successfully made:\n📦 Item: *${potion.name}*\n💫 Effect: *${potion.effect}*\n📈 Alchemy EXP: *+${potion.exp}*\n\nDon't drink it all at once! 😂`;

  await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
