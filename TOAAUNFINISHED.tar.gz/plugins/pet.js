// ─── TOAA RPG Pet ─────────
const { errorReply, fReply } = require('../main');
const { getUser, setUser, isRpgAllowed, removeItem } = require('../helper/rpg');
const { PET_TYPES, FOOD_ITEMS } = require('../helper/rpgPets');
const { getSessionSetting } = require('../helper/function');

module.exports = {
  name: 'pet',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'pet': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);
  const action = args[0]?.toLowerCase();

  if (!user.pet) {
    return errorReply(conn, m,
      `You don't have a pet yet! 😭\nLonely adventuring, huh...\n\n*How to get a friend:*\n🛒 Buy one at \`${prefix}petshop\`\n💕 Get one from \`${prefix}breeding\`\n🗡️ Rare boss drops!`,
      sessionName
    );
  }

  const pet = user.pet;
  const petInfo = PET_TYPES[pet.type];

  if (!action || !['feed', 'train', 'status', 'rename', 'evolve'].includes(action)) {
    const hungerStatus = pet.hunger >= 70 ? '😊 Happy & Full' : pet.hunger >= 40 ? '😐 Doing Okay' : '😰 Starving!';

    let txt = `🐾 *PET PROFILE* 🐾\n\n*${pet.name}'s Profile:*\n`;
    txt += `• Species: *${petInfo.name}*\n• Level: *${pet.level || 1}*\n`;
    txt += `• EXP: *${pet.exp || 0} / ${(pet.level || 1) * 100}*\n`;
    txt += `• Hunger: *${pet.hunger}/100* (${hungerStatus})\n\n`;
    txt += `*Combat Stats:*\n⚔️ Attack: *${pet.stats?.attack || petInfo.baseStats.attack}*\n`;
    txt += `🛡️ Defense: *${pet.stats?.defense || petInfo.baseStats.defense}*\n`;
    txt += `🍀 Luck: *${pet.stats?.luck || petInfo.baseStats.luck}*\n\n`;
    txt += `*Interactions:*\n👉 \`${prefix}pet feed <food>\` — Feed\n👉 \`${prefix}pet train\` — Train\n👉 \`${prefix}pet rename <name>\` — Rename\n`;
    if (petInfo.evolve) txt += `👉 \`${prefix}pet evolve\` — Evolve (if requirements met)\n`;

    return fReply(conn, m, txt, sessionName);
  }

  if (action === 'feed') {
    const foodKey = args[1]?.toLowerCase();

    if (!foodKey) {
      let txt = `*${pet.name}* is staring at you, licking their lips... 🤤\nWhat should we feed them?\n\n*Food in your bag:*\n`;
      for (const [key, food] of Object.entries(FOOD_ITEMS)) {
        const have = user.inventory[key] || 0;
        txt += `\n*${food.name}* (Have: ${have}x)\n🍖 Fullness: +${food.hunger} | ✨ EXP: +${food.exp}\n👉 Feed: \`${prefix}pet feed ${key}\`\n`;
      }
      return fReply(conn, m, txt, sessionName);
    }

    const food = FOOD_ITEMS[foodKey];
    if (!food) {
      return errorReply(conn, m, `Don't feed weird stuff to your pet! They'll get sick! 😂❌`, sessionName);
    }
    if ((user.inventory[foodKey] || 0) < 1) {
      return errorReply(conn, m, `You don't have any *${food.name}* in your bag! Go buy some! 🛒`, sessionName);
    }
    if (pet.hunger >= 100) {
      return errorReply(conn, m, `*${pet.name}*'s stomach is already full! Don't overfeed them! 🤢`, sessionName);
    }

    removeItem(jid, foodKey, 1);
    pet.hunger = Math.min(100, pet.hunger + food.hunger);
    pet.exp = (pet.exp || 0) + food.exp;

    let levelUpMsg = '';
    const expNeeded = (pet.level || 1) * 100;
    if (pet.exp >= expNeeded) {
      pet.level = (pet.level || 1) + 1;
      pet.exp -= expNeeded;
      pet.stats = pet.stats || { ...petInfo.baseStats };
      pet.stats.attack += 2;
      pet.stats.defense += 1;
      pet.stats.luck += 1;
      levelUpMsg = `\n🎉 *WOOHOO! ${pet.name} LEVELED UP to Level ${pet.level}!* 🎉`;
    }

    setUser(jid, user);

    return fReply(conn, m,
      `Nom... nom... nom! 🤤🍖\n\n*${pet.name}* happily devours the *${food.name}* you gave!\n🍖 Hunger filled: *+${food.hunger}* (${pet.hunger}/100)\n✨ Got EXP: *+${food.exp}*${levelUpMsg}`,
      sessionName
    );
  }

  if (action === 'train') {
    if (pet.hunger < 20) {
      return errorReply(conn, m, `That's cruel, training them while starving! 😭\n*${pet.name}*'s stomach is growling, feed them first!`, sessionName);
    }

    pet.hunger = Math.max(0, pet.hunger - 15);
    const expGain = 20 + Math.floor(Math.random() * 20);
    pet.exp = (pet.exp || 0) + expGain;

    let levelUpMsg = '';
    const expNeeded = (pet.level || 1) * 100;
    if (pet.exp >= expNeeded) {
      pet.level = (pet.level || 1) + 1;
      pet.exp -= expNeeded;
      pet.stats = pet.stats || { ...petInfo.baseStats };
      pet.stats.attack += 2;
      pet.stats.defense += 1;
      pet.stats.luck += 1;
      levelUpMsg = `\n🎉 *NICE! ${pet.name} LEVELED UP to Level ${pet.level}!* 🎉`;
    }

    setUser(jid, user);

    let txt = `Hup! Hup! Hiyah!! 🏃‍♂️💨\n\n*${pet.name}* trained hard today!\n✨ EXP gained: *+${expGain}*\n😰 Hunger: *-15*${levelUpMsg}`;
    return fReply(conn, m, txt, sessionName);
  }

  if (action === 'rename') {
    const newName = args.slice(1).join(' ');
    if (!newName || newName.length < 2 || newName.length > 15) {
      return errorReply(conn, m, `What kind of name is that? Give a real one (2-15 characters)! 😂`, sessionName);
    }

    const oldName = pet.name;
    pet.name = newName;
    setUser(jid, user);

    return fReply(conn, m, `Done! Papers updated.\nThey now go by *${newName}*! (Previously: ${oldName}) ✨`, sessionName);
  }

  if (action === 'evolve') {
    if (!petInfo.evolve) {
      return errorReply(conn, m, `*${pet.name}* has reached their final form! Nothing left to evolve into! 🌟`, sessionName);
    }
    if ((pet.level || 1) < 10) {
      return errorReply(conn, m, `Patience — *${pet.name}* is still too young! Needs *Level 10* to evolve (currently Level ${pet.level || 1}). 🐣`, sessionName);
    }

    const evolvedPet = PET_TYPES[petInfo.evolve];
    pet.type = petInfo.evolve;
    pet.stats = { ...evolvedPet.baseStats };
    pet.level = 1;
    pet.exp = 0;

    setUser(jid, user);

    return fReply(conn, m,
      `*FLASH!!* ✨🌟\n\n*${pet.name}* suddenly glows brilliantly!\nThey've *evolved* into a mighty *${evolvedPet.name}*!\n\nStats reset but way stronger now — check with \`${prefix}pet status\`! 😎🔥`,
      sessionName
    );
  }
}
