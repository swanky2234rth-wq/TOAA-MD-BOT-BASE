// Auto-converted from legacy registerCmd('getgroups', ...) in main.js
// Category: owner
const {
  fReply,
  newsletterReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');
// NOTE: sessions.js is require()'d lazily inside the handler below to avoid a
// circular-require deadlock at boot (sessions.js -> main.js -> plugins -> sessions.js).

module.exports = {
  name: 'getgroups',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'getgroups': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
    const { activeSessions, stopSession, reloadExistingSessions } = require('../sessions');

  if (!ctx.isOwner) return newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
  try {
    const groups = await conn.groupFetchAllParticipating();
    const list = Object.values(groups).map((g, i) => `${i + 1}. ${g.subject} (${g.participants.length} members)`).join('\n');
    await fReply(conn, m, `👥 *Groups (${Object.keys(groups).length}):*\n\n${list || 'No groups.'}`, ctx.sessionName);
  } catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, ctx.sessionName); }

      }
    }
  }
};
