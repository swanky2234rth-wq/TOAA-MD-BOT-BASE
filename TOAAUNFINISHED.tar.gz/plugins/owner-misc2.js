const mainCore = require('../main');
const { errorReply, successReply, successSmartReply, unauthorizedReply, fReply, formatUptime, COMMANDS, PLUGINS } = mainCore;
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const settings = require('../settings');

module.exports = {
  name: 'Owner Batch 2',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'botstatus': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const mem = process.memoryUsage();
        const uptime = formatUptime(Date.now() - global.botStartTime);
        const msg = `🤖 Bot Status\n\n⏱️ Uptime: ${uptime}\n💾 RAM: ${(mem.heapUsed / 1024 / 1024).toFixed(2)} MB\n📚 Commands: ${Object.keys(COMMANDS).length}\n🔌 Plugins: ${PLUGINS.size}\n🖥️ Platform: ${process.platform}\n🔢 Node.js: ${process.version}`;
        await successSmartReply(conn, m, msg, ctx.sessionName);
      }
    },

    'update': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        await fReply(conn, m, "Updating bot...", ctx.sessionName);
        const { exec } = require('child_process');
        exec('git pull', (error, stdout) => {
          if (error) {
            conn.sendMessage(m.key.remoteJid, { text: `❌ Update failed: ${error.message}` }, { quoted: m });
          } else {
            conn.sendMessage(m.key.remoteJid, { text: `✅ Bot updated!\n\n${stdout.substring(0, 1000)}` }, { quoted: m });
          }
        });
      }
    },

    'clearcache': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const tempDir = path.join(__dirname, '..', 'temp');
        if (fs.existsSync(tempDir)) {
          const files = fs.readdirSync(tempDir);
          let count = 0;
          for (const file of files) {
            try { fs.unlinkSync(path.join(tempDir, file)); count++; } catch {}
          }
          await successReply(conn, m, `Cache cleared! Removed ${count} files.`, ctx.sessionName);
        } else {
          await successReply(conn, m, "No cache to clear.", ctx.sessionName);
        }
      }
    },

    'sessioninfo': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const { activeSessions } = require('../sessions');
        const list = [...activeSessions.keys()].map((id, i) => `${i + 1}. ${id}`).join('\n') || 'No active sessions';
        await successSmartReply(conn, m, `📱 Active Sessions\n\n${list}`, ctx.sessionName);
      }
    },

    'uploadfile': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const { getQuotedMsg, getMediaType, downloadMedia } = mainCore;
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t) return errorReply(conn, m, "Reply to a file!", ctx.sessionName);
        await fReply(conn, m, 'Uploading...', ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, t.type);
          const formData = new FormData();
          const filename = `file_${Date.now()}.${t.type === 'image' ? 'jpg' : t.type === 'video' ? 'mp4' : t.type === 'audio' ? 'mp3' : 'bin'}`;
          formData.append('file', buf, filename);
          const response = await axios.post('https://linkforgei.vercel.app/api/upload', formData, {
            headers: { 'x-api-key': settings.LINKFORGE_API_KEY || process.env.LINKFORGE_API_KEY, ...formData.getHeaders() },
            timeout: 60000
          });
          if (response.data?.success && response.data?.url) {
            await successReply(conn, m, `File uploaded!\n\n🔗 ${response.data.url}`, ctx.sessionName);
          } else {
            throw new Error("Upload failed");
          }
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'listprem': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        if (!ctx.isOwner) return unauthorizedReply(conn, m, ctx.sessionName);
        const { listPremium } = require('../helper/function');
        const list = listPremium();
        if (!list.length) return errorReply(conn, m, "No premium users.", ctx.sessionName);
        await successSmartReply(conn, m, `Premium Users:\n${list.map((n, i) => `${i + 1}. ${n}`).join('\n')}`, ctx.sessionName);
      }
    }
  }
};
