const mainCore = require('../main');
const { errorReply, successSmartReply, fReply, getQuotedMsg, getMediaType, downloadMedia } = mainCore;
const sharp = require('sharp');
const axios = require('axios');

module.exports = {
  name: 'Media Batch 3',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'watermark': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'image') return errorReply(conn, m, "Reply to an image", ctx.sessionName);
        const text = args.join(' ') || 'TOAA';
        await fReply(conn, m, 'Adding watermark...', ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'image');
          const img = sharp(buf);
          const metadata = await img.metadata();
          const watermarked = await img.composite([{
            input: Buffer.from(
              `<svg width="${metadata.width}" height="${metadata.height}">
                <text x="50%" y="50%" font-size="60" fill="rgba(255,255,255,0.3)" text-anchor="middle" dominant-baseline="middle" font-family="Arial"
                  transform="rotate(-30, ${metadata.width / 2}, ${metadata.height / 2})">${text}</text>
              </svg>`
            ),
            top: 0, left: 0
          }]).toBuffer();
          await conn.sendMessage(m.key.remoteJid, { image: watermarked, caption: 'Watermark added!' }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'textonimage': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'image') return errorReply(conn, m, "Reply to an image", ctx.sessionName);
        const text = args.join(' ') || 'TOAA';
        await fReply(conn, m, 'Adding text...', ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'image');
          const img = sharp(buf);
          const metadata = await img.metadata();
          const fontSize = Math.floor(Math.min(metadata.width, metadata.height) / 10);
          const svg = `<svg width="${metadata.width}" height="${metadata.height}">
            <text x="50%" y="50%" font-size="${fontSize}" fill="white" stroke="black" stroke-width="2" text-anchor="middle" dominant-baseline="middle" font-family="Arial">${text}</text>
          </svg>`;
          const result = await img.composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).toBuffer();
          await conn.sendMessage(m.key.remoteJid, { image: result, caption: 'Text added!' }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'video2gif2': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'video') return errorReply(conn, m, "Reply to a video", ctx.sessionName);
        await fReply(conn, m, 'Converting to GIF...', ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'video');
          await conn.sendMessage(m.key.remoteJid, { video: buf, gifPlayback: true, caption: 'GIF ready!' }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'imgurl': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t) return errorReply(conn, m, `Reply to an image, video, or document with ${ctx.prefix}imgurl`, ctx.sessionName);
        await fReply(conn, m, 'Uploading to CDN...', ctx.sessionName);
        try {
          const buffer = await downloadMedia(t.inner, t.type);
          const formData = new URLSearchParams();
          formData.append("key", process.env.IMGBB_API_KEY || "");
          formData.append("image", buffer.toString("base64"));
          const response = await axios.post("https://api.imgbb.com/1/upload", formData, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            timeout: 60000
          });
          if (response.data?.data?.url) {
            await successSmartReply(conn, m, `URL: ${response.data.data.url}\nExpires: Never`, ctx.sessionName);
          } else {
            throw new Error("Upload failed - no URL returned");
          }
        } catch (err) {
          await errorReply(conn, m, `Upload failed: ${err.message}`, ctx.sessionName);
        }
      }
    }
  }
};
