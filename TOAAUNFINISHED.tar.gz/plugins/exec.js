// plugins/exec.js
console.log('[EXEC] Plugin loaded!');

const { exec } = require('child_process');
const { fReply, errorReply } = require('../main');

// ─── OWNER NUMBERS ───────────────────────────────────────────────────────────
const OWNER_NUMBERS = ['2347047129088', '2347075251066'];

module.exports = {
  name: 'Exec',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'exec': {
      category: 'tools',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderNumber } = ctx;
        const remoteJid = m.key.remoteJid;
        const command = args.join(' ');

        // ─── OWNER CHECK ──────────────────────────────────────────────────────
        if (!OWNER_NUMBERS.includes(senderNumber)) {
          return fReply(conn, m, `*_۞ Access Denied_*`, sessionName);
        }

        if (!command) {
          return fReply(conn, m, 
            `📌 *Exec - Run Shell Commands*\n\n` +
            `Usage: *${prefix}exec <command>*\n` +
            `Example: *${prefix}exec ls -la*`,
            sessionName
          );
        }

        await fReply(conn, m, `⏳ Running: *${command}*`, sessionName);

        exec(command, { timeout: 30000 }, (error, stdout, stderr) => {
          const output = stdout || stderr || error?.message || 'No output';
          fReply(conn, m, 
            `📊 *Output:*\n\`\`\`\n${output.slice(0, 4000)}\n\`\`\``, 
            sessionName
          );
        });
      }
    }
  }
};