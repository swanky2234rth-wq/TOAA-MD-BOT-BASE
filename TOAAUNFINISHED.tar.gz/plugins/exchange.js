const mainCore = require('../main');
const { errorReply } = mainCore;
const econ = require('../helper/economy');

module.exports = {
  name: 'exchange',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'exchange': {
      category: 'economy',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, senderNumber } = ctx;
        const itemKey = (args[0] || '').toLowerCase().replace(/[^a-z]/g, '');
        const alias = { gem: 'gemstone', gemstone: 'gemstone', easteregg: 'easteregg', egg: 'easteregg', blacklotus: 'blacklotus', lotus: 'blacklotus', denarius: 'denarius', denariuscoin: 'denarius', coin: 'denarius' };
        const item = alias[itemKey];

        if (!item) {
          const list = Object.entries(econ.ITEM_LABELS).map(([k, label]) => `• ${label} — ${econ.fmtMoney(econ.ITEM_VALUES[k])} (${k})`).join('\n');
          return errorReply(conn, m,
            `Usage: ${ctx.prefix}exchange <item>\n\nExchangeable items:\n${list}`,
            sessionName
          );
        }

        const acc = econ.getAccount(senderNumber);
        if (!acc.items[item] || acc.items[item] <= 0) {
          return errorReply(conn, m, `You don't have any ${econ.ITEM_LABELS[item]}.`, sessionName);
        }

        econ.removeItem(senderNumber, item, 1);
        const value = econ.ITEM_VALUES[item];
        const newBalance = econ.addMoney(senderNumber, value);

        await conn.sendMessage(m.key.remoteJid, {
          text: `♻️ Exchanged 1x ${econ.ITEM_LABELS[item]} for ${econ.fmtMoney(value)}!\n💳 Balance: ${econ.fmtMoney(newBalance)}`
        }, { quoted: m });
      }
    }
  }
};
