// ─── TOAA GPT-4.1 Nano (via OverChat) ─────────
const { errorReply } = require('../main');
const crypto = require('crypto');

const API = 'https://api.overchat.ai/v1/chat/completions';
const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36';

async function GPT5(prompt, options = {}) {
  const chatId = options.chatId || crypto.randomUUID();
  const deviceId = options.deviceId || crypto.randomUUID();
  const model = options.model || 'openai/gpt-4.1-nano-2025-04-14';

  const messages = [
    ...(options.history || []).map((item) => ({ id: crypto.randomUUID(), role: item.role, content: item.content })),
    { id: crypto.randomUUID(), role: 'user', content: prompt },
  ];

  const body = {
    chatId, model, messages,
    personaId: 'gpt-4o-landing',
    frequency_penalty: 0, max_tokens: 4000, presence_penalty: 0,
    stream: true, temperature: 0.5, top_p: 0.95,
  };

  const headers = {
    'sec-ch-ua-platform': '"Android"',
    'x-device-uuid': deviceId,
    'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
    'sec-ch-ua-mobile': '?1',
    'x-device-language': 'id-ID',
    'x-device-platform': 'web',
    'x-device-version': '1.0.44',
    'user-agent': UA,
    accept: '*/*',
    'content-type': 'application/json',
    origin: 'https://overchat.ai',
    referer: 'https://overchat.ai/',
  };

  const response = await fetch(API, { method: 'POST', headers, body: JSON.stringify(body) });

  if (!response.ok) {
    const text = await response.text();
    return { status: false, code: response.status, error: text };
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let answer = '';
  let responseModel = null;

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim();
      if (!data || data === '[DONE]') continue;

      try {
        const json = JSON.parse(data);
        if (json.model) responseModel = json.model;
        const content = json.choices?.[0]?.delta?.content;
        if (typeof content === 'string') answer += content;
      } catch {}
    }
  }

  return { status: true, code: response.status, model: responseModel || model, answer };
}

module.exports = {
  name: 'gpt5',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'gpt5': { category: 'ai', handler: run },
    'gpt5nano': { category: 'ai', handler: run },
    'gpt41': { category: 'ai', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const text = args.join(' ').trim();

  if (!text) {
    return errorReply(conn, m,
      `🤖 *GPT-4.1 Nano*\n\nAsk anything, answered via the GPT-4.1 Nano model.\n\n*USAGE:*\n${prefix}gpt5 <question>\n\n*EXAMPLE:*\n${prefix}gpt5 What is quantum computing?\n${prefix}gpt5 Write a poem about the ocean\n\n_Might take a moment, hang tight._`,
      sessionName
    );
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

  try {
    const result = await GPT5(text);

    if (!result.status) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `GPT-5 failed: ${result.error || 'no response'}`, sessionName);
    }

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

    const reply = result.answer;
    await conn.sendMessage(m.key.remoteJid, { text: reply.length > 4096 ? reply.slice(0, 4096) + '...' : reply }, { quoted: m });

  } catch (e) {
    console.error('[GPT5] Error:', e.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
  }
}
