// ─── TOAA GitHub Repo Downloader ─────────
const { errorReply } = require('../main');

module.exports = {
  name: 'githubdl',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'githubdl': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;

        let username, repo, branch;

        if (args[0]?.includes('github.com')) {
          const urlMatch = args[0].match(/github\.com\/([^\/]+)\/([^\/]+)/i);
          if (urlMatch) {
            username = urlMatch[1];
            repo = urlMatch[2].replace(/\.git$/, '');
            branch = args[1] || 'main';
          }
        } else {
          username = args[0];
          repo = args[1];
          branch = args[2] || 'main';
        }

        if (!username) {
          return errorReply(conn, m,
            `Usage: ${prefix}githubdl <user> <repo> <branch>\nExample: ${prefix}githubdl niceplugin NiceBot main\nOr: ${prefix}githubdl https://github.com/user/repo`,
            sessionName
          );
        }
        if (!repo) {
          return errorReply(conn, m, `You need to give a repo name too.`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          const repoRes = await axios_fetch(`https://api.github.com/repos/${username}/${repo}`);
          if (!repoRes.ok) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Repo "${username}/${repo}" not found.`, sessionName);
          }

          const repoData = await repoRes.json();
          const defaultBranch = repoData.default_branch || 'main';
          branch = branch || defaultBranch;

          const zipUrl = `https://github.com/${username}/${repo}/archive/refs/heads/${branch}.zip`;

          const checkRes = await axios_fetch(zipUrl, { method: 'HEAD' });
          if (!checkRes.ok) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Branch "${branch}" doesn't exist. Default branch is "${defaultBranch}".`, sessionName);
          }

          await conn.sendMessage(m.key.remoteJid, {
            document: { url: zipUrl },
            fileName: `${repo}-${branch}.zip`,
            mimetype: 'application/zip',
            contextInfo: { forwardingScore: 99, isForwarded: true }
          }, { quoted: m });

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (e) {
          console.error('[GITHUBDL] Error:', e.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
        }
      }
    }
  }
};

// Node 18+ has global fetch; fall back gracefully if this Node version doesn't.
async function axios_fetch(url, opts) {
  if (typeof fetch === 'function') return fetch(url, opts);
  throw new Error('global fetch is not available on this Node version');
}
