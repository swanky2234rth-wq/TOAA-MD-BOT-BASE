// ─── TOAA Birthday Info ─────────
const { errorReply, getMentioned, getQuotedCtx, rawNumber } = require('../main');
const { getBirthday } = require('../helper/birthdayStore');

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

module.exports = {
  name: 'birthday',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'birthday': {
      category: 'user',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, senderJid } = ctx;

        const mentioned = getMentioned(m);
        const quotedCtx = getQuotedCtx(m);
        const target = mentioned[0] || quotedCtx?.participant || senderJid;

        const bday = getBirthday(target);

        if (!bday) {
          if (target === senderJid) {
            return errorReply(conn, m,
              `You haven't set your birthday yet!\n\nUse: ${prefix}setbirthday DD-MM\nExample: ${prefix}setbirthday 25-12`,
              sessionName
            );
          }
          return errorReply(conn, m, `That user hasn't set their birthday.`, sessionName);
        }

        const [day, month] = bday.split('-').map(Number);
        const now = new Date();
        const currentYear = now.getFullYear();
        let nextBday = new Date(currentYear, month - 1, day);
        if (nextBday < now) nextBday = new Date(currentYear + 1, month - 1, day);

        const diffDays = Math.ceil((nextBday.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        const isToday = now.getDate() === day && now.getMonth() === month - 1;

        let text = `🎂 *Birthday Info*\n\n`;
        text += `👤 @${rawNumber(target)}\n`;
        text += `📅 ${day} ${MONTHS[month - 1]}\n`;
        text += isToday ? `🎉 *TODAY IS THEIR BIRTHDAY!*` : `🕕 ${diffDays} day${diffDays !== 1 ? 's' : ''} away`;

        if (isToday) {
          text += `\n\n🎊 *HAPPY BIRTHDAY!* 🎊\nWishing you a great one! 🎉🎂`;
        }

        await conn.sendMessage(m.key.remoteJid, { text, mentions: [target] }, { quoted: m });
      }
    }
  }
};
