// ─── TOAA Country Stalk ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'countrystalk',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'country': {
      category: 'stalker',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix, command } = ctx;
        const text = args.join(' ').trim();

        if (!text) {
          return errorReply(conn, m, `🌍 Give me a country name!\nExample: ${prefix}${command} indonesia`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          // Swapped the source's neoxr.eu (key-gated) for restcountries.com — free, no key.
          const { data } = await axios.get(
            `https://restcountries.com/v3.1/name/${encodeURIComponent(text.trim())}?fields=name,capital,region,subregion,languages,population,currencies,timezones,car,flags`,
            { timeout: 15000 }
          );

          const c = Array.isArray(data) ? data[0] : null;

          if (!c) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `Couldn't find data for "${text}".`, sessionName);
          }

          const name = c.name?.common || text;
          const officialName = c.name?.official || '-';
          const population = c.population ? c.population.toLocaleString() : '-';
          const capitals = c.capital?.length ? c.capital.join(', ') : '-';
          const currencies = c.currencies
            ? Object.values(c.currencies).map(cur => `${cur.name} (${cur.symbol || ''})`).join(', ')
            : '-';
          const languages = c.languages ? Object.values(c.languages).join(', ') : '-';
          const timezones = c.timezones?.length ? c.timezones.join(', ') : '-';

          let txt = `🌍 *COUNTRY INFO: ${name.toUpperCase()}* 🌍\n\n`;
          txt += `🏢 *Capital:* ${capitals}\n`;
          txt += `📜 *Official Name:* ${officialName}\n`;
          txt += `🗺️ *Region:* ${c.region || '-'} (${c.subregion || '-'})\n`;
          txt += `🗣️ *Languages:* ${languages}\n`;
          txt += `👥 *Population:* ${population}\n`;
          txt += `💰 *Currency:* ${currencies}\n`;
          txt += `🕰️ *Timezones:* ${timezones}\n`;
          txt += `🚗 *Driving side:* ${c.car?.side || '-'}\n`;

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

          if (c.flags?.png) {
            await conn.sendMessage(m.key.remoteJid, { image: { url: c.flags.png }, caption: txt }, { quoted: m });
          } else {
            await errorReply(conn, m, txt, sessionName);
          }

        } catch (error) {
          console.error('[COUNTRYSTALK] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `Couldn't find that country — check the spelling.`, sessionName);
        }
      }
    }
  }
};
