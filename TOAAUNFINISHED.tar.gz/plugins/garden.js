// ─── TOAA RPG Garden ─────────
const { errorReply, fReply } = require('../main');
const { getUser, setUser, addExp, isRpgAllowed, addItem } = require('../helper/rpg');
const { getCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { GARDEN_CROPS } = require('../helper/rpgGarden');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

function fmtTime(ms) {
  const minutes = Math.floor(ms / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  return minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
}

module.exports = {
  name: 'garden',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'garden': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const user = getUser(jid);
  if (!user.garden) user.garden = { plots: [], maxPlots: 3 };

  const action = args[0]?.toLowerCase();
  const cropKey = args[1]?.toLowerCase();

  if (!action || !['plant', 'harvest', 'status', 'buy'].includes(action)) {
    let txt = `Hey Farmer! 👨‍🌾🌻\nYour personal garden info center.\n\n`;
    txt += `*Garden Menu:*\n`;
    txt += `• \`${prefix}garden status\` — Check garden status\n`;
    txt += `• \`${prefix}garden buy <crop> <qty>\` — Buy seeds\n`;
    txt += `• \`${prefix}garden plant <crop>\` — Plant a seed in an empty plot\n`;
    txt += `• \`${prefix}garden harvest\` — Harvest everything ready\n\n`;
    txt += `*Available Seeds:*\n`;
    for (const [key, crop] of Object.entries(GARDEN_CROPS)) {
      txt += `\n*${crop.name}*\n⏳ Grow time: ${fmtTime(crop.growTime)}\n💰 Sell price: ${fmtCoin(crop.sellPrice)} | 🌱 Seed price: ${fmtCoin(crop.seedPrice)}\n👉 Buy: \`${prefix}garden buy ${key}\`\n`;
    }
    return fReply(conn, m, txt, sessionName);
  }

  if (action === 'status') {
    const garden = user.garden;
    let txt = `Checking the garden plots... 🚜🌱\n\n*Plot capacity:* ${garden.plots.length}/${garden.maxPlots} filled.\n\n`;

    if (garden.plots.length === 0) {
      txt += `Your garden's bare! 🏜️\nBuy seeds and plant with \`${prefix}garden plant <name>\` to get it green again!`;
    } else {
      txt += `*Plot List:*\n`;
      garden.plots.forEach((plot, i) => {
        const crop = GARDEN_CROPS[plot.crop];
        const elapsed = Date.now() - plot.plantedAt;
        const remaining = Math.max(0, crop.growTime - elapsed);
        const ready = remaining <= 0;
        txt += `\n📍 Plot ${i + 1}: *${crop.name}*\n└ Status: ${ready ? '✨ READY TO HARVEST! ✨' : `Growing, ⏳ ${fmtTime(remaining)} left`}\n`;
      });
    }
    return fReply(conn, m, txt, sessionName);
  }

  if (action === 'buy') {
    if (!cropKey) {
      return errorReply(conn, m, `Which seed do you want to buy? Name it!\nExample: \`${prefix}garden buy carrot 5\``, sessionName);
    }

    const crop = GARDEN_CROPS[cropKey];
    if (!crop) {
      return errorReply(conn, m, `That seed isn't sold at our farm store!\nCheck the list with \`${prefix}garden\``, sessionName);
    }

    const qty = Math.max(1, parseInt(args[2]) || 1);
    const totalCost = crop.seedPrice * qty;
    const balance = getCoin(jid);

    if (balance < totalCost) {
      return errorReply(conn, m, `Not enough coin!\nTotal cost: ${fmtCoin(totalCost)}, your coin: ${fmtCoin(balance)}.`, sessionName);
    }

    removeCoin(jid, totalCost);
    addItem(jid, crop.seed, qty);

    return fReply(conn, m, `Thanks for shopping at the Farm Store! 🛒🌱\n\nYou bought *${qty}x ${crop.name} Seeds*\nTotal paid: *${fmtCoin(totalCost)}*\n\nDon't forget to plant with \`${prefix}garden plant ${cropKey}\`!`, sessionName);
  }

  if (action === 'plant') {
    if (!cropKey) {
      return errorReply(conn, m, `Soil's ready, but what seed do we plant? 🌱\nExample: \`${prefix}garden plant carrot\``, sessionName);
    }

    const crop = GARDEN_CROPS[cropKey];
    if (!crop) {
      return errorReply(conn, m, `That crop isn't in the farming handbook!`, sessionName);
    }

    if (user.garden.plots.length >= user.garden.maxPlots) {
      return errorReply(conn, m, `All your plots are full! 🚜💨\nHarvest first, or wait for a garden upgrade!`, sessionName);
    }

    const have = user.inventory[crop.seed] || 0;
    if (have < 1) {
      return errorReply(conn, m, `You don't have any *${crop.name}* seeds!\nBuy some first at \`${prefix}garden buy ${cropKey}\``, sessionName);
    }

    user.inventory[crop.seed] = have - 1;
    if (user.inventory[crop.seed] <= 0) delete user.inventory[crop.seed];

    user.garden.plots.push({ crop: cropKey, plantedAt: Date.now() });
    setUser(jid, user);

    return fReply(conn, m, `Nice! *${crop.name}* seed planted in the soil! 🌱💦\nJust wait *${fmtTime(crop.growTime)}* to harvest!`, sessionName);
  }

  if (action === 'harvest') {
    const garden = user.garden;
    const readyPlots = garden.plots.filter(p => Date.now() - p.plantedAt >= GARDEN_CROPS[p.crop].growTime);

    if (readyPlots.length === 0) {
      return errorReply(conn, m, `Nothing's ripe yet! Patience! 😂\nCheck timing with \`${prefix}garden status\``, sessionName);
    }

    let totalExp = 0;
    const harvestedItems = [];

    for (const plot of readyPlots) {
      const crop = GARDEN_CROPS[plot.crop];
      const qty = Math.floor(Math.random() * 3) + 2;
      addItem(jid, crop.item, qty);
      totalExp += crop.exp;
      harvestedItems.push(`• ${crop.name} x${qty}`);
    }

    user.garden.plots = garden.plots.filter(p => Date.now() - p.plantedAt < GARDEN_CROPS[p.crop].growTime);
    setUser(jid, user);

    const levelResult = addExp(jid, totalExp);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

    const txt = `HARVEST TIME! 🚜🌾✨\n\nYour hard work paid off, here's what you got:\n${harvestedItems.join('\n')}\n\n📈 Farming Bonus EXP: *+${totalExp}*\n\nPlant more to get richer! 💸`;
    await conn.sendMessage(m.key.remoteJid, { text: txt }, { quoted: m });

    return notifyLevelUp(conn, m, jid, levelResult);
  }
}
