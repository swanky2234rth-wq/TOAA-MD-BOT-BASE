// Auto-converted from legacy registerCmd('tiktok', ...) in main.js
// Category: downloader
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'tiktok',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'tiktok': {
      category: 'downloader',
      handler: async (conn, m, args, ctx) => {

    const { prefix, sessionName } = ctx;
    const text = args.join(' ').trim();
    if (!text || !text.startsWith('http')) return fReply(conn, m, `Usage: ${prefix}tiktok <link>`, sessionName);
    await fReply(conn, m, '⏳ *Downloading TikTok (no watermark)...*', sessionName);
    try {
        const hvTt = await axios.get('https://heavstal-tech.vercel.app/api/v1/downloader/tiktok', { params: { url: text }, headers: { 'x-api-key': 'ht_live_74717f5f78ba30a2d1ff867fb36827fe' }, timeout: 30000 });
        const ttData = hvTt.data?.data || hvTt.data?.result || hvTt.data;
        const noWmUrl = ttData?.video_nowm || ttData?.video_no_wm || ttData?.nowm;
        if (noWmUrl) await conn.sendMessage(m.key.remoteJid, { video: { url: noWmUrl }, caption: `🧩 *TikTok (No Watermark)*` }, { quoted: m });
        else throw new Error('No video URL');
    } catch (e) { await fReply(conn, m, `🎴 *Failed:* ${e.message}`, sessionName); }

      }
    }
  }
};
