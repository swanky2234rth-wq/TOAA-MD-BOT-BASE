// plugins/playvid.js
const axios = require('axios');
const { getSessionSetting } = require('../helper/function');
const { applyFont } = require('../helper/fonts');

async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}
async function errorReply(conn, m, text, sessionName) { await fReply(conn, m, `❌ ${text}`, sessionName); }

async function fetchJson(url) {
  const response = await axios.get(url);
  return response.data;
}

module.exports = {
  name: 'YouTube Video Player',
  version: '1.0.0',
  author: 'TOAA',

  commands: {
    'playvid': {
      category: 'downloader',
      handler: async (nuell, hex, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const text = args.join(' ').trim();

        if (!text)
          return fReply(nuell, hex,
            `🎬 *YouTube Video Downloader*\n\nUsage: ${prefix}playvid <search or URL>\n\nExample:\n${prefix}playvid dj tiktok`,
            sessionName
          );

        await nuell.sendMessage(hex.key.remoteJid, { react: { text: '🔎', key: hex.key } });

        try {
          const apiUrl = `https://api.vreden.my.id/api/v1/download/play/video?query=${encodeURIComponent(text)}`;
          const anu = await fetchJson(apiUrl);

          if (!anu || !anu.status || !anu.result || !anu.result.download)
            return errorReply(nuell, hex, 'Video not found!', sessionName);

          const meta = anu.result.metadata;
          const down = anu.result.download;

          await nuell.sendMessage(hex.key.remoteJid, {
            image: { url: meta.image },
            caption:
              `🎬 *VIDEO RESULT*\n\n📌 *Title:* ${meta.title}\n👤 *Author:* ${meta.author?.name || 'Unknown'}\n⏱️ *Duration:* ${meta.duration?.timestamp || '?'}\n👁️ *Views:* ${meta.views || '?'}\n📅 *Uploaded:* ${meta.ago || '?'}`
          }, { quoted: hex });

          await nuell.sendMessage(hex.key.remoteJid, {
            video: { url: down.url },
            mimetype: 'video/mp4',
            fileName: down.filename || 'video.mp4',
            caption: `✅ Video downloaded (${down.quality || '360p'})`
          }, { quoted: hex });

          await nuell.sendMessage(hex.key.remoteJid, { react: { text: '✅', key: hex.key } });
        } catch (e) {
          console.error('[PLAYVID] Error:', e.message);
          await nuell.sendMessage(hex.key.remoteJid, { react: { text: '❌', key: hex.key } });
          await errorReply(nuell, hex, `Error: ${e.message}`, sessionName);
        }
      }
    }
  }
};
