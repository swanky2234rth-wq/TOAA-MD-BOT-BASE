const backup = require('../helper/backup');

module.exports = {
  name: 'restoredatabase',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'restoredatabase': {
      category: 'owner',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, isOwner } = ctx;
        const mainCore = require('../main');
        if (!isOwner) return mainCore.unauthorizedReply(conn, m, sessionName);

        if (!backup.hasBackup(sessionName)) {
          await conn.sendMessage(m.key.remoteJid, {
            text: `📦 No saved database to restore from yet.`
          }, { quoted: m });
          return;
        }

        const ok = backup.restoreSessionBackup(sessionName);
        await conn.sendMessage(m.key.remoteJid, {
          text: ok
            ? `✅ Database restored! Your prefix, mode, font, and group protection settings are back.`
            : `❌ Restore failed — the backup file may be corrupted.`
        }, { quoted: m });
      }
    }
  }
};
