// plugins/battle.js
const activeBattles = new Map();

module.exports = {
  name: 'Battle System',
  version: '1.1.0',
  author: 'TOAA',
  handleBattle: handleBattle,  // ← ADD THIS LINE
  
  commands: {
    'battle': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        // Required directly from helper/function.js (where these actually
        // live) rather than via '../main', since main.js requires this file
        // at its own top level for handleBattle — a top-level require('../main')
        // here would create a circular-dependency race.
        const { getSessionSetting, applyFont, resolveDisplayJid } = require('../helper/function');
        const { sessionName, prefix, senderNumber, senderJid } = ctx;
        const remoteJid = m.key.remoteJid;
        
        let target = null;
        if (args[0]) {
          const num = args[0].replace(/[^0-9]/g, '');
          if (num) target = `${num}@s.whatsapp.net`;
        }
        
        if (!target && m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
          target = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }
        
        if (!target || target === senderJid) {
          return fReply(conn, m, `⚔️ *Battle Challenge*\n\nUsage: ${prefix}battle @user\n\nChallenge someone to a fight!`, sessionName);
        }

        // Resolve a possibly-LID target to its real phone-number jid before
        // storing it — the battle state keeps this number for the whole
        // fight, so getting it right here matters more than most one-off replies.
        if (remoteJid.endsWith('@g.us')) {
          const meta = await conn.groupMetadata(remoteJid).catch(() => null);
          if (meta?.participants) target = resolveDisplayJid(target, meta.participants);
        }
        
        if (activeBattles.has(remoteJid)) {
          return fReply(conn, m, '⚔️ *A battle is already in progress!*', sessionName);
        }
        
        const targetName = target.split('@')[0];
        
        const battle = {
          player1: senderNumber,
          player2: target.split('@')[0],
          p1HP: 100,
          p2HP: 100,
          turn: senderNumber,
          active: true,
          timer: null
        };
        
        activeBattles.set(remoteJid, battle);
        
        await conn.sendMessage(remoteJid, {
          text: `⚔️ *BATTLE STARTED!* ⚔️\n\n` +
                `👤 @${senderNumber} vs 👤 @${targetName}\n\n` +
                `❤️ ${senderNumber}: ${battle.p1HP} HP\n` +
                `💙 ${targetName}: ${battle.p2HP} HP\n\n` +
                `🔫 @${senderNumber} goes first!\n\n` +
                `*Commands:*\n` +
                `• attack - Deal 10-20 damage\n` +
                `• heal - Restore 10-30 HP\n` +
                `• ult - Deal 30-50 damage (3 turn cooldown)`,
          mentions: [`${senderNumber}@s.whatsapp.net`, target]
        }, { quoted: m });
        
        battle.timer = setTimeout(() => {
          activeBattles.delete(remoteJid);
          conn.sendMessage(remoteJid, { text: '⏰ *Battle timeout! Game ended.*' });
        }, 120000);
      }
    }
  }
};

async function handleBattle(conn, m, senderNumber) {
  const remoteJid = m.key.remoteJid;
  const battle = activeBattles.get(remoteJid);
  if (!battle || !battle.active) return false;
  
  const text = getMsgText(m).trim().toLowerCase();
  if (!['attack', 'heal', 'ult'].includes(text)) return false;
  
  if (battle.turn !== senderNumber) {
    await conn.sendMessage(remoteJid, { text: `⏳ Wait for your turn, @${senderNumber}!`, mentions: [`${senderNumber}@s.whatsapp.net`] });
    return true;
  }
  
  clearTimeout(battle.timer);
  
  const isPlayer1 = senderNumber === battle.player1;
  let damage = 0;
  let heal = 0;
  let message = '';
  
  if (text === 'attack') {
    damage = Math.floor(Math.random() * 11) + 10;
    message = `⚔️ @${senderNumber} attacks for ${damage} damage!`;
  } else if (text === 'heal') {
    heal = Math.floor(Math.random() * 21) + 10;
    if (isPlayer1) {
      battle.p1HP = Math.min(100, battle.p1HP + heal);
      message = `💚 @${senderNumber} heals for ${heal} HP!`;
    } else {
      battle.p2HP = Math.min(100, battle.p2HP + heal);
      message = `💚 @${senderNumber} heals for ${heal} HP!`;
    }
  } else if (text === 'ult') {
    damage = Math.floor(Math.random() * 21) + 30;
    message = `✨ @${senderNumber} uses ULTIMATE for ${damage} damage!`;
  }
  
  if (damage > 0) {
    if (isPlayer1) {
      battle.p2HP -= damage;
      message += `\n💙 Opponent HP: ${Math.max(0, battle.p2HP)}/${battle.p2HP + damage}`;
    } else {
      battle.p1HP -= damage;
      message += `\n❤️ Opponent HP: ${Math.max(0, battle.p1HP)}/${battle.p1HP + damage}`;
    }
  }
  
  if (battle.p1HP <= 0 || battle.p2HP <= 0) {
    const winner = battle.p1HP <= 0 ? battle.player2 : battle.player1;
    activeBattles.delete(remoteJid);
    await conn.sendMessage(remoteJid, {
      text: `🏆 *BATTLE OVER!*\n\n👑 @${winner} WINS!\n\n❤️ Final HP:\n• ${battle.player1}: ${Math.max(0, battle.p1HP)} HP\n• ${battle.player2}: ${Math.max(0, battle.p2HP)} HP`,
      mentions: [`${battle.player1}@s.whatsapp.net`, `${battle.player2}@s.whatsapp.net`]
    });
    return true;
  }
  
  battle.turn = battle.turn === battle.player1 ? battle.player2 : battle.player1;
  
  await conn.sendMessage(remoteJid, {
    text: `${message}\n\n❤️ ${battle.player1}: ${battle.p1HP} HP\n💙 ${battle.player2}: ${battle.p2HP} HP\n\n🎮 @${battle.turn}'s turn!`,
    mentions: [`${battle.player1}@s.whatsapp.net`, `${battle.player2}@s.whatsapp.net`, `${battle.turn}@s.whatsapp.net`]
  });
  
  battle.timer = setTimeout(() => {
    activeBattles.delete(remoteJid);
    conn.sendMessage(remoteJid, { text: '⏰ *Battle timeout! Game ended.*' });
  }, 60000);
  
  return true;
}

function getMsgText(m) {
  return m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption || '';
}

async function fReply(conn, m, text, sessionName) {
  const { getSessionSetting, applyFont } = require('../helper/function');
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}