// Auto-converted from legacy registerCmd('shortlink', ...) in main.js
// Category: utilities
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'shortlink',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'shortlink': {
      category: 'utilities',
      handler: async (conn, m, args, ctx) => {

  const { prefix, sessionName } = ctx; const url = args[0]?.trim();
  if (!url) return fReply(conn, m, `Usage: ${prefix}shortlink <url>`, sessionName);
  try { const { data } = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`); await fReply(conn, m, `🔗 *Shortened:*\n${data}`, sessionName); }
  catch (e) { await fReply(conn, m, `*_۞ 𝙴𝚛𝚛𝚘𝚛: ${e.message}_*`, sessionName); }

      }
    }
  }
};
