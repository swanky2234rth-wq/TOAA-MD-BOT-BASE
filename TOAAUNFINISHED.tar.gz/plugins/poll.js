// Auto-converted from legacy registerCmd('poll', ...) in main.js
// Category: group
const {
  fReply
} = require('../main');
const axios = require('axios');
const settings = require('../settings');

module.exports = {
  name: 'poll',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'poll': {
      category: 'group',
      handler: async (conn, m, args, ctx) => {

  if (!m.key.remoteJid.endsWith('@g.us')) return fReply(conn, m, '*_۞ 𝙶𝚛𝚘𝚞𝚙𝚜 𝙾𝚗𝚕𝚢_*', ctx.sessionName);
  const input = args.join(' ').trim();
  if (!input.includes('|')) return fReply(conn, m, `Usage: ${ctx.prefix}poll Question | Opt1 | Opt2`, ctx.sessionName);
  const parts = input.split('|').map(p => p.trim());
  const question = parts[0]; const options = parts.slice(1);
  if (options.length < 2) return fReply(conn, m, '*_۞ 𝙽𝚎𝚎𝚍 2+ 𝙾𝚙𝚝𝚒𝚘𝚗𝚜_*', ctx.sessionName);
  await conn.sendMessage(m.key.remoteJid, { poll: { name: question, values: options, selectableCount: 1 } }, { quoted: m });

      }
    }
  }
};
