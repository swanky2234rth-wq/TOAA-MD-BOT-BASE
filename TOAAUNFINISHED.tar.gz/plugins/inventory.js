// ─── TOAA RPG Inventory ─────────
const { fReply } = require('../main');
const { getUser, isRpgAllowed } = require('../helper/rpg');
const { getWallet, fmtCoin } = require('../helper/rpgCoin');
const { ITEMS, getCategories } = require('../helper/rpgItems');
const { getSessionSetting } = require('../helper/function');

module.exports = {
  name: 'inventory',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'inventory': {
      category: 'rpg',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const jid = m.key.participant || m.key.remoteJid;

        if (!isRpgAllowed(m, ctx, getSessionSetting)) {
          return fReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
        }

        const user = getUser(jid);
        const wallet = getWallet(jid);
        const categories = getCategories();

        let txt = `🎒 *YOUR INVENTORY*\n\n`;
        txt += `❤️ HP: *${user.health}/${user.maxHealth}*\n`;
        txt += `💰 Coin: *${fmtCoin(wallet.coin)}*\n`;
        txt += `🏦 Bank: *${fmtCoin(wallet.bank)}*\n`;
        txt += `📈 EXP: *${user.exp.toLocaleString('en-US')}*\n\n`;

        let hasItem = false;
        for (const [catName, keys] of Object.entries(categories)) {
          let catText = '';
          for (const key of keys) {
            const count = user.inventory[key] || 0;
            if (count > 0) {
              const item = ITEMS[key];
              catText += `${item.emote} ${item.name}: *${count}x*\n`;
              hasItem = true;
            }
          }
          if (catText) {
            txt += `*${catName}*\n${catText}\n`;
          }
        }

        if (!hasItem) {
          txt += `Your bag's empty! Go play some RPG commands to fill it up. 🚀\n`;
        } else {
          txt += `Use *${prefix}use <item>* to use something! 🎒\n`;
        }

        return fReply(conn, m, txt, sessionName);
      }
    }
  }
};
