// ─── TOAA Alight Motion Downloader ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'alightmotiondl',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'alightmotiondl': { category: 'downloader', handler: run },
    'alightmotion': { category: 'downloader', handler: run },
    'amdl': { category: 'downloader', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const text = args.join(' ').trim();

  if (!text) {
    return errorReply(conn, m,
      `📥 *ALIGHT MOTION DOWNLOADER*\n\nDownload projects/presets from Alight Motion.\n\n*Usage:*\n${prefix}amdl <alight_motion_link>\n\n*Example:* ${prefix}amdl https://alight.link/xxxxx`,
      sessionName
    );
  }

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

  try {
    const apiUrl = `https://kyzznekoo.zone.id/api/alightmotion/download?url=${encodeURIComponent(text.trim())}`;

    const { data } = await axios.get(apiUrl, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36' },
      timeout: 60000
    });

    if (!data?.status || !data?.data?.url) {
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      return errorReply(conn, m, `That Alight Motion link is invalid or the project was deleted.`, sessionName);
    }

    await conn.sendMessage(m.key.remoteJid, {
      document: { url: data.data.url },
      mimetype: 'application/zip',
      fileName: `AlightMotion_TOAA.zip`,
      caption: `✅ Downloaded Alight Motion preset!`
    }, { quoted: m });

    await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

  } catch (error) {
    console.error('[ALIGHTMOTIONDL] Error:', error.message);
    await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
    await errorReply(conn, m, `Something went wrong — try again.`, sessionName);
  }
}
