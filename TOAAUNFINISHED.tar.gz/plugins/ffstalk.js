// ─── TOAA Free Fire Stalk ─────────
const { errorReply } = require('../main');
const axios = require('axios');

module.exports = {
  name: 'ffstalk',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'ffstalk': {
      category: 'stalker',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const uid = args[0]?.trim();

        if (!uid) {
          return errorReply(conn, m, `🔥 *Free Fire Stalk*\n\nUsage: ${prefix}ffstalk <uid>\nExample: ${prefix}ffstalk 470699855`, sessionName);
        }

        await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

        try {
          const { data } = await axios.get(`https://api.nexray.eu.cc/stalker/freefire?uid=${encodeURIComponent(uid)}`, {
            timeout: 30000,
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
          });

          if (!data.status || !data.result) {
            await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
            return errorReply(conn, m, `UID *${uid}* not found or the API is having issues.`, sessionName);
          }

          const r = data.result;

          let caption = `🔥 *FREE FIRE STALK* 🔥\n\n`;
          caption += `👤 *BASIC INFO*\n`;
          caption += `  - Name: *${r.name || '-'}*\n`;
          caption += `  - Level: ${r.level || '-'} (EXP: ${r.exp || '-'})\n`;
          caption += `  - Region: ${r.region || '-'}\n`;
          caption += `  - Likes: ${r.likes || '-'} ❤️\n`;
          caption += `  - Credit Score: ${r.credit_score || '-'}\n`;
          caption += `  - Bio: ${r.signature || '-'}\n\n`;

          caption += `🏆 *RANKING & ACTIVITY*\n`;
          caption += `  - BR Rank Point: ${r.br_rank_point || '-'} (Max: ${r.br_max_rank || '-'})\n`;
          caption += `  - CS Rank Point: ${r.cs_rank_point || '-'} (Max: ${r.cs_max_rank || '-'})\n`;
          caption += `  - Season ID: ${r.season_id || '-'}\n`;
          caption += `  - Account Created: ${r.created_at || '-'}\n`;
          caption += `  - Last Login: ${r.last_login || '-'}\n\n`;

          caption += `🛡️ *GUILD INFO*\n`;
          caption += `  - Guild Name: ${r.guild_name && r.guild_name !== 'None' ? r.guild_name : 'No guild'}\n`;
          if (r.guild_name && r.guild_name !== 'None') {
            caption += `  - Guild Level: ${r.guild_level || '-'}\n`;
            caption += `  - Members: ${r.guild_member || '-'}/${r.guild_capacity || '-'}\n`;
            caption += `  - Guild Leader: ${r.guild_leader_name || '-'} (UID: ${r.guild_leader_uid || '-'})\n`;
          }
          caption += `\n`;

          caption += `🐾 *PET INFO*\n`;
          caption += `  - Pet Level: ${r.pet_level || '-'}\n`;
          caption += `  - Pet EXP: ${r.pet_exp || '-'}\n`;

          const isValidUrl = r.banner_image && (r.banner_image.startsWith('http://') || r.banner_image.startsWith('https://'));

          if (isValidUrl) {
            await conn.sendMessage(m.key.remoteJid, { image: { url: r.banner_image }, caption }, { quoted: m });
          } else {
            await errorReply(conn, m, caption, sessionName);
          }

          await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });

        } catch (error) {
          console.error('[FFSTALK] Error:', error.message);
          await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
          await errorReply(conn, m, `System couldn't pull data from the Free Fire server — try again later.`, sessionName);
        }
      }
    }
  }
};
