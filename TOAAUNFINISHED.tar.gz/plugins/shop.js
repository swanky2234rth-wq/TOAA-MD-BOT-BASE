// ─── TOAA RPG Shop ─────────
// NOTE: legacy source had both shop.js and merchant.js — same NPC-shop
// concept. Ported shop.js (cleaner buy-only/sell-only split per item).
// Dropped buyable farm ingredients (wheat/rice/egg/carrot/potato/
// strawberry/watermelon) since cook.js's recipes were already rebuilt to
// use gatherable materials instead — nothing in this project needs them.
const { errorReply, fReply } = require('../main');
const { isRpgAllowed, getUser, addItem, removeItem } = require('../helper/rpg');
const { getCoin, addCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { getSessionSetting } = require('../helper/function');

const SHOP_ITEMS = {
  potion: { price: 500, type: 'buyable', name: '🥤 Health Potion' },
  mpotion: { price: 500, type: 'buyable', name: '🧪 Mana Potion' },
  stamina: { price: 1000, type: 'buyable', name: '⚡ Stamina Potion' },

  common: { price: 2000, type: 'buyable', name: '📦 Common Crate' },
  uncommon: { price: 10000, type: 'buyable', name: '🛍️ Uncommon Crate' },
  mythic: { price: 50000, type: 'buyable', name: '🎁 Mythic Crate' },
  legendary: { price: 200000, type: 'buyable', name: '💎 Legendary Crate' },

  herb: { price: 150, type: 'buyable', name: '🌿 Herb' },
  meat: { price: 300, type: 'buyable', name: '🍖 Meat' },
  apple: { price: 50, type: 'buyable', name: '🍎 Apple' },
  flower: { price: 60, type: 'buyable', name: '🌸 Flower' },
  mushroom: { price: 60, type: 'buyable', name: '🍄 Mushroom' },
  bread: { price: 40, type: 'buyable', name: '🍞 Bread' },
  fruit: { price: 50, type: 'buyable', name: '🍎 Fruit' },
  premium_food: { price: 500, type: 'buyable', name: '⭐ Premium Food' },

  rock: { price: 20, type: 'sellable', name: '🪨 Rock' },
  coal: { price: 50, type: 'sellable', name: '⚫ Coal' },
  iron: { price: 200, type: 'sellable', name: '⛓️ Iron' },
  gold: { price: 1000, type: 'sellable', name: '🥇 Gold' },
  diamond: { price: 5000, type: 'sellable', name: '💠 Diamond' },
  emerald: { price: 10000, type: 'sellable', name: '💚 Emerald' },

  trash: { price: 10, type: 'sellable', name: '🗑️ Trash' },
  fish: { price: 100, type: 'sellable', name: '🐟 Fish' },
  prawn: { price: 200, type: 'sellable', name: '🦐 Prawn' },
  octopus: { price: 500, type: 'sellable', name: '🐙 Octopus' },
  shark: { price: 2000, type: 'sellable', name: '🦈 Shark' },
  whale: { price: 10000, type: 'sellable', name: '🐳 Whale' },

  leather: { price: 50, type: 'sellable', name: '👞 Leather' },
  mysterybox: { price: 1500, type: 'sellable', name: '📦 Mystery Box' },
  kunai: { price: 100, type: 'sellable', name: '🗡️ Kunai' },
  shuriken: { price: 150, type: 'sellable', name: '⚔️ Shuriken' },
  chakra: { price: 500, type: 'sellable', name: '🌀 Chakra' },
  scroll: { price: 2000, type: 'sellable', name: '📜 Scroll' },
  bowlramen: { price: 800, type: 'sellable', name: '🍜 Ramen' }
};

module.exports = {
  name: 'shop',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'shop': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName, prefix } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const action = args[0]?.toLowerCase();

  if (!action || (action !== 'buy' && action !== 'sell')) {
    let txt = `🏪 *RPG GENERAL STORE* ✨\n\nWelcome! Looking for potions or selling scrap? 😂\n\n`;
    txt += `*How to trade:* 💸\nType \`${prefix}shop buy <name> <qty>\` to buy.\nType \`${prefix}shop sell <name> <qty>\` to sell.\n\n`;

    txt += `*🛍️ FOR SALE (BUY):*\n`;
    for (const item of Object.values(SHOP_ITEMS)) {
      if (item.type === 'buyable') txt += `${item.name}: *${fmtCoin(item.price)}*\n`;
    }
    txt += `\n`;

    txt += `*💰 ACCEPTED (SELL):*\n`;
    for (const item of Object.values(SHOP_ITEMS)) {
      if (item.type === 'sellable') txt += `${item.name}: *${fmtCoin(item.price)}*\n`;
    }

    return fReply(conn, m, txt, sessionName);
  }

  const itemKey = args[1]?.toLowerCase();
  const amount = parseInt(args[2]) || 1;

  if (!itemKey || !SHOP_ITEMS[itemKey]) {
    return errorReply(conn, m, `That item isn't on the shelf! 😭❌\nCheck the list with \`${prefix}shop\`.`, sessionName);
  }

  const item = SHOP_ITEMS[itemKey];

  if (action === 'buy') {
    if (item.type !== 'buyable') {
      return errorReply(conn, m, `*${item.name}* is a sell-only item, can't be bought here! 🫣❌`, sessionName);
    }

    const totalCost = item.price * amount;
    const balance = getCoin(jid);

    if (balance < totalCost) {
      return errorReply(conn, m, `Not enough coin for *${amount}x ${item.name}*! 😭\nYour coin: *${fmtCoin(balance)}*\nShort by: *${fmtCoin(totalCost - balance)}*. Go earn some more! 💸🏃`, sessionName);
    }

    removeCoin(jid, totalCost);
    addItem(jid, itemKey, amount);

    return fReply(conn, m, `THANKS FOR SHOPPING! 🎉✨\n\nYou bought:\n🛒 Item: *${amount}x ${item.name}*\n💸 Total paid: *${fmtCoin(totalCost)}*\n\nCome back soon! 💖🛍️`, sessionName);
  }

  if (action === 'sell') {
    if (item.type !== 'sellable') {
      return errorReply(conn, m, `Sorry, we don't buy *${item.name}* here! 😂❌`, sessionName);
    }

    const user = getUser(jid);
    const stock = user.inventory[itemKey] || 0;

    if (stock < amount) {
      return errorReply(conn, m, `You only have *${stock}x ${item.name}*, can't sell *${amount}*! 😂❌`, sessionName);
    }

    const totalProfit = item.price * amount;
    removeItem(jid, itemKey, amount);
    addCoin(jid, totalProfit);

    return fReply(conn, m, `CHA-CHING! 💰✨\n\nYou sold:\n📦 Item: *${amount}x ${item.name}*\n🤑 Earned: *${fmtCoin(totalProfit)}*\n\nThanks for the trade! 🎉💖`, sessionName);
  }
}
