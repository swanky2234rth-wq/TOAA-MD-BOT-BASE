// plugins/audio-effects.js
console.log('[AUDIO-EFFECTS] Plugin loaded!');

const fs = require('fs');
const path = require('path');
const { tmpdir } = require('os');
const { fReply, errorReply, downloadMedia } = require('../main');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');

if (ffmpegPath) ffmpeg.setFfmpegPath(ffmpegPath);

module.exports = {
  name: 'AudioEffects',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'bass': {
      category: 'audio',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.audioMessage) {
          return fReply(conn, m, `🎧 Reply to an *audio message* to apply bass effect.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const media = await downloadMedia(quoted.audioMessage, 'audio');
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp3`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_bass.mp3`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .audioBitrate('8k')
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg' 
          }, { quoted: m });

        } catch (error) {
          console.error('[BASS] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to apply bass effect.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'blown': {
      category: 'audio',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.audioMessage) {
          return fReply(conn, m, `🎧 Reply to an *audio message* to apply blown effect.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const media = await downloadMedia(quoted.audioMessage, 'audio');
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp3`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_blown.mp3`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .audioFilter('volume=15')
              .audioBitrate('8k')
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg' 
          }, { quoted: m });

        } catch (error) {
          console.error('[BLOWN] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to apply blown effect.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'deep': {
      category: 'audio',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.audioMessage) {
          return fReply(conn, m, `🎧 Reply to an *audio message* to apply deep effect.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const media = await downloadMedia(quoted.audioMessage, 'audio');
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp3`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_deep.mp3`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .audioFrequency(22050)
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg' 
          }, { quoted: m });

        } catch (error) {
          console.error('[DEEP] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to apply deep effect.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'earrape': {
      category: 'audio',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.audioMessage) {
          return fReply(conn, m, `🎧 Reply to an *audio message* to apply earrape effect.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const media = await downloadMedia(quoted.audioMessage, 'audio');
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp3`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_earrape.mp3`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .audioFilter('volume=20')
              .audioBitrate('8k')
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg' 
          }, { quoted: m });

        } catch (error) {
          console.error('[EARRAPE] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to apply earrape effect.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'reverse': {
      category: 'audio',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.audioMessage) {
          return fReply(conn, m, `🎧 Reply to an *audio message* to reverse it.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const media = await downloadMedia(quoted.audioMessage, 'audio');
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp3`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_reverse.mp3`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .audioFilter('areverse')
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg' 
          }, { quoted: m });

        } catch (error) {
          console.error('[REVERSE] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to reverse audio.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'robot': {
      category: 'audio',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.audioMessage) {
          return fReply(conn, m, `🎧 Reply to an *audio message* to apply robot effect.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const media = await downloadMedia(quoted.audioMessage, 'audio');
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp3`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_robot.mp3`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .audioFrequency(22050)
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg' 
          }, { quoted: m });

        } catch (error) {
          console.error('[ROBOT] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to apply robot effect.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    }
  }
};