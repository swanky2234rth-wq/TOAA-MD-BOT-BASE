// ─── TOAA RPG Street Vendor ─────────
const { errorReply } = require('../main');
const { getUser, spendStamina, staminaRegenEta, addExp, isRpgAllowed } = require('../helper/rpg');
const { addCoin, removeCoin, fmtCoin } = require('../helper/rpgCoin');
const { notifyLevelUp } = require('../helper/rpgNotify');
const { getSessionSetting } = require('../helper/function');

const STAMINA_COST = 18;
const COOLDOWN_MS = 180 * 1000;
const cooldowns = new Map();

function fmtEta(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

module.exports = {
  name: 'vending',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'vending': { category: 'rpg', handler: run }
  }
};

async function run(conn, m, args, ctx) {
  const { sessionName } = ctx;
  const jid = m.key.participant || m.key.remoteJid;

  if (!isRpgAllowed(m, ctx, getSessionSetting)) {
    return errorReply(conn, m, `🔒 RPG isn't enabled in this group. An admin can turn it on with .rpg on`, sessionName);
  }

  const lastUsed = cooldowns.get(jid) || 0;
  const elapsed = Date.now() - lastUsed;
  if (elapsed < COOLDOWN_MS) {
    return errorReply(conn, m, `⏱️ Cart's still restocking! Wait *${fmtEta(COOLDOWN_MS - elapsed)}*.`, sessionName);
  }

  const user = getUser(jid);
  if (user.stamina < STAMINA_COST) {
    const eta = staminaRegenEta(jid);
    return errorReply(conn, m, `Legs are wobbly from walking around all day! 🥵\n\nVending costs *${STAMINA_COST} Stamina*, you have *${user.stamina}* left.\nNext point in ~${fmtEta(eta)}.`, sessionName);
  }

  spendStamina(jid, STAMINA_COST);
  cooldowns.set(jid, Date.now());

  await conn.sendMessage(m.key.remoteJid, { react: { text: '🛒', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, { text: `Snacks! Peanuts! Candy! 🍬\nCalling out to passersby... 🗣️` }, { quoted: m });
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const gacha = Math.random();

  if (gacha < 0.2) {
    const loss = Math.floor(Math.random() * 10000) + 5000;
    removeCoin(jid, loss);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🌧️', key: m.key } });
    return conn.sendMessage(m.key.remoteJid, {
      text: `POURING RAIN! NOBODY'S BUYING! 🌧️🥶\n\nNo customers, and your crackers all went soggy.\nCapital loss: *-${fmtCoin(loss)}*\n⚡ Stamina: -${STAMINA_COST}\n\nCheck the forecast next time! ☂️`
    }, { quoted: m });
  }

  if (gacha > 0.85) {
    const bigSale = Math.floor(Math.random() * 80000) + 40000;
    addCoin(jid, bigSale);
    const expGain = Math.floor(bigSale / 20);
    const levelResult = addExp(jid, expGain);

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🤑', key: m.key } });
    await conn.sendMessage(m.key.remoteJid, {
      text: `A WHOLE GROUP BOUGHT EVERYTHING! 🚴‍♂️✨\n\nA fancy cycling group swung by and bought all your drinks and snacks!\n💵 Sudden revenue: *+${fmtCoin(bigSale)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nBest day ever, packing up early! 🎉`
    }, { quoted: m });
    return notifyLevelUp(conn, m, jid, levelResult);
  }

  const earning = Math.floor(Math.random() * 25000) + 10000;
  addCoin(jid, earning);
  const expGain = Math.floor(earning / 20);
  const levelResult = addExp(jid, expGain);

  await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
  await conn.sendMessage(m.key.remoteJid, {
    text: `SOLD DECENT AMOUNT TODAY! 🛒✨\n\n💵 Revenue: *+${fmtCoin(earning)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nTime to restock for tomorrow! 🛍️`
  }, { quoted: m });

  await notifyLevelUp(conn, m, jid, levelResult);
}
