// plugins/converters.js
console.log('[CONVERTERS] Plugin loaded!');

const fs = require('fs');
const path = require('path');
const { tmpdir } = require('os');
const { exec } = require('child_process');
const { fReply, errorReply, downloadMedia } = require('../main');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
const sharp = require('sharp');

if (ffmpegPath) ffmpeg.setFfmpegPath(ffmpegPath);

module.exports = {
  name: 'Converters',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'tomp3': {
      category: 'converter',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.videoMessage) {
          return fReply(conn, m, `🎬 Reply to a *video* to convert it to MP3.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const media = await downloadMedia(quoted.videoMessage, 'video');
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp4`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_output.mp3`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .toFormat('mp3')
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg' 
          }, { quoted: m });

        } catch (error) {
          console.error('[TOMP3] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to convert to MP3.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'tovoicenote': {
      category: 'converter',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || (!quoted.videoMessage && !quoted.audioMessage)) {
          return fReply(conn, m, `🎧 Reply to a *video* or *audio* to convert to voice note.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const msg = quoted.videoMessage || quoted.audioMessage;
          const type = quoted.videoMessage ? 'video' : 'audio';
          const media = await downloadMedia(msg, type);
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp4`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_output.ogg`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .inputOptions('-t 59')
              .toFormat('opus')
              .outputOptions(['-c:a libopus', '-b:a 64k'])
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/ogg', 
            ptt: true 
          }, { quoted: m });

        } catch (error) {
          console.error('[TOVOICENOTE] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to convert to voice note.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'toaudio': {
      category: 'converter',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || (!quoted.videoMessage && !quoted.audioMessage)) {
          return fReply(conn, m, `🎧 Reply to a *video* or *audio* to convert to audio.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const msg = quoted.videoMessage || quoted.audioMessage;
          const type = quoted.videoMessage ? 'video' : 'audio';
          const media = await downloadMedia(msg, type);
          tempInput = path.join(tmpdir(), `${Date.now()}_input.mp4`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_output.mp3`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .toFormat('mp3')
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg', 
            ptt: false 
          }, { quoted: m });

        } catch (error) {
          console.error('[TOAUDIO] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to convert to audio.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'toimage': {
      category: 'converter',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.stickerMessage) {
          return fReply(conn, m, `🖼️ Reply to a *sticker* to convert it to image.`, sessionName);
        }

        try {
          const media = await downloadMedia(quoted.stickerMessage, 'sticker');
          const outputPath = path.join(tmpdir(), `${Date.now()}_output.png`);
          
          await sharp(media).png().toFile(outputPath);
          
          const imageBuffer = fs.readFileSync(outputPath);
          await conn.sendMessage(remoteJid, { 
            image: imageBuffer 
          }, { quoted: m });

          fs.unlinkSync(outputPath);
        } catch (error) {
          console.error('[TOIMAGE] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to convert sticker to image.`, sessionName);
        }
      }
    },

    'tovideo': {
      category: 'converter',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || !quoted.stickerMessage) {
          return fReply(conn, m, `🎬 Reply to an *animated sticker* to convert it to video.`, sessionName);
        }

        if (!quoted.stickerMessage.isAnimated) {
          return fReply(conn, m, `❌ Only *animated stickers* can be converted to video.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const media = await downloadMedia(quoted.stickerMessage, 'sticker');
          tempInput = path.join(tmpdir(), `${Date.now()}_input.webp`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_output.mp4`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            exec(
              `ffmpeg -y -loop 0 -i "${tempInput}" -movflags faststart -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" -r 15 "${tempOutput}"`,
              (err) => err ? reject(err) : resolve()
            );
          });

          const videoBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            video: videoBuffer 
          }, { quoted: m });

        } catch (error) {
          console.error('[TOVIDEO] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to convert sticker to video.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    },

    'toptt': {
      category: 'converter',
      handler: async (conn, m, args, ctx) => {
        const { sessionName } = ctx;
        const remoteJid = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted || (!quoted.audioMessage && !quoted.videoMessage)) {
          return fReply(conn, m, `🎧 Reply to an *audio* or *video* to convert to PTT.`, sessionName);
        }

        let tempInput, tempOutput;
        try {
          const msg = quoted.audioMessage || quoted.videoMessage;
          const type = quoted.audioMessage ? 'audio' : 'video';
          const media = await downloadMedia(msg, type);
          tempInput = path.join(tmpdir(), `${Date.now()}_input.${type === 'audio' ? 'mp3' : 'mp4'}`);
          tempOutput = path.join(tmpdir(), `${Date.now()}_output.opus`);
          fs.writeFileSync(tempInput, media);

          await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
              .toFormat('ogg')
              .audioCodec('libopus')
              .save(tempOutput)
              .on('end', resolve)
              .on('error', reject);
          });

          const audioBuffer = fs.readFileSync(tempOutput);
          await conn.sendMessage(remoteJid, { 
            audio: audioBuffer, 
            mimetype: 'audio/ogg; codecs=opus', 
            ptt: true 
          }, { quoted: m });

        } catch (error) {
          console.error('[TOPTT] Error:', error.message);
          await errorReply(conn, m, `❌ Failed to convert to PTT.`, sessionName);
        } finally {
          if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
          if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
        }
      }
    }
  }
};