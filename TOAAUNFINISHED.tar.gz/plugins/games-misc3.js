const mainCore = require('../main');
const { errorReply, successReply, successSmartReply } = mainCore;

module.exports = {
  name: 'Games Batch 3',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'coinflip': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
        await successReply(conn, m, `🪙 ${result}!`, ctx.sessionName);
      }
    },

    'toss': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
        await successReply(conn, m, `🪙 ${result}!`, ctx.sessionName);
      }
    },

    'dice': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const sides = parseInt(args[0]) || 6;
        if (sides < 2 || sides > 100) return errorReply(conn, m, "Sides must be between 2 and 100", ctx.sessionName);
        const result = Math.floor(Math.random() * sides) + 1;
        await successReply(conn, m, `🎲 Rolled ${result} (d${sides})`, ctx.sessionName);
      }
    },

    'slot': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const symbols = ['🍒', '🍋', '🍊', '🍇', '💎', '7️⃣'];
        const reels = [0, 0, 0].map(() => symbols[Math.floor(Math.random() * symbols.length)]);
        const win = reels[0] === reels[1] && reels[1] === reels[2];
        await successSmartReply(conn, m, `🎰 SLOT MACHINE\n\n[ ${reels.join(' | ')} ]\n\n${win ? '🎉 JACKPOT! You win!' : 'Try again!'}`, ctx.sessionName);
      }
    },

    'mathchallenge': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const operators = ['+', '-', '*'];
        const op = operators[Math.floor(Math.random() * operators.length)];
        const a = Math.floor(Math.random() * 20) + 1;
        const b = Math.floor(Math.random() * 20) + 1;
        let answer;
        switch (op) { case '+': answer = a + b; break; case '-': answer = a - b; break; case '*': answer = a * b; break; }
        await successReply(conn, m, `🧮 Math Challenge\n\n${a} ${op} ${b} = ?\n\nAnswer: ${answer} (hidden)`, ctx.sessionName);
      }
    }
  }
};
