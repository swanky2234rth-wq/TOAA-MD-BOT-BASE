const mainCore = require('../main');
const { errorReply, successReply } = mainCore;

const tictactoeGames = new Map();
const minesweeperGames = new Map();
const mastermindGames = new Map();

module.exports = {
  name: 'Games Batch 2',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'tictactoe': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const remoteJid = m.key.remoteJid;
        const game = tictactoeGames.get(remoteJid);
        const option = args[0]?.toLowerCase();

        if (option === 'end') {
          if (!game) return errorReply(conn, m, "No active game!", ctx.sessionName);
          tictactoeGames.delete(remoteJid);
          return successReply(conn, m, "Game ended!", ctx.sessionName);
        }

        if (!game) {
          tictactoeGames.set(remoteJid, { board: Array(9).fill(' '), turn: 'X', players: [ctx.senderNumber, null], started: false });
          return successReply(conn, m, `🎮 Tic Tac Toe started!\n\nUse ${ctx.prefix}tictactoe join to join\n${ctx.prefix}tictactoe 1-9 to play`, ctx.sessionName);
        }

        if (option === 'join') {
          if (game.players[1]) return errorReply(conn, m, "Game already has 2 players!", ctx.sessionName);
          game.players[1] = ctx.senderNumber;
          game.started = true;
          return successReply(conn, m, `✅ ${ctx.senderNumber} joined!\n\nX: ${game.players[0]}\nO: ${game.players[1]}\n\n${ctx.prefix}tictactoe 1-9 to play`, ctx.sessionName);
        }

        if (!game.started) return errorReply(conn, m, `Waiting for 2 players! Use ${ctx.prefix}tictactoe join`, ctx.sessionName);

        const pos = parseInt(option) - 1;
        if (isNaN(pos) || pos < 0 || pos > 8) return errorReply(conn, m, "Use positions 1-9!", ctx.sessionName);
        if (game.board[pos] !== ' ') return errorReply(conn, m, "That spot is taken!", ctx.sessionName);

        const playerSymbol = game.players[0] === ctx.senderNumber ? 'X' : game.players[1] === ctx.senderNumber ? 'O' : null;
        if (!playerSymbol) return errorReply(conn, m, "You're not in this game!", ctx.sessionName);
        if (game.turn !== playerSymbol) return errorReply(conn, m, `It's ${game.turn}'s turn!`, ctx.sessionName);

        game.board[pos] = playerSymbol;
        const winPatterns = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
        let winner = null;
        for (const p of winPatterns) {
          if (game.board[p[0]] === game.board[p[1]] && game.board[p[1]] === game.board[p[2]] && game.board[p[0]] !== ' ') { winner = game.board[p[0]]; break; }
        }

        const boardDisplay = `\`\`\`\n${game.board[0]} | ${game.board[1]} | ${game.board[2]}\n---------\n${game.board[3]} | ${game.board[4]} | ${game.board[5]}\n---------\n${game.board[6]} | ${game.board[7]} | ${game.board[8]}\n\`\`\``;

        if (winner) {
          const winnerNum = winner === 'X' ? game.players[0] : game.players[1];
          tictactoeGames.delete(remoteJid);
          return conn.sendMessage(remoteJid, { text: `🏆 ${winnerNum} wins!\n\n${boardDisplay}`, mentions: [game.players[0] + '@s.whatsapp.net', game.players[1] + '@s.whatsapp.net'] }, { quoted: m });
        }
        if (!game.board.includes(' ')) {
          tictactoeGames.delete(remoteJid);
          return conn.sendMessage(remoteJid, { text: `🤝 It's a tie!\n\n${boardDisplay}`, mentions: [game.players[0] + '@s.whatsapp.net', game.players[1] + '@s.whatsapp.net'] }, { quoted: m });
        }

        game.turn = game.turn === 'X' ? 'O' : 'X';
        const nextPlayer = game.turn === 'X' ? game.players[0] : game.players[1];
        await conn.sendMessage(remoteJid, { text: `${boardDisplay}\n\n${game.turn}'s turn (@${nextPlayer})`, mentions: [nextPlayer + '@s.whatsapp.net'] }, { quoted: m });
      }
    },

    'minesweeper': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const remoteJid = m.key.remoteJid;
        const game = minesweeperGames.get(remoteJid);

        if (args[0]?.toLowerCase() === 'end') {
          if (!game) return errorReply(conn, m, "No active game!", ctx.sessionName);
          minesweeperGames.delete(remoteJid);
          return successReply(conn, m, "Game ended!", ctx.sessionName);
        }

        if (!game) {
          const size = parseInt(args[0]) || 8;
          const mines = Math.floor((size * size) / 8);
          const board = [];
          for (let i = 0; i < size; i++) {
            board[i] = [];
            for (let j = 0; j < size; j++) board[i][j] = { mine: false, revealed: false, flag: false, count: 0 };
          }
          let placed = 0;
          while (placed < mines) {
            const r = Math.floor(Math.random() * size), c = Math.floor(Math.random() * size);
            if (!board[r][c].mine) { board[r][c].mine = true; placed++; }
          }
          for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
            if (board[r][c].mine) continue;
            let count = 0;
            for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
              const nr = r + dr, nc = c + dc;
              if (nr >= 0 && nr < size && nc >= 0 && nc < size && board[nr][nc].mine) count++;
            }
            board[r][c].count = count;
          }
          minesweeperGames.set(remoteJid, { board, size, mines, gameOver: false });
          return successReply(conn, m, `💣 Minesweeper started! ${mines} mines on ${size}x${size} grid.\nUse ${ctx.prefix}minesweeper <row> <col> to reveal.\nUse ${ctx.prefix}minesweeper flag <row> <col> to flag.`, ctx.sessionName);
        }

        if (game.gameOver) return errorReply(conn, m, `Game over! Start a new game with ${ctx.prefix}minesweeper`, ctx.sessionName);

        const [action, row, col] = args;
        if (!row || !col) return errorReply(conn, m, `Usage: ${ctx.prefix}minesweeper <row> <col>\n${ctx.prefix}minesweeper flag <row> <col>`, ctx.sessionName);

        const r = parseInt(row) - 1, c = parseInt(col) - 1;
        if (isNaN(r) || isNaN(c) || r < 0 || r >= game.size || c < 0 || c >= game.size) {
          return errorReply(conn, m, `Invalid coordinates! Use 1-${game.size}`, ctx.sessionName);
        }
        const cell = game.board[r][c];

        if (action?.toLowerCase() === 'flag') {
          cell.flag = !cell.flag;
          return successReply(conn, m, cell.flag ? '🚩 Flagged!' : '🚩 Unflagged!', ctx.sessionName);
        }
        if (cell.flag) return errorReply(conn, m, "That cell is flagged! Unflag it first.", ctx.sessionName);
        if (cell.mine) { game.gameOver = true; return errorReply(conn, m, `💥 BOOM! You hit a mine! Game over.`, ctx.sessionName); }

        cell.revealed = true;
        let revealed = 0;
        for (const row of game.board) for (const cell of row) if (cell.revealed) revealed++;

        if (revealed === (game.size * game.size - game.mines)) {
          minesweeperGames.delete(remoteJid);
          return successReply(conn, m, `🎉 You won! All safe cells revealed!`, ctx.sessionName);
        }

        let display = `💣 Minesweeper\n\`\`\``;
        for (let rr = 0; rr < game.size; rr++) {
          let line = '';
          for (let cc = 0; cc < game.size; cc++) {
            const cc2 = game.board[rr][cc];
            if (cc2.flag) line += '🚩 ';
            else if (cc2.revealed) line += cc2.count > 0 ? `${cc2.count} ` : '. ';
            else line += '■ ';
          }
          display += line + '\n';
        }
        display += `\`\`\`\n${ctx.prefix}minesweeper <row> <col> to reveal\n${ctx.prefix}minesweeper flag <row> <col> to flag`;
        await successReply(conn, m, display, ctx.sessionName);
      }
    },

    'mastermind': {
      category: 'games',
      handler: async (conn, m, args, ctx) => {
        const remoteJid = m.key.remoteJid;
        const game = mastermindGames.get(remoteJid);
        const colors = ['🔴', '🔵', '🟢', '🟡', '🟣', '🟠'];

        if (args[0]?.toLowerCase() === 'end') {
          if (!game) return errorReply(conn, m, "No active game!", ctx.sessionName);
          mastermindGames.delete(remoteJid);
          return successReply(conn, m, "Game ended!", ctx.sessionName);
        }

        if (!game) {
          const code = [];
          for (let i = 0; i < 4; i++) code.push(colors[Math.floor(Math.random() * colors.length)]);
          mastermindGames.set(remoteJid, { code, attempts: 0, maxAttempts: 10 });
          return successReply(conn, m, `🎯 MASTERMIND\n\nColors: ${colors.join(' ')}\nGuess 4 colors. Example: ${ctx.prefix}mastermind 🔴🔵🟢🟡\nYou have 10 attempts.`, ctx.sessionName);
        }

        const guess = args.join('');
        if (guess.length !== 4) return errorReply(conn, m, "Enter exactly 4 colors!", ctx.sessionName);
        const guessColors = [];
        for (const g of guess) {
          if (!colors.includes(g)) return errorReply(conn, m, `Invalid color! Use: ${colors.join(' ')}`, ctx.sessionName);
          guessColors.push(g);
        }

        game.attempts++;
        let exact = 0, partial = 0;
        const codeCopy = [...game.code], guessCopy = [...guessColors];
        for (let i = 0; i < 4; i++) { if (guessCopy[i] === codeCopy[i]) { exact++; guessCopy[i] = null; codeCopy[i] = null; } }
        for (let i = 0; i < 4; i++) { if (guessCopy[i] && codeCopy.includes(guessCopy[i])) { partial++; codeCopy[codeCopy.indexOf(guessCopy[i])] = null; } }

        const msg = `🎯 Attempt ${game.attempts}/${game.maxAttempts}\nGuess: ${guessColors.join(' ')}\nExact: ${exact} ✅ | Partial: ${partial} 🔄`;

        if (exact === 4) { mastermindGames.delete(remoteJid); return successReply(conn, m, `🎉 You cracked the code in ${game.attempts} attempts!`, ctx.sessionName); }
        if (game.attempts >= game.maxAttempts) { mastermindGames.delete(remoteJid); return successReply(conn, m, `💀 Out of attempts! The code was: ${game.code.join(' ')}`, ctx.sessionName); }
        await successReply(conn, m, msg, ctx.sessionName);
      }
    }
  }
};
