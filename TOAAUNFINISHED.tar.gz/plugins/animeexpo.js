const mainCore = require('../main');
const { errorReply } = mainCore;
const axios = require('axios');

const QUERY = `
query ($search: String, $page: Int) {
  Page(page: $page, perPage: 10) {
    media(search: $search, type: ANIME, status: NOT_YET_RELEASED, sort: POPULARITY_DESC) {
      title { romaji english }
      startDate { year month day }
      status
      studios(isMain: true) { nodes { name } }
      externalLinks { site url }
      siteUrl
    }
  }
}`;

module.exports = {
  name: 'animeexpo',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'animeexpo': {
      category: 'ai',
      handler: async (conn, m, args, ctx) => {
        const { sessionName, prefix } = ctx;
        const query = args.join(' ').trim();

        try {
          const { data } = await axios.post('https://graphql.anilist.co', {
            query: QUERY,
            variables: { search: query || undefined, page: 1 }
          }, { headers: { 'Content-Type': 'application/json' }, timeout: 15000 });

          const list = data?.data?.Page?.media || [];
          if (!list.length) {
            return errorReply(conn, m,
              query ? `No unreleased anime found matching "${query}".` : `No upcoming unreleased anime found right now.`,
              sessionName
            );
          }

          const lines = list.slice(0, 8).map((a, i) => {
            const title = a.title.english || a.title.romaji;
            const date = a.startDate?.year ? `${a.startDate.year}${a.startDate.month ? '-' + String(a.startDate.month).padStart(2, '0') : ''}` : 'TBA';
            const studio = a.studios?.nodes?.[0]?.name || 'Unknown studio';
            const streaming = a.externalLinks?.find(l => ['Crunchyroll', 'Netflix', 'HIDIVE', 'Funimation', 'Amazon'].includes(l.site));
            const where = streaming ? streaming.site : 'Platform TBA';
            return `${i + 1}. *${title}*\n   📅 ${date} | 🎬 ${studio}\n   📺 ${where} — ${a.siteUrl}`;
          });

          await conn.sendMessage(m.key.remoteJid, {
            text: `🎌 *AnimeExpo — Upcoming/Unreleased*${query ? ` for "${query}"` : ''}\n\n${lines.join('\n\n')}`
          }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Couldn't fetch anime data right now: ${e.message}`, sessionName);
        }
      }
    }
  }
};
