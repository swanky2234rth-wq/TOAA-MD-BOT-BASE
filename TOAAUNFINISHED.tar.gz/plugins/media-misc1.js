const mainCore = require('../main');
const { errorReply, successReply, fReply, getQuotedMsg, getMediaType, downloadMedia } = mainCore;
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'Media Batch 1',
  version: '1.0.0',
  author: 'TOAA',
  commands: {
    'crop': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'image') return errorReply(conn, m, "Reply to an image", ctx.sessionName);
        if (args.length < 4) return errorReply(conn, m, `Usage: ${ctx.prefix}crop <x> <y> <width> <height>`, ctx.sessionName);
        const [x, y, w, h] = args.map(Number);
        if ([x, y, w, h].some(isNaN)) return errorReply(conn, m, "All values must be numbers!", ctx.sessionName);
        await fReply(conn, m, 'Cropping image...', ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'image');
          const cropped = await sharp(buf).extract({ left: x, top: y, width: w, height: h }).toBuffer();
          await conn.sendMessage(m.key.remoteJid, { image: cropped, caption: '✂️ Cropped!' }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'filter': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'image') return errorReply(conn, m, "Reply to an image", ctx.sessionName);
        const filter = args[0]?.toLowerCase();
        const filters = ['blur', 'sharpen', 'greyscale', 'sepia', 'negative', 'brightness', 'contrast'];
        if (!filters.includes(filter)) return errorReply(conn, m, `Filters: ${filters.join(', ')}`, ctx.sessionName);
        await fReply(conn, m, `Applying ${filter} filter...`, ctx.sessionName);
        try {
          const buf = await downloadMedia(t.inner, 'image');
          let img = sharp(buf);
          switch (filter) {
            case 'blur': img = img.blur(5); break;
            case 'sharpen': img = img.sharpen(); break;
            case 'greyscale': img = img.greyscale(); break;
            case 'sepia': img = img.modulate({ saturation: 0.5 }); break;
            case 'negative': img = img.negate(); break;
            case 'brightness': img = img.modulate({ brightness: 1.5 }); break;
            case 'contrast': img = img.modulate({ contrast: 1.5 }); break;
          }
          const result = await img.toBuffer();
          await conn.sendMessage(m.key.remoteJid, { image: result, caption: `🎨 ${filter} filter applied!` }, { quoted: m });
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'gifsticker': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'video') return errorReply(conn, m, "Reply to a video/GIF", ctx.sessionName);
        await fReply(conn, m, 'Converting to sticker...', ctx.sessionName);
        try {
          const cmdEntry = mainCore.COMMANDS.sticker;
          if (cmdEntry) return cmdEntry.handler(conn, m, args, ctx);
          throw new Error('sticker command unavailable');
        } catch (e) {
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    },

    'togif': {
      category: 'media',
      handler: async (conn, m, args, ctx) => {
        const quotedMsg = getQuotedMsg(m);
        const t = quotedMsg ? getMediaType(quotedMsg) : getMediaType(m.message || {});
        if (!t || t.type !== 'video') return errorReply(conn, m, "Reply to a video", ctx.sessionName);
        await fReply(conn, m, 'Converting to GIF...', ctx.sessionName);

        const ffmpegPath = require('ffmpeg-static');
        const { exec } = require('child_process');
        const { promisify } = require('util');
        const execPromise = promisify(exec);

        const tmpDir = path.join(__dirname, '..', 'temp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
        const ts = Date.now();
        const inputPath = path.join(tmpDir, `input_${ts}.mp4`);
        const outputPath = path.join(tmpDir, `output_${ts}.mp4`);

        try {
          const buf = await downloadMedia(t.inner, 'video');
          fs.writeFileSync(inputPath, buf);
          await execPromise(`"${ffmpegPath}" -y -i "${inputPath}" -t 10 -vf "scale=480:-2:flags=lanczos,fps=15" -an -c:v libx264 -preset fast -crf 28 "${outputPath}"`);
          if (!fs.existsSync(outputPath)) throw new Error('ffmpeg produced no output');
          const gifBuf = fs.readFileSync(outputPath);
          await conn.sendMessage(m.key.remoteJid, { video: gifBuf, gifPlayback: true, caption: '🎬 GIF ready!' }, { quoted: m });
          fs.unlinkSync(inputPath);
          fs.unlinkSync(outputPath);
        } catch (e) {
          try { if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch {}
          try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch {}
          await errorReply(conn, m, `Failed: ${e.message}`, ctx.sessionName);
        }
      }
    }
  }
};
