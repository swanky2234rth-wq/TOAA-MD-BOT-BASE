// ─── TOAA Style Transform Command Factory (helper) ─────────
const { errorReply, getQuotedMsg, getMediaType, downloadMedia } = require('../main');
const { live3d } = require('./imageAiEngine');

// Builds a plugin command handler for a given style transform prompt.
function buildStyleCommand(label, emoji, prompt) {
  return async (conn, m, args, ctx) => {
    const { sessionName, prefix, command } = ctx;

    const quotedMsg = getQuotedMsg(m);
    const sourceMsg = quotedMsg || m.message;
    const mediaInfo = getMediaType(sourceMsg || {});

    if (!mediaInfo || mediaInfo.type !== 'image') {
      return errorReply(conn, m, `${emoji} *${label}*\n\nSend/reply an image to transform it.\n\n${prefix}${command}`, sessionName);
    }

    await conn.sendMessage(m.key.remoteJid, { react: { text: '🕕', key: m.key } });

    try {
      const buffer = await downloadMedia(mediaInfo.inner, 'image');
      if (!buffer) throw new Error('Failed to download the image.');

      const result = await live3d(buffer, prompt);

      await conn.sendMessage(m.key.remoteJid, { react: { text: '✅', key: m.key } });
      await conn.sendMessage(m.key.remoteJid, { image: result.image }, { quoted: m });

    } catch (error) {
      console.error(`[${label.toUpperCase()}] Error:`, error.message);
      await conn.sendMessage(m.key.remoteJid, { react: { text: '❌', key: m.key } });
      await errorReply(conn, m, `Something went wrong transforming that image — try again.`, sessionName);
    }
  };
}

module.exports = { buildStyleCommand };
