// ─── TOAA RPG Item Registry (helper) ─────────
// Single source of truth for every item name/emote/sell-price in the RPG
// set. Ported from the various legacy plugin files' inline ITEMS/
// SELL_PRICES objects, merged into one place so gathering commands, shop,
// inventory, use, and sellall all agree on the same catalog.
const ITEMS = {
  // Crates
  common: { emote: '📦', name: 'Common Crate', category: 'Crates' },
  uncommon: { emote: '🛍️', name: 'Uncommon Crate', category: 'Crates' },
  mythic: { emote: '🎁', name: 'Mythic Crate', category: 'Crates' },
  legendary: { emote: '💎', name: 'Legendary Crate', category: 'Crates' },

  // Mining
  rock: { emote: '🪨', name: 'Rock', category: 'Mining', sell: 20 },
  coal: { emote: '⚫', name: 'Coal', category: 'Mining', sell: 50 },
  iron: { emote: '⛓️', name: 'Iron', category: 'Mining', sell: 200 },
  gold: { emote: '🥇', name: 'Gold', category: 'Mining', sell: 1000 },
  diamond: { emote: '💠', name: 'Diamond', category: 'Mining', sell: 5000 },
  emerald: { emote: '💚', name: 'Emerald', category: 'Mining', sell: 10000 },

  // Fishing
  trash: { emote: '🗑️', name: 'Trash', category: 'Fishing', sell: 10 },
  fish: { emote: '🐟', name: 'Fish', category: 'Fishing', sell: 100 },
  prawn: { emote: '🦐', name: 'Prawn', category: 'Fishing', sell: 200 },
  octopus: { emote: '🐙', name: 'Octopus', category: 'Fishing', sell: 500 },
  shark: { emote: '🦈', name: 'Shark', category: 'Fishing', sell: 2000 },
  whale: { emote: '🐳', name: 'Whale', category: 'Fishing', sell: 10000 },

  // Woodcutting
  wood: { emote: '🪵', name: 'Wood', category: 'Woodcutting', sell: 30 },
  stick: { emote: '🥢', name: 'Stick', category: 'Woodcutting', sell: 15 },
  apple: { emote: '🍎', name: 'Apple', category: 'Woodcutting', sell: 50 },
  rubber: { emote: '🧴', name: 'Rubber', category: 'Woodcutting', sell: 100 },

  // Hunting
  rabbit: { emote: '🐇', name: 'Rabbit', category: 'Hunting', sell: 150 },
  deer: { emote: '🦌', name: 'Deer', category: 'Hunting', sell: 300 },
  boar: { emote: '🐗', name: 'Boar', category: 'Hunting', sell: 500 },
  bear: { emote: '🐻', name: 'Bear', category: 'Hunting', sell: 1000 },
  lion: { emote: '🦁', name: 'Lion', category: 'Hunting', sell: 2000 },
  dragon: { emote: '🐉', name: 'Dragon', category: 'Hunting', sell: 10000 },

  // Potions & buffs (consumable via `use`, not sellable)
  potion: { emote: '🥤', name: 'Health Potion', category: 'Potions' },
  mpotion: { emote: '🧪', name: 'Mana Potion', category: 'Potions' },
  stamina: { emote: '⚡', name: 'Stamina Potion', category: 'Potions' },

  // Dungeon drops
  herb: { emote: '🌿', name: 'Herb', category: 'Dungeon' },
  leather: { emote: '👞', name: 'Leather', category: 'Dungeon' },
  mysterybox: { emote: '📦', name: 'Mystery Box', category: 'Dungeon' },

  // Gear / misc consumables
  kunai: { emote: '🗡️', name: 'Kunai', category: 'Gear' },
  shuriken: { emote: '⚔️', name: 'Shuriken', category: 'Gear' },
  chakra: { emote: '🌀', name: 'Chakra', category: 'Gear' },
  scroll: { emote: '📜', name: 'Scroll', category: 'Gear' },
  bowlramen: { emote: '🍜', name: 'Ramen', category: 'Gear' },

  // Alchemy base materials
  flower: { emote: '🌸', name: 'Flower', category: 'Alchemy' },
  mushroom: { emote: '🍄', name: 'Mushroom', category: 'Alchemy' },

  // Crafted gear (from blacksmith/enchant) — kept trackable in inventory,
  // not sellable through sellall since they're equippable, not raw material
  sword: { emote: '⚔️', name: 'Iron Sword', category: 'Gear' },
  shield: { emote: '🛡️', name: 'Iron Shield', category: 'Gear' },
  helmet: { emote: '⛑️', name: 'Iron Helmet', category: 'Gear' },
  armor: { emote: '🦺', name: 'Iron Armor', category: 'Gear' },
  axe: { emote: '🪓', name: 'Iron Axe', category: 'Gear' },
  pickaxe: { emote: '⛏️', name: 'Pickaxe', category: 'Gear' },
  bow: { emote: '🏹', name: 'Bow', category: 'Gear' },
  arrow: { emote: '🏹', name: 'Arrow', category: 'Gear' },
  goldsword: { emote: '🗡️', name: 'Gold Sword', category: 'Gear' },
  diamondarmor: { emote: '💎', name: 'Diamond Armor', category: 'Gear' },

  // Alchemy results (potions, consumed via `use`)
  healthpotion: { emote: '❤️', name: 'Health Potion', category: 'Potions' },
  manapotion: { emote: '💙', name: 'Mana Potion', category: 'Potions' },
  staminapotion2: { emote: '⚡', name: 'Stamina Potion', category: 'Potions' },
  strengthpotion: { emote: '💪', name: 'Strength Potion', category: 'Potions' },
  defensepotion: { emote: '🛡️', name: 'Defense Potion', category: 'Potions' },
  luckpotion: { emote: '🍀', name: 'Luck Potion', category: 'Potions' },
  exppotion: { emote: '✨', name: 'EXP Potion', category: 'Potions' },
  antidote: { emote: '💊', name: 'Antidote', category: 'Potions' },
  elixir: { emote: '🧪', name: 'Elixir', category: 'Potions' },

  // Pet food
  bread: { emote: '🍞', name: 'Bread', category: 'Pet Food' },
  meat: { emote: '🍖', name: 'Meat', category: 'Pet Food' },
  fruit: { emote: '🍎', name: 'Fruit', category: 'Pet Food' },
  premium_food: { emote: '⭐', name: 'Premium Food', category: 'Pet Food' },

  // Scavenged junk
  bottle: { emote: '🍶', name: 'Bottle', category: 'Junk', sell: 20 },
  can: { emote: '🥫', name: 'Can', category: 'Junk', sell: 25 },
  cardboard: { emote: '📦', name: 'Cardboard', category: 'Junk', sell: 15 },
  junk: { emote: '🗑️', name: 'Junk', category: 'Junk', sell: 5 },
  newspaper: { emote: '📰', name: 'Newspaper', category: 'Junk', sell: 10 },

  // Garden crops (timed farming via `garden`) + their seeds
  carrot: { emote: '🥕', name: 'Carrot', category: 'Garden', sell: 30 },
  carrotseed: { emote: '🌱', name: 'Carrot Seed', category: 'Garden' },
  tomato: { emote: '🍅', name: 'Tomato', category: 'Garden', sell: 50 },
  tomatoseed: { emote: '🌱', name: 'Tomato Seed', category: 'Garden' },
  corn: { emote: '🌽', name: 'Corn', category: 'Garden', sell: 80 },
  cornseed: { emote: '🌱', name: 'Corn Seed', category: 'Garden' },
  gardenpotato: { emote: '🥔', name: 'Potato', category: 'Garden', sell: 100 },
  gardenpotatoseed: { emote: '🌱', name: 'Potato Seed', category: 'Garden' },
  gardenstrawberry: { emote: '🍓', name: 'Strawberry', category: 'Garden', sell: 150 },
  gardenstrawberryseed: { emote: '🌱', name: 'Strawberry Seed', category: 'Garden' },
  gardenwatermelon: { emote: '🍉', name: 'Watermelon', category: 'Garden', sell: 300 },
  gardenwatermelonseed: { emote: '🌱', name: 'Watermelon Seed', category: 'Garden' },
  pumpkin: { emote: '🎃', name: 'Pumpkin', category: 'Garden', sell: 500 },
  pumpkinseed: { emote: '🌱', name: 'Pumpkin Seed', category: 'Garden' },
  gardenherb: { emote: '🌿', name: 'Garden Herb', category: 'Garden', sell: 120 },
  gardenherbseed: { emote: '🌱', name: 'Herb Seed', category: 'Garden' },

  // Berladang crops (instant farming gig, distinct from garden's timed crops)
  padi: { emote: '🌾', name: 'Rice Stalk', category: 'Farming', sell: 100 },
  jagung: { emote: '🌽', name: 'Corn Cob', category: 'Farming', sell: 150 },
  tomat: { emote: '🍅', name: 'Field Tomato', category: 'Farming', sell: 200 },
  wortel: { emote: '🥕', name: 'Field Carrot', category: 'Farming', sell: 250 },
  fieldstrawberry: { emote: '🍓', name: 'Field Strawberry', category: 'Farming', sell: 500 },
  melon: { emote: '🍈', name: 'Melon', category: 'Farming', sell: 1000 },

  // Treasure chest tiers
  woodenchest: { emote: '📦', name: 'Wooden Chest', category: 'Chests' },
  ironchest: { emote: '🗃️', name: 'Iron Chest', category: 'Chests' },
  goldchest: { emote: '🎁', name: 'Gold Chest', category: 'Chests' },
  diamondchest: { emote: '💎', name: 'Diamond Chest', category: 'Chests' }
};

function getItem(key) {
  return ITEMS[key.toLowerCase()] || null;
}

function getSellPrice(key) {
  return ITEMS[key.toLowerCase()]?.sell || 0;
}

function getCategories() {
  const cats = {};
  for (const [key, item] of Object.entries(ITEMS)) {
    if (!cats[item.category]) cats[item.category] = [];
    cats[item.category].push(key);
  }
  return cats;
}

module.exports = { ITEMS, getItem, getSellPrice, getCategories };
