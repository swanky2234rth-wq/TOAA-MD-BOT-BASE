/*
═══════════════════╗
〚    𝙱𝙾𝚃• ₊ ⃝₊TOAA
〚    𝙳𝙴𝚅•  ₊ ⃝—͟͟͞͞swanky
〚    𝙲𝙾𝙽𝚃𝙰𝙲𝚃• +2347047129088
〚    𝚃𝙴𝙻𝙴𝙶𝚁𝙰𝙼 : t.me/swanky_is_TOAA
〚    𝚅𝙿𝚂 𝙰𝙽𝙳 𝙿𝚃𝙴𝚁𝙾𝙳𝙰𝙲𝚃𝚈𝙻 𝙳𝙴𝙰𝙻𝚂
┗━━━━━━━━━━━━━━━┛
*/

const fs = require('fs');
const path = require('path');
const settings = require('../settings');

// ─── Premium ───────────────────────────────────────────────────────────────────
function loadPremium() {
  try { return JSON.parse(fs.readFileSync(settings.PREMIUM_DB, 'utf-8')); }
  catch { return { premiumUsers: [] }; }
}
function savePremium(data) { fs.writeFileSync(settings.PREMIUM_DB, JSON.stringify(data, null, 2)); }
function isPremium(number) { return loadPremium().premiumUsers.includes(number); }
function addPremium(number) {
  const db = loadPremium();
  if (db.premiumUsers.includes(number)) return false;
  db.premiumUsers.push(number); savePremium(db); return true;
}
function delPremium(number) {
  const db = loadPremium();
  const idx = db.premiumUsers.indexOf(number);
  if (idx === -1) return false;
  db.premiumUsers.splice(idx, 1); savePremium(db); return true;
}
function listPremium() {
  return loadPremium().premiumUsers || [];
}

// ─── Sudo (persistent — survives restarts) ─────────────────────────────────────
function loadSudo() {
  try { return JSON.parse(fs.readFileSync(settings.SUDO_DB, 'utf-8')); }
  catch { return { sudoUsers: [], grantedBy: {} }; }
}
function saveSudo(data) {
  try {
    const dir = path.dirname(settings.SUDO_DB);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(settings.SUDO_DB, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error('[SUDO] Failed to save:', e.message);
  }
}
function addSudo(number, grantedBy) {
  const db = loadSudo();
  if (db.sudoUsers.includes(number)) return false;
  db.sudoUsers.push(number);
  if (grantedBy) db.grantedBy[number] = grantedBy;
  saveSudo(db);
  return true;
}
function delSudo(number) {
  const db = loadSudo();
  const idx = db.sudoUsers.indexOf(number);
  if (idx === -1) return false;
  db.sudoUsers.splice(idx, 1);
  delete db.grantedBy[number];
  saveSudo(db);
  return true;
}
function isSudo(number) {
  return loadSudo().sudoUsers.includes(number);
}
function listSudo() {
  return loadSudo().sudoUsers || [];
}

// ─── Sessions ──────────────────────────────────────────────────────────────────
function getSessionDir(sessionName) { return path.join(settings.SESSIONS_DIR, sessionName); }
function sessionExists(sessionName) {
  const dir = getSessionDir(sessionName);
  return fs.existsSync(dir) && fs.existsSync(path.join(dir, 'creds.json'));
}
function deleteSession(sessionName) {
  const dir = getSessionDir(sessionName);
  if (!fs.existsSync(dir)) return false;
  fs.rmSync(dir, { recursive: true, force: true }); return true;
}
function listSessions() {
  if (!fs.existsSync(settings.SESSIONS_DIR)) return [];
  return fs.readdirSync(settings.SESSIONS_DIR).filter(name =>
    fs.existsSync(path.join(settings.SESSIONS_DIR, name, 'creds.json'))
  );
}

// ─── Per-session settings ──────────────────────────────────────────────────────
function getUserSettingsPath(sessionName) {
  return path.join(settings.SESSIONS_DIR, sessionName, 'usersettings.json');
}
function defaultSettings() {
  return {
    prefix: settings.DEFAULT_PREFIX,
    mode: 'public',
    ownerNumber: '',
    telegramChatId: null,
    autoViewStatus: false,
    autoLikeStatus: false,
    antilink: 'off',
    antidelete: false,
    font: 1,
    botName: settings.BOT_NAME,
    menuImage: settings.MENU_IMAGE,
  };
}
function loadUserSettings(sessionName) {
  const p = getUserSettingsPath(sessionName);
  try { return Object.assign(defaultSettings(), JSON.parse(fs.readFileSync(p, 'utf-8'))); }
  catch { return defaultSettings(); }
}
function saveUserSettings(sessionName, data) {
  const dir = getSessionDir(sessionName);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(getUserSettingsPath(sessionName), JSON.stringify(data, null, 2));
}
function getSessionSetting(sessionName, key, fallback = null) {
  const us = loadUserSettings(sessionName);
  return (key in us && us[key] !== undefined && us[key] !== null) ? us[key] : fallback;
}
function setSessionSetting(sessionName, key, value) {
  const us = loadUserSettings(sessionName);
  us[key] = value;
  saveUserSettings(sessionName, us);
}
function deleteSessionSettings(sessionName) {
  const p = getUserSettingsPath(sessionName);
  try { if (fs.existsSync(p)) fs.unlinkSync(p); } catch {}
}

// ─── Admin check — 
function cleanJidNumber(jid) {
  if (!jid) return '';
  return jid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

function getRawId(jid) {
  if (!jid) return '';
  return String(jid).split('@')[0].split(':')[0];
}

function resolveDisplayJid(jid, participants) {
  if (!jid) return jid;
  if (!jid.endsWith('@lid')) return jid; // already a phone-number JID
  if (!Array.isArray(participants)) return jid;

  const rawLid = getRawId(jid);
  const match = participants.find(p => p.lid && getRawId(p.lid) === rawLid);
  return match?.id || jid;
}

async function isGroupAdmin(conn, groupJid, senderJid) {
  try {
    const meta = await conn.groupMetadata(groupJid);
    const senderRaw = cleanJidNumber(senderJid);
    for (const p of meta.participants || []) {
      const pIdRaw = cleanJidNumber(p.id);
      const pLidRaw = p.lid ? cleanJidNumber(p.lid) : null;
      if (pIdRaw === senderRaw || (pLidRaw && pLidRaw === senderRaw)) {
        return p.admin === 'admin' || p.admin === 'superadmin';
      }
    }
    return false;
  } catch { return false; }
}

function getBotIdentities(conn) {
  const ids = [
    conn.user?.id,
    conn.user?.lid,
    conn.authState?.creds?.me?.id,
    conn.authState?.creds?.me?.lid,
  ].filter(Boolean).map(cleanJidNumber).filter(Boolean);
  return [...new Set(ids)];
}

async function isBotAdmin(conn, groupJid) {
  try {
    const meta = await conn.groupMetadata(groupJid);
    const botIds = getBotIdentities(conn);
    if (!botIds.length) return false;

    for (const p of meta.participants || []) {
      const isAdminRole = p.admin === 'admin' || p.admin === 'superadmin';
      if (!isAdminRole) continue;
      const pIdRaw = cleanJidNumber(p.id);
      const pLidRaw = p.lid ? cleanJidNumber(p.lid) : null;
      if (botIds.includes(pIdRaw) || (pLidRaw && botIds.includes(pLidRaw))) return true;
    }
    return false;
  } catch { return false; }
}

// One metadata fetch for both checks at once — cheaper than calling
async function checkGroupAdmins(conn, groupJid, senderJid) {
  try {
    const meta = await conn.groupMetadata(groupJid);
    const botIds = getBotIdentities(conn);
    const senderRaw = cleanJidNumber(senderJid);

    let isAdmin = false;
    let isBotAdminFlag = false;

    for (const p of meta.participants || []) {
      const isAdminRole = p.admin === 'admin' || p.admin === 'superadmin';
      if (!isAdminRole) continue;
      const pIdRaw = cleanJidNumber(p.id);
      const pLidRaw = p.lid ? cleanJidNumber(p.lid) : null;

      if (pIdRaw === senderRaw || (pLidRaw && pLidRaw === senderRaw)) isAdmin = true;
      if (botIds.includes(pIdRaw) || (pLidRaw && botIds.includes(pLidRaw))) isBotAdminFlag = true;
    }
    return { isAdmin, isBotAdmin: isBotAdminFlag };
  } catch { return { isAdmin: false, isBotAdmin: false }; }
}

async function getGroupAdmins(conn, groupJid) {
  try {
    const meta = await conn.groupMetadata(groupJid);
    return (meta.participants || [])
      .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
      .map(p => p.id);
  } catch { return []; }
}

function isSessionOwner(senderJid, ownerNumber) {
  return getRawId(senderJid) === getRawId(ownerNumber);
}

function normalizeNumber(jid) {
  return jid ? jid.split('@')[0].split(':')[0] : '';
}

module.exports = {
  isPremium, addPremium, delPremium, loadPremium, listPremium,
  isSudo, addSudo, delSudo, loadSudo, listSudo,
  getSessionDir, sessionExists, deleteSession, listSessions,
  loadUserSettings, saveUserSettings, getSessionSetting, setSessionSetting, deleteSessionSettings,
  isGroupAdmin, isBotAdmin, checkGroupAdmins, getGroupAdmins, isSessionOwner,
  normalizeNumber, cleanJidNumber, getRawId, resolveDisplayJid,
};
