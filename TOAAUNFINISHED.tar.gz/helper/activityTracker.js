// ─── TOAA Activity Tracker (helper) ─────────
// Shared per-group message-count + last-active tracker.
// Used by: activity.js hook in main.js, listactive/listinactive/kickinactive plugins.
const fs = require('fs');
const path = require('path');

const ACTIVITY_FILE = path.join(__dirname, '..', 'database', 'activity.json');

let cache = null;

function load() {
  if (cache) return cache;
  try {
    if (fs.existsSync(ACTIVITY_FILE)) {
      cache = JSON.parse(fs.readFileSync(ACTIVITY_FILE, 'utf-8'));
    } else {
      cache = {};
    }
  } catch (e) {
    console.error('[ACTIVITY] Failed to load, starting fresh:', e.message);
    cache = {};
  }
  return cache;
}

let saveTimer = null;
function saveDebounced() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      const dir = path.dirname(ACTIVITY_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(ACTIVITY_FILE, JSON.stringify(cache, null, 2));
    } catch (e) {
      console.error('[ACTIVITY] Failed to save:', e.message);
    }
  }, 2000);
}

// Call on every group message to bump a user's count + lastActive
function recordActivity(groupJid, userJid) {
  const data = load();
  if (!data[groupJid]) data[groupJid] = {};
  if (!data[groupJid][userJid]) data[groupJid][userJid] = { count: 0, lastActive: 0 };
  data[groupJid][userJid].count++;
  data[groupJid][userJid].lastActive = Date.now();
  saveDebounced();
}

// Returns { userJid: { count, lastActive } } for a group, or {} if none
function getGroupActivity(groupJid) {
  const data = load();
  return data[groupJid] || {};
}

module.exports = { recordActivity, getGroupActivity, ACTIVITY_FILE };
