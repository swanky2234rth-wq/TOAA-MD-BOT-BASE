/*
═══════════════════╗
〚    𝙱𝙾𝚃• ₊ ⃝₊TOAA
〚    𝙳𝙴𝚅•  ₊ ⃝—͟͟͞͞swanky
〚    𝙲𝙾𝙽𝚃𝙰𝙲𝚃• +2347047129088
〚    𝚃𝙴𝙻𝙴𝙶𝚁𝙰𝙼 : t.me/swanky_is_TOAA
〚    𝚅𝙿𝚂 𝙰𝙽𝙳 𝙿𝚃𝙴𝚁𝙾𝙳𝙰𝙲𝚃𝚈𝙻 𝙳𝙴𝙰𝙻𝚂
┗━━━━━━━━━━━━━━━┛
*/

// ─── TOAA SESSION BACKUP ──────────────────────────────────────────────────────

const fs = require('fs');
const path = require('path');
const { loadUserSettings, saveUserSettings } = require('./function');

const BACKUP_DIR = path.join(__dirname, '..', 'database', 'backups');

function backupPath(sessionName) {
  return path.join(BACKUP_DIR, `${sessionName}.json`);
}

function saveSessionBackup(sessionName) {
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });


  const mainCore = require('../main');

  const userSettings = loadUserSettings(sessionName);
  const groupSettings = Object.fromEntries(mainCore.groupProtectionSettings || new Map());

  const snapshot = {
    sessionName,
    savedAt: new Date().toISOString(),
    userSettings,
    groupSettings,
  };
  fs.writeFileSync(backupPath(sessionName), JSON.stringify(snapshot, null, 2));
  return snapshot;
}

function hasBackup(sessionName) {
  return fs.existsSync(backupPath(sessionName));
}

function loadBackup(sessionName) {
  if (!hasBackup(sessionName)) return null;
  try { return JSON.parse(fs.readFileSync(backupPath(sessionName), 'utf-8')); } catch { return null; }
}

function restoreSessionBackup(sessionName) {
  const snap = loadBackup(sessionName);
  if (!snap) return false;
  if (snap.userSettings) saveUserSettings(sessionName, snap.userSettings);
  if (snap.groupSettings) {
    const mainCore = require('../main');
    for (const [jid, val] of Object.entries(snap.groupSettings)) {
      mainCore.groupProtectionSettings.set(jid, val);
    }
  }
  return true;
}

function saveAllSessionBackups(sessionNames) {
  let count = 0;
  for (const s of sessionNames) {
    try { saveSessionBackup(s); count++; } catch (e) { console.log('[BACKUP] Failed for', s, e.message); }
  }
  return count;
}

module.exports = { saveSessionBackup, hasBackup, loadBackup, restoreSessionBackup, saveAllSessionBackups, backupPath };
