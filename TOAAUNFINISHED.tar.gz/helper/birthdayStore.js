// ─── TOAA Birthday Storage (helper) ─────────
// Lightweight JSON-file store, shared by birthday.js / setbirthday.js / birthdaylist.js.
// Replaces the source's custom ourin-database.js, which isn't ported here.
const fs = require('fs');
const path = require('path');

const BIRTHDAY_FILE = path.join(__dirname, '..', 'database', 'birthdays.json');

let cache = null;

function load() {
  if (cache) return cache;
  try {
    if (fs.existsSync(BIRTHDAY_FILE)) {
      cache = JSON.parse(fs.readFileSync(BIRTHDAY_FILE, 'utf-8'));
    } else {
      cache = {};
    }
  } catch (e) {
    console.error('[BIRTHDAY] Failed to load, starting fresh:', e.message);
    cache = {};
  }
  return cache;
}

function save() {
  try {
    const dir = path.dirname(BIRTHDAY_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(BIRTHDAY_FILE, JSON.stringify(cache, null, 2));
  } catch (e) {
    console.error('[BIRTHDAY] Failed to save:', e.message);
  }
}

// Returns "DD-MM" string or null
function getBirthday(jid) {
  const data = load();
  return data[jid]?.birthday || null;
}

// dateStr must already be validated as "DD-MM"
function setBirthday(jid, dateStr) {
  const data = load();
  if (!data[jid]) data[jid] = {};
  data[jid].birthday = dateStr;
  save();
}

function getAllBirthdays() {
  return load();
}

module.exports = { getBirthday, setBirthday, getAllBirthdays, BIRTHDAY_FILE };
