// ─── TOAA RPG Engine (helper) ─────────
// Shared foundation for the 'rpg' plugin category: per-user stats
// (exp/level/hp/mana/stamina), the leveling formula, and stamina regen.
// Money itself stays in helper/economy.js — this only tracks RPG-specific
// stats and hands off to economy.js for coin.
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'database', 'rpg.json');

const EXP_PER_LEVEL = 10000;
const STAMINA_REGEN_MS = 3 * 60 * 1000; // +1 stamina every 3 minutes

// ─── Persistence ──────────────────────────────────────────────────────────────
function loadAll() {
  try {
    if (fs.existsSync(DB_FILE)) return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } catch (e) {
    console.error('[RPG] Failed to load:', e.message);
  }
  return {};
}

let _cache = loadAll();
let _saveTimer = null;
function persist() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(_cache, null, 2));
    } catch (e) {
      console.error('[RPG] Failed to save:', e.message);
    }
  }, 300);
}
function save() { persist(); }

function defaultUser() {
  const maxHealth = 100, maxMana = 100, maxStamina = 100;
  return {
    exp: 0,
    level: 1,
    health: maxHealth, maxHealth,
    mana: maxMana, maxMana,
    stamina: maxStamina, maxStamina,
    attack: 10,
    inventory: {},
    lastStaminaTick: Date.now(),
    rpgEnabled: true,          // per-user "is RPG on for me" (used alongside group rpg toggle)
    levelupNotif: true          // leveluprpg.js toggle
  };
}

function normalizeKey(jid) {
  return String(jid).split('@')[0].split(':')[0];
}

function getUser(jid) {
  const key = normalizeKey(jid);
  if (!_cache[key]) {
    _cache[key] = defaultUser();
  } else {
    const def = defaultUser();
    _cache[key] = { ...def, ..._cache[key] };
  }
  regenStamina(key);
  return _cache[key];
}

function setUser(jid, updates) {
  const key = normalizeKey(jid);
  const current = getUser(jid);
  _cache[key] = { ...current, ...updates };
  save();
  return _cache[key];
}

// ─── Stamina regen (lazy, computed on read) ────────────────────────────────────
function regenStamina(key) {
  const u = _cache[key];
  if (!u) return;
  if (u.stamina >= u.maxStamina) { u.lastStaminaTick = Date.now(); return; }

  const now = Date.now();
  const elapsed = now - (u.lastStaminaTick || now);
  const ticks = Math.floor(elapsed / STAMINA_REGEN_MS);

  if (ticks > 0) {
    u.stamina = Math.min(u.maxStamina, u.stamina + ticks);
    u.lastStaminaTick = u.lastStaminaTick + ticks * STAMINA_REGEN_MS;
    save();
  }
}

function staminaRegenEta(jid) {
  const u = getUser(jid);
  if (u.stamina >= u.maxStamina) return 0;
  const elapsed = Date.now() - u.lastStaminaTick;
  return Math.max(0, STAMINA_REGEN_MS - elapsed);
}

function spendStamina(jid, amount) {
  const u = getUser(jid);
  if (u.stamina < amount) return false;
  u.stamina -= amount;
  save();
  return true;
}

// ─── Leveling ───────────────────────────────────────────────────────────────
function calculateLevel(exp) {
  return Math.floor(exp / EXP_PER_LEVEL) + 1;
}

function expForLevel(level) {
  return (level - 1) * EXP_PER_LEVEL;
}

function getRole(level) {
  if (level >= 100) return '🐉 Mythic';
  if (level >= 80) return '⚔️ Legend';
  if (level >= 60) return '💜 Epic';
  if (level >= 40) return '💪 Grandmaster';
  if (level >= 20) return '🎖️ Master';
  if (level >= 10) return '⭐ Elite';
  return '🛡️ Warrior';
}

// Adds EXP, applies level-up stat bumps if a threshold is crossed.
// Returns { leveledUp, oldLevel, newLevel, exp } — caller decides whether
// to render/send the level-up card (based on levelupNotif + settings).
function addExp(jid, amount) {
  const u = getUser(jid);
  const oldExp = u.exp;
  const oldLevel = calculateLevel(oldExp);

  u.exp = oldExp + Math.max(0, Math.round(amount));
  const newLevel = calculateLevel(u.exp);

  let leveledUp = false;
  if (newLevel > oldLevel) {
    leveledUp = true;
    u.level = newLevel;
    u.maxHealth = 100 + (newLevel - 1) * 10;
    u.maxMana = 100 + (newLevel - 1) * 5;
    u.maxStamina = 100 + (newLevel - 1) * 5;
    u.health = u.maxHealth;
    u.mana = u.maxMana;
    u.stamina = u.maxStamina;
    u.lastStaminaTick = Date.now();
  }

  save();
  return { leveledUp, oldLevel, newLevel, exp: u.exp };
}

// ─── Inventory ──────────────────────────────────────────────────────────────
function getItemCount(jid, itemKey) {
  const u = getUser(jid);
  return u.inventory[itemKey] || 0;
}

function addItem(jid, itemKey, qty = 1) {
  const u = getUser(jid);
  u.inventory[itemKey] = (u.inventory[itemKey] || 0) + qty;
  save();
  return u.inventory[itemKey];
}

function removeItem(jid, itemKey, qty = 1) {
  const u = getUser(jid);
  const current = u.inventory[itemKey] || 0;
  if (current < qty) return false;
  u.inventory[itemKey] = current - qty;
  save();
  return true;
}

// ─── Group gate ─────────────────────────────────────────────────────────────
// Mirrors rpg.js's toggle: RPG defaults ON everywhere; in groups it can be
// switched off, but admins/owner can always still play.
function isRpgAllowed(m, ctx, getSessionSetting) {
  const jid = m.key.remoteJid;
  if (!jid.endsWith('@g.us')) return true;
  if (ctx.isAdmin || ctx.isOwner) return true;
  return getSessionSetting(ctx.sessionName, `rpg_${jid}`, true) !== false;
}

module.exports = {
  EXP_PER_LEVEL,
  STAMINA_REGEN_MS,
  getUser,
  setUser,
  spendStamina,
  staminaRegenEta,
  calculateLevel,
  expForLevel,
  getRole,
  addExp,
  isRpgAllowed,
  getItemCount,
  addItem,
  removeItem
};
