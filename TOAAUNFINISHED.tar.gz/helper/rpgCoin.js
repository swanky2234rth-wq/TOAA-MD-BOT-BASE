// ─── TOAA RPG Coin Wallet (helper) ─────────
// Separate currency from helper/economy.js's balance. Every RPG earning/
// spending command (crime, work, mining, casino, bank, shop, etc.) reads
// and writes through here. Persists to database/rpgCoin.json.
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'database', 'rpgCoin.json');

function loadAll() {
  try {
    if (fs.existsSync(DB_FILE)) return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } catch (e) {
    console.error('[RPGCOIN] Failed to load:', e.message);
  }
  return {};
}

let _cache = loadAll();
let _saveTimer = null;
function persist() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(_cache, null, 2));
    } catch (e) {
      console.error('[RPGCOIN] Failed to save:', e.message);
    }
  }, 300);
}

function normalizeKey(jid) {
  return String(jid).split('@')[0].split(':')[0];
}

function getWallet(jid) {
  const key = normalizeKey(jid);
  if (!_cache[key]) _cache[key] = { coin: 0, bank: 0 };
  return _cache[key];
}

function getCoin(jid) {
  return getWallet(jid).coin;
}
function getBank(jid) {
  return getWallet(jid).bank;
}

function addCoin(jid, amount) {
  const w = getWallet(jid);
  w.coin = Math.max(0, w.coin + Math.round(amount));
  persist();
  return w.coin;
}
function removeCoin(jid, amount) {
  const w = getWallet(jid);
  w.coin = Math.max(0, w.coin - Math.round(amount));
  persist();
  return w.coin;
}
function hasCoin(jid, amount) {
  return getWallet(jid).coin >= amount;
}

function deposit(jid, amount) {
  const w = getWallet(jid);
  if (amount <= 0 || w.coin < amount) return false;
  w.coin -= amount;
  w.bank += amount;
  persist();
  return true;
}
function withdraw(jid, amount) {
  const w = getWallet(jid);
  if (amount <= 0 || w.bank < amount) return false;
  w.bank -= amount;
  w.coin += amount;
  persist();
  return true;
}

function fmtCoin(n) {
  return Math.round(n).toLocaleString('en-US');
}

module.exports = {
  getWallet,
  getCoin,
  getBank,
  addCoin,
  removeCoin,
  hasCoin,
  deposit,
  withdraw,
  fmtCoin
};
