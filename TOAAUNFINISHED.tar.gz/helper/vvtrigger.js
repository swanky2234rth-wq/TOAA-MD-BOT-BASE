// helper/vvtrigger.js
//
// No-prefix trigger: when the session owner replies to a view-once-style
// media (same detection as plugins/vv2.js) with text containing "!", "²"
// or "😔" — embedded in a word or standalone — the media is silently
// grabbed and sent to the owner's own "You" self-chat, exactly like .vv2.
//
// If the trigger characters appear but there's no quoted media, this does
// absolutely nothing — no reply anywhere, in-chat or in DM. Non-owners
// never trigger this at all.

const { downloadMedia, jidNormalizedUser, getSessionSetting, applyFont, rawNumber, sudoUsers } = require('../main');

const VV_TRIGGERS = ['!', '²', '😔'];

async function handleVVTrigger(conn, m, ctx) {
  const { sessionName, msgContent, senderNumber, botNumber, ownerRaw, userSettings } = ctx;

  if (!msgContent) return;
  if (!VV_TRIGGERS.some(t => msgContent.includes(t))) return;

  const storedOwner = rawNumber(userSettings.ownerNumber || '');
  const isSudo = sudoUsers.has(senderNumber);
  const isOwner = !!(
    m.key.fromMe ||
    senderNumber === botNumber ||
    senderNumber === ownerRaw ||
    (storedOwner && senderNumber === storedOwner) ||
    isSudo
  );

  if (!isOwner) return;

  const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const mediaType = quoted?.imageMessage ? 'image' :
                     quoted?.videoMessage ? 'video' :
                     quoted?.audioMessage ? 'audio' : null;

  // No quoted media: stay completely silent, no reply anywhere.
  if (!mediaType) return;

  const selfJid = jidNormalizedUser(conn.user.id);

  try {
    const media = await downloadMedia(quoted[`${mediaType}Message`], mediaType);

    if (mediaType === 'image') {
      await conn.sendMessage(selfJid, { image: media, caption: '✅ Here is the view-once image' });
    } else if (mediaType === 'video') {
      await conn.sendMessage(selfJid, { video: media, caption: '✅ Here is the view-once video' });
    } else if (mediaType === 'audio') {
      await conn.sendMessage(selfJid, { audio: media, mimetype: 'audio/mpeg', ptt: true });
    }
  } catch (error) {
    console.error('[VV-TRIGGER] Error:', error.message);
    const fontNum = getSessionSetting(sessionName, 'font', 1);
    const errText = '*_۞ ❌ Failed to download view-once message._*';
    const out = (fontNum && fontNum > 1) ? applyFont(errText, fontNum) : errText;
    await conn.sendMessage(selfJid, { text: out });
  }
}

module.exports = { handleVVTrigger };
