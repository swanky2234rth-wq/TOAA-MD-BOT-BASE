// ─── TOAA RPG Garden Crop Registry (helper) ─────────
const GARDEN_CROPS = {
  carrot: { name: '🥕 Carrot', item: 'carrot', seed: 'carrotseed', growTime: 300000, exp: 50, sellPrice: 30, seedPrice: 10 },
  tomato: { name: '🍅 Tomato', item: 'tomato', seed: 'tomatoseed', growTime: 600000, exp: 80, sellPrice: 50, seedPrice: 20 },
  corn: { name: '🌽 Corn', item: 'corn', seed: 'cornseed', growTime: 900000, exp: 120, sellPrice: 80, seedPrice: 35 },
  potato: { name: '🥔 Potato', item: 'gardenpotato', seed: 'gardenpotatoseed', growTime: 1200000, exp: 150, sellPrice: 100, seedPrice: 45 },
  strawberry: { name: '🍓 Strawberry', item: 'gardenstrawberry', seed: 'gardenstrawberryseed', growTime: 1800000, exp: 200, sellPrice: 150, seedPrice: 60 },
  watermelon: { name: '🍉 Watermelon', item: 'gardenwatermelon', seed: 'gardenwatermelonseed', growTime: 3600000, exp: 350, sellPrice: 300, seedPrice: 100 },
  pumpkin: { name: '🎃 Pumpkin', item: 'pumpkin', seed: 'pumpkinseed', growTime: 7200000, exp: 500, sellPrice: 500, seedPrice: 150 },
  herb: { name: '🌿 Herb', item: 'gardenherb', seed: 'gardenherbseed', growTime: 1500000, exp: 180, sellPrice: 120, seedPrice: 50 }
};

module.exports = { GARDEN_CROPS };
