// ─── TOAA RPG Level-Up Notifier (helper) ─────────
// Call after helper/rpg.js addExp() to send the level-up card if the user
// leveled up and hasn't muted it. Shared by any RPG plugin that grants EXP.
const { getUser, expForLevel, getRole } = require('./rpg');
const { generateLevelUpCard } = require('./rpgCard');

async function notifyLevelUp(conn, m, jid, levelResult) {
  if (!levelResult.leveledUp) return;

  const user = getUser(jid);
  if (user.levelupNotif === false) return;

  const { oldLevel, newLevel, exp } = levelResult;
  const role = getRole(newLevel);
  const number = String(jid).split('@')[0].split(':')[0];

  const caption =
    `🎊 *CONGRATULATIONS @${number}!*\n\n` +
    `Your level went up by ${newLevel - oldLevel}\n` +
    `🥗 Your level is now *${newLevel}*\n\n` +
    `You're now ranked *${role}*\n\n` +
    `Interact with the bot often to keep leveling up!`;

  try {
    let avatarUrl;
    try {
      avatarUrl = await conn.profilePictureUrl(jid, 'image');
    } catch (e) {
      avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(number)}&background=00f2ff&color=fff&size=256`;
    }

    const card = await generateLevelUpCard({
      name: number,
      level: newLevel,
      currentXp: exp,
      requiredXp: expForLevel(newLevel + 1),
      avatarUrl
    });

    await conn.sendMessage(m.key.remoteJid, {
      image: card,
      caption,
      mentions: [jid]
    }, { quoted: m });
  } catch (e) {
    console.error('[RPG] Level-up card failed, falling back to text:', e.message);
    await conn.sendMessage(m.key.remoteJid, { text: caption, mentions: [jid] }, { quoted: m });
  }
}

module.exports = { notifyLevelUp };
