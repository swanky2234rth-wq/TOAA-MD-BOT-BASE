const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', 'database', 'antibadword.json');

function load() {
  try { if (fs.existsSync(FILE)) return JSON.parse(fs.readFileSync(FILE, 'utf-8')); } catch {}
  return {};
}
function saveAll(data) {
  try {
    const dir = path.dirname(FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
  } catch (e) { console.error('[ANTIBADWORD] Save failed:', e.message); }
}

let cache = load();

function getGroupConfig(remoteJid) {
  if (!cache[remoteJid]) cache[remoteJid] = { enabled: false, words: [], warnings: {} };
  return cache[remoteJid];
}

function addWord(remoteJid, word) {
  const cfg = getGroupConfig(remoteJid);
  const w = word.toLowerCase().trim();
  if (!cfg.words.includes(w)) cfg.words.push(w);
  saveAll(cache);
}
function removeWord(remoteJid, word) {
  const cfg = getGroupConfig(remoteJid);
  cfg.words = cfg.words.filter(w => w !== word.toLowerCase().trim());
  saveAll(cache);
}
function setEnabled(remoteJid, enabled) {
  getGroupConfig(remoteJid).enabled = enabled;
  saveAll(cache);
}

function containsBadWord(remoteJid, text) {
  const cfg = getGroupConfig(remoteJid);
  if (!cfg.enabled || !cfg.words.length || !text) return null;
  const lower = text.toLowerCase();
  return cfg.words.find(w => new RegExp(`\\b${w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(lower)) || null;
}

// Called from main.js's dispatcher for every group message.
async function handleAntibadword(conn, m, remoteJid, senderJid, botAdminFn) {
  const text = m.message?.conversation || m.message?.extendedTextMessage?.text ||
               m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || '';
  const hit = containsBadWord(remoteJid, text);
  if (!hit) return false;

  const senderNum = senderJid.split('@')[0].split(':')[0];
  const cfg = getGroupConfig(remoteJid);
  cfg.warnings[senderNum] = (cfg.warnings[senderNum] || 0) + 1;
  saveAll(cache);

  try { await conn.sendMessage(remoteJid, { delete: m.key }); } catch (e) { /* bot may not be admin */ }

  const warnCount = cfg.warnings[senderNum];
  if (warnCount >= 3) {
    cfg.warnings[senderNum] = 0;
    saveAll(cache);
    try {
      await conn.groupParticipantsUpdate(remoteJid, [senderJid], 'remove');
      await conn.sendMessage(remoteJid, {
        text: `🔨 @${senderNum} removed after 3 bad-word warnings.`,
        mentions: [senderJid]
      });
    } catch {
      await conn.sendMessage(remoteJid, {
        text: `⚠️ @${senderNum} hit 3 warnings but I couldn't remove them — make me admin!`,
        mentions: [senderJid]
      });
    }
  } else {
    await conn.sendMessage(remoteJid, {
      text: `⚠️ @${senderNum} watch your language! Warning ${warnCount}/3 for using "${hit}".`,
      mentions: [senderJid]
    });
  }
  return true;
}

module.exports = { getGroupConfig, addWord, removeWord, setEnabled, containsBadWord, handleAntibadword };
