// ─── TOAA Group Protection Settings (helper) ─────────
// Shared per-group toggle store for antibot, antidocument, antimedia,
// banchat, notifclosegroup. Replaces the source's custom ourin-database.js.
const fs = require('fs');
const path = require('path');

const GP_FILE = path.join(__dirname, '..', 'database', 'groupProtection.json');

let cache = null;

function load() {
  if (cache) return cache;
  try {
    cache = fs.existsSync(GP_FILE) ? JSON.parse(fs.readFileSync(GP_FILE, 'utf-8')) : {};
  } catch (e) {
    console.error('[GROUPPROTECTION] Failed to load, starting fresh:', e.message);
    cache = {};
  }
  return cache;
}

function save() {
  try {
    const dir = path.dirname(GP_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(GP_FILE, JSON.stringify(cache, null, 2));
  } catch (e) {
    console.error('[GROUPPROTECTION] Failed to save:', e.message);
  }
}

function getGroup(jid) {
  const data = load();
  return data[jid] || {};
}

function setGroup(jid, updates) {
  const data = load();
  data[jid] = { ...(data[jid] || {}), ...updates };
  save();
  return data[jid];
}

module.exports = { getGroup, setGroup, GP_FILE };
