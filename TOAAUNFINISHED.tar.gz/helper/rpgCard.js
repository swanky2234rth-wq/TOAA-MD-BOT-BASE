// ─── TOAA RPG Level-Up Card (helper) ─────────
// Ported from ourin-level.js's generateLevelUpCard. Renders a canvas image
// shown when a user levels up (unless they've muted it via leveluprpg.js).
const { createCanvas, loadImage } = require('@napi-rs/canvas');

const DEFAULT_BG = 'https://images.wallpapersden.com/image/download/anime-night-sky-scenery_bWlsZ26UmZqaraWkpJRmbmdlrWZnZWU.jpg';

async function generateLevelUpCard({ name, level, currentXp, requiredXp, avatarUrl, backgroundUrl }) {
  const width = 800, height = 280;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.save();
  ctx.beginPath();
  ctx.roundRect(10, 10, width - 20, height - 20, 30);
  ctx.clip();
  try {
    const background = await loadImage(backgroundUrl || DEFAULT_BG);
    const ratio = Math.max(width / background.width, height / background.height);
    const x = (width - background.width * ratio) / 2;
    const y = (height - background.height * ratio) / 2;
    ctx.drawImage(background, x, y, background.width * ratio, background.height * ratio);
  } catch (e) {
    ctx.fillStyle = '#1e1e2f';
    ctx.fillRect(0, 0, width, height);
  }
  ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
  ctx.fillRect(0, 0, width, height);
  ctx.restore();

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
  ctx.lineWidth = 2;
  ctx.strokeRect(10, 10, width - 20, height - 20);

  try {
    const avatar = await loadImage(avatarUrl).catch(() => null);
    if (avatar) {
      ctx.shadowColor = '#00f2ff';
      ctx.shadowBlur = 20;
      ctx.save();
      ctx.beginPath();
      ctx.arc(120, height / 2, 85, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(avatar, 35, height / 2 - 85, 170, 170);
      ctx.restore();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = '#00f2ff';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(120, height / 2, 85, 0, Math.PI * 2);
      ctx.stroke();
    }
  } catch (e) {}

  ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
  ctx.shadowBlur = 5;
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 40px sans-serif';
  ctx.fillText('LEVEL UP!', 230, 85);

  ctx.fillStyle = '#00f2ff';
  ctx.font = 'italic 25px sans-serif';
  ctx.fillText(`Congratulations, ${name}!`, 230, 125);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#ffffff';
  ctx.font = 'italic bold 90px sans-serif';
  ctx.fillText(`${level}`, width - 50, 120);
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('LEVEL', width - 55, 45);
  ctx.textAlign = 'left';

  const barX = 230, barY = 185, barWidth = 520, barHeight = 30;
  const progress = Math.min(currentXp / requiredXp, 1);

  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.beginPath();
  ctx.roundRect(barX, barY, barWidth, barHeight, 15);
  ctx.fill();

  const barGrad = ctx.createLinearGradient(barX, 0, barX + barWidth, 0);
  barGrad.addColorStop(0, '#ff00cc');
  barGrad.addColorStop(1, '#3333ff');
  ctx.fillStyle = barGrad;
  ctx.beginPath();
  ctx.roundRect(barX, barY, barWidth * progress, barHeight, 15);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText(`${currentXp.toLocaleString()} / ${requiredXp.toLocaleString()} XP`, barX + 15, barY + 21);

  ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
  ctx.font = '12px sans-serif';
  ctx.fillText('TOAA', 230, 245);

  return canvas.toBuffer('image/png');
}

module.exports = { generateLevelUpCard };
