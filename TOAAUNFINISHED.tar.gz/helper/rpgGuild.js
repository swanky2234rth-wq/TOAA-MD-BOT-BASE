// ─── TOAA RPG Guild Store (helper) ─────────
// Guild data is its own collection, not per-user — a guild has members,
// a treasury, a level, etc. Persists to database/rpgGuild.json.
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'database', 'rpgGuild.json');

function loadAll() {
  try {
    if (fs.existsSync(DB_FILE)) return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } catch (e) {
    console.error('[RPGGUILD] Failed to load:', e.message);
  }
  return {};
}

let _cache = loadAll();
let _saveTimer = null;
function persist() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(_cache, null, 2));
    } catch (e) {
      console.error('[RPGGUILD] Failed to save:', e.message);
    }
  }, 300);
}

function getAllGuilds() {
  return _cache;
}

function getGuild(guildId) {
  return _cache[guildId] || null;
}

function findGuildByName(name) {
  return Object.values(_cache).find(g => g.name.toLowerCase() === name.toLowerCase()) || null;
}

function createGuild(guildId, name, leaderJid) {
  _cache[guildId] = {
    id: guildId,
    name,
    leader: leaderJid,
    members: [leaderJid],
    treasury: 0,
    level: 1,
    exp: 0,
    createdAt: Date.now()
  };
  persist();
  return _cache[guildId];
}

function deleteGuild(guildId) {
  delete _cache[guildId];
  persist();
}

function saveGuild(guildId, guildData) {
  _cache[guildId] = guildData;
  persist();
}

module.exports = { getAllGuilds, getGuild, findGuildByName, createGuild, deleteGuild, saveGuild };
