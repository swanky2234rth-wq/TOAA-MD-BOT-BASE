// ─── TOAA Image AI Engine (helper) ─────────

const axios = require('axios');
const FormData = require('form-data');
const { randomUUID } = require('crypto');

const hdrs = {
  'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
  'Accept': '*/*',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
  'Origin': 'https://imgupscaler.ai',
  'Referer': 'https://imgupscaler.ai/',
};

const api = axios.create({ baseURL: 'https://api.imgupscaler.ai' });

async function uploadBuf(buf) {
  const ext = 'jpg';
  const form1 = new FormData();
  form1.append('file_name', `${randomUUID()}.${ext}`);

  const { data: reg } = await api.post('/api/common/upload/upload-image', form1, {
    headers: { ...hdrs, ...form1.getHeaders(), 'sec-fetch-site': 'same-site' },
  });
  const { url: uploadUrl, object_name } = reg.result;

  await axios.put(uploadUrl, buf, { headers: { 'Content-Type': 'image/jpeg' } });

  const form2 = new FormData();
  form2.append('object_name', object_name);

  const { data: signed } = await api.post('/api/common/upload/sign-object', form2, {
    headers: { ...hdrs, ...form2.getHeaders(), 'sec-fetch-site': 'same-site' },
  });

  return signed.result.url;
}

async function live3d(imageBuffer, prompt) {
  const imgUrl = await uploadBuf(imageBuffer);

  const { data } = await axios.get(
    `https://kyzznekoo.zone.id/api/img/v2/nanobanana?url=${encodeURIComponent(imgUrl)}&prompt=${encodeURIComponent(prompt)}`,
    { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', 'Content-Type': 'application/json' } }
  );

  if (!data?.status || !data?.data?.result_url) {
    throw new Error('Failed to edit image via nanobanana.');
  }

  const imgResponse = await axios.get(data.data.result_url, { responseType: 'arraybuffer' });
  return { image: Buffer.from(imgResponse.data) };
}

async function fluxImage(message, ratio = '1:1') {
  const r = await axios.post(
    'https://api.yuulabs.web.id/api/ai/flux-img',
    { message, ratio },
    { headers: { 'Content-Type': 'application/json' }, timeout: 120000 }
  );

  const data = r.data;
  if (!data?.status || !data?.result?.url) {
    throw new Error(data?.message || data?.error || 'Failed to generate image');
  }

  return data.result;
}

module.exports = { live3d, fluxImage, uploadBuf };
