// ─── TOAA RPG Recipe Registry (helper) ─────────
// Recipes for cook.js, blacksmith.js, alchemy.js. Every material referenced
// here exists in rpgItems.js — legacy recipes calling for invented items
// (wheat, rice, egg, carrot, potato, strawberry, tomato, watermelon,
// dragonscale) were trimmed or reworked to use what's actually gatherable
// in this project (fish/rabbit/boar/apple/wood/herb/flower/mushroom/etc.)

const COOK_RECIPES = {
  fishsoup: { name: '🍲 Fish Soup', materials: { fish: 2 }, effect: { health: 30 }, exp: 40 },
  grilledmeat: { name: '🍖 Grilled Meat', materials: { rabbit: 1, wood: 1 }, effect: { health: 40, stamina: 10 }, exp: 60 },
  applepie: { name: '🥧 Apple Pie', materials: { apple: 3 }, effect: { health: 25 }, exp: 30 },
  steak: { name: '🥩 Steak', materials: { boar: 1, coal: 1 }, effect: { health: 60, stamina: 15 }, exp: 100 },
  ramen: { name: '🍜 Ramen', materials: { fish: 2, wood: 1, herb: 1 }, effect: { health: 35, stamina: 45 }, exp: 110 },
  smoothie: { name: '🥤 Smoothie', materials: { apple: 3, herb: 1 }, effect: { stamina: 30, mana: 20 }, exp: 70 },
  elixirfood: { name: '✨ Elixir Food', materials: { herb: 5, diamond: 1, gold: 2 }, effect: { stamina: 100, health: 100, mana: 50 }, exp: 300 }
};

const BLACKSMITH_RECIPES = {
  sword: { materials: { iron: 3, wood: 2 }, result: 'sword', name: '⚔️ Iron Sword', exp: 200 },
  shield: { materials: { iron: 4, leather: 2 }, result: 'shield', name: '🛡️ Iron Shield', exp: 250 },
  helmet: { materials: { iron: 2, leather: 1 }, result: 'helmet', name: '⛑️ Iron Helmet', exp: 150 },
  armor: { materials: { iron: 5, leather: 3 }, result: 'armor', name: '🦺 Iron Armor', exp: 350 },
  axe: { materials: { iron: 2, wood: 3 }, result: 'axe', name: '🪓 Iron Axe', exp: 180 },
  pickaxe: { materials: { iron: 3, wood: 2 }, result: 'pickaxe', name: '⛏️ Pickaxe', exp: 180 },
  bow: { materials: { wood: 4, stick: 2 }, result: 'bow', name: '🏹 Bow', exp: 200 },
  arrow: { materials: { wood: 1, iron: 1 }, result: 'arrow', name: '🏹 Arrow x10', exp: 50, qty: 10 },
  goldsword: { materials: { gold: 5, diamond: 2, iron: 3 }, result: 'goldsword', name: '🗡️ Gold Sword', exp: 500 },
  diamondarmor: { materials: { diamond: 8, iron: 5, leather: 3 }, result: 'diamondarmor', name: '💎 Diamond Armor', exp: 800 }
};

const ALCHEMY_RECIPES = {
  healthpotion: { name: '❤️ Health Potion', materials: { herb: 3 }, effect: 'Restores 50 HP', exp: 80, result: 'healthpotion' },
  manapotion: { name: '💙 Mana Potion', materials: { herb: 2, flower: 1 }, effect: 'Restores 50 Mana', exp: 90, result: 'manapotion' },
  staminapotion: { name: '⚡ Stamina Potion', materials: { herb: 2, mushroom: 1 }, effect: 'Restores 30 Stamina', exp: 100, result: 'staminapotion2' },
  strengthpotion: { name: '💪 Strength Potion', materials: { herb: 3, iron: 2 }, effect: '+20 ATK (temporary)', exp: 200, result: 'strengthpotion' },
  defensepotion: { name: '🛡️ Defense Potion', materials: { herb: 3, leather: 2 }, effect: '+15 DEF (temporary)', exp: 180, result: 'defensepotion' },
  luckpotion: { name: '🍀 Luck Potion', materials: { herb: 5, diamond: 1 }, effect: '+30% Drop Rate (temporary)', exp: 300, result: 'luckpotion' },
  exppotion: { name: '✨ EXP Potion', materials: { herb: 4, gold: 2 }, effect: '+50% EXP (temporary)', exp: 250, result: 'exppotion' },
  antidote: { name: '💊 Antidote', materials: { herb: 2 }, effect: 'Cures poison', exp: 50, result: 'antidote' },
  elixir: { name: '🧪 Elixir', materials: { herb: 10, diamond: 2, gold: 5 }, effect: 'Restores all stats', exp: 500, result: 'elixir' }
};

const ENCHANTABLE = {
  sword: { name: '⚔️ Sword', stat: 'attack', bonus: 5, cost: 500, successRate: 70 },
  shield: { name: '🛡️ Shield', stat: 'defense', bonus: 4, cost: 500, successRate: 70 },
  armor: { name: '🦺 Armor', stat: 'health', bonus: 20, cost: 800, successRate: 60 },
  helmet: { name: '⛑️ Helmet', stat: 'defense', bonus: 3, cost: 400, successRate: 75 },
  bow: { name: '🏹 Bow', stat: 'attack', bonus: 4, cost: 450, successRate: 72 },
  goldsword: { name: '🗡️ Gold Sword', stat: 'attack', bonus: 10, cost: 2000, successRate: 50 },
  diamondarmor: { name: '💎 Diamond Armor', stat: 'health', bonus: 50, cost: 5000, successRate: 40 }
};

module.exports = { COOK_RECIPES, BLACKSMITH_RECIPES, ALCHEMY_RECIPES, ENCHANTABLE };
