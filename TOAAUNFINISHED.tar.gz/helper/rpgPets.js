// ─── TOAA RPG Pet Registry (helper) ─────────
const PET_TYPES = {
  cat: { name: '🐱 Cat', baseStats: { attack: 5, defense: 3, luck: 5 }, evolve: 'lion' },
  dog: { name: '🐕 Dog', baseStats: { attack: 8, defense: 5, luck: 2 }, evolve: 'wolf' },
  bird: { name: '🐦 Bird', baseStats: { attack: 4, defense: 2, luck: 8 }, evolve: 'phoenix' },
  fish: { name: '🐟 Fish', baseStats: { attack: 2, defense: 2, luck: 10 }, evolve: 'dragon' },
  rabbit: { name: '🐰 Rabbit', baseStats: { attack: 3, defense: 4, luck: 6 }, evolve: 'thunderbunny' },
  lion: { name: '🦁 Lion', baseStats: { attack: 15, defense: 10, luck: 8 }, evolve: null },
  wolf: { name: '🐺 Wolf', baseStats: { attack: 18, defense: 12, luck: 5 }, evolve: null },
  phoenix: { name: '🔥 Phoenix', baseStats: { attack: 12, defense: 8, luck: 15 }, evolve: null },
  dragon: { name: '🐉 Dragon', baseStats: { attack: 20, defense: 15, luck: 12 }, evolve: null },
  thunderbunny: { name: '⚡ Thunder Bunny', baseStats: { attack: 10, defense: 12, luck: 18 }, evolve: null }
};

const FOOD_ITEMS = {
  bread: { name: '🍞 Bread', hunger: 10, exp: 5 },
  fish: { name: '🐟 Fish', hunger: 20, exp: 10 },
  meat: { name: '🍖 Meat', hunger: 30, exp: 15 },
  fruit: { name: '🍎 Fruit', hunger: 15, exp: 8 },
  premium_food: { name: '⭐ Premium Food', hunger: 50, exp: 30 }
};

const PETS_FOR_SALE = {
  cat: { name: '🐱 Cat', price: 5000, desc: 'Brings luck (High Luck, Medium Attack)' },
  dog: { name: '🐕 Dog', price: 6000, desc: 'Loyal guardian (High Attack, Good Defense)' },
  bird: { name: '🐦 Bird', price: 4500, desc: 'Agile & lucky (Very High Luck)' },
  fish: { name: '🐟 Fish', price: 3000, desc: 'Cheap and cheerful (Brings fortune)' },
  rabbit: { name: '🐰 Rabbit', price: 5500, desc: 'Small & nimble (Balanced stats)' }
};

const BREEDING_RESULTS = {
  'cat+cat': ['cat', 'cat', 'lion'],
  'dog+dog': ['dog', 'dog', 'wolf'],
  'cat+dog': ['cat', 'dog', 'rabbit'],
  'bird+bird': ['bird', 'bird', 'phoenix'],
  'fish+fish': ['fish', 'fish', 'dragon'],
  'rabbit+rabbit': ['rabbit', 'rabbit', 'thunderbunny'],
  'cat+bird': ['cat', 'bird', 'phoenix'],
  'dog+rabbit': ['dog', 'rabbit', 'wolf'],
  default: ['cat', 'dog', 'bird', 'fish', 'rabbit']
};

module.exports = { PET_TYPES, FOOD_ITEMS, PETS_FOR_SALE, BREEDING_RESULTS };
