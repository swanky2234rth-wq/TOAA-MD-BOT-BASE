// ─── TOAA Group Memory (helper) ─────────
// Lets Toaa AI remember short facts people share about themselves/others in
// a given group, so a later question from someone else can be answered
// using what was already discussed — e.g. "My name is Broken, I'm a dev"
// followed later by "who's Broken?" from a different user.
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'database', 'groupMemory.json');
const MAX_FACTS_PER_GROUP = 200;   // rolling cap so the file can't grow forever
const MAX_FACTS_IN_PROMPT = 40;    // how many facts get sent to the AI per call

function loadAll() {
  try {
    if (fs.existsSync(DB_FILE)) return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } catch (e) {
    console.error('[GROUPMEMORY] Failed to load:', e.message);
  }
  return {};
}

let _cache = loadAll();
let _saveTimer = null;
function persist() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(_cache, null, 2));
    } catch (e) {
      console.error('[GROUPMEMORY] Failed to save:', e.message);
    }
  }, 300);
}

function getGroupFacts(groupJid) {
  if (!_cache[groupJid]) _cache[groupJid] = [];
  return _cache[groupJid];
}

// Adds one fact tied to a specific sender. `fact` should be a short, plain
// sentence — e.g. "Broken is a dev." Facts are deduped by (senderNumber,
// fact text) so the same statement repeated doesn't pile up.
function addFact(groupJid, senderNumber, senderName, fact) {
  if (!fact || !fact.trim()) return;
  const facts = getGroupFacts(groupJid);
  const clean = fact.trim().slice(0, 300);

  const isDupe = facts.some(f => f.senderNumber === senderNumber && f.fact === clean);
  if (isDupe) return;

  facts.push({
    senderNumber,
    senderName: senderName || senderNumber,
    fact: clean,
    at: Date.now()
  });

  if (facts.length > MAX_FACTS_PER_GROUP) facts.splice(0, facts.length - MAX_FACTS_PER_GROUP);
  persist();
}

// Returns a short block of recent facts for this group, formatted for
// injection into the AI persona/system prompt.
function getFactsForPrompt(groupJid) {
  const facts = getGroupFacts(groupJid);
  if (!facts.length) return '';

  const recent = facts.slice(-MAX_FACTS_IN_PROMPT);
  return recent
    .map(f => `- ${f.senderName} (@${f.senderNumber}) said: ${f.fact}`)
    .join('\n');
}

function clearGroupFacts(groupJid) {
  _cache[groupJid] = [];
  persist();
}

module.exports = { addFact, getFactsForPrompt, clearGroupFacts };
