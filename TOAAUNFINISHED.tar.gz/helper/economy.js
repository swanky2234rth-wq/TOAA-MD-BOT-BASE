// ─── TOAA ECONOMY ENGINE ──────────────────────────────────────────────────────


const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'database', 'economy.json');

const HOUR = 60 * 60 * 1000;
const EFFECT_DURATION = 48 * HOUR; // stealth/security/max security/counter

const COOLDOWNS = {
  swipe: 2 * HOUR,
  trade: 2 * HOUR,
  work: 3 * HOUR,
  spin: 4 * HOUR,
};

const SWIPE_AMOUNT = 15000;
const WORK_AMOUNT = 30000;
const TRADE_MAX_WIN = 150000; // rare jackpot ceiling

const ITEM_VALUES = {
  gemstone: 3200000,
  easteregg: 1300000,
  blacklotus: 810000,
  denarius: 500000,
};
const ITEM_LABELS = {
  gemstone: 'Gemstone 💎',
  easteregg: 'Easter Egg 🥚',
  blacklotus: 'Black Lotus 🪷',
  denarius: 'Denarius Coin 🪙',
};

const PRICES = {
  booster: 300000,
  stealth: 320000,
  security: 95000,
  instinct: 80000,
  maxsecurity: 450000, // not explicitly priced in spec — set above counter's cost since it's the strongest protection
  counter: 390000,
};

// ─── Persistence ──────────────────────────────────────────────────────────────
function loadAll() {
  try {
    if (fs.existsSync(DB_FILE)) return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } catch (e) {
    console.error('[ECONOMY] Failed to load:', e.message);
  }
  return {};
}

let _cache = loadAll();
let _saveTimer = null;
function persist() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(_cache, null, 2));
    } catch (e) {
      console.error('[ECONOMY] Failed to save:', e.message);
    }
  }, 300); // debounce rapid writes
}

function defaultAccount() {
  return {
    balance: 0,
    items: { gemstone: 0, easteregg: 0, blacklotus: 0, denarius: 0 },
    effects: { stealth: 0, security: 0, maxsecurity: 0, counter: 0 }, // each value = expiry timestamp, 0 = inactive
    cooldowns: { swipe: {}, trade: 0, work: 0, spin: 0 }, // swipe cooldown is per-target
    spinCount: 0,
    rareGivenThisCycle: false,
    booster: false,
  };
}

function getAccount(number) {
  const key = String(number).replace(/[^0-9]/g, '');
  if (!_cache[key]) {
    _cache[key] = defaultAccount();
  } else {
    // backfill any fields added after a user's account was first created
    const def = defaultAccount();
    _cache[key] = { ...def, ..._cache[key], items: { ...def.items, ..._cache[key].items }, effects: { ...def.effects, ..._cache[key].effects }, cooldowns: { ...def.cooldowns, ..._cache[key].cooldowns } };
  }
  return _cache[key];
}

function save() { persist(); }

// ─── Money / items ──────────────────────────────────────────────────────────
function addMoney(number, amount) {
  const acc = getAccount(number);
  acc.balance = Math.max(0, acc.balance + Math.round(amount));
  save();
  return acc.balance;
}
function removeMoney(number, amount) {
  const acc = getAccount(number);
  acc.balance = Math.max(0, acc.balance - Math.round(amount));
  save();
  return acc.balance;
}
function addItem(number, item, qty = 1) {
  const acc = getAccount(number);
  acc.items[item] = (acc.items[item] || 0) + qty;
  save();
  return acc.items[item];
}
function removeItem(number, item, qty = 1) {
  const acc = getAccount(number);
  acc.items[item] = Math.max(0, (acc.items[item] || 0) - qty);
  save();
  return acc.items[item];
}

// ─── Effects (stealth / security / max security / counter) ──────────────────
function hasEffect(number, effect) {
  const acc = getAccount(number);
  return (acc.effects[effect] || 0) > Date.now();
}
function grantEffect(number, effect) {
  const acc = getAccount(number);
  acc.effects[effect] = Date.now() + EFFECT_DURATION;
  save();
  return acc.effects[effect];
}
function effectRemaining(number, effect) {
  const acc = getAccount(number);
  const rem = (acc.effects[effect] || 0) - Date.now();
  return rem > 0 ? rem : 0;
}

// ─── Cooldowns ────────────────────────────────────────────────────────────────
function isOnCooldown(number, action) {
  const acc = getAccount(number);
  const until = acc.cooldowns[action] || 0;
  return until > Date.now();
}
function cooldownRemaining(number, action) {
  const acc = getAccount(number);
  const rem = (acc.cooldowns[action] || 0) - Date.now();
  return rem > 0 ? rem : 0;
}
function setCooldown(number, action, durationMs) {
  const acc = getAccount(number);
  acc.cooldowns[action] = Date.now() + durationMs;
  save();
}

function isSwipeOnCooldown(attacker, target) {
  const acc = getAccount(attacker);
  const until = acc.cooldowns.swipe[target] || 0;
  return until > Date.now();
}
function swipeCooldownRemaining(attacker, target) {
  const acc = getAccount(attacker);
  const rem = (acc.cooldowns.swipe[target] || 0) - Date.now();
  return rem > 0 ? rem : 0;
}
function setSwipeCooldown(attacker, target) {
  const acc = getAccount(attacker);
  acc.cooldowns.swipe[target] = Date.now() + COOLDOWNS.swipe;
  save();
}

// ─── Spin rarity: 
function nextSpinRareEligibility(number) {
  const acc = getAccount(number);
  acc.spinCount = (acc.spinCount || 0) + 1;
  const posInCycle = ((acc.spinCount - 1) % 4) + 1; // 1..4
  if (posInCycle === 1) acc.rareGivenThisCycle = false; // fresh cycle
  const eligible = (posInCycle === 3 || posInCycle === 4) && !acc.rareGivenThisCycle;
  save();
  return eligible;
}
function markSpinResult(number, wasRare) {
  if (!wasRare) return;
  const acc = getAccount(number);
  acc.rareGivenThisCycle = true;
  save();
}

// ─── Formatting helpers ───────────────────────────────────────────────────────
function fmtMoney(n) {
  return '$' + Math.round(n).toLocaleString('en-US');
}
function fmtDuration(ms) {
  const totalMin = Math.ceil(ms / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

// ─── Net worth (for leaderboard) ─────────────────────────────────────────────
function netWorth(number) {
  const acc = getAccount(number);
  const itemValue = Object.entries(acc.items).reduce((sum, [k, v]) => sum + (ITEM_VALUES[k] || 0) * v, 0);
  return acc.balance + itemValue;
}

function allAccounts() {
  return _cache;
}

// ─── Pending gamble / collab invitations
const pendingGambles = new Map(); // key: `${remoteJid}:${targetNumber}` -> { challenger, amount, remoteJid, expires }
const pendingCollabs = new Map(); // key: `${remoteJid}:${targetNumber}` -> { inviter, victimNumber, remoteJid, expires }

const INVITE_TTL = 5 * 60 * 1000;

function addPendingGamble(remoteJid, targetNumber, challenger, amount) {
  pendingGambles.set(`${remoteJid}:${targetNumber}`, { challenger, amount, remoteJid, expires: Date.now() + INVITE_TTL });
}
function addPendingCollab(remoteJid, targetNumber, inviter, victimNumber) {
  pendingCollabs.set(`${remoteJid}:${targetNumber}`, { inviter, victimNumber, remoteJid, expires: Date.now() + INVITE_TTL });
}

// Called from main.js's message dispatcher on every non-command message so a
// plain "Proceed"/"Decline"/"Accept" reply can resolve a pending invitation.
async function handlePendingReplies(conn, m, senderNumber, remoteJid) {
  const text = (m.message?.conversation || m.message?.extendedTextMessage?.text || '').trim().toLowerCase();
  if (!['proceed', 'decline', 'accept'].includes(text)) return false;

  const send = (body, mentionNumbers = []) =>
    conn.sendMessage(remoteJid, { text: body, mentions: mentionNumbers.map(n => `${n}@s.whatsapp.net`) }, { quoted: m });

  const gambleKey = `${remoteJid}:${senderNumber}`;
  const gamble = pendingGambles.get(gambleKey);
  if (gamble && gamble.expires > Date.now()) {
    pendingGambles.delete(gambleKey);
    if (text === 'decline') {
      await send(`@${senderNumber} declined the gamble.`, [senderNumber, gamble.challenger]);
      return true;
    }
    const challengerAcc = getAccount(gamble.challenger);
    const targetAcc = getAccount(senderNumber);
    if (challengerAcc.balance < gamble.amount || targetAcc.balance < gamble.amount) {
      await send(`Gamble cancelled — one of you no longer has enough money.`, [senderNumber, gamble.challenger]);
      return true;
    }
    const winnerIsChallenger = Math.random() < 0.5;
    const winner = winnerIsChallenger ? gamble.challenger : senderNumber;
    const loser = winnerIsChallenger ? senderNumber : gamble.challenger;
    removeMoney(loser, gamble.amount);
    addMoney(winner, gamble.amount * 2);
    await send(
      `🎲 Gamble settled!\n\n🏆 @${winner} wins ${fmtMoney(gamble.amount * 2)}!\n💸 @${loser} loses ${fmtMoney(gamble.amount)}.`,
      [gamble.challenger, senderNumber]
    );
    return true;
  }

  const collabKey = `${remoteJid}:${senderNumber}`;
  const collab = pendingCollabs.get(collabKey);
  if (collab && collab.expires > Date.now()) {
    pendingCollabs.delete(collabKey);
    if (text === 'decline') {
      await send(`@${senderNumber} declined the collab request.`, [senderNumber, collab.inviter]);
      return true;
    }
    const result = doSwipe(collab.inviter, collab.victimNumber, { collabPartner: senderNumber });
    if (result.outcome === 'success') {
      const share = Math.round(result.amount / 2);
      addMoney(collab.inviter, share);
      addMoney(senderNumber, share);
    }
    await send(formatSwipeResult(result, collab.inviter, collab.victimNumber), [collab.inviter, senderNumber, collab.victimNumber]);
    return true;
  }

  return false;
}

// ─── Swipe mechanics (shared by swipe.js and the collab flow above) ─────────
function doSwipe(attacker, target, opts = {}) {
  const targetHasCounter = hasEffect(target, 'counter');
  const targetHasMaxSecurity = hasEffect(target, 'maxsecurity');
  const targetHasSecurity = hasEffect(target, 'security');
  const attackerHasStealth = hasEffect(attacker, 'stealth');
  const isCollab = !!opts.collabPartner;

  // Counter always resolves first and silences security per the spec.
  if (targetHasCounter) {
    removeMoney(attacker, SWIPE_AMOUNT);
    addMoney(target, SWIPE_AMOUNT);
    return { outcome: 'countered' };
  }

  // Max security blocks everything, including collabs and stealth.
  if (targetHasMaxSecurity) {
    return { outcome: 'blocked-maxsecurity' };
  }

  // Regular security blocks the swipe unless the attacker collabed or used stealth.
  if (targetHasSecurity && !isCollab && !attackerHasStealth) {
    return { outcome: 'blocked-security' };
  }

  let amount = SWIPE_AMOUNT;
  if (isCollab) amount = Math.round(SWIPE_AMOUNT * 1.5); // collabs are more lucrative per spec
  removeMoney(target, amount);
  if (!isCollab) addMoney(attacker, amount); // collab callers split the take themselves

  return { outcome: 'success', amount };
}

function formatSwipeResult(result, attacker, target, mentions) {
  switch (result.outcome) {
    case 'countered':
      return `🛡️ @${target} had *Counter* active! It backfired — @${attacker} lost ${fmtMoney(SWIPE_AMOUNT)} to them instead.`;
    case 'blocked-maxsecurity':
      return `🔒 @${target} has *Max Security* — the swipe was completely blocked.`;
    case 'blocked-security':
      return `🔒 @${target} has *Security* active — swipe blocked (need Stealth or a Collab to get past it).`;
    case 'success':
      return `🕵️ @${attacker} swiped ${fmtMoney(result.amount)} from @${target}!`;
    default:
      return `Swipe attempt resolved.`;
  }
}

module.exports = {
  HOUR, EFFECT_DURATION, COOLDOWNS, SWIPE_AMOUNT, WORK_AMOUNT, TRADE_MAX_WIN,
  ITEM_VALUES, ITEM_LABELS, PRICES,
  getAccount, save, allAccounts,
  addMoney, removeMoney, addItem, removeItem,
  hasEffect, grantEffect, effectRemaining,
  isOnCooldown, cooldownRemaining, setCooldown,
  isSwipeOnCooldown, swipeCooldownRemaining, setSwipeCooldown,
  canRollRareItem: nextSpinRareEligibility, markSpinResult,
  fmtMoney, fmtDuration, netWorth,
  addPendingGamble, addPendingCollab, handlePendingReplies,
  doSwipe, formatSwipeResult,
};
