/*
═══════════════════╗
〚    𝙱𝙾𝚃• ₊ ⃝₊TOAA
〚    𝙳𝙴𝚅•  ₊ ⃝—͟͟͞͞swanky
〚    𝙲𝙾𝙽𝚃𝙰𝙲𝚃• +2349010262734
〚    𝙸𝙽𝚂𝙿𝙸𝚁𝙰𝚃𝙸𝙾𝙽• 𝑇𝐻𝐸 OVERLORDS
〚    𝙱𝚄𝙳𝙳𝚈• TOAA
〚    𝚃𝙴𝙻𝙴𝙶𝚁𝙰𝙼 : t.me/swanky_is_TOAA
〚    𝚅𝙿𝚂 𝙰𝙽𝙳 𝙿𝚃𝙴𝚁𝙾𝙳𝙰𝙲𝚃𝚈𝙻 𝙳𝙴𝙰𝙻𝚂
┗━━━━━━━━━━━━━━━┛
*/
const fs = require('fs');
const path = require('path');
const os = require('os');
const axios = require('axios');
const yts = require('yt-search');
const FormData = require('form-data');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const {
  default: makeWASocket,
  downloadContentFromMessage,
  proto,
  generateWAMessageFromContent,
  generateWAMessage,
  prepareWAMessageMedia,
  jidNormalizedUser
} = require("@whiskeysockets/baileys");
const settings = require('./settings');
const {
  isPremium, addPremium, delPremium,
  isSudo, addSudo, delSudo, listSudo,
  loadUserSettings, saveUserSettings,
  getSessionSetting, setSessionSetting,
  isGroupAdmin, isBotAdmin, checkGroupAdmins, getGroupAdmins, isSessionOwner,
  normalizeNumber, cleanJidNumber, getRawId, resolveDisplayJid,
} = require('./helper/function');
const { fromJid, formatUptime, measureSpeed } = require('./helper/utils');
const { handleBattle } = require('./plugins/battle');
const { handleQuizAnswer } = require('./plugins/quiz');
const { applyFont, FONT_COUNT } = require('./helper/fonts');

global.botStartTime = global.botStartTime || Date.now();

// ─── Email transporter for appeals ───────────────────────────────────────────
let emailTransporter = null;

function initEmailTransporter() {
    if (!settings.SENDER_EMAIL || !settings.SENDER_PASS) return null;
    try {
        emailTransporter = nodemailer.createTransport({
            service: 'gmail',
            auth: { user: settings.SENDER_EMAIL, pass: settings.SENDER_PASS }
        });
        console.log('[EMAIL] Transporter initialized');
        return emailTransporter;
    } catch (e) {
        console.error('[EMAIL] Failed to initialize:', e.message);
        return null;
    }
}

// ─── Anti Group Chat Mention (antigcm) settings ─────────────────────────────────
const antigcmSettings = new Map();
const antigcmWarnings = new Map();
const ANTIGCM_FILE = path.join(__dirname, 'database', 'antigcm.json');
const MAX_ANTIGCM_WARNS = 3;

// Load existing antigcm settings
if (fs.existsSync(ANTIGCM_FILE)) {
  try {
    const saved = JSON.parse(fs.readFileSync(ANTIGCM_FILE, 'utf-8'));
    for (const [jid, enabled] of Object.entries(saved)) {
      antigcmSettings.set(jid, enabled);
    }
    console.log(`[ANTIGCM] Loaded ${antigcmSettings.size} group settings`);
  } catch (e) {
    console.error('[ANTIGCM] Failed to load:', e.message);
  }
}

function saveAntigcmSettings() {
  try {
    const dir = path.dirname(ANTIGCM_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const obj = Object.fromEntries(antigcmSettings);
    fs.writeFileSync(ANTIGCM_FILE, JSON.stringify(obj, null, 2));
  } catch (e) {
    console.error('[ANTIGCM] Failed to save:', e.message);
  }
}


// ─── Newsletter footer (menu, uptime, access denied, alive only) ──────────────
function getNewsletterFooter() {
  return {
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: settings.WA_CHANNEL_JID || "120363410600924136@newsletter",
        newsletterName: settings.BOT_NAME || "*TOAA*",
        serverMessageId: -1
      }
    }
  };
}

// ─── General footer (all other commands — no title/thumbnail/body) ────────────
function getFooterReply() {
  return {};
}

// ─── Admin check helper ──────────────────────────────────────────────────────
function requireAdmin(ctx, conn, m) {
  if (!ctx.isAdmin && !ctx.isOwner) {
    newsletterReply(conn, m, '*_۞ 𝙰𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*', ctx.sessionName);
    return false;
  }
  return true;
}

// ─── Antidelete store ─────────────────────────────────────────────────────────
const antideleteStore = new Map();

function storeMsg(sessionName, m) {
  if (!antideleteStore.has(sessionName)) antideleteStore.set(sessionName, new Map());
  const store = antideleteStore.get(sessionName);
  if (m.message && Object.keys(m.message).length > 0) store.set(m.key.id, m);
  if (store.size > 500) store.delete(store.keys().next().value);
}

function getStoredMsg(sessionName, msgId) {
  const store = antideleteStore.get(sessionName);
  return store ? store.get(msgId) : null;
}

// ─── Antilink warnings tracker ────────────────────────────────────────────────
const antilinkWarnings = new Map();

// ─── Sticker command storage ────────────────────────────────────────────────
const STICKCMD_FILE = path.join(__dirname, 'database', 'stickercmds.json');
let stickerCmds = new Map();

// Load existing sticker commands
if (fs.existsSync(STICKCMD_FILE)) {
    try {
        const sc = JSON.parse(fs.readFileSync(STICKCMD_FILE, 'utf-8'));
        stickerCmds = new Map(Object.entries(sc));
        console.log(`[STICKER] Loaded ${stickerCmds.size} sticker commands`);
    } catch (e) {
        console.error('[STICKER] Failed to load:', e.message);
    }
}

function saveStickerCmds() {
    try {
        const dir = path.dirname(STICKCMD_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(STICKCMD_FILE, JSON.stringify(Object.fromEntries(stickerCmds), null, 2));
        console.log(`[STICKER] Saved ${stickerCmds.size} sticker commands`);
    } catch (e) {
        console.error('[STICKER] Failed to save:', e.message);
    }
}

// ─── Download media ───────────────────────────────────────────────────────────
async function downloadMedia(msg, type) {
  const stream = await downloadContentFromMessage(msg, type);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

function getMediaType(msgObj) {
  if (msgObj.imageMessage) return { type: 'image', inner: msgObj.imageMessage };
  if (msgObj.videoMessage) return { type: 'video', inner: msgObj.videoMessage };
  if (msgObj.audioMessage) return { type: 'audio', inner: msgObj.audioMessage };
  if (msgObj.stickerMessage) return { type: 'sticker', inner: msgObj.stickerMessage };
  if (msgObj.documentMessage) return { type: 'document', inner: msgObj.documentMessage };
  return null;
}

// ─── Command registry ──────────────────────────────────────────────────────────
const COMMANDS = {};
function registerCmd(name, category, handler) {
  if (typeof category === 'function') {
    handler = category;
    category = 'utilities';
  }
  COMMANDS[name] = { handler, category };
}

// ─── Font-aware reply (normal commands) ──────────────────────────────────────
async function fReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  await conn.sendMessage(m.key.remoteJid, { text: out }, { quoted: m });
}

// ─── Newsletter reply (menu, uptime, access denied, alive) ────────────────────
async function newsletterReply(conn, m, text, sessionName) {
  const fontNum = getSessionSetting(sessionName, 'font', 1);
  const out = (fontNum && fontNum > 1) ? applyFont(text, fontNum) : text;
  const nl = getNewsletterFooter();
  await conn.sendMessage(m.key.remoteJid, { text: out, ...nl }, { quoted: m });
}

async function plainReply(conn, m, text) {
  await conn.sendMessage(m.key.remoteJid, { text }, { quoted: m });
}

async function fReplyWithFooter(nuell, hex, text, sessionId) {
  await newsletterReply(nuell, hex, text, sessionId);
}

async function successReply(nuell, hex, text, sessionId) {
  const wrapped = text.includes('\n') ? text : `*_${text}_*`;
  await fReply(nuell, hex, wrapped, sessionId);
}

async function successReplyWithFooter(nuell, hex, text, sessionId) {
  const wrapped = text.includes('\n') ? text : `*_${text}_*`;
  await fReplyWithFooter(nuell, hex, wrapped, sessionId);
}

async function errorReply(nuell, hex, text, sessionId) {
  const wrapped = text.includes('\n') ? `۞ ${text}` : `*_۞ ${text}_*`;
  await fReply(nuell, hex, wrapped, sessionId);
}

async function unauthorizedReply(nuell, hex, sessionId) {
  await fReply(nuell, hex, `*_۞ 𝙰𝚌𝚌𝚎𝚜𝚜 𝙳𝚎𝚗𝚒𝚎𝚍_*`, sessionId);
}

async function botAdminRequiredReply(nuell, hex, sessionId) {
  await fReply(nuell, hex, `*_۞ 𝙱𝚘𝚝 𝙼𝚞𝚜𝚝 𝙱𝚎 𝙰𝚗 𝙰𝚍𝚖𝚒𝚗 𝚃𝚘 𝚄𝚜𝚎 𝚃𝚑𝚒𝚜 𝙲𝚘𝚖𝚖𝚊𝚗𝚍_*`, sessionId);
}

async function smartReply(nuell, hex, text, sessionId) {
  if (text.includes('\n')) {
    await nuell.sendMessage(hex.key.remoteJid, { text }, { quoted: hex });
  } else {
    await fReply(nuell, hex, text, sessionId);
  }
}

async function successSmartReply(nuell, hex, text, sessionId) {
  if (text.includes('\n')) {
    await nuell.sendMessage(hex.key.remoteJid, { text }, { quoted: hex });
  } else {
    await successReply(nuell, hex, text, sessionId);
  }
}

async function errorSmartReply(nuell, hex, text, sessionId) {
  if (text.includes('\n')) {
    await nuell.sendMessage(hex.key.remoteJid, { text: `۞ ${text}` }, { quoted: hex });
  } else {
    await errorReply(nuell, hex, text, sessionId);
  }
}

function getQuotedCtx(m) {
  return m.message?.extendedTextMessage?.contextInfo || null;
}
function getQuotedMsg(m) {
  return m.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
}

function getMsgText(m) {
  return (
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    m.message?.documentMessage?.caption ||
    m.message?.buttonsResponseMessage?.selectedButtonId ||
    m.message?.templateButtonReplyMessage?.selectedId ||
    m.message?.listResponseMessage?.singleSelectReply?.selectedRowId ||
    ''
  );
}

function getMentioned(m) {
  return m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
}

function resolveTarget(m, args) {
  const ctx = getQuotedCtx(m);
  if (ctx?.participant) return ctx.participant;
  if (ctx?.remoteJid && !ctx.remoteJid.endsWith('@g.us')) return ctx.remoteJid;
  const mentioned = getMentioned(m);
  if (mentioned.length) return mentioned[0];
  if (args[0]) {
    const num = args[0].replace(/[^0-9]/g, '');
    if (num) return `${num}@s.whatsapp.net`;
  }
  return null;
}

function isStatusMention(message) {
  if (!message) return false;
  
  const msgText = getMsgText({ message });
  
  const statusPatterns = [
    /status.*mention/i,
    /view.*status/i,
    /story.*mention/i,
    /update.*status/i,
    /new status from/i,
    /posted a status/i,
    /status update/i,
    /view my status/i,
    /check my status/i
  ];
  
  for (const pattern of statusPatterns) {
    if (pattern.test(msgText)) return true;
  }
  
  if (message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
    if (msgText.includes('status') || msgText.includes('story')) {
      return true;
    }
  }
  
  if (message.protocolMessage?.type === 25) {
    return true;
  }
  
  return false;
}

const groupProtectionSettings = new Map();
function getGroupSettings(jid) {
  if (!groupProtectionSettings.has(jid)) {
    groupProtectionSettings.set(jid, {
      antidemote: { active: false },
      antipromote: { active: false },
      botprotect: { active: false }
    });
  }
  return groupProtectionSettings.get(jid);
}
function updateGroupSettings(jid, updates) {
  const current = getGroupSettings(jid);
  groupProtectionSettings.set(jid, { ...current, ...updates });
}

function rawNumber(jidOrNumber) {
  if (!jidOrNumber) return '';
  return String(jidOrNumber)
    .split('@')[0]
    .split(':')[0]
    .replace(/\D/g, '');
}

const PLUGINS = new Map();
let totalPluginsCount = 0;

function loadPlugins() {
  const pluginsDir = path.join(__dirname, 'plugins');
  if (!fs.existsSync(pluginsDir)) {
    fs.mkdirSync(pluginsDir);
    return 0;
  }
  
  const pluginFiles = fs.readdirSync(pluginsDir).filter(file => file.endsWith('.js'));
  let pluginCount = 0;
  
  for (const file of pluginFiles) {
    try {
      const plugin = require(path.join(pluginsDir, file));
      
      if (plugin.commands) {
        let cmdCount = 0;
        for (const [cmdName, cmdData] of Object.entries(plugin.commands)) {
          if (!COMMANDS[cmdName]) {
            COMMANDS[cmdName] = {
              handler: cmdData.handler,
              category: cmdData.category || 'plugin'
            };
            cmdCount++;
          }
        }
        
        PLUGINS.set(plugin.name || file.replace('.js', ''), {
          name: plugin.name || file.replace('.js', ''),
          version: plugin.version || '1.0',
          author: plugin.author || 'Unknown',
          commands: cmdCount
        });
        pluginCount++;
        console.log(`🧩 Loaded plugin: ${plugin.name} (${cmdCount} commands)`);
      }
    } catch (err) {
      console.error(`🎴 Failed to load plugin ${file}:`, err.message);
    }
  }
  return pluginCount;
}

async function getCurrentAliveConfig(sessionName) {
    try {
        const configFile = './database/alive_config.json';
        if (fs.existsSync(configFile)) {
            const configs = JSON.parse(fs.readFileSync(configFile, 'utf-8'));
            return configs[sessionName] || { name: 'TOAA', quote: '𝙴𝚟𝚎𝚛𝚢𝚘𝚗𝚎 𝚒𝚜 𝚊 𝚜𝚕𝚊𝚟𝚎 𝚝𝚘 𝚜𝚘𝚖𝚎𝚝𝚑𝚒𝚗𝚐', imageUrl: 'https://i.ibb.co/60pgqPj9/photo-2026-04-29-00-18-01-7633969691903393816.jpg' };
        }
    } catch {}
    return { name: 'TOAA', quote: '𝙴𝚟𝚎𝚛𝚢𝚘𝚗𝚎 𝚒𝚜 𝚊 𝚜𝚕𝚊𝚟𝚎 𝚝𝚘 𝚜𝚘𝚖𝚎𝚝𝚑𝚒𝚗𝚐', imageUrl: 'https://i.ibb.co/60pgqPj9/photo-2026-04-29-00-18-01-7633969691903393816.jpg' };
}

function generateAppealEmail(bannedNumber, userId) {
    const date = new Date().toLocaleString();
    return `WhatsApp Support Team,

I am writing to formally appeal the restriction on my WhatsApp number: +${bannedNumber}

━━━━━━━━━━━━━━━━━━━━━

📋 ACCOUNT INFORMATION:
• Number: +${bannedNumber}
• User ID Reference: ${userId}

━━━━━━━━━━━━━━━━━━━━━━━━
I acknowledge that my account may have violated WhatsApp's terms of service.

So I've done the things below to ensure that i don't go against Whatsapp terms of service again...
1. Immediately ceased all outbound messaging
2. Deleted all contact lists lacking documented consent
3. Implemented double opt-in verification
4. Reviewed WhatsApp Commerce and Business Policies
5. Will use only approved message templates

I respectfully request a review of my account restriction. I am committed to following all WhatsApp Business policies and guidelines strictly.

Thank you for your time and consideration.

Sincerely,
WhatsApp Business User
+${bannedNumber}.`;
}

async function saveAppealRecord(number, userId, emailId, appealText) {
    const APPEAL_FILE = path.join(__dirname, 'database', 'appeals_sent.json');
    let appeals = [];
    if (fs.existsSync(APPEAL_FILE)) {
        try { appeals = JSON.parse(fs.readFileSync(APPEAL_FILE, 'utf-8')); } catch (e) {}
    }
    appeals.push({
        number: number,
        userId: userId,
        emailId: emailId,
        sentAt: Date.now(),
        appealText: appealText.substring(0, 500)
    });
    if (appeals.length > 100) appeals = appeals.slice(-100);
    fs.writeFileSync(APPEAL_FILE, JSON.stringify(appeals, null, 2));
}

const { createCanvas } = require('@napi-rs/canvas');

const _testCanvas = createCanvas(1, 1);
const _testCtx = _testCanvas.getContext('2d');
if (!_testCtx.roundRect) {
  const CanvasRenderingContext2D = Object.getPrototypeOf(_testCtx).constructor;
  CanvasRenderingContext2D.prototype.roundRect = function(x, y, w, h, r) {
    if (w < 2 * r) r = w / 2;
    if (h < 2 * r) r = h / 2;
    this.moveTo(x+r, y);
    this.lineTo(x+w-r, y);
    this.quadraticCurveTo(x+w, y, x+w, y+r);
    this.lineTo(x+w, y+h-r);
    this.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
    this.lineTo(x+r, y+h);
    this.quadraticCurveTo(x, y+h, x, y+h-r);
    this.lineTo(x, y+r);
    this.quadraticCurveTo(x, y, x+r, y);
    return this;
  };
}

const WORD_POOL = ['APPLE','MANGO','GRAPE','LEMON','MELON','PEACH','BERRY','PLUM','TIGER','LION','EAGLE','SHARK','WOLF','BEAR','HORSE','ZEBRA','OCEAN','RIVER','CLOUD','STORM','FLAME','FROST','EARTH','STONE','SWORD','ARROW','CROWN','SHIELD','TOWER','BLADE','CHAIN','VAULT','MUSIC','DANCE','DREAM','LIGHT','NIGHT','STAR','MOON','SOLAR','MONEY','TRADE','CRAFT','BUILD','FORGE','POWER','SPEED','FORCE','BRAIN','NERVE','PULSE','HEART','BLOOD','BONES','FLESH','SOUL','JAPAN','CHINA','GHANA','INDIA','SPAIN','ITALY','KENYA','BRAZIL','ORANGE','PAPAYA','GUAVA','KIWI','LIME','OLIVE','CHERRY','FIG','DATES','COCONUT','PEAR','BANANA','GRAPES','WATERMELON','HONEYDEW','CRANBERRY','RASPBERRY','BLUEBERRY','BLACKBERRY','APRICOT','NECTARINE','POMEGRANATE','LEOPARD','PANTHER','CHEETAH','JAGUAR','COUGAR','LYNX','FOX','COYOTE','JACKAL','HYENA','RHINO','HIPPO','GIRAFFE','CAMEL','DEER','MOOSE','ELK','BISON','ZEBRA','KANGAROO','KOALA','PANDA','MONKEY','GORILLA','CHIMP','BABOON','SLOTH','OTTER','BEAVER','RACCOON','SQUIRREL','RABBIT','HARE','MOLE','MOUSE','RAT','BAT','HAWK','FALCON','OWL','CROW','RAVEN','PARROT','SWAN','DUCK','GOOSE','PIGEON','DOVE','SPARROW','FINCH','PENGUIN','SEAGULL','OCTOPUS','CRAB','LOBSTER','SHRIMP','CLAM','OYSTER','JELLYFISH','SEAL','DOLPHIN','WHALE','ORCA','DESERT','JUNGLE','FOREST','SWAMP','MARSH','TUNDRA','TAIGA','SAVANNAH','MEADOW','VALLEY','HILL','MOUNTAIN','PEAK','VOLCANO','CAVE','CLIFF','CANYON','REEF','ISLAND','BEACH','DUNE','GLACIER','ICE','SNOW','HAIL','RAIN','HURRICANE','TORNADO','CYCLONE','TSUNAMI','AURORA','RAINBOW','DEW','FOG','MIST','BREEZE','GALE','DUST','ASH','LAVA','MAGMA','PEBBLE','BOULDER','QUARTZ','DIAMOND','RUBY','EMERALD','SAPPHIRE','DRAGON','WYRM','GRIFFIN','PHOENIX','UNICORN','PEGASUS','FAIRY','ELF','DWARF','ORC','GOBLIN','TROLL','OGRE','GIANT','CENTAUR','MERMAID','SIREN','MINOTAUR','CYCLOPS','WEREWOLF','VAMPIRE','GHOST','ZOMBIE','SKELETON','DEMON','ANGEL','SPIRIT','WIZARD','SORCERER','WITCH','WARLOCK','MAGE','NECROMANCER','DRUID','BARD','ROGUE','KNIGHT','PALADIN','RANGER','MONK','CLERIC','BARBARIAN','ASSASSIN','ARCHER','GUARDIAN','SENTINEL','BERSERKER','MYSTIC','SEER','ORACLE','PROPHET','SHAMAN','HEALER','SUMMONER','ENCHANTER','ILLUSIONIST','ALCHEMIST'];

const activeWordGrids = new Map();
const GRID_SIZE = 10;
const GAME_DURATION = 10 * 60 * 1000;

const CELL  = 52;
const PAD   = 28;
const WORD_LIST_HEIGHT = 0;

function pickWords() {
  return [...WORD_POOL].sort(() => Math.random() - 0.5).slice(0, 8);
}

function buildGrid(words) {
  const grid = Array.from({ length: GRID_SIZE }, () => Array(GRID_SIZE).fill(''));
  const placed = [];
  const wordPositions = {};
  const directions = [[0,1],[1,0],[1,1],[0,-1],[-1,0],[-1,-1],[1,-1],[-1,1]];

  for (const word of words) {
    let success = false;
    for (let attempt = 0; attempt < 100 && !success; attempt++) {
      const [dr, dc] = directions[Math.floor(Math.random() * directions.length)];
      const row = Math.floor(Math.random() * GRID_SIZE);
      const col = Math.floor(Math.random() * GRID_SIZE);
      const endRow = row + dr * (word.length - 1);
      const endCol = col + dc * (word.length - 1);
      if (endRow < 0 || endRow >= GRID_SIZE || endCol < 0 || endCol >= GRID_SIZE) continue;
      let canPlace = true;
      for (let i = 0; i < word.length; i++) {
        const r = row + dr * i, c = col + dc * i;
        if (grid[r][c] !== '' && grid[r][c] !== word[i]) { canPlace = false; break; }
      }
      if (!canPlace) continue;
      const cells = [];
      for (let i = 0; i < word.length; i++) {
        const r = row + dr * i, c = col + dc * i;
        grid[r][c] = word[i];
        cells.push({ r, c });
      }
      wordPositions[word] = cells;
      placed.push(word);
      success = true;
    }
  }

  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let r = 0; r < GRID_SIZE; r++)
    for (let c = 0; c < GRID_SIZE; c++)
      if (grid[r][c] === '') grid[r][c] = letters[Math.floor(Math.random() * letters.length)];

  return { grid, placed, wordPositions };
}

function renderGridImage(grid, words, foundWords, wordPositions) {
  const canvasW = GRID_SIZE * CELL + PAD * 2;
  const canvasH = GRID_SIZE * CELL + PAD * 2 + WORD_LIST_HEIGHT;

  const canvas = createCanvas(canvasW, canvasH);
  const ctx = canvas.getContext('2d');

  const bg = ctx.createLinearGradient(0, 0, canvasW, canvasH);
  bg.addColorStop(0, '#0f0c29');
  bg.addColorStop(0.5, '#302b63');
  bg.addColorStop(1, '#24243e');
  ctx.fillStyle = bg;
  ctx.roundRect(0, 0, canvasW, canvasH, 18);
  ctx.fill();

  const foundCells = new Set();
  for (const word of foundWords) {
    const cells = wordPositions[word] || [];
    for (const { r, c } of cells) foundCells.add(`${r},${c}`);
  }

  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const x = PAD + c * CELL;
      const y = PAD + r * CELL;
      const isFound = foundCells.has(`${r},${c}`);

      ctx.beginPath();
      ctx.roundRect(x + 3, y + 3, CELL - 6, CELL - 6, 6);
      if (isFound) {
        ctx.fillStyle = 'rgba(100, 220, 130, 0.18)';
      } else {
        ctx.fillStyle = 'rgba(255,255,255,0.06)';
      }
      ctx.fill();

      ctx.strokeStyle = isFound ? 'rgba(100,220,130,0.5)' : 'rgba(255,255,255,0.10)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.font = `bold ${CELL * 0.44}px monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = isFound ? '#64dc82' : '#e8e8ff';
      ctx.fillText(grid[r][c], x + CELL / 2, y + CELL / 2);
    }
  }

  for (const word of foundWords) {
    const cells = wordPositions[word];
    if (!cells || cells.length === 0) continue;
    const first = cells[0], last = cells[cells.length - 1];
    const x1 = PAD + first.c * CELL + CELL / 2;
    const y1 = PAD + first.r * CELL + CELL / 2;
    const x2 = PAD + last.c * CELL + CELL / 2;
    const y2 = PAD + last.r * CELL + CELL / 2;

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.strokeStyle = 'rgba(100, 220, 130, 0.85)';
    ctx.lineWidth = 3.5;
    ctx.lineCap = 'round';
    ctx.stroke();
  }

  return canvas.toBuffer('image/png');
}

async function handleWordGrid(conn, m, senderNumber, pushName) {
  const remoteJid = m.key.remoteJid;
  const game = activeWordGrids.get(remoteJid);
  if (!game) return false;

  const text = getMsgText(m)?.trim().toUpperCase();
  if (!text || text.includes(' ') || text.length < 3) return false;

  if (game.words.includes(text) && !game.foundWords.has(text)) {
    game.foundWords.add(text);
    if (!game.scores[senderNumber]) game.scores[senderNumber] = { points: 0, name: pushName || senderNumber };
    game.scores[senderNumber].points++;
    game.scores[senderNumber].name = pushName || game.scores[senderNumber].name;

    const displayName = pushName || senderNumber;
    const remaining = game.words.filter(w => !game.foundWords.has(w)).length;

    if (game.lastMsgKey) {
      try { await conn.sendMessage(remoteJid, { delete: game.lastMsgKey }); } catch (e) {}
    }

    if (remaining === 0) {
      clearTimeout(game.timer);
      activeWordGrids.delete(remoteJid);
      const scoreList = Object.entries(game.scores)
        .sort((a, b) => b[1].points - a[1].points)
        .map(([n, d], i) => `${i + 1}. ${d.name} (@${n}) — ${d.points} pt${d.points !== 1 ? 's' : ''}`)
        .join('\n');

      const imgBuffer = renderGridImage(game.grid, game.words, game.foundWords, game.wordPositions);
      await conn.sendMessage(remoteJid, {
        image: imgBuffer,
        caption: `🎉 *All words found!* ${displayName} (@${senderNumber}) got the last one!\n\n🏆 *Scores:*\n${scoreList}`,
        mentions: [`${senderNumber}@s.whatsapp.net`, ...Object.keys(game.scores).map(n => `${n}@s.whatsapp.net`)]
      }, { quoted: m });
      return true;
    }

    const hints = game.words
      .filter(w => !game.foundWords.has(w))
      .map(w => `${w[0]}${'_ '.repeat(w.length - 1).trim()}`)
      .join('\n');

    const imgBuffer = renderGridImage(game.grid, game.words, game.foundWords, game.wordPositions);
    const sent = await conn.sendMessage(remoteJid, {
      image: imgBuffer,
      caption: ` *${text}* found by ${displayName} (@${senderNumber})! +1 point\n📊 ${remaining} word${remaining !== 1 ? 's' : ''} remaining\n\n📝 *Hints:*\n${hints}`,
      mentions: [`${senderNumber}@s.whatsapp.net`]
    }, { quoted: m });

    game.lastMsgKey = sent.key;

    return true;
  }

  return false;
}

const activeWCG = new Map();
const WCG_TURN_TIME = 30 * 1000;
const WCG_JOIN_TIME = 30 * 1000;

function getMinLength(round) {
  if (round <= 3) return 3;
  if (round <= 6) return 4;
  if (round <= 10) return 5;
  return 6;
}

function getRandomLetter() {
  const letters = 'ABCDEFGHIJKLMNOPRSTW';
  return letters[Math.floor(Math.random() * letters.length)];
}

function isValidWord(word) {
  return /^[a-zA-Z]+$/.test(word);
}

async function startNextTurnWCG(conn, remoteJid, game) {
  const activePlayers = game.players.filter(p => !game.eliminated.includes(p));
  if (activePlayers.length === 1) return endWCG(conn, remoteJid, game, activePlayers[0]);
  if (activePlayers.length === 0) return endWCG(conn, remoteJid, game, null);

  game.round++;
  game.minLength = getMinLength(game.round);
  game.currentLetter = getRandomLetter();
  game.currentPlayerIndex = (game.currentPlayerIndex + 1) % activePlayers.length;
  const currentPlayer = activePlayers[game.currentPlayerIndex];
  game.currentPlayer = currentPlayer;
  game.awaitingAnswer = true;

  const diffLabel = game.round <= 3 ? '🟢 Easy' : game.round <= 6 ? '🟡 Medium' : game.round <= 10 ? '🟠 Hard' : '🔴 Extreme';

  await conn.sendMessage(remoteJid, {
    text: `🔤 *Round ${game.round}* | ${diffLabel}\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n👤 @${currentPlayer}'s turn!\n\n📌 Letter: *${game.currentLetter}*\n📏 Min length: *${game.minLength} letters*\n⏳ You have 30 seconds!`,
    mentions: [`${currentPlayer}@s.whatsapp.net`]
  });

  game.timer = setTimeout(async () => {
    const g = activeWCG.get(remoteJid);
    if (!g || !g.awaitingAnswer) return;
    g.awaitingAnswer = false;
    g.eliminated.push(currentPlayer);
    const remaining = g.players.filter(p => !g.eliminated.includes(p));
    await conn.sendMessage(remoteJid, {
      text: `⏰ *Time's up!* @${currentPlayer} didn't answer and is *eliminated!*\n👥 ${remaining.length} player${remaining.length !== 1 ? 's' : ''} remaining.`,
      mentions: [`${currentPlayer}@s.whatsapp.net`]
    });
    await startNextTurnWCG(conn, remoteJid, g);
  }, WCG_TURN_TIME);
}

async function handleWCG(conn, m, senderNumber) {
  const remoteJid = m.key.remoteJid;
  const game = activeWCG.get(remoteJid);
  if (!game || !game.started || !game.awaitingAnswer) return false;
  if (game.currentPlayer !== senderNumber) return false;
  if (game.eliminated.includes(senderNumber)) return false;

  const word = getMsgText(m)?.trim().toUpperCase();
  if (!word || word.includes(' ') || !isValidWord(word)) return false;

  if (word[0] !== game.currentLetter) {
    await conn.sendMessage(remoteJid, {
      text: `❌ @${senderNumber} — Word must start with *${game.currentLetter}*! Eliminated!`,
      mentions: [`${senderNumber}@s.whatsapp.net`]
    }, { quoted: m });
    game.awaitingAnswer = false;
    clearTimeout(game.timer);
    game.eliminated.push(senderNumber);
    const remaining = game.players.filter(p => !game.eliminated.includes(p));
    if (remaining.length <= 1) return endWCG(conn, remoteJid, game, remaining[0] || null);
    await startNextTurnWCG(conn, remoteJid, game);
    return true;
  }

  if (word.length < game.minLength) {
    await conn.sendMessage(remoteJid, {
      text: `❌ @${senderNumber} — Word must be at least *${game.minLength} letters* long! Eliminated!`,
      mentions: [`${senderNumber}@s.whatsapp.net`]
    }, { quoted: m });
    game.awaitingAnswer = false;
    clearTimeout(game.timer);
    game.eliminated.push(senderNumber);
    const remaining = game.players.filter(p => !game.eliminated.includes(p));
    if (remaining.length <= 1) return endWCG(conn, remoteJid, game, remaining[0] || null);
    await startNextTurnWCG(conn, remoteJid, game);
    return true;
  }

  if (game.usedWords.has(word)) {
    await conn.sendMessage(remoteJid, {
      text: `❌ @${senderNumber} — *${word}* was already used! Eliminated!`,
      mentions: [`${senderNumber}@s.whatsapp.net`]
    }, { quoted: m });
    game.awaitingAnswer = false;
    clearTimeout(game.timer);
    game.eliminated.push(senderNumber);
    const remaining = game.players.filter(p => !game.eliminated.includes(p));
    if (remaining.length <= 1) return endWCG(conn, remoteJid, game, remaining[0] || null);
    await startNextTurnWCG(conn, remoteJid, game);
    return true;
  }

  clearTimeout(game.timer);
  game.awaitingAnswer = false;
  game.usedWords.add(word);
  game.scores[senderNumber] = (game.scores[senderNumber] || 0) + 1;

  const activePlayers = game.players.filter(p => !game.eliminated.includes(p));
  await conn.sendMessage(remoteJid, {
    text: `✅ *${word}* — Nice one @${senderNumber}! +1 point 🎯\n📊 Score: ${game.scores[senderNumber]} pt${game.scores[senderNumber] !== 1 ? 's' : ''}`,
    mentions: [`${senderNumber}@s.whatsapp.net`]
  }, { quoted: m });

  await startNextTurnWCG(conn, remoteJid, game);
  return true;
}

async function endWCG(conn, remoteJid, game, winner) {
  clearTimeout(game.timer);
  activeWCG.delete(remoteJid);
  const scores = formatScoresWCG(game.scores, game.players);
  const mentions = game.players.map(p => `${p}@s.whatsapp.net`);
  await conn.sendMessage(remoteJid, {
    text: `🏁 *Word Chain Game Over!*\n\n${winner ? `👑 Winner: @${winner}` : '🤝 No winner!'}\n\n🏆 *Final Scores:*\n${scores || 'No points scored.'}`,
    mentions
  });
}

function formatScoresWCG(scores, players) {
  return Object.entries(scores)
    .sort((a, b) => b[1] - a[1])
    .map(([n, p], i) => `${i + 1}. @${n} — ${p} pt${p !== 1 ? 's' : ''}`)
    .join('\n');
}

const bannedUsers = new Set();
const sudoUsers = new Set(listSudo());
const LINK_REGEX = /(https?:\/\/|www\.|chat\.whatsapp\.com\/|t\.me\/)[^\s]*/i;
function containsLink(text) { return LINK_REGEX.test(text || ''); }

async function handleStatus(conn, m, sessionName) {
  const autoView = getSessionSetting(sessionName, 'autoViewStatus', false);
  const autoLike = getSessionSetting(sessionName, 'autoLikeStatus', false);
  if (autoView || autoLike) await conn.readMessages([m.key]);
  if (autoLike) { try { await conn.sendMessage(m.key.remoteJid, { react: { text: '❤️', key: m.key } }); } catch {} }
}

async function handleDelete(conn, update, sessionName) {
  try {
    const snipePlugin = require('./plugins/snipe');
    if (snipePlugin.onMessageDelete) {
      const keys = update?.keys || [];
      for (const key of keys) {
        const stored = getStoredMsg(sessionName, key.id);
        if (stored) await snipePlugin.onMessageDelete(conn, stored, sessionName);
      }
    }
  } catch (e) {}

  const enabled = getSessionSetting(sessionName, 'antidelete', false);
  if (!enabled) return;
  const keys = update?.keys || [];
  for (const key of keys) {
    const stored = getStoredMsg(sessionName, key.id);
    if (!stored) continue;
    const remoteJid = stored.key.remoteJid;
    const sender = normalizeNumber(stored.key.participant || stored.key.remoteJid);
    const msg = stored.message;
    if (!msg) continue;
    const header = `🔒 *Antidelete*\n👤 @${sender}`;
    try {
      if (msg.conversation || msg.extendedTextMessage) {
        await conn.sendMessage(remoteJid, { text: `${header}\n\n${msg.conversation || msg.extendedTextMessage?.text || ''}`, mentions: [`${sender}@s.whatsapp.net`] });
      } else if (msg.imageMessage) { const buf = await downloadMedia(msg.imageMessage, 'image'); await conn.sendMessage(remoteJid, { image: buf, caption: `${header}\n${msg.imageMessage.caption||''}`, mentions: [`${sender}@s.whatsapp.net`] }); }
      else if (msg.videoMessage) { const buf = await downloadMedia(msg.videoMessage, 'video'); await conn.sendMessage(remoteJid, { video: buf, caption: `${header}\n${msg.videoMessage.caption||''}`, mentions: [`${sender}@s.whatsapp.net`] }); }
      else if (msg.audioMessage) { const buf = await downloadMedia(msg.audioMessage, 'audio'); await conn.sendMessage(remoteJid, { audio: buf, mimetype: 'audio/mp4' }); await conn.sendMessage(remoteJid, { text: header, mentions: [`${sender}@s.whatsapp.net`] }); }
      else if (msg.stickerMessage) { const buf = await downloadMedia(msg.stickerMessage, 'sticker'); await conn.sendMessage(remoteJid, { sticker: buf }); await conn.sendMessage(remoteJid, { text: header, mentions: [`${sender}@s.whatsapp.net`] }); }
      else if (msg.documentMessage) { const buf = await downloadMedia(msg.documentMessage, 'document'); await conn.sendMessage(remoteJid, { document: buf, mimetype: msg.documentMessage.mimetype, fileName: msg.documentMessage.fileName }); await conn.sendMessage(remoteJid, { text: header, mentions: [`${sender}@s.whatsapp.net`] }); }
      else await conn.sendMessage(remoteJid, { text: `${header}\n[Unsupported type deleted]`, mentions: [`${sender}@s.whatsapp.net`] });
    } catch (e) { process.stdout.write(`[ANTIDELETE ERR] ${e.message}\n`); }
  }
}

async function handleAntilink(conn, m, sessionName, senderJid, botNumber) {
  const remoteJid = m.key.remoteJid;
  
  const mode = getSessionSetting(sessionName, `antilink_${remoteJid}`, 'off');
  if (mode === 'off') return;

  const text = getMsgText(m);
  if (!containsLink(text)) return;

  const senderNumber = rawNumber(senderJid);

  if (senderNumber === botNumber) return;

  const us = loadUserSettings(sessionName);
  const ownerRaw = rawNumber(us.ownerNumber || '');
  const isOwner = m.key.fromMe || senderNumber === botNumber || senderNumber === ownerRaw;
  if (isOwner) return;

  try {
    const isAdmin = await isGroupAdmin(conn, remoteJid, senderJid);
    if (isAdmin) return;
  } catch (e) {}

  const warnKey = `${sessionName}:${remoteJid}:${senderNumber}`;
  let userWarnings = antilinkWarnings.get(warnKey) || 0;

  if (mode === 'del') {
    await conn.sendMessage(remoteJid, { delete: m.key });
  }
  else if (mode === 'warn') {
    await conn.sendMessage(remoteJid, { delete: m.key });
    await conn.sendMessage(remoteJid, {
      text: `🎴 @${senderNumber} *Links are not allowed!*`,
      mentions: [senderJid]
    });
  }
  else if (mode === 'kick') {
    await conn.sendMessage(remoteJid, { delete: m.key });
    const newWarnings = userWarnings + 1;
    antilinkWarnings.set(warnKey, newWarnings);
    if (newWarnings >= 2) {
      await conn.sendMessage(remoteJid, {
        text: `🀄 @${senderNumber} *Kicked for sending links repeatedly!*`,
        mentions: [senderJid]
      });
      await conn.groupParticipantsUpdate(remoteJid, [senderJid], 'remove');
      antilinkWarnings.delete(warnKey);
    } else {
      await conn.sendMessage(remoteJid, {
        text: `🎴 @${senderNumber} *Links are not allowed!* Warning #${newWarnings}/2 - Next offense = KICK`,
        mentions: [senderJid]
      });
    }
  }
}

async function handleSilence(conn, m, sessionName, senderJid, botNumber) {
  const remoteJid = m.key.remoteJid;
  const senderNumber = rawNumber(senderJid);
  if (senderNumber === botNumber) return false;

  const silenced = getSessionSetting(sessionName, `silence_${remoteJid}`, []);
  if (!silenced.includes(senderNumber)) return false;

  const us = loadUserSettings(sessionName);
  const ownerRaw = rawNumber(us.ownerNumber || '');
  if (senderNumber === ownerRaw) return false;

  try {
    await conn.sendMessage(remoteJid, { delete: m.key });
  } catch (e) {
    process.stdout.write(`[SILENCE ERR] ${e.message}\n`);
  }
  return true;
}

const welcomeSettings = new Map();
const goodbyeSettings = new Map();

const welcomeMessages = new Map();
const goodbyeMessages = new Map();

function getDefaultWelcomeMessage(groupName, userTag) {
  return `Your presence in *${groupName}* ain't unnoticed, @${userTag}\nWelcome to this domain⛓️`;
}

function getDefaultGoodbyeMessage(groupName, userTag) {
  return `Sayonara @${userTag}\n*${groupName}* lives on without you regardless.`;
}

function processCustomMessage(template, groupName, userName, userTag) {
  let msg = template;
  msg = msg.replace(/{group}/g, groupName);
  msg = msg.replace(/{userName}/g, userName);
  msg = msg.replace(/{user}/g, userTag);
  return msg;
}

async function sendWelcomeMessage(conn, groupJid, participantJid, groupName, userName) {
  const enabled = welcomeSettings.get(groupJid);
  if (!enabled) return;
  
  const userTag = participantJid.split('@')[0];
  const customTemplate = welcomeMessages.get(groupJid);
  
  let message;
  if (customTemplate) {
    message = processCustomMessage(customTemplate, groupName, userName || userTag, userTag);
  } else {
    message = getDefaultWelcomeMessage(groupName, userTag);
  }
  
  await conn.sendMessage(groupJid, { 
    text: message, 
    mentions: [participantJid] 
  });
}

async function sendGoodbyeMessage(conn, groupJid, participantJid, groupName, userName) {
  const enabled = goodbyeSettings.get(groupJid);
  if (!enabled) return;
  
  const userTag = participantJid.split('@')[0];
  const customTemplate = goodbyeMessages.get(groupJid);
  
  let message;
  if (customTemplate) {
    message = processCustomMessage(customTemplate, groupName, userName || userTag, userTag);
  } else {
    message = getDefaultGoodbyeMessage(groupName, userTag);
  }
  
  await conn.sendMessage(groupJid, { 
    text: message, 
    mentions: [participantJid] 
  });
}

async function handleMessage(conn, m, sessionName, ownerNumber) {
  try {
    if (!m?.message) return;
    const remoteJid = m.key.remoteJid;

    if (remoteJid === 'status@broadcast') {
      await handleStatus(conn, m, sessionName);
      return;
    }

    if (m.message.ephemeralMessage) m.message = m.message.ephemeralMessage.message;

    storeMsg(sessionName, m);

    const senderJid = m.key.fromMe
      ? conn.user.id
      : (m.key.participant || remoteJid);

    const senderNumber = rawNumber(senderJid);
    const botNumber    = rawNumber(conn.user.id);
    const ownerRaw     = rawNumber(ownerNumber);

    if (bannedUsers.has(senderNumber)) return;

    if (remoteJid.endsWith('@g.us')) {
  const silenced = await handleSilence(conn, m, sessionName, senderJid, botNumber);
  if (silenced) return;

  await handleAntilink(conn, m, sessionName, senderJid, botNumber);

  try {
    const badwords = require('./helper/badwords');
    const hit = await badwords.handleAntibadword(conn, m, remoteJid, senderJid);
    if (hit) return;
  } catch (e) {
    console.log('[ANTIBADWORD] hook error:', e.message);
  }
  
  const antigcmMode = antigcmSettings.get(remoteJid);
  if (antigcmMode && antigcmMode !== false) {
    try {
      const rawMsgType = m.message ? Object.keys(m.message)[0] : '';
      const isGroupMentionMsg = ['messageContextInfo', 'groupStatusMentionMessage'].includes(rawMsgType);
      
      if (isGroupMentionMsg) {
        console.log(`[ANTIGCM] Detected group mention from ${senderNumber}`);
        
        try {
          await conn.sendMessage(remoteJid, { delete: m.key });
          console.log(`[ANTIGCM] Deleted message from ${senderNumber}`);
        } catch (deleteErr) {
          console.log(`[ANTIGCM] Failed to delete: ${deleteErr.message}`);
        }
        
        const warnKey = `${remoteJid}:${senderNumber}`;
        
        if (antigcmMode === 'warn') {
          const warnCount = (antigcmWarnings.get(warnKey) || 0) + 1;
          antigcmWarnings.set(warnKey, warnCount);
          
          if (warnCount >= MAX_ANTIGCM_WARNS) {
            antigcmWarnings.delete(warnKey);
            try {
              await conn.groupParticipantsUpdate(remoteJid, [senderJid], 'remove');
              await conn.sendMessage(remoteJid, {
                text: `🔨 @${senderNumber} has been removed after ${MAX_ANTIGCM_WARNS} warnings for tagging the group from status!`,
                mentions: [senderJid]
              });
            } catch (kickErr) {
              console.log(`[ANTIGCM] Failed to kick: ${kickErr.message}`);
            }
          } else {
            await conn.sendMessage(remoteJid, {
              text: `⚠️ @${senderNumber} Warning ${warnCount}/${MAX_ANTIGCM_WARNS} — Do not tag this group from your status!`,
              mentions: [senderJid]
            });
          }
        } 
        else if (antigcmMode === 'kick') {
          const warnCount = (antigcmWarnings.get(warnKey) || 0) + 1;
          antigcmWarnings.set(warnKey, warnCount);
          
          if (warnCount >= MAX_ANTIGCM_WARNS) {
            antigcmWarnings.delete(warnKey);
            try {
              await conn.groupParticipantsUpdate(remoteJid, [senderJid], 'remove');
              await conn.sendMessage(remoteJid, {
                text: `🔨 @${senderNumber} has been kicked for tagging the group from status!`,
                mentions: [senderJid]
              });
            } catch (kickErr) {
              console.log(`[ANTIGCM] Failed to kick: ${kickErr.message}`);
            }
          } else {
            await conn.sendMessage(remoteJid, {
              text: `⚠️ @${senderNumber} Warning ${warnCount}/${MAX_ANTIGCM_WARNS} — Do not tag this group from your status! Next offense = KICK`,
              mentions: [senderJid]
            });
          }
        }
        else if (antigcmMode === true || antigcmMode === 'delete') {
          await conn.sendMessage(remoteJid, {
            text: `🚫 @${senderNumber} Do not tag this group from your status!`,
            mentions: [senderJid]
          });
        }
        
        return;
      }
    } catch (err) {
      console.log(`[ANTIGCM] Error: ${err.message}`);
    }
  }
}

    const userSettings = loadUserSettings(sessionName);
    const prefix = userSettings.prefix || settings.DEFAULT_PREFIX;
    const mode   = userSettings.mode   || 'public';

    const msgContent = getMsgText(m);

    let isCmd = false;
    let command = '';
    let args = [];
    let text = '';

    const incomingSticker = m.message?.stickerMessage;
    if (incomingSticker && stickerCmds.size > 0) {
      try {
        let stickerHash = null;
        
        if (incomingSticker.fileSha256) {
          stickerHash = Buffer.from(incomingSticker.fileSha256).toString('hex').slice(0, 16);
        } else if (incomingSticker.fileEncSha256) {
          stickerHash = Buffer.from(incomingSticker.fileEncSha256).toString('hex').slice(0, 16);
        } else {
          const stickerBuf = await downloadMedia(incomingSticker, 'sticker');
          stickerHash = crypto.createHash('sha256').update(stickerBuf).digest('hex').slice(0, 16);
        }
        
        if (stickerCmds.has(stickerHash)) {
          const stkCmd = stickerCmds.get(stickerHash);
          command = stkCmd.cmd;
          isCmd = true;
          args = [];
          text = '';
          console.log(`[STICKER] Triggered command: ${command} from sticker hash: ${stickerHash}`);
        }
      } catch (e) {
        console.log('[STICKER] Error processing sticker:', e.message);
      }
    }

    if (!isCmd && msgContent.startsWith(prefix)) {
      const body = msgContent.slice(prefix.length).trim();
      const [commandRaw, ...cmdArgs] = body.split(' ');
      command = commandRaw.toLowerCase();
      isCmd = true;
      args = cmdArgs;
      text = cmdArgs.join(' ');
    }

if (!isCmd) {
  await handleWCG(conn, m, senderNumber);
  await handleWordGrid(conn, m, senderNumber, m.pushName);
  await handleQuizAnswer(conn, m, senderNumber);
  await handleBattle(conn, m, senderNumber);

  try {
    const econ = require('./helper/economy');
    const handled = await econ.handlePendingReplies(conn, m, senderNumber, remoteJid);
    if (handled) return;
  } catch (e) {
    console.log('[ECONOMY] pending-reply hook error:', e.message);
  }

  // ─── AUTO REACT ──────────────────────────────────────────────────────────
  try {
    const autoReactEnabled = getSessionSetting(sessionName, 'autoReact', false);
    if (autoReactEnabled && msgContent) {
      const reactions = ['👍', '❤️', '🔥', '😁', '🤣', '😎', '✨', '💯', '👀', '😊', '🥰', '🎉'];
      const pick = reactions[Math.floor(Math.random() * reactions.length)];
      await conn.sendMessage(remoteJid, { react: { text: pick, key: m.key } });
    }
  } catch (e) {
    // Silent fail
  }

  // ─── TOAA AI DETECTION ──────────────────────────────────────────────────────
  if (msgContent) {
    try {
      const toaaPlugin = require('./plugins/toaa');
      const mentionsToaa = /\btoaa\b/i.test(msgContent);
      
      // ─── CHECK IF THIS IS A GROUP OR DM ──────────────────────────────────
      const isGroup = remoteJid.endsWith('@g.us');
      
      // ─── CHECK IF THIS IS A REPLY TO THE BOT ─────────────────────────────
      const replyParticipant = m.message?.extendedTextMessage?.contextInfo?.participant;
      const hasQuoted = !!m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const botLid = rawNumber(conn.user.lid || '');
      const isReplyToBot = replyParticipant
        ? (rawNumber(replyParticipant) === botNumber || (botLid && rawNumber(replyParticipant) === botLid))
        : (hasQuoted && !remoteJid.endsWith('@g.us'));

      // ─── CHECK IF THERE'S AN ACTIVE CONVERSATION ──────────────────────────
      let hasActiveConv = false;
      if (typeof toaaPlugin.hasActiveConversation === 'function') {
        hasActiveConv = toaaPlugin.hasActiveConversation(sessionName, remoteJid);
      }

      // ─── OWNERSHIP CHECK (moved up — trigger logic needs this) ────────────
      const storedOwnerToaa = rawNumber(userSettings.ownerNumber || '');
      const isSudoToaa = sudoUsers.has(senderNumber);
      const isOwnerToaa = !!(
        m.key.fromMe ||
        senderNumber === botNumber ||
        senderNumber === ownerRaw ||
        (storedOwnerToaa && senderNumber === storedOwnerToaa) ||
        isSudoToaa
      );

      // ─── TRIGGER LOGIC ──────────────────────────────────────────────────────
      // Owner (in DMs AND groups): say "toaa" once, then can keep replying to
      // Toaa's messages without repeating it — conversation continues.
      // Everyone else (in DMs AND groups): must say "toaa" every single
      // message, no continuation, ever.
      let shouldTrigger = false;

      if (isOwnerToaa) {
        const continuingReply = !mentionsToaa && isReplyToBot && hasActiveConv;
        shouldTrigger = mentionsToaa || continuingReply;
      } else {
        shouldTrigger = mentionsToaa;
      }

      if (shouldTrigger && typeof toaaPlugin.onMention === 'function') {
        const isUserPremiumToaa = isPremium(senderNumber);
        let isAdminToaa = false;
        if (remoteJid.endsWith('@g.us')) isAdminToaa = await isGroupAdmin(conn, remoteJid, senderJid);

        // Detect whether this message is a reply to media (image/video/
        // audio/sticker/document), so Toaa's persona knows the media is
        // already present and shouldn't ask the user to attach/provide it.
        const quotedForToaa = getQuotedMsg(m);
        const hasQuotedMediaToaa = !!(quotedForToaa && getMediaType(quotedForToaa));

        const toaaCtx = {
          prefix, sessionName, senderNumber, botNumber,
          isOwner: isOwnerToaa, isUserPremium: isUserPremiumToaa, isAdmin: isAdminToaa,
          args: [], command: 'toaa', senderJid, hasQuotedMedia: hasQuotedMediaToaa
        };
        
        await toaaPlugin.onMention(conn, m, msgContent, toaaCtx);
      }
    } catch (e) {
      console.error('[TOAA-AI] mention hook error:', e.message);
    }
  }

  // ─── AUTO TYPE & AUTO RECORD ─────────────────────────────────────────────
  try {
    const autoType = getSessionSetting(sessionName, 'autoType', false);
    const autoRecord = getSessionSetting(sessionName, 'autoRecord', false);

    if (!m.key.fromMe && msgContent) {
      if (autoType) {
        const typingDuration = 2000 + Math.floor(Math.random() * 3000);
        await conn.sendPresenceUpdate('composing', remoteJid);
        
        if (autoRecord) {
          setTimeout(async () => {
            try {
              await conn.sendPresenceUpdate('recording', remoteJid);
            } catch (e) {}
          }, typingDuration);
        }
        
        setTimeout(async () => {
          try {
            await conn.sendPresenceUpdate('paused', remoteJid);
          } catch (e) {}
        }, typingDuration + 2000);
      } else if (autoRecord) {
        const recordingDuration = 3000 + Math.floor(Math.random() * 4000);
        await conn.sendPresenceUpdate('recording', remoteJid);
        
        setTimeout(async () => {
          try {
            await conn.sendPresenceUpdate('paused', remoteJid);
          } catch (e) {}
        }, recordingDuration);
      }
    }
  } catch (e) {
    // Silent fail
  }

  return;
}

    const storedOwner = rawNumber(userSettings.ownerNumber || '');
    const isSudo      = sudoUsers.has(senderNumber);

    const isOwner = !!(
      m.key.fromMe ||
      senderNumber === botNumber ||
      senderNumber === ownerRaw ||
      (storedOwner && senderNumber === storedOwner) ||
      isSudo
    );

    const isUserPremium = isPremium(senderNumber);
    let isAdmin = false;
    let botAdmin = false;
    if (remoteJid.endsWith('@g.us')) {
      const admins = await checkGroupAdmins(conn, remoteJid, senderJid);
      isAdmin = admins.isAdmin;
      botAdmin = admins.isBotAdmin;
    }

    if (mode === 'self' && !isOwner && !isSudo) return;

if (remoteJid.endsWith('@g.us') && !isOwner) {
      try {
        const banchatPlugin = require('./plugins/banchat');
        if (banchatPlugin.isChatBanned && banchatPlugin.isChatBanned(remoteJid)) return;
      } catch (e) { console.error('[BANCHAT] hook error:', e.message); }
    }

    const ctx = { prefix, sessionName, senderNumber, botNumber, isOwner, isUserPremium, isAdmin, botAdmin, args, command, senderJid };

        try { const lbPlugin = require('./plugins/lb'); if (lbPlugin.onMessage) await lbPlugin.onMessage(conn, m, senderNumber); } catch (e) {}
    try { const spyPlugin = require('./plugins/spy'); if (spyPlugin.onMessage) await spyPlugin.onMessage(conn, m, sessionName, senderNumber, remoteJid); } catch (e) {}
    try { const duelPlugin = require('./plugins/duel'); if (duelPlugin.onMessage) await duelPlugin.onMessage(conn, m, sessionName, senderNumber); } catch (e) {}
    
try {
  if (remoteJid.endsWith('@g.us')) {
    const { recordActivity } = require('./helper/activityTracker');
    recordActivity(remoteJid, senderJid);
  }
} catch (e) { console.error('[ACTIVITY] hook error:', e.message); }

try {
      if (remoteJid.endsWith('@g.us')) {
        const antibotPlugin = require('./plugins/antibot');
        if (antibotPlugin.detectBot) {
          const handled = await antibotPlugin.detectBot(conn, m, sessionName, senderJid, botNumber);
          if (handled) return;
        }
      }
    } catch (e) { console.error('[ANTIBOT] hook error:', e.message); }
    try {
      if (remoteJid.endsWith('@g.us')) {
        const antidocPlugin = require('./plugins/antidocument');
        if (antidocPlugin.checkAntidocument) {
          const handled = await antidocPlugin.checkAntidocument(conn, m, sessionName, senderJid, isAdmin, isOwner);
          if (handled) return;
        }
      }
    } catch (e) { console.error('[ANTIDOCUMENT] hook error:', e.message); }
    try {
      if (remoteJid.endsWith('@g.us')) {
        const antimediaPlugin = require('./plugins/antimedia');
        if (antimediaPlugin.checkAntimedia) {
          const handled = await antimediaPlugin.checkAntimedia(conn, m, sessionName, senderJid, isAdmin, isOwner);
          if (handled) return;
        }
      }
    } catch (e) { console.error('[ANTIMEDIA] hook error:', e.message); }

    if (COMMANDS[command]) await COMMANDS[command].handler(conn, m, args, ctx);
  } catch (err) {
    process.stdout.write(`[CASE ERROR] ${err.message}\n`);
  }
}

const hangmanGames = new Map();

// ─── XTAG / NAME TAG PROTECTION ───────────────────────────────────────────────
const xTagSettings = new Map();

const X_TAG_FILE = path.join(__dirname, 'database', 'xtag.json');
const X_TAG_CHECK_INTERVAL = 2 * 60 * 60 * 1000; // 2 hours
const X_TAG_KICK_DELAY = 30 * 60 * 1000;          // 30 minutes

// Group interval timers
const xTagTimers = new Map();

// Individual warning/kick timers
const xTagKickTimers = new Map();


// ─── Load saved XTAG settings ─────────────────────────────────────────────────
if (fs.existsSync(X_TAG_FILE)) {
  try {
    const saved = JSON.parse(fs.readFileSync(X_TAG_FILE, 'utf-8'));

    for (const [jid, data] of Object.entries(saved)) {
      xTagSettings.set(jid, {
        active: Boolean(data.active),
        symbol: data.symbol || '𖢖',
        warned: new Map(
          Object.entries(data.warned || {}).map(([num, time]) => [
            num,
            Number(time)
          ])
        )
      });
    }

    console.log(`[XTAG] Loaded ${xTagSettings.size} group settings`);
  } catch (e) {
    console.error('[XTAG] Failed to load:', e.message);
  }
}


// ─── Save XTAG settings ──────────────────────────────────────────────────────
function saveXTagSettings() {
  try {
    const dir = path.dirname(X_TAG_FILE);

    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const obj = {};

    for (const [jid, data] of xTagSettings.entries()) {
      obj[jid] = {
        active: data.active,
        symbol: data.symbol || '𖢖',
        warned: Object.fromEntries(data.warned || [])
      };
    }

    fs.writeFileSync(
      X_TAG_FILE,
      JSON.stringify(obj, null, 2)
    );
  } catch (e) {
    console.error('[XTAG] Failed to save:', e.message);
  }
}


// ─── Get participant display name ─────────────────────────────────────────────
function getXTagDisplayName(conn, participantJid) {
  try {
    const contact = conn.store?.contacts?.[participantJid];

    return (
      contact?.notify ||
      contact?.name ||
      contact?.verifiedName ||
      ''
    );
  } catch {
    return '';
  }
}


// ─── Check whether user has the required XTAG symbol ─────────────────────────
function hasXTagSymbol(conn, participantJid, symbol) {
  const displayName = getXTagDisplayName(conn, participantJid);

  return Boolean(
    displayName &&
    symbol &&
    displayName.includes(symbol)
  );
}


// ─── Clear individual XTAG warning timer ──────────────────────────────────────
function clearXTagKickTimer(groupJid, participantNumber) {
  const key = `${groupJid}:${participantNumber}`;
  const timer = xTagKickTimers.get(key);

  if (timer) {
    clearTimeout(timer);
    xTagKickTimers.delete(key);
  }
}


// ─── Schedule XTAG kick ───────────────────────────────────────────────────────
function scheduleXTagKick(conn, groupJid, participantJid, participantNumber) {
  const key = `${groupJid}:${participantNumber}`;

  // Prevent duplicate timers
  clearXTagKickTimer(groupJid, participantNumber);

  const timer = setTimeout(async () => {
    xTagKickTimers.delete(key);

    const current = xTagSettings.get(groupJid);

    if (!current || !current.active) {
      return;
    }

    if (!current.warned.has(participantNumber)) {
      return;
    }

    const symbol = current.symbol || '𖢖';

    try {
      // Get fresh group metadata
      const meta = await conn.groupMetadata(groupJid);

      const participant = meta.participants.find(
        p => rawNumber(p.id) === participantNumber
      );

      // User has already left / was removed
      if (!participant) {
        current.warned.delete(participantNumber);
        saveXTagSettings();
        return;
      }

      const actualJid = participant.id;

      // ─────────────────────────────────────────────────────────────
      // IMPORTANT:
      // Check the CURRENT display name again before kicking.
      // If they added the symbol, remove the warning and do NOT kick.
      // ─────────────────────────────────────────────────────────────
      if (hasXTagSymbol(conn, actualJid, symbol)) {
        current.warned.delete(participantNumber);
        saveXTagSettings();

        console.log(
          `[XTAG] ${participantNumber} complied with the name requirement in ${groupJid}`
        );

        return;
      }

      // Still doesn't have the symbol → kick
      await conn.groupParticipantsUpdate(
        groupJid,
        [actualJid],
        'remove'
      );

      await conn.sendMessage(groupJid, {
        text:
          `🔨 @${participantNumber} was kicked for not adding ` +
          `*${symbol}* to their name within 30 minutes.`,
        mentions: [actualJid]
      });

      current.warned.delete(participantNumber);
      saveXTagSettings();

      console.log(
        `[XTAG] Kicked ${participantNumber} from ${groupJid}`
      );

    } catch (e) {
      console.error(
        `[XTAG] Delayed kick failed for ${participantNumber}:`,
        e.message
      );
    }
  }, X_TAG_KICK_DELAY);

  xTagKickTimers.set(key, timer);
}


// ─── Run XTAG check ───────────────────────────────────────────────────────────
async function runXTagCheck(conn, groupJid, sessionName) {
  const settings_xt = xTagSettings.get(groupJid);

  if (!settings_xt || !settings_xt.active) {
    return;
  }

  const symbol = settings_xt.symbol || '𖢖';

  let meta;

  try {
    meta = await conn.groupMetadata(groupJid);
  } catch (e) {
    console.error(
      `[XTAG] Failed to get metadata for ${groupJid}:`,
      e.message
    );
    return;
  }

  const botNum = rawNumber(conn.user.id);

  for (const participant of meta.participants) {
    const pJid = participant.id;
    const pNum = rawNumber(pJid);

    // Never process the bot
    if (!pNum || pNum === botNum) {
      continue;
    }

    // Never process admins
    if (
      participant.admin === 'admin' ||
      participant.admin === 'superadmin'
    ) {
      continue;
    }

    // ─────────────────────────────────────────────────────────────
    // FIRST: If this user was previously warned, check whether
    // they have already complied.
    // ─────────────────────────────────────────────────────────────
    if (settings_xt.warned.has(pNum)) {
      if (hasXTagSymbol(conn, pJid, symbol)) {
        settings_xt.warned.delete(pNum);
        clearXTagKickTimer(groupJid, pNum);
        saveXTagSettings();

        console.log(
          `[XTAG] ${pNum} added ${symbol} and cleared their warning`
        );
      }

      // Whether compliant or not, don't issue another warning here.
      continue;
    }

    // ─────────────────────────────────────────────────────────────
    // Check current display name
    // ─────────────────────────────────────────────────────────────
    const displayName = getXTagDisplayName(conn, pJid);

    // Already has required symbol
    if (displayName.includes(symbol)) {
      continue;
    }

    // ─────────────────────────────────────────────────────────────
    // User doesn't have symbol → warn them
    // ─────────────────────────────────────────────────────────────
    const warnedAt = Date.now();

    settings_xt.warned.set(pNum, warnedAt);
    saveXTagSettings();

    try {
      await conn.sendMessage(groupJid, {
        text:
          `⚠️ @${pNum} — Your display name must include *${symbol}*!\n\n` +
          `Please add it within *30 minutes* or you will be kicked.`,
        mentions: [pJid]
      });

      console.log(
        `[XTAG] Warned ${pNum} in ${groupJid}`
      );
    } catch (e) {
      console.error(
        `[XTAG] Failed to warn ${pNum}:`,
        e.message
      );

      // Don't leave a warning behind if the warning message failed
      settings_xt.warned.delete(pNum);
      saveXTagSettings();

      continue;
    }

    // Start exactly one 30-minute timer
    scheduleXTagKick(
      conn,
      groupJid,
      pJid,
      pNum
    );
  }
}


// ─── Start XTAG interval ──────────────────────────────────────────────────────
function startXTagInterval(conn, groupJid, sessionName) {
  if (xTagTimers.has(groupJid)) {
    return;
  }

  // Run immediately when enabled
  runXTagCheck(conn, groupJid, sessionName).catch(err => {
    console.error(
      `[XTAG] Initial check failed for ${groupJid}:`,
      err.message
    );
  });

  const id = setInterval(() => {
    runXTagCheck(conn, groupJid, sessionName).catch(err => {
      console.error(
        `[XTAG] Interval check failed for ${groupJid}:`,
        err.message
      );
    });
  }, X_TAG_CHECK_INTERVAL);

  xTagTimers.set(groupJid, id);

  console.log(
    `[XTAG] Interval started for ${groupJid}`
  );
}


// ─── Stop XTAG interval ──────────────────────────────────────────────────────
function stopXTagInterval(groupJid) {
  const id = xTagTimers.get(groupJid);

  if (id) {
    clearInterval(id);
    xTagTimers.delete(groupJid);

    console.log(
      `[XTAG] Interval stopped for ${groupJid}`
    );
  }

  // Clear all individual kick timers belonging to this group
  for (const [key, timer] of xTagKickTimers.entries()) {
    if (key.startsWith(`${groupJid}:`)) {
      clearTimeout(timer);
      xTagKickTimers.delete(key);
    }
  }

  // Keep saved settings, but don't leave stale warnings
  const current = xTagSettings.get(groupJid);

  if (current) {
    current.warned.clear();
    saveXTagSettings();
  }
}

initEmailTransporter();

module.exports = {
  ANTIGCM_FILE,
  CELL,
  COMMANDS,
  GAME_DURATION,
  GRID_SIZE,
  LINK_REGEX,
  MAX_ANTIGCM_WARNS,
  PAD,
  PLUGINS,
  STICKCMD_FILE,
  WCG_JOIN_TIME,
  WCG_TURN_TIME,
  WORD_LIST_HEIGHT,
  WORD_POOL,
  _testCanvas,
  _testCtx,
  activeWCG,
  activeWordGrids,
  antideleteStore,
  antigcmSettings,
  antigcmWarnings,
  antilinkWarnings,
  bannedUsers,
  buildGrid,
  containsLink,
  downloadMedia,
  emailTransporter,
  endWCG,
  fReply,
  formatScoresWCG,
  generateAppealEmail,
  getCurrentAliveConfig,
  getDefaultGoodbyeMessage,
  getDefaultWelcomeMessage,
  getFooterReply,
  getGroupSettings,
  getMediaType,
  getMentioned,
  getMinLength,
  getMsgText,
  getNewsletterFooter,
  getQuotedCtx,
  getQuotedMsg,
  getRandomLetter,
  getStoredMsg,
  goodbyeMessages,
  goodbyeSettings,
  groupProtectionSettings,
  handleAntilink,
  handleSilence,
  handleDelete,
  handleMessage,
  handleStatus,
  handleWCG,
  handleWordGrid,
  initEmailTransporter,
  isStatusMention,
  isValidWord,
  loadPlugins,
  newsletterReply,
  pickWords,
  plainReply,
  processCustomMessage,
  rawNumber,
  registerCmd,
  renderGridImage,
  requireAdmin,
  resolveTarget,
  runXTagCheck,
  saveAntigcmSettings,
  saveAppealRecord,
  saveStickerCmds,
  saveXTagSettings,
  sendGoodbyeMessage,
  sendWelcomeMessage,
  startNextTurnWCG,
  stickerCmds,
  storeMsg,
  sudoUsers,
  updateGroupSettings,
  welcomeMessages,
  welcomeSettings,
  xTagSettings,
  isPremium,
  addPremium,
  delPremium,
  loadUserSettings,
  saveUserSettings,
  getSessionSetting,
  setSessionSetting,
  isGroupAdmin,
  normalizeNumber,
  cleanJidNumber,
  fromJid,
  formatUptime,
  measureSpeed,
  handleBattle,
  handleQuizAnswer,
  applyFont,
  FONT_COUNT,
  downloadContentFromMessage,
  proto,
  generateWAMessageFromContent,
  generateWAMessage,
  prepareWAMessageMedia,
  jidNormalizedUser,
  hangmanGames,
  X_TAG_FILE,
  X_TAG_CHECK_INTERVAL,
  X_TAG_KICK_DELAY,
  xTagTimers,
  startXTagInterval,
  stopXTagInterval,
  fReplyWithFooter,
  successReply,
  successReplyWithFooter,
  errorReply,
  unauthorizedReply,
  botAdminRequiredReply,
  smartReply,
  successSmartReply,
  errorSmartReply,
  isBotAdmin,
  checkGroupAdmins,
  getGroupAdmins,
  isSessionOwner,
  getRawId,
  resolveDisplayJid,
  addSudo,
  delSudo
};

totalPluginsCount = loadPlugins();
module.exports.totalPluginsCount = totalPluginsCount;
