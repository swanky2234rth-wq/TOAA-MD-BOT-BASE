/*
═══════════════════════════════════════════════════╗
〚  𝙱𝙾𝚃•   ₊ ⃝₊TOAA
〚  𝙳𝙴𝚅•   ₊ ⃝—͟͟͞͞swanky
〚  𝙵𝙸𝙻𝙴•  index.js — Bootstrap only
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
*/

//── Console logging ─────────────────────────────────────────────────

const settings = require('./settings');

global.botStartTime = global.botStartTime || Date.now();

const { CHANNEL, loadVerifiedUsers, bot } = require('./telegram');
const {
  reloadExistingSessions, activeSessions, QUEUE_CONCURRENCY,
  getCachedSessionSetting, setCachedSessionSetting, getGroupMeta, invalidateGroupCache,
} = require('./sessions');

global.getCachedSessionSetting = getCachedSessionSetting;
global.setCachedSessionSetting = setCachedSessionSetting;
global.getGroupMeta            = getGroupMeta;
global.invalidateGroupCache    = invalidateGroupCache;

// ─── Colors ────────────────────────────────────────────────────────────────

const C = {
  reset:  '\x1b[0m',
  purple: '\x1b[35m',
  blue:   '\x1b[34m',
  cyan:   '\x1b[36m',
  red:    '\x1b[31m',
};

const originalLog = console.log.bind(console);

// ─── Console Banner ──────────────────────────────────────────────────────────

function printBanner() {
  originalLog('');
  originalLog('╔━━━━━━━━━━━━━━━━✴━━━━━━━━━━━━━━━━━╗');
  originalLog('              TOAA                ');
  originalLog('       𝙱𝚘𝚝 𝙸𝚗𝚒𝚝𝚒𝚊𝚕𝚒𝚣𝚒𝚗𝚐....      ');
  originalLog('╚━━━━━━━━━━━━━━━━✴━━━━━━━━━━━━━━━━━╝');
  originalLog('');
}

// ─── Activity Logger — intercepts tagged lines from logIncoming() ──────────

const B = C.blue;
const R = C.red;
const X = C.reset;

const _origLog = console.log;
console.log = (...args) => {
  const text = args.join(' ');

  if (text.includes('【 CHANNEL 】')) {
    const [, rest] = text.split('【 CHANNEL 】');
    const [name, message, time] = rest.trim().split('||');
    _origLog(
      `\n${B}╔━━━━━━━﹝${R}𝐂𝐇𝐀𝐍𝐍𝐄𝐋${B}﹞━━━━━━╗${X}\n` +
      `${B}│${R}𝙲𝙷𝙰𝙽𝙽𝙴𝙻${B}⥱ ${X}${name?.trim()}\n` +
      `${B}│${R}𝚄𝙿𝙳𝙰𝚃𝙴${B} ⥱ ${X}${message?.trim()}\n` +
      `${B}│${R}𝚃𝙸𝙼𝙴${B}⥱ ${X}${time?.trim()}\n` +
      `${B}╚━━━━━━━━━━${R}Hɘxx${B}━━━━━━━━━━╝${X}`
    );
    return;
  }

  if (text.includes('【 GROUP 】')) {
    const [, rest] = text.split('【 GROUP 】');
    const [name, sender, message, time, admin] = rest.trim().split('||');
    _origLog(
      `\n${B}╔━━━━━━━﹝${R}𝐆𝐑𝐎𝐔𝐏 𝐂𝐇𝐀𝐓${B}﹞━━━━━━━╗${X}\n` +
      `${B}│${R}𝙽𝙰𝙼𝙴${B}⥱ ${X}${name?.trim()}\n` +
      `${B}│${R}𝚂𝙴𝙽𝙳𝙴𝚁${B} ⥱ ${X}${sender?.trim()}\n` +
      `${B}│${R}𝙼𝙴𝚂𝚂𝙰𝙶𝙴${B} ⥱ ${X}${message?.trim()}\n` +
      `${B}│${R}𝚃𝙸𝙼𝙴${B} ⥱ ${X}${time?.trim()}\n` +
      `${B}│${R}𝙰𝙳𝙼𝙸𝙽¿${B} ⥱ ${X}${admin?.trim()}\n` +
      `${B}╚━━━━━━━━━━━━${R}Hɘxx${B}━━━━━━━━━━━━╝${X}`
    );
    return;
  }

  if (text.includes('【 PRIVATE 】')) {
    const [, rest] = text.split('【 PRIVATE 】');
    const [name, message, time] = rest.trim().split('||');
    _origLog(
      `\n${B}╔━━━━━━━﹝${R}𝐏𝐑𝐈𝐕𝐀𝐓𝐄 𝐂𝐇𝐀𝐓${B}﹞━━━━━━╗${X}\n` +
      `${B}│${R}𝙽𝙰𝙼𝙴${B}⥱ ${X}${name?.trim()}\n` +
      `${B}│${R}𝙼𝙴𝚂𝚂𝙰𝙶𝙴${B} ⥱ ${X}${message?.trim()}\n` +
      `${B}│${R}𝚃𝙸𝙼𝙴${B} ⥱ ${X}${time?.trim()}\n` +
      `${B}╚━━━━━━━━━━━━${R}Hɘxx${B}━━━━━━━━━━━━╝${X}`
    );
    return;
  }

  _origLog(...args);
};

process.on('uncaughtException',  e => console.log(`[UNCAUGHT] ${e.message}`));
process.on('unhandledRejection', e => console.log(`\n  【 UNHANDLED REJECTION 】 ${e?.message || e}`));

// ─── Startup Sequence ─────────────────────────────────────────────────────────

async function start() {
  printBanner();

  try {
    await bot.deleteWebHook({ drop_pending_updates: true });
  } catch (_) {}

  bot.on('polling_error', (err) => {
    originalLog('  【 TG ERROR 】' + err.message);
  });

  await new Promise(resolve => setTimeout(resolve, 1500));

  await reloadExistingSessions();

  if (activeSessions.size > 0) {
    originalLog('  ☆ Active sessions:');
    for (const [sessionName, data] of activeSessions) {
      originalLog(`    - ${data.ownerNumber} (User: ${data.telegramChatId})`);
    }
  }

  process.stdout.write(
    `\n${C.red}███╗   ██╗██╗   ██╗███████╗██╗     ██╗     ${C.reset}\n` +
    `${C.red}████╗  ██║██║   ██║██╔════╝██║     ██║     ${C.reset}\n` +
    `${C.red}██╔██╗ ██║██║   ██║█████╗  ██║     ██║     ${C.reset}\n` +
    `${C.red}██║╚██╗██║██║   ██║██╔══╝  ██║     ██║     ${C.reset}\n` +
    `${C.red}██║ ╚████║╚██████╔╝███████╗███████╗███████╗${C.reset}\n` +
    `${C.red}╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚══════╝╚══════╝${C.reset}\n` +
    `\n${C.red}╭────── ✦ TOAA ✦ ──────╮${C.reset}\n` +
             `${C.red}│ ❖ 𝗦𝗧𝗔𝗧𝗨𝗦   ⤑ 𝙰𝚌𝚝𝚒𝚟𝚎${C.reset}\n` +
             `${C.red}│ ❖ CREATOR  ⤑ swanky${C.reset}\n` +
             `${C.red}│    𝐑ᴇᴀᴅʏ 𝐅ᴏʀ 𝐏ᴀɪʀɪɴɢ.${C.reset}\n` +
             `${C.red}╰────────────────────────────╯${C.reset}\n\n`
  );
}

// ─── Graceful Shutdown ────────────────────────────────────────────────────────

process.once('SIGINT', () => {
  originalLog('\n  【 SHUTDOWN 】 Received SIGINT, stopping...');
  bot.stopPolling();
  process.exit(0);
});

process.once('SIGTERM', () => {
  originalLog('\n  【 SHUTDOWN 】 Received SIGTERM, stopping...');
  bot.stopPolling();
  process.exit(0);
});

start().catch(err => {
  originalLog('\n  【 FATAL 】' + err.message);
  originalLog(err.stack);
  process.exit(1);
});
