/*
═══════════════════════╗
〚  𝙱𝙾𝚃•   ₊ ⃝₊TOAA
〚  𝙳𝙴𝚅•   ₊ ⃝—͟͟͞͞swanky
〚  𝙵𝙸𝙻𝙴•  telegram.js — Telegram pairing bridge
┗━━━━━━━━━━━━━━━━━┛
*/

const fs          = require('fs');
const path        = require('path');
const TelegramBot = require('node-telegram-bot-api');

const settings = require('./settings');
const {
  deleteSessionSettings, isPremium, addPremium, delPremium, listPremium
} = require('./helper/function');
const { formatUptime } = require('./helper/utils');

const DB_DIR        = path.join(__dirname, 'database');
const REPORTS_FILE  = path.join(DB_DIR, 'reports.json');
const VERIFIED_FILE = path.join(DB_DIR, 'verified.json');

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

const TOKEN             = settings.TELEGRAM_TOKEN;
const OWNER_ID           = parseInt(settings.OWNER_ID, 10);
const CHANNEL            = settings.TG_CHANNEL || 'swankysaltar';
const TG_LINK            = settings.TG_LINK || `https://t.me/${CHANNEL}`;
const GROUP              = settings.TG_GROUP || '';
const TG_GROUP_LINK      = settings.TG_GROUP_LINK || TG_LINK;
const WA_CHANNEL_LINK    = settings.WA_CHANNEL_LINK   || '';
const WA_CHANNEL_INVITE  = settings.WA_CHANNEL_INVITE || '';
const REPORT_CHAT        = settings.REPORT_CHAT || settings.OWNER_ID;

if (!TOKEN) { console.error('[FATAL] TELEGRAM_TOKEN is not set in settings.js'); process.exit(1); }

const bot = new TelegramBot(TOKEN, { polling: true });

// ─── Verified Users System (Persistent) ──────────────────────────────────────

function loadVerifiedUsers() {
  try {
    if (fs.existsSync(VERIFIED_FILE)) return new Set(JSON.parse(fs.readFileSync(VERIFIED_FILE, 'utf-8')));
  } catch {}
  return new Set();
}
function saveVerifiedUsers(set) {
  try { fs.writeFileSync(VERIFIED_FILE, JSON.stringify([...set])); } catch (e) { console.error('[VERIFIED] Failed to save:', e); }
}
function isUserVerified(userId) {
  if (userId === OWNER_ID) return true;
  if (settings.PREMIUM_USERS?.includes(String(userId))) return true;
  return loadVerifiedUsers().has(String(userId));
}
function verifyUser(userId) {
  const verified = loadVerifiedUsers();
  if (!verified.has(String(userId))) { verified.add(String(userId)); saveVerifiedUsers(verified); return true; }
  return false;
}
function unverifyUser(userId) {
  const verified = loadVerifiedUsers();
  if (verified.has(String(userId))) { verified.delete(String(userId)); saveVerifiedUsers(verified); return true; }
  return false;
}

// ─── Privilege helpers ────────────────────────────────────────────────────────

function isOwner(userId) { return userId === OWNER_ID; }
function isPrivileged(userId) {
  return isOwner(userId) || settings.PREMIUM_USERS?.includes(String(userId)) || isPremium(String(userId));
}

// ─── Active Message Tracker (the one hanging layout per user) ───────────────

const activeMsg  = new Map(); // userId -> layout message id (start/pair/etc.)
const lastPlain   = new Map(); // userId -> last plain-reply message id (usage errors, etc.)

function trackMsg(userId, messageId) { activeMsg.set(String(userId), messageId); }
function getTrackedMsg(userId) { return activeMsg.get(String(userId)); }

async function deleteMsg(chatId, messageId) {
  if (!messageId) return;
  try { await bot.deleteMessage(chatId, messageId); } catch {}
}

async function plainReply(chatId, text) {
  const userKey = String(chatId);
  const prev = lastPlain.get(userKey);
  if (prev) await deleteMsg(chatId, prev);

  const sent = await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' }).catch(() => null);
  if (sent) lastPlain.set(userKey, sent.message_id);
  return sent;
}

async function renderLayout(chatId, userId, { text, photo, keyboard, parseMode = 'Markdown' }) {
  const tracked = getTrackedMsg(userId);

  if (tracked) {
    try {
      if (photo) {
        // Photo messages can't have their photo swapped via editMessageText;
        // only the caption/markup can change in place.
        await bot.editMessageCaption(text, {
          chat_id: chatId, message_id: tracked, parse_mode: parseMode, reply_markup: keyboard
        });
      } else {
        await bot.editMessageText(text, {
          chat_id: chatId, message_id: tracked, parse_mode: parseMode, reply_markup: keyboard
        });
      }
      return tracked;
    } catch {
     
    }
  }

  let sent;
  try {
    if (photo) {
      sent = await bot.sendPhoto(chatId, photo, { caption: text, parse_mode: parseMode, reply_markup: keyboard });
    } else {
      sent = await bot.sendMessage(chatId, text, { parse_mode: parseMode, reply_markup: keyboard });
    }
  } catch (photoErr) {
    console.error('[renderLayout] Photo/primary send failed, retrying as plain text:', photoErr?.message);
    try {
      sent = await bot.sendMessage(chatId, text, { parse_mode: parseMode, reply_markup: keyboard });
    } catch (textErr) {
      console.error('[renderLayout] Plain text fallback also failed:', textErr?.message);
      throw textErr;
    }
  }
  trackMsg(userId, sent.message_id);
  return sent.message_id;
}

// ─── FORCE-JOIN CHECK WITH VERIFICATION ──────────────────────────────────────

function joinKeyboard() {
  return {
    inline_keyboard: [
      [{ text: 'Cʜᴀɴɴᴇʟ', url: TG_LINK, style: 'primary' }],
      [{ text: 'Gʀᴏᴜᴘ', url: TG_GROUP_LINK, style: 'primary' }],
      [{ text: '𝗔𝗨𝗧𝗛𝗢𝗥𝗜𝗭𝗘', callback_data: 'verify_join', style: 'success' }]
    ]
  };
}

async function checkMembership(usernameOrId, userId, botInfo) {
  const chatRef = usernameOrId.startsWith('@') ? usernameOrId : `@${usernameOrId}`;
  const admins     = await bot.getChatAdministrators(chatRef);
  const isBotAdmin = admins.some(a => a.user.id === botInfo.id);

  if (!isBotAdmin) {
    return { ok: true, botAdmin: false, chatRef };
  }

  const member   = await bot.getChatMember(chatRef, userId);
  const isMember = ['member', 'administrator', 'creator'].includes(member.status);
  return { ok: isMember, botAdmin: true, chatRef };
}

async function checkForceJoin(userId, chatId, msg) {
  if (isUserVerified(userId)) return true;
  if (isPrivileged(userId))   { verifyUser(userId); return true; }

  if (!settings.TG_CHANNEL || settings.TG_CHANNEL === '') {
    verifyUser(userId);
    return true;
  }

  try {
    const botInfo = await bot.getMe();

    const channelCheck = await checkMembership(CHANNEL, userId, botInfo);
    if (!channelCheck.botAdmin) {
      console.log(`[WARNING] Bot is NOT admin in ${channelCheck.chatRef} — bypassing that check`);
      await bot.sendMessage(OWNER_ID,
        `⚠️ *BOT NOT ADMIN IN CHANNEL*\n\nAdd @${botInfo.username} as admin in ${channelCheck.chatRef} for force-join to work.\n\nCurrently bypassing that check.`,
        { parse_mode: 'Markdown' }
      ).catch(() => {});
    }

    let groupCheck = { ok: true, botAdmin: false };
    if (GROUP) {
      groupCheck = await checkMembership(GROUP, userId, botInfo);
      if (!groupCheck.botAdmin) {
        console.log(`[WARNING] Bot is NOT admin in ${groupCheck.chatRef} — bypassing that check`);
        await bot.sendMessage(OWNER_ID,
          `⚠️ *BOT NOT ADMIN IN GROUP*\n\nAdd @${botInfo.username} as admin in ${groupCheck.chatRef} for force-join to work.\n\nCurrently bypassing that check.`,
          { parse_mode: 'Markdown' }
        ).catch(() => {});
      }
    }

    if (channelCheck.ok && groupCheck.ok) {
      verifyUser(userId);
      return true;
    }

    const firstName = msg?.from?.first_name || 'User';
    await renderScreen(chatId, userId, gateScreen(firstName, !channelCheck.ok, !groupCheck.ok));
    return false;

  } catch (err) {
    console.error(`[FORCE-JOIN] Error checking user ${userId}:`, err?.message);
    await plainReply(chatId,
      `⚠️ *VERIFICATION ERROR*\n\nUnable to verify membership.\n\nPlease join our channel and group first:\n${TG_LINK}\n${TG_GROUP_LINK}\n\nIf you already joined, contact @${settings.OWNER_HANDLE || 'swanky_is_TOAA'}`
    );
    return false;
  }
}

async function withForceJoin(msg, handler) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!(await checkForceJoin(userId, chatId, msg))) return;
  await handler();
}

// ─── RICH MESSAGE ENGINE ──────────────────────────────────────────────────────
// Every screen is a list of blocks. The same blocks render two ways:
//   1) Rich Message HTML  (h1, details, table, tg-button-row ...)
//   2) Classic HTML       (fallback so the bot never breaks)
// Uses Bot API 10.1+ sendRichMessage / editMessageText(rich_message). Set RICH_ENABLED: false in settings.js to force classic.

const RICH_ENABLED = settings.RICH_ENABLED !== false;

// ── Premium emoji ──
// Add more ids in settings.js:  PREMIUM_EMOJI: { crown: '1234567890', ... }
const EMOJI_IDS = Object.assign({ ok: '6217739736837000786' }, settings.PREMIUM_EMOJI || {});
const EMOJI_FB = {
  ok: '✅', crown: '👑', wave: '👋', point: '👇', gear: '⚙️', link: '🔗', phone: '📱',
  bolt: '⚡', user: '👤', lock: '🔒', book: '📖', warn: '⚠️', bot: '🤖', spark: '✨',
  back: '⬅️', dev: '🧑‍💻', chan: '📢', group: '👥', del: '🗑️', ping: '🏓', list: '📋', gate: '🔐'
};
function fb(name) { return EMOJI_FB[name] || '•'; }
function em(name) {
  const id = EMOJI_IDS[name];
  return id ? `<tg-emoji emoji-id="${id}">${fb(name)}</tg-emoji>` : fb(name);
}

// ── Block builders ──
const H   = (x, l = 1) => ({ t: 'h', l, x });
const P   = (x)        => ({ t: 'p', x });
const HR  = ()         => ({ t: 'hr' });
const TBL = (rows)     => ({ t: 'table', rows });
const DET = (s, b)     => ({ t: 'det', s, b });
const BTN = (...rows)  => ({ t: 'btn', rows });
const IMG = (src)      => ({ t: 'img', src });
const urlBtn = (text, u, style = 'primary') => ({ text, url: u, style });
const cbBtn  = (text, d, style = 'primary') => ({ text, cb: d,  style });
const cpBtn  = (text, value, style = 'primary') => ({ text, copy: String(value), style });

function escAttr(t) { return String(t ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;'); }
function stripTags(t) { return String(t ?? '').replace(/<[^>]+>/g, ''); }

// ── Renderer 1: Rich Message HTML ──
function renderRich(blocks) {
  return blocks.map(b => {
    switch (b.t) {
      case 'h':     return `<h${b.l}>${b.x}</h${b.l}>`;
      case 'p':     return `<p>${b.x}</p>`;
      case 'hr':    return `<hr>`;
      case 'img':   return `<img src="${escAttr(b.src)}"/>`;
      case 'table': return `<table bordered striped>${b.rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</table>`;
      case 'det':   return `<details><summary>${b.s}</summary>${renderRich(b.b)}</details>`;
      case 'btn':   return b.rows.map(r => r.filter(x => !x.copy)).filter(r => r.length).map(row => {
        const w = Math.floor(100 / row.length) + '%';
        const items = row.map(x => x.url
          ? `<tg-button width="${w}" type="url" url="${escAttr(x.url)}" style="${x.style}">${x.text}</tg-button>`
          : `<tg-button width="${w}" type="callback_data" data="${escAttr(x.cb)}" style="${x.style}">${x.text}</tg-button>`
        ).join('');
        return `<tg-button-row align="center">${items}</tg-button-row>`;
      }).join('\n');
      default: return '';
    }
  }).join('\n');
}

// ── Renderer 2: Classic HTML (fallback) ──
function classicText(blocks) {
  return blocks.filter(b => b.t !== 'btn').map(b => {
    switch (b.t) {
      case 'h':     return `<b>${b.x}</b>\n`;
      case 'p':     return `${b.x}\n`;
      case 'hr':    return `━━━━━━━━━━━━━━━━━━`;
      case 'table': {
        const rows  = b.rows.map(r => r.map(stripTags));
        const width = Math.max(...rows.map(r => (r[0] || '').length));
        return `<pre>${rows.map(r => r[0].padEnd(width + 2) + (r[1] ?? '')).join('\n')}</pre>`;
      }
      case 'det':   return `<blockquote expandable><b>${b.s}</b>\n${classicText(b.b)}</blockquote>`;
      default:      return '';
    }
  }).join('\n');
}
function classicKeyboard(blocks) {
  const rows = [];
  for (const b of blocks.filter(x => x.t === 'btn'))
    for (const row of b.rows)
      rows.push(row.map(x => x.copy ? { text: stripTags(x.text), copy_text: { text: x.copy }, style: x.style }
                      : x.url  ? { text: stripTags(x.text), url: x.url, style: x.style }
                               : { text: stripTags(x.text), callback_data: x.cb, style: x.style }));
  return { inline_keyboard: rows };
}

// ── Transport (Bot API 10.1+) ──
const richPayload = (blocks) => JSON.stringify({ html: renderRich(blocks) });
// Copy-to-clipboard buttons ride along as a normal inline keyboard under the rich message
function copyMarkup(blocks) {
  const rows = [];
  for (const b of blocks.filter(x => x.t === 'btn'))
    for (const row of b.rows)
      if (row.length && row.every(x => x.copy))
        rows.push(row.map(x => ({ text: stripTags(x.text), copy_text: { text: x.copy }, style: x.style })));
  return rows.length ? JSON.stringify({ inline_keyboard: rows }) : undefined;
}

async function sendScreen(chatId, blocks) {
  if (RICH_ENABLED) {
    try {
      const form = { chat_id: chatId, rich_message: richPayload(blocks) };
      const mk = copyMarkup(blocks); if (mk) form.reply_markup = mk;
      return await bot._request('sendRichMessage', { form });
    } catch (e) { console.error('[RICH] sendRichMessage failed, using classic fallback:', e?.message); }
  }
  return bot.sendMessage(chatId, classicText(blocks), {
    parse_mode: 'HTML', reply_markup: classicKeyboard(blocks), disable_web_page_preview: true
  });
}
async function editScreen(chatId, messageId, blocks) {
  if (RICH_ENABLED) {
    try {
      const form = { chat_id: chatId, message_id: messageId, rich_message: richPayload(blocks) };
      const mk = copyMarkup(blocks); if (mk) form.reply_markup = mk;
      await bot._request('editMessageText', { form });
      return;
    } catch (e) {
      if (/not modified/i.test(e?.message || '')) return;
      console.error('[RICH] edit failed, using classic fallback:', e?.message);
    }
  }
  await bot.editMessageText(classicText(blocks), {
    chat_id: chatId, message_id: messageId, parse_mode: 'HTML',
    reply_markup: classicKeyboard(blocks), disable_web_page_preview: true
  });
}

// editId given  -> edit that message in place (menu navigation)
// editId absent -> delete the old layout and send a fresh one
async function renderScreen(chatId, userId, blocks, { editId } = {}) {
  if (editId) {
    try { await editScreen(chatId, editId, blocks); trackMsg(userId, editId); return editId; }
    catch (e) { if (/not modified/i.test(e?.message || '')) return editId; }
    await deleteMsg(chatId, editId);
  }
  const tracked = getTrackedMsg(userId);
  if (tracked && tracked !== editId) await deleteMsg(chatId, tracked);
  const sent = await sendScreen(chatId, blocks);
  const id = sent?.message_id;
  if (id) trackMsg(userId, id);
  return id;
}

// ─── SCREENS ──────────────────────────────────────────────────────────────────

function escHtml(t) {
  return String(t ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function ownerUrl() {
  return `https://t.me/${(settings.OWNER_HANDLE || 'swanky_is_TOAA').replace(/^t\.me\//, '').replace(/^@/, '')}`;
}
function slotBar(userId) {
  let used = 0, max = 3;
  try {
    const sess = require('./sessions');
    used = sess.getPairedByTgId(userId).length;
    max  = sess.MAX_SESSIONS_PER_USER || 3;
  } catch {}
  used = Math.min(used, max);
  return '▰'.repeat(used) + '▱'.repeat(max - used) + `  ${used}/${max}`;
}
const backRow = () => [cbBtn(`${fb('back')} Back to Menu`, 'm_home', 'primary')];

function homeScreen({ firstName, userId, username }) {
  const who   = username ? '@' + escHtml(username) : escHtml(firstName);
  const owner = escHtml(settings.OWNER_NAME || 'swanky');
  const bn    = escHtml(settings.BOT_NAME   || 'TOAA');

  const menuRows = [
    [cbBtn(`${fb('phone')} Pair Device`, 'm_pair', 'primary'), cbBtn(`${fb('list')} My Sessions`, 'm_sessions', 'primary')],
    [cbBtn(`${fb('gear')} How it works`, 'm_how', 'success')],
    [cbBtn(`${fb('user')} User Menu`, 'm_user', 'danger')]
  ];
  if (isPrivileged(userId)) menuRows[2].push(cbBtn(`${fb('crown')} Owner Menu`, 'm_owner', 'danger'));

  const img = settings.TG_MENU_IMAGE;
  return [
    BTN([urlBtn(`${fb('dev')} Contact Developer`, ownerUrl(), 'primary')]),
    H(`${em('crown')} ${bn} Pairing Center`, 1),
    ...((img && img !== 'https://img.jpg') ? [IMG(img)] : []),
    P(`Welcome, <b>${who}</b>! ${em('wave')}`),
    P(`I link your WhatsApp number to the bot in seconds. Choose an option below to get started ${em('point')}`),
    HR(),
    DET(`${em('bot')} BOT INFORMATION`, [TBL([
      ['Creator', owner],
      ['Status',  'Active'],
      ['User',    who],
      ['ID',      `<code>${escHtml(userId)}</code>`],
      ['Slots',   `<code>${slotBar(userId)}</code>`],
      ['Uptime',  `<code>${escHtml(formatUptime(process.uptime() * 1000))}</code>`]
    ])]),
    BTN(...menuRows),
    BTN([urlBtn(`${fb('chan')} Channel`, TG_LINK, 'success'), urlBtn(`${fb('group')} Group`, TG_GROUP_LINK, 'success')]),
    P(`<i>Made by ${owner}</i>`)
  ];
}

function pairScreen() {
  return [
    H(`${em('phone')} Pair Device`, 2),
    HR(),
    P(`Send this command in the chat:`),
    P(`<code>/pair 2348012345678</code>`),
    P(`Use the country code and no <b>+</b>. I'll reply with a code to enter in WhatsApp under <b>Linked Devices → Link with phone number</b>.`),
    BTN([cbBtn(`${fb('list')} My Sessions`, 'm_sessions', 'success')], backRow())
  ];
}

function sessionsScreen(userId) {
  let list = [], max = 3;
  try {
    const sess = require('./sessions');
    list = sess.getPairedByTgId(userId);
    max  = sess.MAX_SESSIONS_PER_USER || 3;
  } catch {}
  const body = list.length
    ? [TBL(list.map((s, i) => [`#${i + 1}`, `<code>+${escHtml(s.waNumber)}</code>`])),
       P(`Remove one with <code>/delpair &lt;number&gt;</code>`)]
    : [P(`You have no linked numbers yet.`)];
  return [
    H(`${em('list')} My Sessions`, 2),
    HR(),
    P(`Slots used: <code>${list.length}/${max}</code>`),
    ...body,
    BTN(backRow())
  ];
}

function howScreen() {
  return [
    H(`${em('gear')} How it works`, 2),
    HR(),
    DET(`1. Send your number`, [P(`Use <code>/pair &lt;number&gt;</code> with the country code and no +.`)]),
    DET(`2. Get your code`,   [P(`I generate an 8-character pairing code for that number.`)]),
    DET(`3. Link in WhatsApp`, [P(`Open <b>Linked Devices → Link with phone number</b> and enter the code.`)]),
    DET(`4. Manage sessions`, [P(`<code>/delpair</code> removes a session, <code>/ping</code> checks I'm alive.`)]),
    BTN(backRow())
  ];
}

function userScreen() {
  return [
    H(`${em('user')} User Menu`, 2),
    HR(),
    TBL([
      ['/pair &lt;number&gt;',    'Link a WhatsApp number'],
      ['/delpair &lt;number&gt;', 'Unlink a session'],
      ['/ping',                   'Check the bot is alive'],
      ['/health',                 'Bot health stats'],
      ['/report &lt;text&gt;',    'Send a report to the owner']
    ]),
    BTN(backRow())
  ];
}

function ownerScreen() {
  return [
    H(`${em('crown')} Owner / Premium Menu`, 2),
    HR(),
    TBL([
      ['/addprem &lt;number&gt;',    'Add premium'],
      ['/delprem &lt;number&gt;',    'Remove premium'],
      ['/listprem',                  'List premium users'],
      ['/listpaired',                'All paired sessions'],
      ['/sessions',                  'Session count'],
      ['/reports',                   'Recent reports'],
      ['/kicksession &lt;name&gt;',  'Stop a session'],
      ['/verifyuser &lt;id&gt;',     'Verify a user'],
      ['/unverifyuser &lt;id&gt;',   'Unverify a user'],
      ['/ban &lt;id&gt;',            'Ban + wipe sessions']
    ]),
    BTN(backRow())
  ];
}

function gateScreen(firstName, needChannel, needGroup) {
  const rows = [];
  if (needChannel) rows.push(urlBtn('Channel', TG_LINK, 'primary'));
  if (needGroup)   rows.push(urlBtn('Group', TG_GROUP_LINK, 'primary'));
  return [
    H(`${em('gate')} TOAA Pairing Gate`, 1),
    HR(),
    P(`Welcome, <b>${escHtml(firstName)}</b>! ${em('wave')}`),
    P(`Join our ${[needChannel && 'channel', needGroup && 'group'].filter(Boolean).join(' and ')} to use this bot, then tap <b>Authorize</b>.`),
    BTN(rows, [cbBtn(`${fb('ok')} Authorize`, 'verify_join', 'success')])
  ];
}

function generatedScreen(number, code) {
  return [
    H(`${em('ok')} Pairing Code Generated`, 2),
    HR(),
    P(`Number: <code>+${escHtml(number)}</code>`),
    P(`Your code (tap it to copy):`),
    P(`<code>${escHtml(code)}</code>`),
    P(`Open WhatsApp → <b>Linked Devices</b> → <b>Link with phone number</b> and enter the code.`),
    BTN([cpBtn(`${fb('list')} Copy Code`, code, 'success')],
        [cbBtn(`${fb('list')} My Sessions`, 'm_sessions', 'primary'), cbBtn(`${fb('back')} Menu`, 'm_home', 'primary')])
  ];
}

// ─── Public layout helpers (names kept for the rest of the project) ───────────

function startKeyboard() { return classicKeyboard(homeScreen({ firstName: 'there', userId: 0 })); }
function startText(firstName, userId, username) { return classicText(homeScreen({ firstName, userId, username })); }

async function sendStartLayout(chatId, userId, msg) {
  await renderScreen(chatId, userId, homeScreen({
    firstName: msg?.from?.first_name || 'there',
    userId,
    username:  msg?.from?.username
  }));
}

// Kept for any other file that still imports the old text version
function generatedCodeText(number, code) {
  return (
    `╔═════───◯───════╗\n` +
    `┃─── *[⎝ 𝙶𝙴𝙽𝙴𝚁𝙰𝚃𝙴𝙳 ⎠]*\n` +
    `┃\n` +
    `┃⤑ *𝙽𝚄𝙼𝙱𝙴𝚁:* \`+${number}\`\n` +
    `┃⤑ *𝙲𝙾𝙳𝙴:* \`${code}\`\n` +
    `┃\n` +
    `┃[⎝ ʟɪɴᴋ ᴅᴇᴠɪᴄᴇ ᴡɪᴛʜ ᴄᴏᴅᴇ ⎠]\n` +
    `╚═════───◯───════╝`
  );
}
async function renderGeneratedCode(chatId, userId, number, code) {
  return renderScreen(chatId, userId, generatedScreen(number, code));
}

// ─── Callback Query Handler ───────────────────────────────────────────────────

bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const msgId  = query.message.message_id;
  const data   = query.data || '';

  if (data === 'verify_join') {
    if (isUserVerified(userId)) {
      await bot.answerCallbackQuery(query.id, { text: '√ ᴀʟʀᴇᴀᴅʏ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ!', show_alert: false });
      await deleteMsg(chatId, msgId);
      activeMsg.delete(String(userId));
      await sendStartLayout(chatId, userId, query);
      return;
    }

    try {
      const botInfo = await bot.getMe();

      const channelCheck = await checkMembership(CHANNEL, userId, botInfo);
      if (!channelCheck.botAdmin) {
        return bot.answerCallbackQuery(query.id, { text: '⚠️ Bot is not admin in channel. Contact owner.', show_alert: true });
      }

      let groupCheck = { ok: true, botAdmin: false };
      if (GROUP) {
        groupCheck = await checkMembership(GROUP, userId, botInfo);
        if (!groupCheck.botAdmin) {
          return bot.answerCallbackQuery(query.id, { text: '⚠️ Bot is not admin in group. Contact owner.', show_alert: true });
        }
      }

      if (channelCheck.ok && groupCheck.ok) {
        verifyUser(userId);
        await bot.answerCallbackQuery(query.id, { text: '✅ VERIFIED! Welcome to TOAA.', show_alert: true });
        await deleteMsg(chatId, msgId);
        activeMsg.delete(String(userId));
        await sendStartLayout(chatId, userId, query);
      } else {
        const missing = [];
        if (!channelCheck.ok) missing.push('the channel');
        if (!groupCheck.ok)   missing.push('the group');
        await bot.answerCallbackQuery(query.id, { text: `❌ You still need to join ${missing.join(' and ')}!`, show_alert: true });
      }
    } catch (err) {
      console.error('[VERIFY] Error:', err);
      await bot.answerCallbackQuery(query.id, { text: '❌ Verification failed. Make sure bot is admin in channel/group.', show_alert: true });
    }
    return;
  }

  // Everything past this point requires verification.
  await bot.answerCallbackQuery(query.id);
  if (!(await checkForceJoin(userId, chatId, query))) return;

  const ctx = { firstName: query.from.first_name || 'there', userId, username: query.from.username };
  const screens = {
    m_home:     () => homeScreen(ctx),
    m_pair:     () => pairScreen(),
    m_sessions: () => sessionsScreen(userId),
    m_how:      () => howScreen(),
    m_user:     () => userScreen(),
    m_owner:    () => isPrivileged(userId) ? ownerScreen() : null
  };
  const blocks = screens[data]?.();
  if (blocks) await renderScreen(chatId, userId, blocks, { editId: msgId });
});

// ─── REPORTS HELPERS ─────────────────────────────────

function loadReports() {
  try { if (fs.existsSync(REPORTS_FILE)) return JSON.parse(fs.readFileSync(REPORTS_FILE, 'utf-8')); } catch {}
  return [];
}
function saveReports(data) { fs.writeFileSync(REPORTS_FILE, JSON.stringify(data, null, 2)); }
function addReport(telegramId, username, text) {
  const reports = loadReports();
  reports.push({ id: telegramId, username, text, at: new Date().toISOString() });
  saveReports(reports);
}

// ─── TELEGRAM COMMANDS ───────────────────────────────────────

// ─── /start ───────────────────────────────────────────────────────────────────
bot.onText(/^\/start$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  await deleteMsg(chatId, msg.message_id);

  try {
    if (!(await checkForceJoin(userId, chatId, msg))) return;
    await sendStartLayout(chatId, userId, msg);
  } catch (err) {
    console.error('[START] Failed to show start layout:', err?.message);
    await plainReply(chatId, '⚠️ Something went wrong loading the menu. Please try /start again.');
  }
});

// ─── /pair ───────────────────────────
bot.onText(/^\/pair(?:\s+(\d+))?$/, async (msg, match) => {
  const {
    getPairedByTgId, registerPaired, getTotalActiveSessions,
    startWASession, MAX_SESSIONS_PER_USER, MAX_TOTAL_SESSIONS
  } = require('./sessions');

  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);

  await withForceJoin(msg, async () => {
    const number = match?.[1]?.trim();

    if (!number) {
      return plainReply(chatId, '❌ *Usage:* `/pair <whatsapp_number>`\n*Example:* `/pair 2347047129088`');
    }

    const cleanNumber = number.replace(/[^0-9]/g, '');
    if (cleanNumber.length < 10) {
      return plainReply(chatId, '❌ *Invalid number.* Please include country code.\nExample: `2347047129088`');
    }

    const existing = getPairedByTgId(userId);
    if (existing.length >= MAX_SESSIONS_PER_USER) {
      const list = existing.map((s, i) => `${i + 1}. \`+${s.waNumber}\``).join('\n');
      return plainReply(chatId,
        `⚠️ *Your session limit reached (${MAX_SESSIONS_PER_USER}/3).*\n\n` +
        `Your active numbers:\n${list}\n\n` +
        `Use /delpair \`<number>\` to remove one first.`
      );
    }

    const totalSessions = getTotalActiveSessions();
    if (totalSessions >= MAX_TOTAL_SESSIONS) {
      return plainReply(chatId,
        `🀄 *Pairing Declined*\n\n` +
        `*Reason:* Pairing limits maxed (${totalSessions}/${MAX_TOTAL_SESSIONS})\n\n` +
        `The bot has reached its maximum active session limit.\n\n` +
        `Please try again later or contact the owner.`
      );
    }

    const sessionName = `session_${userId}_${Date.now()}`;

    await renderLayout(chatId, userId, {
      text: `⏳ *Generating pairing code for* \`+${cleanNumber}\`*...*\n\n_This may take a few seconds._`,
      keyboard: null
    });

    registerPaired(userId, cleanNumber, sessionName);
    await startWASession(sessionName, chatId, cleanNumber);
  });
});

// ─── /delpair ─────────────────────────────────────────────────────────────────
bot.onText(/^\/delpair(?:\s+(\d+))?$/, async (msg, match) => {
  const {
    getPairedByTgId, unregisterPairedSession, stopSession, clearSessionCache, SESSIONS_DIR
  } = require('./sessions');

  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);

  await withForceJoin(msg, async () => {
    const inputNumber = match?.[1]?.trim();

    const sessions = getPairedByTgId(userId);
    if (!sessions.length) {
      return plainReply(chatId, '❌ *You have no active sessions.*');
    }

    async function removeSession(sessionName, waNumber) {
      await stopSession(sessionName);
      try { fs.rmSync(path.join(SESSIONS_DIR, sessionName), { recursive: true, force: true }); } catch {}
      deleteSessionSettings(sessionName);
      unregisterPairedSession(userId, sessionName);
      clearSessionCache(sessionName);
      await renderLayout(chatId, userId, {
        text: `✅ *Session removed.*\n\n📱 Number: \`+${waNumber}\``,
        keyboard: null
      });
    }

    if (sessions.length === 1 && !inputNumber) {
      return removeSession(sessions[0].sessionName, sessions[0].waNumber);
    }

    if (inputNumber) {
      const clean  = inputNumber.replace(/[^0-9]/g, '');
      const target = sessions.find(s => s.waNumber === clean);
      if (!target) {
        const list = sessions.map((s, i) => `${i + 1}. \`+${s.waNumber}\``).join('\n');
        return plainReply(chatId, `❌ *Number not found.*\n\nYour sessions:\n${list}`);
      }
      return removeSession(target.sessionName, target.waNumber);
    }

    const list = sessions.map((s, i) => `${i + 1}. \`+${s.waNumber}\``).join('\n');
    return plainReply(chatId,
      `📋 *Your active sessions:*\n\n${list}\n\nUse /delpair \`<number>\` to remove one.\nExample: \`/delpair ${sessions[0].waNumber}\``
    );
  });
});

// ─── /ping ────────────────────────────────────────────────────────────────────
bot.onText(/^\/ping$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);

  await withForceJoin(msg, async () => {
    const start = Date.now();
    const ms = Date.now() - start;
    await plainReply(chatId, `🏓 *Pong!* \`${ms}ms\``);
  });
});

// ─── /listpaired (owner/premium only) ─────────────────────────────────────────
bot.onText(/^\/listpaired$/, async (msg) => {
  const { getAllPaired, activeSessions } = require('./sessions');
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);

  if (!isPrivileged(userId)) return plainReply(chatId, '🔰 Owner / Premium only.');

  const all  = getAllPaired();
  const keys = Object.keys(all);
  if (!keys.length) return plainReply(chatId, '📋 *No active sessions.*');

  let totalSessions = 0;
  for (const tgId of keys) {
    const val = all[tgId];
    totalSessions += Array.isArray(val) ? val.length : 1;
  }

  let text = `📋 *𝗦𝗘𝗦𝗦𝗜𝗢𝗡𝗦 (${totalSessions}/${settings.MAX_SESSIONS || 30})*\n\n`;
  for (const tgId of keys) {
    const val      = all[tgId];
    const sessions = Array.isArray(val) ? val : [val];
    text += `✰𝚃𝙶: \`${tgId}\` (${sessions.length}/2)\n`;
    for (const { waNumber, sessionName, pairedAt } of sessions) {
      const isAlive = activeSessions.has(sessionName);
      const date    = new Date(pairedAt).toLocaleString();
      text += `  ✰ \`+${waNumber}\` ${isAlive ? '🧩' : '🎴'} — ${date}\n`;
    }
    text += '\n';
  }

  await plainReply(chatId, text);
});

// ─── /sessions (owner only) - Check current session count ────────────────────
bot.onText(/^\/sessions$/, async (msg) => {
  const { getTotalActiveSessions, MAX_TOTAL_SESSIONS } = require('./sessions');
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isOwner(userId)) return plainReply(chatId, '❌ *Owner only.*');

  const totalSessions = getTotalActiveSessions();
  const remaining = MAX_TOTAL_SESSIONS - totalSessions;

  await plainReply(chatId,
    `📊 *Session Statistics*\n\n` +
    `┌─────────────────┐\n` +
    `│ 📱 *Active:* ${totalSessions}/${MAX_TOTAL_SESSIONS}\n` +
    `│ ✅ *Remaining:* ${remaining}\n` +
    `└─────────────────┘\n\n` +
    `Use /listpaired to see all sessions.`
  );
});

// ─── /health ──────────────────────────────────────────────────────────────────
bot.onText(/^\/health$/, async (msg) => {
  const { activeSessions, activeWorkers, QUEUE_CONCURRENCY, messageQueue } = require('./sessions');
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);

  await withForceJoin(msg, async () => {
    const uptime   = formatUptime(Date.now() - global.botStartTime);
    const mem      = process.memoryUsage();
    const ramUsed  = (mem.heapUsed  / 1024 / 1024).toFixed(2);
    const ramTotal = (mem.heapTotal / 1024 / 1024).toFixed(2);
    const verified = loadVerifiedUsers().size;

    await plainReply(chatId,
      `❤️ *TOAA HEALTH* ❤️\n\n` +
      `⏱ Uptime: ${uptime}\n` +
      `💾 RAM: ${ramUsed}/${ramTotal} MB\n` +
      `📡 Sessions: ${activeSessions.size}/${settings.MAX_SESSIONS || 30}\n` +
      `✅ Verified Users: ${verified}\n` +
      `⚙️ Workers: ${activeWorkers.count}/${QUEUE_CONCURRENCY}\n` +
      `📨 Queued msgs: ${messageQueue.length}\n` +
      `✅ Status: Online`
    );
  });
});

// ─── /report ──────────────────────────────────────────────────────────────────
bot.onText(/^\/report(?:\s+(.+))?$/s, async (msg, match) => {
  const chatId   = msg.chat.id;
  const userId   = msg.from.id;
  const username = msg.from.username || msg.from.first_name || String(userId);
  const text     = match?.[1]?.trim();
  await deleteMsg(chatId, msg.message_id);

  await withForceJoin(msg, async () => {
    if (!text) {
      return plainReply(chatId, '📣 Usage: `/report <message>`\nExample: `/report Command not working`');
    }

    addReport(userId, username, text);
    try { await bot.sendMessage(REPORT_CHAT, `📣 *NEW REPORT*\n👤 @${username} (\`${userId}\`)\n💬 ${text}`, { parse_mode: 'Markdown' }); } catch {}
    await plainReply(chatId, '✅ *Report sent to owner.*');
  });
});

// ─── Owner-only commands ───────────────────────────────────────────────────────
bot.onText(/^\/addprem(?:\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isOwner(userId)) return plainReply(chatId, '🔰 Owner only.');
  const number = match?.[1]?.trim();
  if (!number) return plainReply(chatId, 'Usage: `/addprem <number>`');
  const result = addPremium(number);
  await plainReply(chatId, result ? `✅ ${number} added to premium.` : `⚠️ ${number} is already premium.`);
});

bot.onText(/^\/delprem(?:\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isOwner(userId)) return plainReply(chatId, '🔰 Owner only.');
  const number = match?.[1]?.trim();
  if (!number) return plainReply(chatId, 'Usage: `/delprem <number>`');
  const result = delPremium(number);
  await plainReply(chatId, result ? `✅ ${number} removed from premium.` : `⚠️ ${number} was not premium.`);
});

bot.onText(/^\/listprem$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isPrivileged(userId)) return plainReply(chatId, '🔰 Owner / Premium only.');
  const list = listPremium();
  if (!list.length) return plainReply(chatId, '📋 No premium users.');
  await plainReply(chatId, `👑 *Premium Users:*\n\n${list.map((n, i) => `${i + 1}. \`${n}\``).join('\n')}`);
});

bot.onText(/^\/reports$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isOwner(userId)) return plainReply(chatId, '🔰 Owner only.');
  const reports = loadReports();
  if (!reports.length) return plainReply(chatId, '📋 No reports.');
  const last5 = reports.slice(-5).reverse();
  let text = `📣 *Recent Reports:*\n\n`;
  for (const r of last5) text += `👤 @${r.username}\n💬 ${r.text}\n🕐 ${new Date(r.at).toLocaleString()}\n\n`;
  await plainReply(chatId, text);
});

bot.onText(/^\/kicksession(?:\s+(.+))?$/, async (msg, match) => {
  const { stopSession } = require('./sessions');
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isOwner(userId)) return plainReply(chatId, '🔰 Owner only.');
  const sessionName = match?.[1]?.trim();
  if (!sessionName) return plainReply(chatId, 'Usage: `/kicksession <session_name>`');
  const stopped = await stopSession(sessionName);
  await plainReply(chatId, stopped ? `✅ Session \`${sessionName}\` stopped.` : `⚠️ Session not found.`);
});

bot.onText(/^\/verifyuser(?:\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isOwner(userId)) return plainReply(chatId, '🔰 Owner only.');
  const targetId = match?.[1]?.trim();
  if (!targetId) return plainReply(chatId, 'Usage: `/verifyuser <telegram_user_id>`');
  await plainReply(chatId, verifyUser(parseInt(targetId)) ? `✅ User \`${targetId}\` verified.` : `⚠️ User \`${targetId}\` already verified.`);
});

bot.onText(/^\/unverifyuser(?:\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isOwner(userId)) return plainReply(chatId, '🔰 Owner only.');
  const targetId = match?.[1]?.trim();
  if (!targetId) return plainReply(chatId, 'Usage: `/unverifyuser <telegram_user_id>`');
  await plainReply(chatId, unverifyUser(parseInt(targetId)) ? `✅ User \`${targetId}\` unverified.` : `⚠️ User \`${targetId}\` was not verified.`);
});

bot.onText(/^\/ban(?:\s+(\d+))?$/, async (msg, match) => {
  const { getPairedByTgId, unregisterPairedSession, stopSession, clearSessionCache, SESSIONS_DIR } = require('./sessions');
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isOwner(userId)) return plainReply(chatId, '🔰 Owner only.');
  const targetId = match?.[1]?.trim();
  if (!targetId) return plainReply(chatId, 'Usage: `/ban <telegram_user_id>`');

  const sessions = getPairedByTgId(parseInt(targetId, 10));
  for (const s of sessions) {
    await stopSession(s.sessionName);
    try { fs.rmSync(path.join(SESSIONS_DIR, s.sessionName), { recursive: true, force: true }); } catch {}
    deleteSessionSettings(s.sessionName);
    unregisterPairedSession(parseInt(targetId, 10), s.sessionName);
    clearSessionCache(s.sessionName);
  }
  delPremium(targetId);
  unverifyUser(parseInt(targetId, 10));

  await plainReply(chatId, `👾 Banned \`${targetId}\` — removed *${sessions.length}* session(s).`);
});

// ─── /morecmds (owner / premium only) ──────────────────────────────────────────
bot.onText(/^\/morecmds$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  await deleteMsg(chatId, msg.message_id);
  if (!isPrivileged(userId)) return plainReply(chatId, '🔰 Owner / Premium only.');

  await plainReply(chatId,
    `┏━━━━━━━━━━━━━━━━━━━◯\n` +
    `┃───( 𝙊𝙬𝙣𝙚𝙧/𝙋𝙧𝙚𝙢 𝘾𝙢𝙙𝙨)\n` +
    `┃╭────◌\n` +
    `┃│/addprem <number>\n` +
    `┃│/delprem <number>\n` +
    `┃│/listprem\n` +
    `┃│/listpaired\n` +
    `┃│/sessions\n` +
    `┃│/reports\n` +
    `┃│/kicksession <name>\n` +
    `┃│/verifyuser <id>\n` +
    `┃│/unverifyuser <id>\n` +
    `┃│/ban <id>\n` +
    `┃╰────◌\n` +
    `┗━━━━━━━━━━━━━━━━━━━━◯`
  );
});

module.exports = {
  bot,
  OWNER_ID, CHANNEL, TG_LINK, TG_GROUP_LINK, WA_CHANNEL_LINK, WA_CHANNEL_INVITE,
  isUserVerified, verifyUser, unverifyUser, loadVerifiedUsers,
  checkForceJoin, withForceJoin,
  isOwner, isPrivileged,
  renderLayout, plainReply, trackMsg, getTrackedMsg, deleteMsg,
  startKeyboard, startText, sendStartLayout,
  generatedCodeText, renderGeneratedCode,
};
